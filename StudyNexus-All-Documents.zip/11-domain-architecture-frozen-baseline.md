# StudyNexus — Final Frozen Architectural Baseline
# Domain Architecture Correction, Freeze & Canonical Reference

**Date:** 2026-08-08
**Status:** FROZEN — Architectural Baseline
**Prerequisite:** Domain Architecture (18), Domain Architecture Validation & ADR Review (19)
**Architectural Philosophy:** Laravel Beyond CRUD (Brent Roose & Freek Van der Herten) — Pragmatic Domain-Driven Design
**Stack:** TALL (Laravel + Blade + Livewire + Flux + Tailwind CSS) + Filament (Admin)
**Verdict:** FROZEN WITH DOCUMENTED DEFERMENTS
**Objective:** Apply the four mandatory corrections from the adversarial validation, perform a final consistency review, and produce the canonical frozen architectural baseline that implementation will be built against.

---

## 1. Correction Application Record

This section documents the application of the four mandatory corrections (F1–F4) identified in the Domain Architecture Validation & ADR Review (19). Each correction is applied with explicit rationale, before-and-after state, and consistency verification.

### F1 — Namespace Inconsistency: RESOLVED

**Problem:** The Entity→Eloquent mapping table (Section 4 of the architecture) used `App\Models\Institution` while the directory structure (Section 26) used `App\Domain\Models\Institution`. Two competing namespaces for the same class.

**Decision:** `App\Domain\Models\*` is canonical. The mapping table was incorrect; the directory structure was correct.

**Rationale:** The `App\Domain\Models\` namespace serves the established Laravel Beyond CRUD architectural intent — keeping domain models together under `App\Domain\` so that anyone opening the codebase sees the domain model first and in one place. Using Laravel's default `App\Models\` would scatter domain concepts away from their sibling VOs, enums, events, and services. The cost is a one-line change in `config/app.php` to set the Models namespace — a trivial configuration cost for meaningful domain cohesion.

**Before:**
```
| Educational Institution | App\Models\Institution | institutions | ...
| Programme               | App\Models\Programme   | programmes  | ...
```

**After:**
```
| Educational Institution | App\Domain\Models\Institution | institutions | ...
| Programme               | App\Domain\Models\Programme   | programmes  | ...
```

**Consistency check:** The namespace `App\Domain\Models\` is now used consistently in:
- Entity→Eloquent mapping table (Section 4)
- Directory structure (Section 26)
- Code examples throughout the document
- ADR-10 (Namespace and Directory Structure)

**Impact on ADRs:** ADR-10 is updated to explicitly state `App\Domain\Models\` as the canonical model namespace and to note the `config/app.php` configuration requirement.

---

### F2 — Ceremonial DomainEvent Interface: RESOLVED (Removed)

**Problem:** The `DomainEvent` interface required every domain event to implement four methods (`eventType()`, `aggregateId()`, `aggregateType()`, `occurredAt()`) that provided no runtime value. No Laravel mechanism checks for the interface, no listener requires it, and no test depends on it. The interface was textbook DDD ceremony without pragmatic benefit.

**Decision:** Remove the `DomainEvent` interface entirely. Domain events are plain PHP classes that extend Laravel's base dispatching mechanism when needed.

**Rationale:** Laravel's event system dispatches any object — it does not require an interface. The four methods on the `DomainEvent` interface can all be derived from the event class itself (class name for type, constructor-set timestamp for occurredAt, payload properties for aggregate IDs). Adding a trait that provides these defaults would reduce boilerplate but still adds an abstraction that no consumer requires. The cleanest Laravel Beyond CRUD approach is: domain events are plain PHP classes with constructor-injected payload. Listeners type-hint the specific event class. If a generic handler that processes any domain event polymorphically is needed in the future, a trait or interface can be introduced then — driven by actual demand, not speculative ceremony.

**Before:**
```php
interface DomainEvent
{
    public function eventType(): string;
    public function aggregateId(): string;
    public function aggregateType(): string;
    public function occurredAt(): DateTimeImmutable;
}

class InstitutionEstablished implements DomainEvent { ... }
```

**After:**
```php
class InstitutionEstablished
{
    public function __construct(
        public readonly string $institutionId,
        public readonly string $name,
        public readonly string $type,
        public readonly DateTimeImmutable $occurredAt = new DateTimeImmutable(),
    ) {}
}
```

**Consistency check:**
- All 27 domain events are plain PHP classes with no shared interface.
- Each event carries the minimum payload needed by its listeners.
- Listeners type-hint the specific event class.
- No generic handler processes events polymorphically — none is needed.
- The `occurredAt` timestamp is set in the constructor as an immutable default.

**Impact on ADRs:** ADR-3 (Domain Event Implementation) is updated to record the explicit decision: domain events are plain PHP classes, no shared interface, no shared trait. The sub-decision "interface vs trait vs none" is resolved as "none."

---

### F3 — ReassignProgramme: RESOLVED (Removed from Actions)

**Problem:** `ReassignProgramme` was listed as an Application Action but had "No independent invocation" — it is only called by `InstitutionMerger` during the merge operation. By the architecture's own Action criterion, an Action must represent an application use case with an entry point (HTTP, console, queue, API). An operation with no independent invocation is not an Action.

**Decision:** Remove `ReassignProgramme` from the Action catalogue. `Programme::reassignTo(InstitutionId $newOwnerId)` is a domain method on the Programme model, invoked internally by `InstitutionMerger::merge()`.

**Rationale:** The question "Who owns the invariant and who is responsible for the business operation?" answers clearly: the `InstitutionMerger` domain service orchestrates the cross-aggregate merge operation. Within that transaction, it calls `Programme::reassignTo()` on each affected programme. The reassignment is a domain operation — it changes programme ownership while maintaining INV-P1 (every programme belongs to exactly one institution). But it is not an application use case — no user or external system invokes "reassign programme" independently. The Action pattern should not be applied to internal domain methods, or every meaningful method on every aggregate would become an Action, which contradicts Laravel Beyond CRUD's guidance that Actions represent orchestrated application use cases, not every domain method.

**Before:**
```
Actions/Programmes/ReassignProgramme.php  ← listed in Action inventory
```

**After:**
```
(Removed — Programme::reassignTo() is a domain method only)
```

**Consistency check:**
- `InstitutionMerger::merge()` still calls `Programme::reassignTo()` internally.
- `MergeInstitutions` Action still invokes `InstitutionMerger::merge()`.
- No entry point (HTTP, console, queue, API) loses access to reassignment — it was never independently accessible.
- Action count reduces from 23 to 22 (with further reductions from F4).

**Impact on ADRs:** ADR-2 (Action Pattern Adoption) is updated to include the explicit criterion: "An Action must have at least one independent entry point (HTTP, console, queue, API). Internal domain operations invoked only by other domain operations or services are not Actions."

---

### F4 — Action Justification Inconsistency: RESOLVED

**Problem:** The architecture kept `RenameInstitution` as an Action because "search index update needed" but listed `Programme::suspendAdmission()` / `Programme::resumeAdmission()` as "NOT Needed" — even though those operations also trigger search index updates via domain event listeners (`ProgrammeAdmissionSuspended` → `UpdateSearchIndex`). This is an inconsistent application of the same justification.

**Root cause:** Search index updates are handled by domain event listeners, not by Actions. When `Institution::rename()` dispatches `InstitutionRenamed`, the `UpdateSearchIndex` listener handles the index update. The `RenameInstitution` Action's search index coordination is redundant — the event listener already handles it. Similarly, `ReactivateInstitution`'s search inclusion is handled by the `InstitutionReactivated` event listener.

**Decision:** Establish one coherent Action criterion and apply it consistently:

**Action Criterion (Final):**

An operation becomes an Application Action when **at least one** of these conditions is true:

1. **Multi-step orchestration** — The operation coordinates more than one domain operation, validation step, or application concern in a single transaction.
2. **Multi-entry-point reuse** — The operation is invoked from multiple entry points (HTTP + Filament + Import, etc.) and a single Action class provides the reusable orchestration point.
3. **Significant cascade** — The operation triggers cascading effects across multiple aggregates that require explicit transactional coordination beyond what event listeners provide.
4. **Authorization + complex validation** — The operation requires authorization checks AND non-trivial validation that cannot be expressed as a Form Request alone.

Search index updates are NOT sufficient justification for an Action because they are handled by event listeners. Authorization alone is NOT sufficient — Laravel Policies handle authorization at the controller/Livewire level. Simple domain calls with authorization can live in controllers/Livewire components directly.

**Actions Removed:**

| Removed Action | Why | What Handles It Instead |
|---------------|-----|----------------------|
| `RenameInstitution` | Single domain call + auth; search index handled by `InstitutionRenamed` event listener | Controller/Livewire calls `Institution::rename()` directly; `UpdateSearchIndex` listener handles index |
| `ReactivateInstitution` | Single domain call + auth; search inclusion handled by `InstitutionReactivated` event listener | Controller/Livewire calls `Institution::reactivate()` directly; `UpdateSearchIndex` listener handles index |

**Actions Retained (with corrected justification):**

| Retained Action | Corrected Justification |
|----------------|----------------------|
| `CreateInstitution` | Multi-entry-point (HTTP + Filament + Import); jurisdiction validation + domain + event dispatch |
| `SuspendInstitution` | Significant cascade (programme status cascade via event + notification coordination) |
| `CloseInstitution` | Significant cascade (programme discontinuation cascade + scholarship flag cascade + search exclusion coordination) |
| `MergeInstitutions` | Multi-step orchestration across multiple aggregates; transactional coordination; most complex operation |
| `PublishAdmissionPolicy` | Multi-step orchestration: cycle validation + rule validation + domain operation + event |
| `RecordAccreditation` | Authorization + jurisdiction guard + trust signal cascade trigger |
| `CreateProgramme` | Multi-entry-point (HTTP + Filament + Import); institution validation + award level guard |
| `DiscontinueProgramme` | Cascade coordination (scholarship flag cascade) |
| `AnnounceScholarship` | Authorization + provider validation (moderate but multi-concern) |
| `OpenScholarshipApplications` | Authorization + policy check + notification trigger |
| `ExpireScholarship` | Time-based trigger from scheduler; batch coordination |
| `TargetScholarshipProgrammes` | Authorization + programme existence validation |
| `AnnounceAdmissionCycle` | Authorization + authority validation |
| `ActivateAdmissionCycle` | Authorization + read model update trigger + multi-entry-point (HTTP + Filament + Scheduler) |
| `AdvanceAdmissionCyclePhase` | Authorization + notification dispatch |
| `RegisterInformationSource` | Multi-entry-point (Filament + Import); reference validation |
| `VerifyInformationSource` | Authorization + trust signal cascade trigger |
| `MarkSourceUnreliable` | Authorization + trust cascade coordination |
| `ImportInstitutionData` | Significant orchestration: parsing + validation + deduplication + batch + event dispatch |
| `ExpireScholarships` (batch) | Time-based batch operation from scheduler |

**Further corrections applied:**

`AnnounceAdmissionCycle` is marginal — it's authorization + authority validation, which could be a Form Request + Policy. However, it coordinates authority validation (ensuring the authority exists and governs the relevant jurisdiction) which is non-trivial validation beyond a Form Request. **Retained** on the multi-concern principle.

`TargetScholarshipProgrammes` is marginal — it's authorization + programme existence check. The programme existence check is a simple guard, not complex orchestration. However, it involves coordinating the many-to-many relationship between scholarship and programmes, which requires explicit transactional handling to maintain consistency. **Retained** on the transactional consistency principle.

**Final Action count: 20** (3 removed from original 23: RenameInstitution, ReactivateInstitution, ReassignProgramme).

The validation recommended removing `AnnounceAdmissionCycle` and `TargetScholarshipProgrammes` as well (SF-1, targeting 19 Actions). After careful review, both are retained:
- `AnnounceAdmissionCycle` coordinates authority validation (ensuring the authority exists and governs the relevant jurisdiction) which is non-trivial validation beyond a Form Request.
- `TargetScholarshipProgrammes` coordinates transactional relationship updates between scholarship and programmes, requiring explicit transactional handling to maintain consistency.

This is a deliberate departure from the validation's specific reduction target of 19. The validation was adversarial; its count was a suggestion, not a requirement. 20 Actions with consistent, documented justification is better than 19 Actions with two marginal ones silently absorbed into controllers where their validation logic would be lost.

**Consistency check:**
- No Action has "search index update" as its sole justification.
- No Action has "authorization only" as its sole justification.
- Every Action meets at least one criterion from the Action Criterion.
- Every removed operation has a documented alternative (direct domain call + event listener).
- The "Actions NOT Needed" list is updated to include RenameInstitution and ReactivateInstitution.

**Impact on ADRs:** ADR-2 (Action Pattern Adoption) is updated with the explicit Action Criterion (4 conditions) and the final count of 20.

---

### Correction Summary

| Correction | Status | Change | Impact |
|-----------|--------|--------|--------|
| F1: Namespace inconsistency | ✅ Resolved | `App\Models\*` → `App\Domain\Models\*` everywhere | Mapping table + ADR-10 |
| F2: DomainEvent interface | ✅ Resolved | Interface removed; events are plain PHP classes | Event architecture + ADR-3 |
| F3: ReassignProgramme | ✅ Resolved | Removed from Action list; remains as domain method | Action count 23→22 + ADR-2 |
| F4: Action justification | ✅ Resolved | Removed RenameInstitution + ReactivateInstitution; established Action Criterion | Action count 22→20 + ADR-2 |

**All four must-fix corrections are resolved. No remaining architectural contradictions.**

---

## 2. ADR Review and Finalization

### ADR Status Update

All ADRs from the architecture document (ADR-1 through ADR-14) are reviewed, corrected where needed, and promoted to **Accepted** status. Missing ADRs identified by the validation are added.

| ADR # | Title | Original Status | Final Status | Changes Applied |
|-------|-------|----------------|-------------|----------------|
| ADR-1 | Eloquent Model as Aggregate Root Persistence | Proposed | **Accepted** | Reframed honestly: "Eloquent models contain domain behaviour; no separate domain entity classes. This is Option C from the validation — the model IS the aggregate's persistence representation with domain operations as named methods." |
| ADR-2 | Action Pattern Adoption | Proposed | **Accepted** | Updated with explicit Action Criterion (4 conditions); count reduced from 23 to 20; removed RenameInstitution, ReactivateInstitution, ReassignProgramme |
| ADR-3 | Domain Event Implementation | Proposed | **Accepted** | Sub-decision resolved: no shared interface, no shared trait; events are plain PHP classes with constructor-injected payload; listeners type-hint specific event class |
| ADR-4 | Value Object Persistence | Proposed | **Accepted** | No change to decision; classification remains: custom Eloquent casts for complex VOs, PHP enums for enum-like VOs, JSON for collection VOs |
| ADR-5 | Read Model Strategy | Proposed | **Accepted** | No change |
| ADR-6 | Search Engine Selection | Proposed | **Accepted** | Added trigger: "Switch to Typesense when PostgreSQL FTS latency exceeds 200ms at 10k programmes or when faceted search response time exceeds 100ms" |
| ADR-7 | Spatie Package Adoption | Proposed | **Accepted** | Timing corrections: laravel-backup → "Adopt when deploying to production"; laravel-sitemap → "Adopt when public pages exist" |
| ADR-8 | Filament vs Custom Admin | Proposed | **Accepted** | No change |
| ADR-9 | Bounded Context Implementation | Proposed | **Accepted** | No change |
| ADR-10 | Namespace and Directory Structure | Proposed | **Accepted** | Fixed: canonical model namespace is `App\Domain\Models\*`; `config/app.php` Models namespace must be updated |
| ADR-11 | Polymorphic vs Separate Tables | Proposed | **Accepted** | No change |
| ADR-12 | Repository Decision | Proposed | **Accepted** | Added known seam: "InstitutionMerger directly loads and persists multiple aggregates within a transaction. If aggregate reconstruction becomes complex, introduce Repository per aggregate." |
| ADR-13 | Reference Data Management | Proposed | **Accepted** | No change |
| ADR-14 | Testing Strategy | Proposed | **Accepted** | No change |
| ADR-15 | InstitutionType and AwardLevel: Enum vs Reference Data | (New) | **Accepted** | Decision: PHP enums for MVP; migration trigger = "when 4th+ country requires types not in existing enum, evaluate migration to reference data table with code-change vs data-change trade-off" |
| ADR-16 | Domain Event Interface Contract | (New) | **Accepted** | Decision: None. Domain events are plain PHP classes. No shared interface or trait. If a generic handler is needed in future, introduce then with evidence. |
| ADR-17 | Caching and Performance Strategy | (New) | **Deferred** | Not yet decided. Trigger: production performance requirements. Approach will be: Redis for read-model caching, model caching for frequently-accessed institutions/programmes, HTTP cache for public pages, cache invalidation via domain event listeners. |
| ADR-18 | Data Ingestion Architecture | (New) | **Deferred** | Not yet decided. Trigger: first import implementation. Concerns: import sources, formats (CSV/JSON/API), validation pipeline, deduplication strategy, conflict resolution, provenance tracking, batch processing, error handling, rollback. |

### ADR-15 Detail: InstitutionType and AwardLevel

**Context:** InstitutionType and AwardLevel are currently PHP backed enums. This means adding a new institution type (e.g., "Language School" for Study Abroad) or award level (e.g., "Certificate" for vocational education) requires a code change — a new enum case must be added and deployed.

**Decision:** Retain as PHP enums for MVP.

**Rationale:**
- Enum values are domain concepts with behaviour (e.g., `InstitutionType::University->isDegreeGranting()`). Reference data tables cannot express this behaviour without additional code.
- The set of institution types and award levels is relatively stable — new values are added infrequently (maybe 2-3 per year as new countries are onboarded).
- Code changes for new enum values are trivial and carry zero deployment risk in a Laravel application (no migration needed, just add the case).
- Reference data tables introduce a join on every query, add Filament management UI complexity, and lose the behavioural methods that enums provide.
- The trade-off is explicitly acknowledged: when the 4th+ country requires types not in the existing enum, re-evaluate.

**Migration trigger:** When adding a new country requires 3+ new InstitutionType or AwardLevel values that don't fit the existing enum, evaluate migrating to a reference data table with a hybrid approach (enum for behaviour, table for extensible values).

---

### ADR-16 Detail: Domain Event Interface

**Context:** The validation identified the DomainEvent interface as ceremonial. Three options were considered: (1) remove entirely, (2) replace with trait, (3) keep with justification.

**Decision:** Remove entirely (Option 1).

**Rationale:** No concrete benefit identified. No generic handler processes events polymorphically. The four methods (eventType, aggregateId, aggregateType, occurredAt) are derivable from the class itself. Adding a trait would reduce boilerplate but still adds an abstraction without a consumer. Plain PHP classes are the simplest approach that works — consistent with Laravel Beyond CRUD's "avoid ceremony that provides no business value."

---

## 3. Final Aggregate Boundary Audit

Re-running the Laravel Beyond CRUD aggregate test for every Aggregate Root.

### Aggregate Root 1: Educational Institution

| Test | Answer |
|------|--------|
| What invariant does it protect? | INV-I1: An institution has exactly one official name. INV-I2: An institution's status follows the lifecycle: Provisional → Operational → Suspended → Closed. INV-I3: An institution has at most one active admission policy per cycle. INV-I4: An institution's accreditation records are unique per authority per period. INV-I5: An institution cannot be closed if it has operational programmes (must reassign first). |
| What business operations does it own? | establish(), rename(), suspend(), reactivate(), close(), publishAdmissionPolicy(), recordAccreditation() |
| What state must remain consistent? | Name, status, active policies, accreditation records — all must be consistent within the aggregate boundary. |
| What entities belong inside it? | Admission Policy (child entity — lifecycle controlled by institution), Accreditation Record (child entity — lifecycle controlled by institution) |
| What must it NOT know about? | Programme details (beyond ownership FK), Scholarship details, Search index state, Read model state, Which Information Sources reference it |
| What operations belong in an Action? | CreateInstitution (multi-entry-point), SuspendInstitution (cascade), CloseInstitution (cascade), MergeInstitutions (cross-aggregate orchestration) |
| What operations belong in a Domain Service? | Merge operation (InstitutionMerger) — crosses two Institution aggregates |
| What information belongs to Queries/read models? | isAdmitting (cross-aggregate), accreditation status (derived), trust signal (computed), search results |

**Verdict: Confirmed.** Five invariants, seven domain operations, two child entities, strong consistency boundary.

---

### Aggregate Root 2: Programme

| Test | Answer |
|------|--------|
| What invariant does it protect? | INV-P1: Every programme belongs to exactly one institution. INV-P2: A programme's status follows: Prospective → Admitting → Suspended → Discontinued. INV-P3: A programme has at most one active admission policy per cycle. INV-P4: Award level is immutable after creation. INV-P5: Tuition fee currency must match institution's country currency (enforced at application layer). INV-P6: A discontinued programme cannot have its admission resumed. |
| What business operations does it own? | introduce(), suspendAdmission(), resumeAdmission(), discontinue(), publishAdmissionPolicy(), recordAccreditation(), reassignTo() (internal, called by InstitutionMerger) |
| What state must remain consistent? | Status, ownership, active policies, accreditation records — all must be consistent. |
| What entities belong inside it? | Admission Policy (child entity), Accreditation Record (child entity) |
| What must it NOT know about? | Scholarship targeting, Search index state, Student eligibility, Institution's other programmes |
| What operations belong in an Action? | CreateProgramme (multi-entry-point + validation), DiscontinueProgramme (cascade), PublishAdmissionPolicy (multi-step), RecordAccreditation (guard + trigger) |
| What operations belong in a Domain Service? | None — reassignTo() is a domain method, not a service |
| What information belongs to Queries/read models? | isAdmitting, accreditation status, eligibility status, search results |

**Verdict: Confirmed.** Six invariants, seven domain operations, two child entities.

---

### Aggregate Root 3: Scholarship

| Test | Answer |
|------|--------|
| What invariant does it protect? | INV-S1: A scholarship's status follows: Draft → Announced → Open → Closed → Expired (or Withdrawn from Announced/Open). INV-S2: Applications cannot be opened without a published eligibility policy. INV-S3: A scholarship targets at least one programme or institution. INV-S4: Application deadline must be set before opening applications. |
| What business operations does it own? | announce(), openApplications(), closeApplications(), withdraw(), expire(), targetProgrammes() |
| What state must remain consistent? | Status, eligibility policy, targeted programmes/institutions, application deadline |
| What entities belong inside it? | Eligibility Policy (child entity — lifecycle controlled by scholarship) |
| What must it NOT know about? | Programme details (beyond targeting FK), Student applications, Search index state |
| What operations belong in an Action? | AnnounceScholarship (validation), OpenScholarshipApplications (policy check + notification), ExpireScholarship (scheduler trigger), TargetScholarshipProgrammes (transactional relationship) |
| What operations belong in a Domain Service? | None |
| What information belongs to Queries/read models? | isApplicableTo, search results, candidate matching |

**Verdict: Confirmed.** Four invariants, six domain operations, one child entity.

---

### Aggregate Root 4: Admission Cycle

| Test | Answer |
|------|--------|
| What invariant does it protect? | INV-C1: Phase sequence must advance in order (Announced → Application → Screening → Admission → Matriculation → Closed). INV-C2: A cycle cannot be activated before its start date. INV-C3: Phase advance is irreversible — cannot go back to a previous phase. |
| What business operations does it own? | announce(), activate(), advancePhase(), close(), archive() |
| What state must remain consistent? | Status, current phase, phase dates |
| What entities belong inside it? | None — Admission Policies reference the cycle but are owned by their parent (Institution/Programme) |
| What must it NOT know about? | Which policies reference it, Programme admission status, Search index state |
| What operations belong in an Action? | AnnounceAdmissionCycle (authority validation), ActivateAdmissionCycle (read model trigger + multi-entry), AdvanceAdmissionCyclePhase (notification) |
| What operations belong in a Domain Service? | None |
| What information belongs to Queries/read models? | isAdmissionOpen, current cycle phase, cycle calendar |

**Verdict: Confirmed.** Three invariants, five domain operations, no child entities.

---

### Aggregate Root 5: Information Source

| Test | Answer |
|------|--------|
| What invariant does it protect? | INV-S1: Reliability follows lifecycle: Unverified → Verified (or Unreliable → Deprecated). INV-S2: A deprecated source cannot be re-verified. INV-S3: Verification requires a verified causer (admin or trusted system). |
| What business operations does it own? | register(), verify(), markUnreliable(), deprecate() |
| What state must remain consistent? | Reliability status, attribution records |
| What entities belong inside it? | None |
| What must it NOT know about? | Which entities reference it, Trust signal computation, Search index state |
| What operations belong in an Action? | RegisterInformationSource (multi-entry-point), VerifyInformationSource (trust cascade trigger), MarkSourceUnreliable (trust cascade) |
| What operations belong in a Domain Service? | None |
| What information belongs to Queries/read models? | isReliable, trust signal, source attribution |

**Verdict: Confirmed.** Three invariants, four domain operations, no child entities.

---

### Identity-Only Check

None of the five aggregate roots were promoted based on identity alone. Each has:
- Protected invariants (3–6 per aggregate)
- Domain operations with precondition checks
- Consistency boundaries that would be violated by demotion

The three supporting entities (Qualification, Scholarship Provider, Education Authority) have identity but no protected invariants — they are correctly classified as reference data managed via Filament CRUD, not aggregate roots.

---

## 4. Final Value Object Audit

### Audit Results

| # | Value Object | Genuine Domain Meaning? | Immutable? | Invariants? | Classification | Verdict |
|---|-------------|:-----------------------:|:----------:|:-----------:|---------------|---------|
| 1 | Admission Rule | Yes — encapsulates qualification requirement, threshold, subjects, rule type | Yes | Yes — rule type determines required fields | Immutable PHP Object + JSON Cast | **Keep** |
| 2 | Eligibility Rule | Yes — encapsulates eligibility criterion, comparator, value | Yes | Yes — criterion type determines required fields | Immutable PHP Object + JSON Cast | **Keep** |
| 3 | Subject Combination | Yes — ordered set of subjects with combination type (AND/OR) | Yes | Yes — at least one subject required | Immutable PHP Object + JSON Cast | **Keep** |
| 4 | Qualification Threshold | Yes — qualification reference + comparator + value + scale | Yes | Yes — comparator must be valid | Immutable PHP Object + JSON Cast | **Keep** |
| 5 | Validity Period | Yes — start + end dates with invariant (start ≤ end) | Yes | Yes — start ≤ end | Immutable PHP Object + Custom Cast | **Keep** |
| 6 | Trust Signal | Yes — computed domain concept | Yes (read-only) | N/A — computed | Computed (never stored) | **Keep** |
| 7 | Monetary Amount | Yes — amount + currency with equality semantics | Yes | Yes — amount ≥ 0 for fees; currency is ISO 4217 | Immutable PHP Object + Custom Cast | **Keep** |
| 8 | Duration | Yes — value + unit (years/months/semesters) | Yes | Yes — value > 0 | Immutable PHP Object + Custom Cast | **Keep** |
| 9 | Location | Yes — country + region + city; nullable for online-only | Yes | Yes — country is ISO 3166-1 | Immutable PHP Object + Custom Cast (nullable) | **Keep** |
| 10 | Authority Jurisdiction | Yes — jurisdiction type + criteria | Yes | No — purely structural | Immutable PHP Object + JSON Cast | **Keep** (marginal — could be JSON column without VO, but VO provides type safety) |
| 11 | Phase Sequence | Yes — ordered list of phases with timing | Yes | Yes — phases must be ordered chronologically | Immutable PHP Object + JSON Cast | **Keep** |
| 12 | Admission Pathway | Yes — name + authority reference; demoted from entity | Yes | No — purely structural | Immutable PHP Object | **Keep** |
| 13 | Institution Type | Yes — domain concept with behaviour (isDegreeGranting, isTertiary) | N/A (enum) | Yes — enum constrains values | PHP Backed Enum | **Keep** (enum vs reference data tension documented in ADR-15) |
| 14 | Award Level | Yes — domain concept with behaviour (isPostgraduate, isUndergraduate) | N/A (enum) | Yes — enum constrains values | PHP Backed Enum | **Keep** (same tension as InstitutionType) |
| 15 | Admission Mode | Yes — Cyclic/Rolling/MultipleIntake affects isAdmitting query logic | N/A (enum) | Yes | PHP Backed Enum | **Keep** |
| 16 | Accreditation Status | Yes — Full/Interim/Probationary/Revoked/Expired | N/A (enum) | Yes | PHP Backed Enum | **Keep** |
| 17 | Policy Status | Yes — Draft/Published/Superseded | N/A (enum) | Yes | PHP Backed Enum | **Keep** |
| 18 | Programme Status | Yes — Prospective/Admitting/Suspended/Discontinued | N/A (enum) | Yes — constrains state transitions | PHP Backed Enum | **Keep** |
| 19 | Scholarship Status | Yes — Draft/Announced/Open/Closed/Expired/Withdrawn | N/A (enum) | Yes — constrains state transitions | PHP Backed Enum | **Keep** |
| 20 | Institution Status | Yes — Provisional/Operational/Suspended/Closed | N/A (enum) | Yes — constrains state transitions | PHP Backed Enum | **Keep** |
| 21 | Source Reliability | Yes — Unverified/Verified/Unreliable/Deprecated | N/A (enum) | Yes — constrains transitions | PHP Backed Enum | **Keep** |
| 22 | Information Category | Yes — Official/Unofficial/Historical/Scraped | N/A (enum) | Yes | PHP Backed Enum | **Keep** |
| 23 | Authority Type | Yes — Regulatory/Accreditation/Funding/Admissions | N/A (enum) | Yes | PHP Backed Enum | **Keep** |
| 24 | Provider Type | Yes — Government/Corporate/NGO/Institution | N/A (enum) | Yes | PHP Backed Enum | **Keep** |
| 25 | Ownership Type | Yes — Public/Private/PPP/Religious | N/A (enum) | Yes | PHP Backed Enum | **Keep** |
| 26 | Delivery Mode | Yes — OnCampus/Online/Hybrid | N/A (enum) | Yes | PHP Backed Enum | **Keep** |
| 27 | Qualification Status | Yes — Active/Deprecated | N/A (enum) | Yes | PHP Backed Enum | **Keep** |
| 28 | Coverage Type | Yes — Full/Partial/TuitionOnly/Stipend | N/A (enum) | Yes | PHP Backed Enum | **Keep** |

**Verdict: All 28 VOs retained.** No speculative VOs found. No VOs that should be reference data, DTOs, or entities instead. AuthorityJurisdiction is marginal — it could be stored as raw JSON without a VO wrapper — but the VO provides type safety and equality semantics that raw JSON does not. The cost is a small cast class; the benefit is compile-time safety. Retained on the pragmatism principle: a VO that prevents bugs is worth a cast class.

---

## 5. Behaviour Audit

### Domain Operations Verification

| Aggregate | Operation | Protects Invariant? | Correct Layer? | Verdict |
|-----------|-----------|:-------------------:|:--------------:|---------|
| Institution | establish() | INV-I1, INV-I2 | Domain method on model | ✅ |
| Institution | rename() | INV-I1 | Domain method on model | ✅ |
| Institution | suspend() | INV-I2 | Domain method on model | ✅ |
| Institution | reactivate() | INV-I2 | Domain method on model | ✅ |
| Institution | close() | INV-I2, INV-I5 | Domain method on model | ✅ |
| Institution | publishAdmissionPolicy() | INV-I3 | Domain method on model | ✅ |
| Institution | recordAccreditation() | INV-I4 | Domain method on model | ✅ |
| Programme | introduce() | INV-P1, INV-P2, INV-P4 | Domain method on model | ✅ |
| Programme | suspendAdmission() | INV-P2 | Domain method on model | ✅ |
| Programme | resumeAdmission() | INV-P2, INV-P6 | Domain method on model | ✅ |
| Programme | discontinue() | INV-P2 | Domain method on model | ✅ |
| Programme | reassignTo() | INV-P1 | Domain method (internal) | ✅ |
| Scholarship | announce() | INV-S1 | Domain method on model | ✅ |
| Scholarship | openApplications() | INV-S1, INV-S2, INV-S4 | Domain method on model | ✅ |
| Scholarship | closeApplications() | INV-S1 | Domain method on model | ✅ |
| Scholarship | withdraw() | INV-S1 | Domain method on model | ✅ |
| Scholarship | expire() | INV-S1 | Domain method on model | ✅ |
| AdmissionCycle | announce() | INV-C1 | Domain method on model | ✅ |
| AdmissionCycle | activate() | INV-C1, INV-C2 | Domain method on model | ✅ |
| AdmissionCycle | advancePhase() | INV-C1, INV-C3 | Domain method on model | ✅ |
| AdmissionCycle | close() | INV-C1 | Domain method on model | ✅ |
| InformationSource | register() | INV-S1 | Domain method on model | ✅ |
| InformationSource | verify() | INV-S1, INV-S3 | Domain method on model | ✅ |
| InformationSource | markUnreliable() | INV-S1 | Domain method on model | ✅ |
| InformationSource | deprecate() | INV-S1, INV-S2 | Domain method on model | ✅ |

### Read-Model Query Verification

| Query | Cross-Aggregate? | Eventually Consistent? | Classification Correct? |
|-------|:----------------:|:---------------------:|:----------------------:|
| isAdmitting | Yes (Programme + AdmissionCycle + AdmissionPolicy) | Yes | ✅ Read-model query |
| isApplicableTo | Yes (Scholarship + EligibilityPolicy + Student qualifications) | Yes | ✅ Read-model query |
| isReliable | No (single source) — but trust signal is computed | Yes (trust signal) | ✅ Read-model query |
| isAdmissionOpen | Yes (AdmissionCycle current phase) | Minimal lag | ✅ Read-model query |

**All four read-model classifications confirmed.** None should be domain operations — they derive answers from multiple aggregates and serve read concerns.

### Cross-Aggregate Operations

| Operation | Crosses Aggregates? | Mechanism | Verdict |
|-----------|:-------------------:|-----------|---------|
| Merge institutions | Yes (Institution + Programme) | Domain Service (InstitutionMerger) within transaction | ✅ Correct |
| Suspend institution (cascade) | Yes (Institution → Programme status) | Domain event listener (InstitutionSuspended → ProgrammeStatusCascade) | ✅ Correct |
| Close institution (cascade) | Yes (Institution → Programme → Scholarship) | Domain event listeners with cascading events | ✅ Correct |
| Scholarship targeting | Yes (Scholarship → Programme/Institution) | Action coordinates FK relationships within transaction | ✅ Correct |
| Trust signal recalculation | Yes (InformationSource → all referencing entities) | Domain event listener (async) | ✅ Correct |

**No cross-aggregate operations are incorrectly forced into a single aggregate.**

---

## 6. Temporal Model Review

### Cycle-Based vs Rolling/Multiple-Intake Admission

The model supports both admission patterns without structural modification:

| Pattern | How It Works | Model Support |
|---------|-------------|---------------|
| **Cycle-based** (Nigeria JAMB, South Africa) | Programme has `admission_mode = Cyclic`. AdmissionCycle tracks phases. `isAdmitting` checks cycle phase + policy existence. | `AdmissionMode::Cyclic` + `AdmissionCycle` aggregate + `AdmissionPolicy` with `cycle_id` FK |
| **Rolling** (UK, US, many international) | Programme has `admission_mode = Rolling`. No cycle required. `isAdmitting` returns true if status is Admitting (no cycle check). | `AdmissionMode::Rolling` + `IsProgrammeAdmitting` query handles the branch |
| **Multiple-intake** (some African, some Asian) | Programme has `admission_mode = MultipleIntake`. Similar to rolling but with explicit intake dates. | `AdmissionMode::MultipleIntake` + intake dates as Programme attributes |

### Temporal Concepts Audit

| Temporal Concept | Domain Concept? | Implementation | Verdict |
|-----------------|:--------------:|---------------|---------|
| Admission Cycle phases | Yes — INV-C1, INV-C3 | PhaseSequence VO on AdmissionCycle | ✅ Correct |
| Policy validity period | Yes — policies have start/end dates | ValidityPeriod VO on AdmissionPolicy/EligibilityPolicy | ✅ Correct |
| Scholarship deadlines | Yes — INV-S4 | application_deadline attribute on Scholarship | ✅ Correct |
| Accreditation periods | Yes — accreditation has validity period | ValidityPeriod VO on AccreditationRecord | ✅ Correct |
| Historical information | Partially — provenance tracks source + timestamp | Provenance attributes on entities + Information Source | ✅ Correct |
| Changes over time | No generic versioning needed | Activity log (Spatie) for audit; domain events for reactions | ✅ Correct — no version tables |

**Verdict:** Temporal model is adequate. No generic versioning abstraction needed. Each temporal concept is a genuine domain concept with its own representation.

---

## 7. Provenance and Trust Review

### Domain Provenance vs Audit Logging

| Concern | Mechanism | Namespace | Contains |
|---------|-----------|-----------|----------|
| **Domain provenance** | `source_id` FK on entities + Information Source aggregate | `App\Domain\Models\InformationSource` | Which source provided the data, when it was acquired, verification status, trust level |
| **Audit logging** | Spatie `laravel-activitylog` | `App\Listeners\LogActivity` | Who performed the action, when, from where, before/after values |
| **Domain events** | Laravel native events | `App\Domain\Events\*` | Business facts that other parts of the system react to |
| **Technical observability** | Laravel logging + optional monitoring | `App\Exceptions\*` + `config/logging.php` | Error logs, performance metrics, system health |

**Key distinction:** Domain provenance answers "Where did this information come from and is it trustworthy?" Audit logging answers "Who changed this and when?" These are different questions answered by different mechanisms. Spatie `laravel-activitylog` is NOT a substitute for domain provenance — it records who performed operations, not where information originated.

**Provenance attributes on entities:**
- `source_id` (FK to InformationSource) on Institution, Programme, Scholarship, AdmissionPolicy
- `acquired_at` (timestamp when data was acquired from the source)
- `last_verified_at` (timestamp of last verification)

These are domain attributes, not audit concerns.

---

## 8. Study Abroad Stress Test

### Scenario Results

| # | Scenario | Existing Model Represents It? | New Entity Needed? | New VO Sufficient? | Reference Data? | Future BC? | Structural Modification? |
|---|----------|:----------------------------:|:------------------:|:------------------:|:---------------:|:----------:|:------------------------:|
| 1 | Nigerian student applying to UK university | Yes — Institution (UK) + Programme (UK) + AdmissionPolicy with UK-specific rules | No | No — AdmissionMode=Rolling, Location VO handles UK | New country seed data | No | No |
| 2 | Nigerian student applying to Canadian university | Yes — same pattern as UK | No | No | New country seed data | No | No |
| 3 | Nigerian student applying to US university | Yes — same pattern; rolling/multiple intake | No | No | New country seed data | No | No |
| 4 | Nigerian student applying to German university | Yes — Institution (DE) with German accreditation authority | No | No — LanguageRequirement could be part of AdmissionRule VO | New country seed data | No | No |
| 5 | Nigerian student applying to South African university | Yes — cycle-based like Nigeria | No | No | New country seed data | No | No |
| 6 | International student applying to Nigerian university | Yes — same Institution + Programme; eligibility rules may differ for international applicants | No | No — AdmissionRule VO can express international vs domestic requirements | No | No | No |
| 7 | Programme with rolling admission | Yes — AdmissionMode::Rolling | No | No — already modelled | No | No | No |
| 8 | Programme with multiple intakes | Yes — AdmissionMode::MultipleIntake | No | No — already modelled | No | No | No |
| 9 | Scholarship available across multiple countries | Yes — Scholarship targets programmes/institutions; cross-border targeting is FK-based | No | No | No | No | No |
| 10 | Institution accredited by different authorities across jurisdictions | Yes — AccreditationRecord is polymorphic; belongsTo EducationAuthority; multiple records per institution | No | No | New authority seed data | No | No |

### Study Abroad Concepts Not Yet Modelled

The following Study Abroad concepts are NOT in the current domain model and are candidates for future bounded contexts:

| Concept | Current Model Status | Recommendation |
|---------|---------------------|---------------|
| Visa requirements | Not modelled | **Future BC:** Immigration & Visa. Reference data per country pair. Not a domain entity — it's product/content data. |
| Language requirements | Partially — AdmissionRule VO can express language proficiency as a rule type | **Extend AdmissionRule** with `language_proficiency` rule type. No new entity. |
| International qualification equivalency | Not modelled | **Future BC:** Qualification Equivalency. Mapping between qualification systems. Not MVP. |
| Proof-of-funds requirements | Not modelled | **Reference data** per country. Not a domain entity. |
| Accommodation information | Not modelled | **Product/content data.** Not a domain concern. |
| Tuition in foreign currency | Yes — MonetaryAmount VO includes currency (ISO 4217) | **Already modelled.** No change. |
| Application process tracking | Not modelled | **Future BC:** Application Management. Significantly different from opportunity discovery. |
| Pathway/foundation programmes | Yes — Programme with appropriate AwardLevel + AdmissionPathway | **Already modelled.** Foundation programmes are programmes. |

**Verdict:** The current domain model supports 10/10 Study Abroad scenarios with zero structural modifications. Six future concepts are identified for future bounded contexts or reference data. No speculative entities are created.

---

## 9. Future Education Expansion Stress Test

| Education Type | Fits Existing Model? | What Adapts | New Entity Needed? |
|---------------|:-------------------:|------------|:------------------:|
| Primary education | Yes | InstitutionType enum adds "PrimarySchool" | No |
| Secondary education | Yes | InstitutionType enum adds "SecondarySchool" | No |
| Tertiary education | Already modelled | — | No |
| Vocational education | Yes | InstitutionType enum adds "VocationalInstitute" | No |
| Professional certification | Yes | InstitutionType + AwardLevel enum additions | No |
| Language education | Yes | InstitutionType enum adds "LanguageSchool" | No |
| Online education | Yes | DeliveryMode::Online already exists | No |
| Bootcamps | Yes | InstitutionType enum adds "Bootcamp" | No |
| Foundation programmes | Yes | Programme with AwardLevel "Foundation" | No |
| Pathway programmes | Yes | AdmissionPathway VO | No |
| Exchange programmes | Yes | Programme + Scholarship (exchange type) | No |
| Short courses | Yes | Programme with Duration VO (short) | No |
| Professional development | Yes | InstitutionType + AwardLevel additions | No |

**Verdict:** All 13 education types fit the existing model with enum additions only. No structural modifications. The architecture is genuinely "education-type agnostic" — it models institutions, programmes, admissions, and scholarships as universal domain concepts, not as tertiary-specific concepts.

**Over-generalization check:** No generic `EducationalThing`, `Policy`, `Opportunity`, `Authority`, `Requirement`, `Provider`, or `Offering` abstractions exist. Each entity earns its place through domain language, behaviour, invariants, and lifecycle.

---

## 10. Final Architecture Catalogue

### Entities

| # | Entity | Classification | Aggregate Membership | Identity | Lifecycle | Responsibilities | Invariants | Relationships |
|---|--------|---------------|---------------------|----------|-----------|-----------------|-----------|---------------|
| 1 | Educational Institution | Aggregate Root | Own boundary | UUID | Provisional → Operational → Suspended → Closed | Name, type, status, policies, accreditation | INV-I1 through INV-I5 | hasMany AdmissionPolicy, hasMany AccreditationRecord, hasMany Programme |
| 2 | Programme | Aggregate Root | Own boundary | UUID | Prospective → Admitting → Suspended → Discontinued | Name, award level, admission, policies, accreditation | INV-P1 through INV-P6 | belongsTo Institution, hasMany AdmissionPolicy, hasMany AccreditationRecord |
| 3 | Scholarship | Aggregate Root | Own boundary | UUID | Draft → Announced → Open → Closed → Expired/Withdrawn | Value, eligibility, targeting, deadlines | INV-S1 through INV-S4 | belongsTo ScholarshipProvider, hasMany EligibilityPolicy |
| 4 | Admission Cycle | Aggregate Root | Own boundary | UUID | Announced → Active → Closed → Archived | Phases, dates, authority | INV-C1 through INV-C3 | belongsTo EducationAuthority |
| 5 | Information Source | Aggregate Root | Own boundary | UUID | Registered → Verified/Unreliable → Deprecated | Provenance, trust, verification | INV-S1 through INV-S3 | Referenced by FK from entities |
| 6 | Admission Policy | Child Entity | Institution or Programme | UUID (composite) | Draft → Published → Superseded | Rules, validity, pathway | One active per cycle per parent | belongsTo Governable (polymorphic), belongsTo AdmissionCycle |
| 7 | Eligibility Policy | Child Entity | Scholarship | UUID (composite) | Draft → Published → Superseded | Rules, validity | One active per scholarship | belongsTo Scholarship |
| 8 | Accreditation Record | Child Entity | Institution or Programme | UUID (composite) | Created → valid until expiry | Authority, status, validity period | Unique per authority per period | belongsTo Accreditable (polymorphic), belongsTo EducationAuthority |
| 9 | Qualification | Supporting Entity | None (reference data) | Auto-increment | Active → Deprecated | Name, level, authority | None | belongsTo EducationAuthority |
| 10 | Scholarship Provider | Supporting Entity | None (reference data) | Auto-increment | Active → Inactive | Name, type | None | hasMany Scholarship |
| 11 | Education Authority | Supporting Entity | None (reference data) | Auto-increment | Active → Inactive | Name, type, jurisdiction | None | hasMany AdmissionCycle, hasMany AccreditationRecord, hasMany Qualification |

### Value Objects

| # | Value Object | Purpose | Invariants | Owner | Equality Semantics | Implementation |
|---|-------------|---------|-----------|-------|-------------------|---------------|
| 1 | Admission Rule | Encapsulates admission requirement (qualification, threshold, subjects, type) | Rule type determines required fields | AdmissionPolicy | Value equality (all fields match) | Immutable PHP Object + JSON Cast |
| 2 | Eligibility Rule | Encapsulates eligibility criterion | Criterion type determines required fields | EligibilityPolicy | Value equality | Immutable PHP Object + JSON Cast |
| 3 | Subject Combination | Ordered set of subjects with combination type | At least one subject | AdmissionRule (nested) | Value equality | Immutable PHP Object + JSON Cast |
| 4 | Qualification Threshold | Qualification ref + comparator + value + scale | Comparator must be valid | AdmissionRule (nested) | Value equality | Immutable PHP Object + JSON Cast |
| 5 | Validity Period | Start + end dates for policy/accreditation validity | Start ≤ end | AdmissionPolicy, EligibilityPolicy, AccreditationRecord | Date range equality | Immutable PHP Object + Custom Cast |
| 6 | Trust Signal | Computed reliability indicator for source | N/A (computed) | InformationSource (via Query) | Value equality | Computed (never stored) |
| 7 | Monetary Amount | Amount + currency for fees and scholarship values | Amount ≥ 0 for fees; currency is ISO 4217 | Programme (tuition), Scholarship (value) | Amount + currency equality | Immutable PHP Object + Custom Cast |
| 8 | Duration | Value + unit for programme length | Value > 0 | Programme | Value + unit equality | Immutable PHP Object + Custom Cast |
| 9 | Location | Country + region + city for institution location | Country is ISO 3166-1 | Institution | All fields equality | Immutable PHP Object + Custom Cast (nullable) |
| 10 | Authority Jurisdiction | Jurisdiction type + criteria for authority scope | None | EducationAuthority | Value equality | Immutable PHP Object + JSON Cast |
| 11 | Phase Sequence | Ordered list of admission cycle phases | Phases ordered chronologically | AdmissionCycle | Sequence equality | Immutable PHP Object + JSON Cast |
| 12 | Admission Pathway | Name + authority reference for admission route | None | AdmissionPolicy | Value equality | Immutable PHP Object |
| 13–28 | (13 PHP enums) | Constrain domain values | Enum constrains values | Various | Enum case equality | PHP Backed Enum |

### Aggregate Roots

| # | Aggregate Root | Invariant Boundary | Owned Entities | Operations | Forbidden Knowledge |
|---|---------------|-------------------|---------------|-----------|-------------------|
| 1 | Educational Institution | INV-I1 through INV-I5 (name, status lifecycle, policy uniqueness, accreditation uniqueness, close guard) | AdmissionPolicy, AccreditationRecord | establish, rename, suspend, reactivate, close, publishAdmissionPolicy, recordAccreditation | Programme details, Scholarship, Search, Read models |
| 2 | Programme | INV-P1 through INV-P6 (ownership, status lifecycle, policy uniqueness, award immutability, currency, discontinuation) | AdmissionPolicy, AccreditationRecord | introduce, suspendAdmission, resumeAdmission, discontinue, publishAdmissionPolicy, recordAccreditation, reassignTo | Scholarship targeting, Student eligibility, Search |
| 3 | Scholarship | INV-S1 through INV-S4 (status lifecycle, policy requirement, targeting, deadline) | EligibilityPolicy | announce, openApplications, closeApplications, withdraw, expire, targetProgrammes | Programme details, Student applications, Search |
| 4 | Admission Cycle | INV-C1 through INV-C3 (phase order, activation date, irreversibility) | None | announce, activate, advancePhase, close, archive | Policy references, Programme status, Search |
| 5 | Information Source | INV-S1 through INV-S3 (reliability lifecycle, deprecation terminal, verified causer) | None | register, verify, markUnreliable, deprecate | Entity references, Trust computation, Search |

### Actions

| # | Action | Use Case | Why It Is an Action | Aggregate(s) Involved | Domain Operation Invoked |
|---|--------|----------|-------------------|---------------------|------------------------|
| 1 | CreateInstitution | Create a new institution | Multi-entry-point (HTTP + Filament + Import); jurisdiction validation | Institution | Institution::establish() |
| 2 | SuspendInstitution | Suspend an operational institution | Significant cascade (programme status) | Institution | Institution::suspend() |
| 3 | CloseInstitution | Permanently close an institution | Significant cascade (programmes + scholarships + search) | Institution | Institution::close() |
| 4 | MergeInstitutions | Merge two institutions into one | Multi-step cross-aggregate orchestration; most complex operation | Institution (×2), Programme (×N) | InstitutionMerger::merge() |
| 5 | PublishAdmissionPolicy | Publish admission policy for a cycle | Multi-step: cycle validation + rule validation + domain | Programme or Institution | publishAdmissionPolicy() |
| 6 | RecordAccreditation | Record accreditation for entity | Authorization + jurisdiction guard + trust trigger | Programme or Institution | recordAccreditation() |
| 7 | CreateProgramme | Create a new programme | Multi-entry-point (HTTP + Filament + Import); validation | Programme, Institution | Programme::introduce() |
| 8 | DiscontinueProgramme | Discontinue a programme | Cascade (scholarship flag) | Programme | Programme::discontinue() |
| 9 | AnnounceScholarship | Announce a new scholarship | Authorization + provider validation | Scholarship | Scholarship::announce() |
| 10 | OpenScholarshipApplications | Open scholarship applications | Authorization + policy check + notification trigger | Scholarship | Scholarship::openApplications() |
| 11 | ExpireScholarship | Expire a scholarship (time-based) | Scheduler trigger; batch coordination | Scholarship | Scholarship::expire() |
| 12 | TargetScholarshipProgrammes | Set scholarship targeting | Transactional relationship coordination | Scholarship, Programme | Scholarship::targetProgrammes() |
| 13 | AnnounceAdmissionCycle | Announce a new admission cycle | Authorization + authority validation | AdmissionCycle | AdmissionCycle::announce() |
| 14 | ActivateAdmissionCycle | Activate an admission cycle | Multi-entry-point (HTTP + Filament + Scheduler); read model trigger | AdmissionCycle | AdmissionCycle::activate() |
| 15 | AdvanceAdmissionCyclePhase | Advance cycle to next phase | Authorization + notification dispatch | AdmissionCycle | AdmissionCycle::advancePhase() |
| 16 | RegisterInformationSource | Register a new information source | Multi-entry-point (Filament + Import) | InformationSource | InformationSource::register() |
| 17 | VerifyInformationSource | Verify source reliability | Authorization + trust cascade trigger | InformationSource | InformationSource::verify() |
| 18 | MarkSourceUnreliable | Mark source as unreliable | Authorization + trust cascade | InformationSource | InformationSource::markUnreliable() |
| 19 | ImportInstitutionData | Import data from external source | Significant orchestration: parsing + validation + dedup + batch | Multiple | Multiple creates/updates |
| 20 | ExpireScholarships | Batch-expire overdue scholarships | Time-based batch from scheduler | Scholarship (×N) | Scholarship::expire() per item |

### Queries

| # | Query | Read Concern | Source | Write Model or Read Model/Search Index |
|---|-------|-------------|--------|---------------------------------------|
| 1 | GetInstitutionDetails | Institution detail page | Eloquent (eager-loaded) | Write model |
| 2 | SearchInstitutions | Institution search/filter | Search engine (Typesense) or Eloquent | Search index |
| 3 | GetInstitutionAccreditationStatus | Accreditation summary for institution | Eloquent (derived) | Write model |
| 4 | GetProgrammeDetails | Programme detail page | Eloquent (eager-loaded) | Write model |
| 5 | IsProgrammeAdmitting | Is programme currently admitting? | Eloquent (cross-aggregate) | Read model query |
| 6 | SearchProgrammes | Programme search/filter | Search engine or Eloquent | Search index |
| 7 | GetScholarshipDetails | Scholarship detail page | Eloquent (eager-loaded) | Write model |
| 8 | IsScholarshipApplicableTo | Is scholarship applicable to student? | Eloquent (cross-aggregate) | Read model query |
| 9 | SearchScholarships | Scholarship search/filter | Search engine or Eloquent | Search index |
| 10 | IsAdmissionOpen | Is admission currently open? | Eloquent (cycle phase) | Read model query |
| 11 | GetCurrentCyclePhase | Current phase of cycle | Eloquent | Write model |
| 12 | IsSourceReliable | Is source reliable enough? | Eloquent | Write model |
| 13 | GetTrustSignal | Computed trust score | Eloquent (computed) | Read model query |
| 14 | GetOpportunityFeed | Educational opportunity feed | Search engine | Search index |
| 15 | CompareOpportunities | Side-by-side comparison | Eloquent (multiple) | Write model |

### Domain Services

| # | Domain Service | Why It Cannot Belong to an Aggregate |
|---|---------------|-------------------------------------|
| 1 | InstitutionMerger | Must coordinate across two Institution aggregates and all their Programme aggregates within a single transactional boundary. Neither Institution alone can orchestrate this — it requires loading multiple aggregates and ensuring INV-P1 (programme ownership) holds across the reassignment. |

### Domain Events

| # | Event | Business Fact | Emitted By | Consumers |
|---|-------|--------------|-----------|-----------|
| 1 | InstitutionEstablished | A new institution was created | Institution | UpdateSearchIndex, LogActivity |
| 2 | InstitutionRenamed | An institution's name was changed | Institution | UpdateSearchIndex, LogActivity |
| 3 | InstitutionSuspended | An institution was suspended | Institution | UpdateSearchIndex, ProgrammeStatusCascade |
| 4 | InstitutionReactivated | An institution was reactivated | Institution | UpdateSearchIndex, ProgrammeStatusRestore |
| 5 | InstitutionClosed | An institution was permanently closed | Institution | UpdateSearchIndex, ProgrammeDiscontinueCascade, ScholarshipFlag |
| 6 | InstitutionsMerged | Two institutions were merged | InstitutionMerger | SearchRebuild, ProgrammeReassignment |
| 7 | InstitutionAccredited | An institution received accreditation | Institution | TrustSignal, UpdateSearchIndex |
| 8 | InstitutionalAdmissionPolicyPublished | An institution published admission policy | Institution | UpdateSearchIndex, OpportunityFeed |
| 9 | ProgrammeIntroduced | A new programme was created | Programme | UpdateSearchIndex, LogActivity |
| 10 | ProgrammeAdmissionPolicyPublished | A programme published admission policy | Programme | UpdateSearchIndex, OpportunityFeed |
| 11 | ProgrammeAdmissionSuspended | A programme's admission was suspended | Programme | UpdateSearchIndex |
| 12 | ProgrammeAdmissionResumed | A programme's admission was resumed | Programme | UpdateSearchIndex |
| 13 | ProgrammeDiscontinued | A programme was discontinued | Programme | UpdateSearchIndex, ScholarshipFlag |
| 14 | ProgrammeAccredited | A programme received accreditation | Programme | TrustSignal, UpdateSearchIndex |
| 15 | ScholarshipAnnounced | A new scholarship was announced | Scholarship | UpdateSearchIndex, CandidateNotification |
| 16 | ScholarshipEligibilityPolicyPublished | A scholarship published eligibility policy | Scholarship | EligibleCandidateRecalc |
| 17 | ScholarshipApplicationsOpened | Scholarship applications opened | Scholarship | UpdateSearchIndex, CandidateNotification |
| 18 | ScholarshipApplicationsClosed | Scholarship applications closed | Scholarship | UpdateSearchIndex |
| 19 | ScholarshipWithdrawn | A scholarship was withdrawn | Scholarship | UpdateSearchIndex, ApplicantNotification |
| 20 | ScholarshipExpired | A scholarship expired | Scholarship | UpdateSearchIndex |
| 21 | ScholarshipTargetsUpdated | Scholarship targeting was updated | Scholarship | UpdateSearchIndex |
| 22 | AdmissionCycleAnnounced | A new admission cycle was announced | AdmissionCycle | UpdateSearchIndex |
| 23 | AdmissionCycleActivated | An admission cycle was activated | AdmissionCycle | ReadModelUpdate |
| 24 | AdmissionCyclePhaseAdvanced | A cycle phase was advanced | AdmissionCycle | ReadModelUpdate, NotificationDispatch |
| 25 | AdmissionCycleClosed | An admission cycle was closed | AdmissionCycle | ReadModelUpdate |
| 26 | InformationSourceVerified | A source was verified | InformationSource | TrustSignalRecalc |
| 27 | InformationSourceMarkedUnreliable | A source was marked unreliable | InformationSource | TrustSignalRecalc |
| 28 | InformationSourceDeprecated | A source was deprecated | InformationSource | TrustSignalCascade, DataProvenanceFlag |
| 29 | QualificationDeprecated | A qualification was deprecated | Qualification | PolicyCreationGuard |

---

## 11. Final Laravel Architecture

### Canonical Directory Structure

```
app/
    Domain/                         — Domain model (the heart)
        Models/                     — Eloquent models (aggregate roots + child + supporting)
            Institution.php        — Aggregate Root
            Programme.php          — Aggregate Root
            Scholarship.php        — Aggregate Root
            AdmissionCycle.php     — Aggregate Root
            InformationSource.php  — Aggregate Root
            AdmissionPolicy.php    — Child Entity
            EligibilityPolicy.php  — Child Entity
            AccreditationRecord.php — Child Entity
            Qualification.php      — Supporting Entity
            ScholarshipProvider.php — Supporting Entity
            EducationAuthority.php — Supporting Entity
        ValueObjects/              — Immutable domain value objects
            AdmissionRule.php
            EligibilityRule.php
            SubjectCombination.php
            QualificationThreshold.php
            ValidityPeriod.php
            MonetaryAmount.php
            Duration.php
            Location.php
            AuthorityJurisdiction.php
            PhaseSequence.php
            AdmissionPathway.php
        Enums/                     — PHP backed enums
            InstitutionType.php
            AwardLevel.php
            AdmissionMode.php
            AccreditationStatus.php
            PolicyStatus.php
            ProgrammeStatus.php
            ScholarshipStatus.php
            InstitutionStatus.php
            SourceReliability.php
            InformationCategory.php
            AuthorityType.php
            ProviderType.php
            OwnershipType.php
            DeliveryMode.php
            QualificationStatus.php
            CoverageType.php
        Events/                    — Domain event classes (plain PHP, no shared interface)
            InstitutionEstablished.php
            InstitutionRenamed.php
            InstitutionSuspended.php
            InstitutionReactivated.php
            InstitutionClosed.php
            InstitutionsMerged.php
            InstitutionAccredited.php
            InstitutionalAdmissionPolicyPublished.php
            ProgrammeIntroduced.php
            ProgrammeAdmissionPolicyPublished.php
            ProgrammeAdmissionSuspended.php
            ProgrammeAdmissionResumed.php
            ProgrammeDiscontinued.php
            ProgrammeAccredited.php
            ScholarshipAnnounced.php
            ScholarshipEligibilityPolicyPublished.php
            ScholarshipApplicationsOpened.php
            ScholarshipApplicationsClosed.php
            ScholarshipWithdrawn.php
            ScholarshipExpired.php
            ScholarshipTargetsUpdated.php
            AdmissionCycleAnnounced.php
            AdmissionCycleActivated.php
            AdmissionCyclePhaseAdvanced.php
            AdmissionCycleClosed.php
            InformationSourceVerified.php
            InformationSourceMarkedUnreliable.php
            InformationSourceDeprecated.php
            QualificationDeprecated.php
        Services/                  — Domain services (only 1)
            InstitutionMerger.php
        Exceptions/                — Domain exceptions
            InvalidStateTransitionException.php
            InvariantViolationException.php
            InstitutionMergeException.php
        Casts/                     — Custom Eloquent casts for VOs
            MonetaryAmountCast.php
            ValidityPeriodCast.php
            LocationCast.php
            DurationCast.php
            AdmissionRuleCast.php
            EligibilityRuleCast.php
            PhaseSequenceCast.php
            AuthorityJurisdictionCast.php
            AdmissionPathwayCast.php

    Actions/                       — Application actions (20 use cases)
        Institutions/
            CreateInstitution.php
            SuspendInstitution.php
            CloseInstitution.php
            MergeInstitutions.php
        Programmes/
            CreateProgramme.php
            PublishAdmissionPolicy.php
            RecordAccreditation.php
            DiscontinueProgramme.php
        Scholarships/
            AnnounceScholarship.php
            OpenScholarshipApplications.php
            ExpireScholarship.php
            TargetScholarshipProgrammes.php
        AdmissionCycles/
            AnnounceAdmissionCycle.php
            ActivateAdmissionCycle.php
            AdvanceAdmissionCyclePhase.php
        InformationSources/
            RegisterInformationSource.php
            VerifyInformationSource.php
            MarkSourceUnreliable.php
        Imports/
            ImportInstitutionData.php
        Scheduled/
            ExpireScholarships.php
            ActivateCycles.php

    Queries/                       — Read-model queries
        Institutions/
            GetInstitutionDetails.php
            SearchInstitutions.php
            GetInstitutionAccreditationStatus.php
        Programmes/
            GetProgrammeDetails.php
            IsProgrammeAdmitting.php
            SearchProgrammes.php
        Scholarships/
            GetScholarshipDetails.php
            IsScholarshipApplicableTo.php
            SearchScholarships.php
        AdmissionCycles/
            IsAdmissionOpen.php
            GetCurrentCyclePhase.php
        InformationSources/
            IsSourceReliable.php
            GetTrustSignal.php
        Opportunities/
            GetOpportunityFeed.php
            CompareOpportunities.php

    Data/                          — Spatie Laravel Data DTOs
        InstitutionData.php
        ProgrammeData.php
        ScholarshipData.php
        AdmissionCycleData.php
        AdmissionPolicyData.php
        EligibilityPolicyData.php
        ImportData/
            InstitutionImportRow.php

    Policies/                      — Laravel authorization policies
        InstitutionPolicy.php
        ProgrammePolicy.php
        ScholarshipPolicy.php
        AdmissionCyclePolicy.php
        InformationSourcePolicy.php

    Listeners/                     — Domain event listeners (application layer)
        UpdateSearchIndex.php
        UpdateReadModel.php
        DispatchNotifications.php
        RecalculateTrustSignal.php
        LogActivity.php

    Livewire/                      — Livewire components
        Public/
            InstitutionSearch.php
            ProgrammeSearch.php
            ScholarshipSearch.php
            InstitutionDetail.php
            ProgrammeDetail.php
            ScholarshipDetail.php
            OpportunityComparison.php
            EligibilityChecker.php
        Authenticated/
            Dashboard.php
            SavedOpportunities.php
            Preferences.php
            EligibilityAssessments.php

    Filament/                      — Filament admin panel
        Resources/
            InstitutionResource.php
            ProgrammeResource.php
            ScholarshipResource.php
            AdmissionCycleResource.php
            InformationSourceResource.php
            QualificationResource.php
            ScholarshipProviderResource.php
            EducationAuthorityResource.php
        Pages/
            Dashboard.php

    Support/                       — Shared application utilities
        CountryReference.php       — ISO 3166-1 wrapper (not a domain VO)
        ReferenceDataSeeder.php    — Reference data seeding helpers

config/
    studyNexus.php                 — Domain-specific configuration

database/
    migrations/
    seeders/
        CountrySeeder.php           — ISO 3166-1 data
        NigeriaReferenceDataSeeder.php  — Nigerian authorities, qualifications, pathways
        GhanaReferenceDataSeeder.php    — Ghana reference data (when needed)
        ...

routes/
    web.php                         — Public routes (Blade/Livewire)
    authenticated.php               — Authenticated user routes
    filament.php                    — Filament admin routes (auto-generated)
    api.php                         — API routes (if needed later)

tests/
    Unit/Domain/
    Feature/Actions/
    Feature/Queries/
    Browser/Livewire/
```

### Namespace Configuration

```php
// config/app.php
'models_namespace' => 'App\\Domain\\Models',
```

This ensures Laravel's factory and policy resolution uses the correct namespace.

### Directory Justification

Every directory has a reason:

| Directory | Reason |
|-----------|--------|
| `app/Domain/` | Heart of the application — anyone opening the codebase sees the domain model first |
| `app/Domain/Models/` | Domain models kept together (not scattered in Laravel default `app/Models/`) |
| `app/Domain/ValueObjects/` | Immutable domain concepts with equality semantics |
| `app/Domain/Enums/` | PHP backed enums constraining domain values |
| `app/Domain/Events/` | Domain events as business facts |
| `app/Domain/Services/` | Cross-aggregate domain operations (only InstitutionMerger) |
| `app/Domain/Exceptions/` | Domain-specific exceptions |
| `app/Domain/Casts/` | Custom Eloquent casts bridging VOs and database |
| `app/Actions/` | Application use cases — one per orchestrated operation |
| `app/Queries/` | Read concerns — separate from write Actions |
| `app/Data/` | Spatie Laravel Data DTOs for request/response transformation |
| `app/Policies/` | Laravel authorization policies |
| `app/Listeners/` | Domain event listeners (application layer reactions) |
| `app/Livewire/` | Livewire components — architectural boundary |
| `app/Filament/` | Filament admin — architectural boundary |
| `app/Support/` | Shared application utilities that don't belong to domain |

**No directory exists merely because DDD books commonly show it.** No `app/Domain/Repositories/`, no `app/Domain/Services/Interfaces/`, no `app/Domain/Aggregates/`. Every directory serves a concrete purpose.

---

## 12. UI Architecture

### Public Website

| Mechanism | When Used | Examples |
|-----------|-----------|---------|
| **Blade** | Static/server-rendered content; SEO-critical pages | Institution profile, programme detail, scholarship detail, about pages, country guides |
| **Livewire** | Dynamic/interacting UI; real-time filtering; form interactions | Search with filters, eligibility checker, opportunity comparison, saved opportunities |
| **Alpine.js** | Lightweight browser-side interactions; UI toggles; animations | Dropdown menus, accordion sections, tooltip toggles, mobile menu |
| **Flux** | Reusable UI component/design-system layer | Form inputs, buttons, cards, modals, tables — consistent design tokens |

### Authenticated Dashboards

| Mechanism | When Used | Examples |
|-----------|-----------|---------|
| **Livewire** | Primary UI mechanism for authenticated pages | Student dashboard, saved opportunities, eligibility assessments, qualification profile |
| **Blade** | Page layout and static sections | Dashboard layout, navigation, sidebar |
| **Flux** | UI components | Charts, data tables, notification panels |

### Administration

| Mechanism | When Used |
|-----------|-----------|
| **FilamentPHP** | All admin/back-office operations: managing institutions, programmes, scholarships, authorities, sources, reviewing imported data, moderation, data verification |

### Key UI Rules

1. **The UI layer is a consumer of domain/application behaviour.** No domain rules in Livewire components or Blade templates.
2. **Filament Resources invoke Actions.** Business logic is never in Filament Resource hooks.
3. **Livewire components call Actions or Queries.** Domain operations are never called directly from Livewire except for simple operations that bypass Actions per the Action Criterion.
4. **Alpine.js is for presentation only.** No business logic, no API calls.
5. **Flux provides consistent UI components.** It does not contain behaviour.

---

## 13. Spatie Integration Map

| Package | Decision | Where Used | Why | Domain Coupling | When |
|---------|----------|------------|-----|----------------|------|
| laravel-permission | **Adopt Now** | Policies, Filament gate, middleware | Role/permission-based authorization is a core requirement | Low — permissions are application-layer; domain invariants are separate | Pre-implementation |
| laravel-medialibrary | **Adopt Now** | Institution logos, document attachments | Media upload/management is needed for institution profiles | None — media is infrastructure, not domain | When institution profile UI is built |
| laravel-backup | **Adopt when deploying to production** | Backup job | No production database until production | None | Production deployment |
| laravel-activitylog | **Adopt Now** | Listeners/LogActivity.php | Audit trail for admin actions and status changes | Low — logs domain events but is not domain logic | Pre-implementation |
| laravel-sluggable | **Adopt Now** | Institution, Programme, Scholarship models | SEO-friendly URLs for public pages | None — slug is presentation concern, not domain | Pre-implementation |
| laravel-query-builder | **Adopt Now** | Query classes, Livewire search components | Structured API/HTTP filtering without manual query building | None — query construction is infrastructure | When search UI is built |
| laravel-data | **Adopt Now** | app/Data/ DTOs, Form Requests | Type-safe request/response transformation with validation | None — DTOs are application-layer; domain VOs are separate classes | Pre-implementation |
| laravel-sitemap | **Adopt when public pages exist** | SEO sitemap generation | No public pages until public UI is built | None | When public UI is built |
| schema-org | **Adopt when public pages exist** | Blade templates (structured data) | Schema.org markup for SEO | None — structured data is presentation | When public UI is built |
| laravel-settings | **Adopt Later** | Admin settings (feature flags, thresholds) | Flexible key-value settings for admin configuration | None | When admin settings UI is needed |
| laravel-schedule-monitor | **Evaluate When Needed** | Scheduled tasks monitoring | Useful for monitoring import/cycle jobs | None | When scheduled tasks are in production |
| laravel-newsletter | **Evaluate When Needed** | Email newsletter integration | May be needed for student notifications | None | When newsletter feature is requested |
| laravel-ray | **Evaluate When Needed** | Development debugging | Debug tool, not production dependency | None | Developer preference |
| laravel-model-states | **Rejected** | — | PHP enums + domain methods + events are cleaner for 3–5 state machines; no state machine exceeds 7 states or 6 transitions | N/A | Re-evaluate only if any state machine exceeds 7 states or 6 transitions |
| laravel-fractal | **Rejected** | — | Laravel Data provides superior DTO/transformer support with Laravel-native validation | N/A | Not reconsidered |
| valuestore | **Rejected** | — | laravel-settings is a better fit if settings are needed; valuestore's flat-file approach doesn't suit database-backed application | N/A | Not reconsidered |

### Key Distinction: Architectural Dependency vs Optional Tooling

| Category | Packages | Removal Impact |
|----------|----------|---------------|
| **Architectural dependency** | permission, activitylog, sluggable, query-builder, data | Application cannot function correctly without these |
| **Optional infrastructure tooling** | medialibrary, backup, sitemap, schema-org, settings, schedule-monitor, newsletter, ray | Application functions without these; they add capability |

---

## 14. Search and External Infrastructure

### Search Architecture

| Component | Role | Domain Coupling |
|-----------|------|----------------|
| **Database (PostgreSQL)** | Primary data store; full-text search fallback | Direct — Eloquent models |
| **Typesense** | Search engine for faceted search + autocomplete | None — accessed via Scout; domain never coupled to search engine |
| **Scout** | Laravel search abstraction; switches between drivers | Low — search indexing is infrastructure concern |

### Search Indexing Flow

```
Domain Operation → Domain Event → UpdateSearchIndex Listener → Scout → Typesense/PostgreSQL
```

The domain never calls the search engine directly. Search indexing is always triggered by domain events, ensuring the domain model remains unaware of search infrastructure.

### External Infrastructure

| Component | Role | Triggered By |
|-----------|------|-------------|
| **Queues** | Async event processing, import jobs, notifications | Domain events, scheduled tasks |
| **Scheduled tasks** | Scholarship expiry, cycle activation, import runs | Laravel scheduler |
| **Import pipeline** | Data ingestion from external sources | Console command or admin trigger |
| **Scraping** | External data acquisition (future) | Not MVP |

**Search infrastructure does NOT leak domain concepts into the core domain.** The search index is a projection of domain state — it is eventually consistent and rebuildable from the write model.

---

## 15. Security and Authorization

### Authorization Architecture

| Layer | Mechanism | Purpose |
|-------|-----------|---------|
| **Authentication** | Laravel Fortify or custom | User identity (student, admin, counsellor) |
| **Authorization** | Laravel Policies + Spatie Permission | Role/permission-based access control |
| **Domain invariants** | Domain operation methods | Business rules that must hold regardless of user permissions |

### Critical Distinction

**A user having permission to perform an operation does NOT mean the domain invariant is satisfied.** These are two separate checks:

1. **Authorization check:** "Is this user allowed to suspend an institution?" → Policy check → `InstitutionPolicy@suspend`
2. **Domain invariant check:** "Can this institution be suspended?" → Domain method → `Institution::suspend()` throws `InvalidStateTransitionException` if not Operational

Both checks must pass. Authorization is application-layer; invariant enforcement is domain-layer. They must remain separate.

### Role Model (Deferred)

The specific roles and permissions will be defined during implementation. The architecture supports:

- **Super Admin** — all operations
- **Data Manager** — CRUD on institutions, programmes, scholarships; import; verification
- **Content Editor** — edit descriptions, media; publish/unpublish
- **Data Viewer** — read-only access to admin panel
- **Student** — authenticated public features (saved, comparisons, eligibility)
- **Counsellor/Tutor** — student-facing features + institutional data view

---

## 16. Testing Architecture

### Test Layers (Priority Order)

| Priority | Layer | What It Tests | How |
|:--------:|-------|--------------|-----|
| 1 | **Domain Unit** | Invariants, state transitions, VO equality, enum behaviour | PHPUnit on model instances without DB |
| 2 | **Feature (Actions)** | Action orchestration, authorization, event dispatch | PHPUnit with SQLite in-memory |
| 3 | **Feature (Queries)** | Query correctness, read model accuracy | PHPUnit with SQLite + factories |
| 4 | **Browser (Livewire)** | UI interactions, form submission, search | Laravel Dusk or Livewire testing |

### Domain Test Examples

```php
// Domain unit test — no database needed
test('institution cannot be closed with operational programmes', function () {
    $institution = Institution::factory()->operational()->make();
    // Programme relationship would need DB, so test the guard method
    expect(fn() => $institution->close())
        ->toThrow(InvariantViolationException::class);
});

test('programme status follows lifecycle', function () {
    $programme = Programme::factory()->admitting()->make();
    $programme->suspendAdmission();
    expect($programme->status)->toBe(ProgrammeStatus::Suspended);
});
```

---

## 17. SEO Architecture

### SEO Strategy

| Technique | Implementation | When |
|-----------|---------------|------|
| Server-rendered pages | Blade templates | Always |
| Schema.org structured data | Spatie schema-org + Blade | When public UI is built |
| Sitemaps | Spatie laravel-sitemap | When public UI is built |
| Canonical URLs | Blade `<link rel="canonical">` | When public UI is built |
| Meta tags | Blade `<meta>` + Laravel Data | When public UI is built |
| Crawlable faceted navigation | URL-driven filters (not JS-only) | When search UI is built |
| Open Graph tags | Blade `<meta property="og:">` | When public UI is built |

### SEO Rule

**Every public page must be server-rendered (Blade) as the initial response.** Livewire enhances the page after first load. Search engines see the full HTML. This is the TALL stack's core SEO advantage over SPA architectures.

---

## 18. Data Ingestion Architecture (Deferred)

### Deferred to ADR-18

Data ingestion architecture is deferred to implementation. The `ImportInstitutionData` Action exists as a placeholder. The following concerns will be addressed when the first import is implemented:

- Import sources (JAMB, JAMB caps, university websites, manual entry)
- Formats (CSV, JSON, API, scraping)
- Validation pipeline (schema validation, domain validation, business rule validation)
- Deduplication strategy (matching on name + type + country, or registration identifier)
- Conflict resolution (newer-wins, manual review, trust-based)
- Provenance tracking (source attribution on every imported entity)
- Batch processing (queue-based for large imports)
- Error handling (per-row error collection, rollback strategy)
- Monitoring (progress tracking, failure alerts)

**This is not a gap — it is an intentional deferral.** The import pipeline will be designed when the first real data source is integrated, because the format and validation rules will be source-specific.

---

## 19. Performance Architecture (Deferred)

### Deferred to ADR-17

Performance architecture is deferred to implementation. The following will be addressed when production requirements are known:

- **Caching strategy:** Redis for read-model caching; model caching for frequently-accessed institutions/programmes; HTTP cache for public pages
- **Cache invalidation:** Domain event listeners invalidate relevant caches
- **Database indexing:** Index strategy defined during migration creation
- **Eager loading:** Query classes define eager-loaded relationships
- **Search index lag tolerance:** Eventually consistent — acceptable for discovery domain
- **Scalability triggers:** Define when to add caching, when to switch search engines

---

## 20. Architectural Smell Detection (Final)

| Smell | Original Status | Resolution |
|-------|----------------|------------|
| SMELL-1: Ceremonial DomainEvent interface | Must Fix | ✅ **Resolved** — Interface removed (F2) |
| SMELL-2: ReassignProgramme as Action | Must Fix | ✅ **Resolved** — Removed from Action list (F3) |
| SMELL-3: Inconsistent Action justification | Must Fix | ✅ **Resolved** — Action Criterion established; 2 Actions removed (F4) |
| SMELL-4: Namespace inconsistency | Must Fix | ✅ **Resolved** — `App\Domain\Models\` canonical (F1) |
| SMELL-5: Code review as enforcement | Fix during implementation | Acknowledged — add custom PHPStan rules during implementation (CD-5) |

**No remaining architectural smells.** All must-fix items are resolved.

---

## 21. Global Expansion Test

### Multi-Country Validation (Reconfirmed)

The model was tested against 9 countries in the architecture document. Reconfirming:

| Country | Admission Pattern | Institution Types | New Entity? | New VO? | Structural Change? |
|---------|------------------|------------------|:-----------:|:-------:|:------------------:|
| Nigeria | Cycle-based (JAMB) | University, Polytechnic, College | No | No | No |
| Ghana | Cycle-based | University, Technical University, College | No | No | No |
| Kenya | Mixed (cycle + rolling) | University, College, TVET | No | No | No |
| South Africa | Cycle-based | University, University of Technology, TVET | No | No | No |
| UK | Rolling/UCAS | University, College | No | No | No |
| US | Rolling/multiple intake | University, College, Community College | No | No | No |
| Canada | Rolling | University, College, Institute | No | No | No |
| Germany | Cycle-based (winter/summer semester) | Universität, Fachhochschule | No | No | No |
| Australia | Rolling/semester-based | University, TAFE, College | No | No | No |

**Verdict:** Zero structural changes for 9 countries. New countries require only reference data seeding (new InstitutionType enum cases, new EducationAuthority records, new Qualification records, new CountrySeeder).

### Nigeria Is First Dataset, Not Architectural Boundary

No Nigerian concept is encoded as a universal abstraction:
- JAMB is an EducationAuthority instance, not a class
- UTME is an AdmissionPathway VO instance, not a base class
- Nigerian Naira is a currency code in MonetaryAmount, not a special attribute
- Nigerian university types are InstitutionType enum cases, not a type hierarchy

---

## 22. Future Bounded Contexts

The following are identified as future bounded contexts — NOT part of the current MVP domain:

| Bounded Context | Trigger | Why Separate |
|----------------|---------|-------------|
| **Application Management** | Students need to track actual applications (not just discover opportunities) | Fundamentally different lifecycle (apply → submit → review → accept/reject); different aggregate roots; different consistency requirements |
| **Immigration & Visa** | Study Abroad requires visa/citizenship guidance | Country-pair-specific reference data; no overlap with opportunity discovery |
| **Qualification Equivalency** | International students need qualification mapping | Mapping between qualification systems; potentially complex rules; different read patterns |
| **User Profiles & Journey** | Personalized recommendations require deep user modelling | User identity, qualification history, preference learning — different consistency and privacy requirements |
| **Payment & Transactions** | Application fees, tuition payments | Financial transactions require different consistency guarantees; regulatory compliance |

**These are NOT implemented now.** They are identified so that the current architecture does not accidentally preclude them. The single-app + namespace-separation approach provides refactor seams for future extraction.

---

## 23. Implementation Readiness

### Readiness Checklist

| # | Check | Status | Blocker? | Notes |
|---|-------|:------:|:--------:|-------|
| 1 | Aggregate boundaries defined | ✅ | No | All 5 boundaries confirmed |
| 2 | Invariants specified | ✅ | No | 22 invariants across 5 aggregates |
| 3 | Domain operations specified | ✅ | No | Named methods on each aggregate |
| 4 | Value Objects classified | ✅ | No | 28 VOs with implementation strategy |
| 5 | Domain events enumerated | ✅ | No | 29 events with listeners |
| 6 | Actions identified | ✅ | No | 20 Actions with consistent justification |
| 7 | Read models specified | ✅ | No | 15 queries with implementation approach |
| 8 | Directory structure defined | ✅ | No | Namespace consistent (`App\Domain\Models\`) |
| 9 | Spatie packages evaluated | ✅ | No | 5 adopt now, 2 when ready, 5 later/evaluate, 3 rejected |
| 10 | ADRs finalized | ✅ | No | 16 Accepted, 2 Deferred |
| 11 | Testing strategy defined | ✅ | No | 4 layers with domain highest priority |
| 12 | SEO architecture defined | ✅ | No | Server-rendered + Schema.org + sitemaps |
| 13 | Dependency direction defined | ✅ | No | Clear layering with constraints |
| 14 | Filament boundary defined | ✅ | No | Admin only; domain rules outside |
| 15 | Livewire boundary defined | ✅ | No | Application UI; consumer of domain |
| 16 | Global extensibility tested | ✅ | No | 9 countries, 0 structural changes |
| 17 | Performance architecture | ⚠️ | No | Deferred to ADR-17 (not blocking) |
| 18 | Data ingestion architecture | ⚠️ | No | Deferred to ADR-18 (not blocking) |
| 19 | Security/authorization model | ⚠️ | No | Role model deferred to implementation |
| 20 | Namespace consistency | ✅ | No | Fixed (F1) |
| 21 | No unresolved contradictions | ✅ | No | All 4 must-fix corrections resolved |
| 22 | No ceremonial abstractions | ✅ | No | DomainEvent interface removed (F2) |
| 23 | No Nigeria-specific universals | ✅ | No | All Nigerian concepts are data instances |
| 24 | Study Abroad stress-tested | ✅ | No | 10/10 scenarios, 0 structural changes |
| 25 | Future education stress-tested | ✅ | No | 13/13 types fit with enum additions |

### Remaining Deferments

| # | Deferment | Impact | Trigger |
|---|-----------|--------|---------|
| D-1 | Performance/caching strategy | Infrastructure; not domain | Production performance requirements |
| D-2 | Data ingestion pipeline | Infrastructure; one Action placeholder exists | First real data source integration |
| D-3 | Admin role/permission model | Application-layer; not domain | First admin user creation |
| D-4 | Search engine selection (Typesense vs PostgreSQL FTS) | Infrastructure; not domain | Search feature implementation |
| D-5 | Queue driver (Redis vs Database) | Infrastructure; not domain | Async event processing |
| D-6 | Custom PHPStan rules | Development tooling | During implementation |
| D-7 | InstitutionType/AwardLevel enum→reference-data migration | Data model; ADR-15 documents trigger | 4th+ country requiring 3+ new types |

**None of these deferments are architectural blockers.** They are infrastructure or application-layer decisions that do not affect the domain model.

---

## 24. Final Architecture Scorecard

| Criterion | Score | Justification |
|-----------|:-----:|--------------|
| **LBC alignment** | 9/10 | Correctly pragmatic: Eloquent models with domain behaviour, 20 Actions (not 23), no repositories, no event sourcing, no CQRS. Reduced from 8→9 because Action Criterion is now explicit and consistently applied. |
| **Domain integrity** | 9/10 | Solid invariants, correct aggregate boundaries, consistent Action justification. No unresolved contradictions. |
| **Pragmatism** | 8/10 | 20 Actions (down from 23); no ceremonial interface; namespace consistent; enum tension documented. Improved from 7→8 because three sources of impragmatism removed. Remaining concern: AuthorityJurisdiction VO is marginal. |
| **Global extensibility** | 9/10 | 9 countries + 10 Study Abroad scenarios + 13 education types = zero structural changes. Enum tension documented with migration trigger. |
| **Maintainability** | 8/10 | Clean namespace separation; explicit Action Criterion; no ceremonial abstractions. Risk: if Action discipline slips, new ceremonial Actions could proliferate. |
| **Testability** | 8/10 | Domain unit tests prioritized; factory strategy still unspecified (deferred); event listener testing unspecified (deferred). |
| **TALL-stack fit** | 9/10 | Server-rendered for SEO, Livewire for interactivity, Filament for admin. React/Next.js/Vue explicitly excluded. |
| **Filament integration** | 8/10 | Boundary well-drawn; custom page specifications deferred to implementation. |
| **Spatie integration** | 8/10 | Package selection correct; timing corrected; clear distinction between architectural dependency and optional tooling. |
| **SEO suitability** | 9/10 | Thorough SEO architecture; Schema.org, sitemaps, canonical URLs, crawlable faceted navigation. |
| **Performance scalability** | 7/10 | Caching strategy deferred (ADR-17); no database index strategy yet; no eager loading strategy yet. These are infrastructure, not domain. |
| **Data ingestion** | 7/10 | Placeholder Action exists; full architecture deferred (ADR-18). Improved from 6→7 because the deferral is explicit and documented. |
| **Study Abroad extensibility** | 9/10 | 10/10 scenarios pass; future concepts identified for bounded contexts; no speculative entities. Improved from 8→9 after stress test. |
| **Complexity control** | 8/10 | 28 VOs, 20 Actions, 29 events — reduced from 23 Actions. Surface area is manageable. Each concept earns its place. |

### Overall Score: 8.4/10

Improved from 7.9/10 (validation) due to: F1 namespace fix, F2 interface removal, F3/F4 Action reduction, explicit Action Criterion, ADR-15/16 added, timing corrections, Study Abroad stress test.

---

## 25. Required Corrections (Applied)

| # | Correction | Source | Status |
|---|-----------|--------|--------|
| MF-1 | Fix namespace inconsistency | F1 | ✅ Applied |
| MF-2 | Remove DomainEvent interface | F2 | ✅ Applied |
| MF-3 | Remove ReassignProgramme from Action list | F3 | ✅ Applied |
| MF-4 | Reconcile Action justification | F4 | ✅ Applied |

### Should-Fix Corrections (Applied or Documented)

| # | Correction | Status |
|---|-----------|--------|
| SF-1 | Reduce Actions from 23 to 20 | ✅ Applied (3 removed; 2 marginal Actions retained with justification) |
| SF-2 | laravel-backup → "Adopt when deploying to production" | ✅ Applied |
| SF-3 | laravel-sitemap → "Adopt when public pages exist" | ✅ Applied |
| SF-4 | Data Ingestion architecture section | ✅ Documented (Section 18, deferred to ADR-18) |
| SF-5 | Performance/Caching architecture section | ✅ Documented (Section 19, deferred to ADR-17) |
| SF-6 | InstitutionType/AwardLevel enum tension | ✅ Documented (ADR-15) |

---

## 26. FINAL ARCHITECTURAL FREEZE

### 1. What Is Now Canonical

The following are frozen and must not be revisited without a formal ADR supersession citing concrete evidence:

| # | Frozen Decision | Canonical Form |
|---|----------------|---------------|
| F-1 | **5 aggregate roots** | Educational Institution, Programme, Scholarship, Admission Cycle, Information Source — with their invariant boundaries, domain operations, and child entity membership |
| F-2 | **No repositories** | Eloquent IS the repository; InstitutionMerger coupling documented as known seam |
| F-3 | **Eloquent models as aggregate persistence** | Domain operations are named methods on Eloquent models; no separate domain entity classes; `App\Domain\Models\*` namespace |
| F-4 | **20 Application Actions** | With explicit Action Criterion (4 conditions); no Action without meeting at least one condition |
| F-5 | **TALL stack** | Laravel + Blade + Livewire + Alpine.js + Flux + Tailwind CSS; no SPA; no React/Next.js/Vue/Inertia |
| F-6 | **Filament for admin only** | Domain rules remain outside Filament; Filament Resources invoke Actions |
| F-7 | **28 Value Objects** | 11 immutable PHP objects + 1 computed + 1 demoted entity + 15 PHP enums |
| F-8 | **29 Domain Events** | Plain PHP classes; no shared interface; no shared trait; no event sourcing |
| F-9 | **1 Domain Service** | InstitutionMerger — cross-aggregate merge coordination |
| F-10 | **3 child entities** | Admission Policy, Eligibility Policy, Accreditation Record — lifecycle controlled by parent aggregate |
| F-11 | **3 supporting entities** | Qualification, Scholarship Provider, Education Authority — reference data managed via Filament CRUD |
| F-12 | **Admission Pathway as VO** | Demoted from entity; no independent lifecycle |
| F-13 | **4 read-model queries** | isAdmitting, isApplicableTo, isReliable, isAdmissionOpen — not domain operations |
| F-14 | **Spatie package matrix** | 5 adopt now, 2 when ready, 5 later/evaluate, 3 rejected (see Section 13) |
| F-15 | **laravel-data for DTOs only** | Domain VOs = plain PHP; DTOs = Laravel Data; never the same class |
| F-16 | **laravel-model-states rejected** | PHP enums + domain methods + events are cleaner for current state machines |
| F-17 | **Single bounded context for MVP** | Namespace separation provides seams; extraction when justified |
| F-18 | **Global-first, Nigeria-first-dataset** | No Nigerian concepts as universal abstractions; all are data instances |
| F-19 | **Namespace: App\Domain\Models\*** | Canonical model namespace; `config/app.php` updated |

### 2. What Was Changed From the Previous Architecture

| Change | Before | After | Reason |
|--------|--------|-------|--------|
| Model namespace | `App\Models\*` (inconsistent) | `App\Domain\Models\*` (consistent) | F1 — namespace inconsistency |
| DomainEvent interface | `interface DomainEvent` with 4 methods | Removed; events are plain PHP classes | F2 — ceremonial abstraction |
| ReassignProgramme | Listed as Action | Removed; is domain method only | F3 — no independent invocation |
| RenameInstitution | Listed as Action | Removed; event listener handles search | F4 — inconsistent justification |
| ReactivateInstitution | Listed as Action | Removed; event listener handles search | F4 — inconsistent justification |
| Action count | 23 | 20 | F3 + F4 |
| Action Criterion | Implicit (4 informal conditions) | Explicit (4 formal conditions) | F4 — consistency |
| ADR-1 framing | "Eloquent Model as Aggregate Root Persistence" | Reframed honestly as Option C | Validation recommendation |
| ADR-3 sub-decision | Unresolved (interface vs trait vs none) | Resolved: none | F2 |
| ADR count | 14 (all Proposed) | 18 (16 Accepted, 2 Deferred) | ADR-15 through ADR-18 added |
| laravel-backup timing | "Adopt Now" | "Adopt when deploying to production" | Validation recommendation |
| laravel-sitemap timing | "Adopt Now" | "Adopt when public pages exist" | Validation recommendation |

### 3. What Remains Intentionally Deferred

| Deferment | Why | Trigger |
|-----------|-----|---------|
| Performance/caching strategy (ADR-17) | Production requirements unknown | Production performance testing |
| Data ingestion architecture (ADR-18) | Source formats unknown | First real data source integration |
| Admin role/permission model | Application-layer; not domain | First admin user creation |
| Search engine selection | Both options viable; MVP works with PostgreSQL FTS | Performance testing at scale |
| Queue driver | Both options viable; MVP works with database driver | Async event processing volume |
| Custom PHPStan rules | Development tooling; not architectural | During implementation |
| Filament custom pages | UI detail; not domain | Admin UI implementation |
| Factory strategy | Testing detail; not domain | Migration creation |

### 4. What Assumptions Remain

| Assumption | Risk if Wrong | Mitigation |
|-----------|---------------|-----------|
| PHP enums are sufficient for InstitutionType/AwardLevel | Adding many new types requires code changes | ADR-15 migration trigger defined |
| No repositories needed for MVP | Complex aggregate reconstruction becomes difficult | Known seam documented; introduce if needed |
| Eloquent models can carry domain behaviour without becoming anemic | Developers may fall back to attribute assignment | PHPStan rules + code review |
| Eventual consistency is acceptable for discovery | Users may expect real-time accuracy | Document lag tolerance; add caching if needed |
| Single bounded context is sufficient for MVP | Domain coupling increases with features | Namespace seams; extraction when justified |

### 5. What Can Only Be Changed Through a Future ADR

All frozen decisions (F-1 through F-19) require a formal ADR supersession to change. The superseding ADR must:
1. Cite the original ADR being superseded
2. Present concrete evidence (production incident, performance data, user feedback, new domain discovery)
3. Evaluate alternatives
4. Acknowledge the cost of change

Theoretical concerns alone are insufficient to supersede a frozen decision.

### 6. What Should NOT Be Revisited During Implementation Without New Domain Evidence

| Decision | Why |
|----------|-----|
| Aggregate boundaries | Survived adversarial validation + two rounds of review |
| No-repository decision | Correct for MVP; seam documented |
| Action Criterion | Explicit, consistent, applied uniformly |
| TALL stack | SEO-critical; simplicity-critical |
| DomainEvent removal | No consumer requires it; re-introduction needs evidence |
| InstitutionMerger as domain service | Correct cross-aggregate coordination |
| Admission Pathway as VO | No independent lifecycle or invariants |
| Supporting entity classification | No invariants to protect |

---

## 27. Final Verdict

```
┌──────────────────────────────────────────────────────────────────────┐
│                                                                      │
│   FROZEN WITH DOCUMENTED DEFERMENTS                                  │
│                                                                      │
│   Architecture Score: 8.4/10                                         │
│   All 4 must-fix corrections applied                                 │
│   16 ADRs Accepted, 2 ADRs Deferred                                  │
│   7 intentional deferments documented                                │
│   5 assumptions documented with mitigations                          │
│                                                                      │
│   The architecture is a stable, pragmatic baseline that is           │
│   strong enough to build against. It is not perfect — no             │
│   architecture is — but it is consistent, justified, and             │
│   explicitly aware of its limitations.                               │
│                                                                      │
│   Implementation may proceed.                                        │
│                                                                      │
│   Strongest dimensions:                                              │
│   - Domain integrity (9/10)                                          │
│   - Global extensibility (9/10)                                      │
│   - Study Abroad extensibility (9/10)                                │
│   - LBC alignment (9/10)                                             │
│   - TALL-stack fit (9/10)                                            │
│   - SEO suitability (9/10)                                           │
│                                                                      │
│   Weakest dimensions (acceptable, not blocking):                     │
│   - Performance scalability (7/10) — deferred to ADR-17             │
│   - Data ingestion (7/10) — deferred to ADR-18                      │
│   - Pragmatism (8/10) — AuthorityJurisdiction VO is marginal         │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

---

### Architectural Summary

**Stack:** Laravel + Blade + Livewire + Flux + Alpine.js + Tailwind CSS + Filament (admin)
**Philosophy:** Laravel Beyond CRUD (Pragmatic Domain-Driven Design)
**Domain:** 5 aggregate roots, 3 child entities, 3 supporting entities, 28 VOs, 29 domain events, 15 queries, 1 domain service, 22 invariants
**Application:** 20 Actions (with explicit criterion), 5 Policies
**Structure:** `App\Domain\` (models, VOs, enums, events, services, casts) + `App\Actions\` (use cases) + `App\Queries\` (reads) + `App\Data\` (DTOs) + `App\Livewire\` (public UI) + `App\Filament\` (admin UI)
**Spatie:** 5 architectural + 5 optional, 3 rejected
**No:** Repositories, Event Sourcing, CQRS framework, SPA, Microservices, Generic abstractions, DomainEvent interface, React/Next.js/Vue/Inertia
**Global:** 9 countries tested, 10 Study Abroad scenarios tested, 13 education types tested — zero structural changes
**Status:** FROZEN WITH DOCUMENTED DEFERMENTS — implementation may proceed

---

*End of Final Frozen Architectural Baseline*
