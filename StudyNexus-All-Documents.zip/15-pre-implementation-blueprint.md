# Document 24: Pre-Implementation Blueprint

**StudyNexus — From Architecture to Code: The Definitive Implementation Guide**

| Field | Value |
|---|---|
| Date | 2026-08-08 |
| Status | CANONICAL PRE-IMPLEMENTATION BLUEPRINT |
| Prerequisite | Documents 20 (Frozen Baseline), 21 (Post-Freeze Review), 22 (Ecosystem Review), 23 (Final Architecture) |
| Author | StudyNexus Architecture Team |
| Purpose | Translate every architectural decision from Documents 20–23 into concrete, sequenced, verifiable implementation steps. No design decisions remain after this document. |

> "Architecture without implementation instructions is aspiration. This document closes the gap: every namespace, every migration column, every trait method, every package version, every test class — specified. The next action after this document is `composer create-project laravel/laravel studynexus`."

---

## Table of Contents

1. Blueprint Purpose and Scope
2. Technology Stack — Exact Versions and Configuration
3. Laravel Project Scaffolding — Step-by-Step
4. Namespace Configuration — Canonical and Enforceable
5. Domain Layer — Models, Migrations, Value Objects, Enums
6. Content Layer — Models, Migrations, Traits, Enums
7. Reference Data Layer — Models, Migrations, Seeders
8. Auth and RBAC — Models, Migrations, Policies, Spatie Configuration
9. Engagement Layer — Models, Migrations, Polymorphic Relationships
10. Community Module — Models, Migrations, Actions, Queries
11. Study Abroad Module — Queries, Livewire, Reference Data
12. Search Infrastructure — Typesense Collections, Scout Configuration, Listeners
13. SEO Infrastructure — Sitemaps, Structured Data, Meta Tags, Middleware
14. Notification Infrastructure — Notification Classes, Channels, Scheduling
15. Admin Panel — Filament Resources, Pages, Widgets
16. Public Site — Controllers, Livewire Components, Blade Templates, Routes
17. Domain Events and Listeners — Complete Wiring
18. Domain Actions — Complete Wiring
19. Domain Queries — Complete Wiring
20. Feature Flags — Configuration and Middleware
21. Shared Blade Components and Design Tokens
22. Package Integration Checklist — Adopt Now (17 Packages)
23. Test Architecture — Unit, Feature, Browser
24. Database Migration Sequence — Ordered and Dependency-Aware
25. Implementation Phases — Sequenced with File Lists
26. Implementation Verification Checklist
27. Anti-Patterns and Forbidden Code
28. Architectural Drift Guards
29. Blueprint Closure

---

## 1. Blueprint Purpose and Scope

### 1.1 Why This Document Exists

Documents 20–23 produced a comprehensive, adversarially-tested architecture. But architecture is design at the namespace level. Implementation is design at the file and line level. The gap between "we need an `Article` model with `HasSlug`, `IsPublishable`, `HasSeoMeta`, `HasMedia`, `HasProvenance`, `IsSearchable` traits" and "here is the exact migration, the exact model file, the exact trait files, the exact Filament resource, the exact Blade template, the exact test class" is where projects fail. This document closes that gap.

### 1.2 What This Document IS

- **A file-by-file implementation guide.** Every file that must exist is listed with its path, its purpose, and its key contents (class signature, migration columns, trait methods, route definition, etc.).
- **A sequencing document.** Files are ordered by dependency — you cannot create a migration that references a table that does not exist yet.
- **A verification checklist.** Each phase has explicit "done when" criteria.
- **A guard against architectural drift.** Forbidden patterns, namespace import rules, and anti-patterns are explicitly enumerated.

### 1.3 What This Document Is NOT

- **Not executable code.** This is a blueprint, not a generator. Implementation still requires a developer to write code — but the design decisions are already made.
- **Not a replacement for Laravel documentation.** Standard Laravel, Filament, Livewire, and Spatie usage is not re-explained. This document specifies WHAT to build, not HOW to use the framework.
- **Not frozen.** The `Can-Evolve-Later` items from Doc 23 Section 30.2 are explicitly marked as evolvable. Everything else is must-freeze.

### 1.4 Document Conventions

| Convention | Meaning |
|---|---|
| `app/Domain/Models/Institution.php` | Exact file path relative to Laravel project root |
| `class Institution extends Model` | Class signature with parent |
| `use HasSlug, IsPublishable;` | Trait usage |
| `→ Phase 1a` | Implementation phase (see Section 25) |
| `MUST` | Non-negotiable requirement |
| `SHOULD` | Strong recommendation, deviation requires justification |
| `MAY` | Optional, implementer's choice |
| `FORBIDDEN` | Must never appear in codebase |

---

## 2. Technology Stack — Exact Versions and Configuration

### 2.1 Core Stack

| Component | Package | Version | Constraint |
|---|---|---|---|
| PHP | — | 8.3+ | `^8.3` (required for readonly promoted properties, enums, fibers) |
| Laravel | `laravel/framework` | 12.x | `^12.0` |
| PostgreSQL | — | 16+ | Primary data store (ADR-01) |
| Redis | — | 7+ | Cache + queue driver |
| Typesense | — | 29.x | Search engine (ADR-06) |
| Node.js | — | 20 LTS | Asset compilation (Vite) |

### 2.2 Frontend Stack

| Component | Package | Version | Constraint |
|---|---|---|---|
| Tailwind CSS | `tailwindcss` | 4.x | `^4.0` |
| Alpine.js | `alpinejs` | 3.x | `^3.0` (CDN or Vite) |
| Livewire | `livewire/livewire` | 3.x | `^3.0` |
| Flux | `livewire/flux` | 1.x | `^1.0` (UI component library) |

### 2.3 Admin Stack

| Component | Package | Version | Constraint |
|---|---|---|---|
| Filament | `filament/filament` | 3.x | `^3.0` |
| Tiptap | `filament/tiptap-editor` | 3.x | Rich text for content authoring |

### 2.4 Spatie/Laravel Ecosystem — Adopt Now (17 Packages)

| # | Package | Version | Purpose | Config/Provider |
|---|---|---|---|---|
| 1 | `spatie/laravel-permission` | `^6.0` | RBAC roles + permissions | `Spatie\Permission\PermissionServiceProvider` |
| 2 | `spatie/laravel-medialibrary` | `^11.0` | File/media management | `Spatie\MediaLibrary\MediaLibraryServiceProvider` |
| 3 | `spatie/laravel-tags` | `^4.0` | Taxonomy/tagging | `Spatie\Tags\TagsServiceProvider` |
| 4 | `spatie/laravel-activitylog` | `^4.0` | Audit trail | `Spatie\Activitylog\ActivitylogServiceProvider` |
| 5 | `spatie/laravel-sitemap` | `^7.0` | XML sitemaps | Auto-discovered |
| 6 | `spatie/laravel-honeypot` | `^4.0` | Spam protection | Auto-discovered |
| 7 | `spatie/laravel-backup` | `^8.0` | DB/file backup | `Spatie\Backup\BackupServiceProvider` |
| 8 | `spatie/laravel-webhook-client` | `^3.0` | Incoming webhooks | Auto-discovered |
| 9 | `spatie/laravel-personal-data-export` | `^4.0` | GDPR export | Auto-discovered |
| 10 | `maatwebsite/excel` | `^3.1` | Import/export | `Maatwebsite\Excel\ExcelServiceProvider` |
| 11 | `minimolabs/laravel-webpush` | `^1.0` | Web Push notifications | Auto-discovered |
| 12 | `laravel/socialite` | `^5.0` | Social login | `Laravel\Socialite\SocialiteServiceProvider` |
| 13 | `laravel/pulse` | `^1.0` | App monitoring | `Laravel\Pulse\PulseServiceProvider` |
| 14 | `spatie/laravel-sluggable` | `^3.0` | Slug generation | Auto-discovered |
| 15 | `spatie/laravel-searchable` | `^3.0` | Search abstraction | Auto-discovered |
| 16 | `laravel/scout` | `^10.0` | Typesense driver | `Laravel\Scout\ScoutServiceProvider` |
| 17 | `spatie/laravel-data` | `^4.0` | Data transfer objects | `Spatie\LaravelData\LaravelDataServiceProvider` |

### 2.5 Additional Packages

| Package | Version | Purpose |
|---|---|---|
| `laravel/breeze` | `^1.x` | Auth scaffolding (Blade stack) |
| `laravel/horizon` | `^5.0` | Queue dashboard (Phase 2) |
| `barryvdh/laravel-dompdf` | `^2.0` | PDF generation (if needed) |

### 2.6 Composer Scripts

```json
{
    "scripts": {
        "post-autoload-dump": [
            "Illuminate\\Foundation\\ComposerScripts::postAutoloadDump",
            "@php artisan package:discover --ansi",
            "@php artisan filament:upgrade"
        ],
        "test": "pest",
        "test:coverage": "pest --coverage",
        "analyse": "phpstan analyse",
        "format": "pint"
    }
}
```

### 2.7 Environment Configuration Template

```env
# .env — StudyNexus
APP_NAME=StudyNexus
APP_ENV=local
APP_DEBUG=true
APP_URL=http://studynexus.test

DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=studynexus
DB_USERNAME=studynexus
DB_PASSWORD=secret

CACHE_STORE=redis
QUEUE_CONNECTION=redis
SESSION_DRIVER=redis

REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

SCOUT_DRIVER=typesense
TYPESENSE_API_KEY=xyz
TYPESENSE_HOST=localhost
TYPESENSE_PORT=8108
TYPESENSE_PROTOCOL=http

# Feature Flags
FEATURE_COMMUNITY=false
FEATURE_STUDY_ABROAD=true
FEATURE_NOTIFICATIONS_WEBPUSH=false
FEATURE_NOTIFICATIONS_SMS=false
FEATURE_EXAM_PREPARATION=true
```

---

## 3. Laravel Project Scaffolding — Step-by-Step

### 3.1 Project Creation

```bash
# Step 1: Create Laravel project
composer create-project laravel/laravel studynexus "12.*"
cd studynexus

# Step 2: Install Breeze (Blade stack — no Inertia, no API)
composer require laravel/breeze --dev
php artisan breeze:install blade

# Step 3: Install all Adopt Now packages
composer require spatie/laravel-permission:^6.0
composer require spatie/laravel-medialibrary:^11.0
composer require spatie/laravel-tags:^4.0
composer require spatie/laravel-activitylog:^4.0
composer require spatie/laravel-sitemap:^7.0
composer require spatie/laravel-honeypot:^4.0
composer require spatie/laravel-backup:^8.0
composer require spatie/laravel-webhook-client:^3.0
composer require spatie/laravel-personal-data-export:^4.0
composer require maatwebsite/excel:^3.1
composer require minimolabs/laravel-webpush:^1.0
composer require laravel/socialite:^5.0
composer require laravel/pulse:^1.0
composer require spatie/laravel-sluggable:^3.0
composer require spatie/laravel-searchable:^3.0
composer require laravel/scout:^10.0
composer require spatie/laravel-data:^4.0

# Step 4: Install Filament
composer require filament/filament:"^3.0"

# Step 5: Install Filament Tiptap Editor
composer require filament/tiptap-editor:"^3.0"

# Step 6: Install dev tooling
composer require --dev laravel/telescope phpstan/phpstan laravel/pint pestphp/pest

# Step 7: Install frontend
npm install -D tailwindcss@4 alpinejs@3
npm install livewire@3 @livewire/flux
```

### 3.2 Directory Creation (Architectural Skeleton)

```bash
# Domain layer
mkdir -p app/Domain/{Models,ValueObjects,Enums,Events,Actions,Queries,Services,Invariants,Casts,Exceptions}

# Domain Actions sub-directories
mkdir -p app/Domain/Actions/{Institutions,Programmes,Scholarships,AdmissionCycles,InformationSources,Imports,Scheduled}

# Domain Queries sub-directories
mkdir -p app/Domain/Queries/{Institutions,Programmes,Scholarships,AdmissionCycles,InformationSources,Opportunities}

# Content layer
mkdir -p app/Content/{Models,Concerns,Enums,Actions,Queries}

# Reference data layer
mkdir -p app/Reference/Models

# Community module
mkdir -p app/Community/{Models,Actions,Queries}

# Study Abroad module
mkdir -p app/StudyAbroad/{Queries,Livewire}

# Product/presentation layer
mkdir -p app/Product/{Livewire,ValueObjects}

# Search infrastructure
mkdir -p app/Search/{Indexers,Listeners}

# SEO infrastructure
mkdir -p app/SEO/{Sitemaps,StructuredData}

# Admin panel
mkdir -p app/Admin/Filament/{Resources,Pages}

# Notifications
mkdir -p app/Notifications

# Policies
mkdir -p app/Policies

# Custom middleware
mkdir -p app/Http/Middleware

# Livewire components
mkdir -p app/Livewire/{Public,Authenticated}

# Blade components
mkdir -p resources/views/components/{seo,domain,content,product,community}

# Feature flags config
touch config/features.php

# Test directories
mkdir -p tests/{Unit/Domain,Feature/Actions,Feature/Queries,Feature/Livewire,Browser}
```

### 3.3 Namespace Configuration

```php
// config/app.php — Override default model namespace
'models_namespace' => 'App\\Domain\\Models',
```

This ensures Laravel's factory and policy resolution uses `App\Domain\Models\` as the canonical namespace.

---

## 4. Namespace Configuration — Canonical and Enforceable

### 4.1 Namespace Map

| Namespace | Base Path | Layer | May Import From | May NOT Import From |
|---|---|---|---|---|
| `App\Domain` | `app/Domain/` | Domain | `App\Domain` only | Content, Community, StudyAbroad, Product, Search, SEO, Reference |
| `App\Content` | `app/Content/` | Content | `App\Content`, `App\Domain`, `App\Reference` | Community, StudyAbroad, Product, Search, SEO |
| `App\Community` | `app/Community/` | Community | `App\Community`, `App\Domain` | Content, StudyAbroad, Product, Search, SEO |
| `App\StudyAbroad` | `app/StudyAbroad/` | StudyAbroad | `App\StudyAbroad`, `App\Domain`, `App\Content`, `App\Reference` | Community, Product, Search, SEO |
| `App\Reference` | `app/Reference/` | Reference | `App\Reference` only | Domain, Content, Community, Product, Search, SEO |
| `App\Product` | `app/Product/` | Product | `App\Product`, `App\Domain`, `App\Content`, `App\Reference` | Community, Search, SEO |
| `App\Search` | `app/Search/` | Search | `App\Search`, `App\Domain`, `App\Content` | Community, Product, SEO |
| `App\SEO` | `app/SEO/` | SEO | `App\SEO`, `App\Domain`, `App\Content` | Community, Product, Search |
| `App\Admin` | `app/Admin/` | Admin | All namespaces | — |
| `App\Http` | `app/Http/` | HTTP | All namespaces | — |
| `App\Notifications` | `app/Notifications/` | Notifications | `App\Domain`, `App\Content` | — |
| `App\Policies` | `app/Policies/` | Policies | `App\Domain`, `App\Content` | — |

### 4.2 Domain Purity Rule

```php
// FORBIDDEN: Any file in App\Domain\ that imports from outside App\Domain\
// This is the single most important architectural invariant.

// CORRECT:
namespace App\Domain\Models;
use App\Domain\ValueObjects\Country;
use App\Domain\Enums\InstitutionType;

// WRONG:
namespace App\Domain\Models;
use App\Content\Models\Article; // VIOLATION — Domain must not know about Content
```

### 4.3 Future Enforcement (Deferred)

A PHPStan custom rule to enforce namespace import boundaries is deferred to Phase 1a implementation. Until then, enforcement is by code review and convention.

---

## 5. Domain Layer — Models, Migrations, Value Objects, Enums

### 5.1 Aggregate Root Migrations

#### `database/migrations/2024_01_01_000001_create_institutions_table.php`

```php
Schema::create('institutions', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('slug')->unique();
    $table->string('type');              // InstitutionType enum
    $table->string('ownership_type');     // InstitutionOwnership enum
    $table->string('status');             // InstitutionStatus enum
    $table->string('country_code', 2);   // ISO 3166-1 alpha-2
    $table->string('state')->nullable();
    $table->string('city')->nullable();
    $table->json('address')->nullable();  // Address VO (JSON cast)
    $table->json('coordinates')->nullable(); // GeographicCoordinates VO
    $table->json('contact_info')->nullable(); // ContactInfo VO
    $table->year('founded_year')->nullable();
    $table->text('description')->nullable();
    $table->string('website_url')->nullable();
    $table->unsignedInteger('programme_count')->default(0);  // Counter cache
    $table->unsignedInteger('save_count')->default(0);
    $table->unsignedInteger('follow_count')->default(0);
    $table->unsignedInteger('like_count')->default(0);
    $table->timestamps();
    $table->softDeletes();

    $table->index(['status', 'country_code']);
    $table->index('slug');
});
```

#### `database/migrations/2024_01_01_000002_create_programmes_table.php`

```php
Schema::create('programmes', function (Blueprint $table) {
    $table->id();
    $table->foreignId('institution_id')->constrained()->cascadeOnDelete();
    $table->string('name');
    $table->string('slug');
    $table->string('award_type');         // AwardType enum
    $table->string('level');              // ProgrammeLevel enum
    $table->string('status');             // ProgrammeStatus enum
    $table->string('mode_of_study');      // ModeOfStudy enum
    $table->json('duration')->nullable(); // Duration VO
    $table->string('discipline')->nullable(); // Discipline enum
    $table->text('description')->nullable();
    $table->json('tuition_range')->nullable(); // Money VO (min + max + currency)
    $table->unsignedInteger('save_count')->default(0);
    $table->unsignedInteger('follow_count')->default(0);
    $table->unsignedInteger('like_count')->default(0);
    $table->timestamps();
    $table->softDeletes();

    $table->unique(['institution_id', 'slug']); // Programme slug unique within institution
    $table->index(['status', 'institution_id']);
    $table->index('slug');
});
```

#### `database/migrations/2024_01_01_000003_create_scholarships_table.php`

```php
Schema::create('scholarships', function (Blueprint $table) {
    $table->id();
    $table->foreignId('institution_id')->nullable()->constrained()->nullOnDelete();
    $table->foreignId('scholarship_provider_id')->nullable()->constrained()->nullOnDelete();
    $table->string('title');
    $table->string('slug')->unique();
    $table->string('status');              // ScholarshipStatus enum
    $table->string('category');            // ScholarshipCategory enum
    $table->json('amount')->nullable();    // ScholarshipAmount VO
    $table->string('coverage_type')->nullable(); // CoverageType enum
    $table->text('description')->nullable();
    $table->text('eligibility_summary')->nullable();
    $table->timestamp('application_opens_at')->nullable();
    $table->timestamp('application_closes_at')->nullable();
    $table->unsignedInteger('save_count')->default(0);
    $table->unsignedInteger('follow_count')->default(0);
    $table->unsignedInteger('like_count')->default(0);
    $table->timestamps();
    $table->softDeletes();

    $table->index(['status', 'application_closes_at']);
    $table->index('slug');
});
```

#### `database/migrations/2024_01_01_000004_create_scholarship_programme_table.php`

```php
Schema::create('scholarship_programme', function (Blueprint $table) {
    $table->id();
    $table->foreignId('scholarship_id')->constrained()->cascadeOnDelete();
    $table->foreignId('programme_id')->constrained()->cascadeOnDelete();
    $table->timestamps();

    $table->unique(['scholarship_id', 'programme_id']);
});
```

#### `database/migrations/2024_01_01_000005_create_admission_cycles_table.php`

```php
Schema::create('admission_cycles', function (Blueprint $table) {
    $table->id();
    $table->foreignId('institution_id')->nullable()->constrained()->nullOnDelete();
    $table->foreignId('education_authority_id')->nullable()->constrained()->nullOnDelete();
    $table->string('name');
    $table->string('slug');
    $table->string('status');              // CycleStatus enum
    $table->json('phases');                // PhaseSequence VO (JSON cast)
    $table->string('current_phase')->nullable();
    $table->timestamp('opens_at')->nullable();
    $table->timestamp('closes_at')->nullable();
    $table->timestamp('results_at')->nullable();
    $table->text('description')->nullable();
    $table->timestamps();
    $table->softDeletes();

    $table->index(['status', 'institution_id']);
});
```

#### `database/migrations/2024_01_01_000006_create_admission_policies_table.php`

```php
Schema::create('admission_policies', function (Blueprint $table) {
    $table->id();
    $table->string('policyable_type');     // MorphTo: Institution or Programme
    $table->unsignedBigInteger('policyable_id');
    $table->foreignId('admission_cycle_id')->constrained()->cascadeOnDelete();
    $table->string('pathway');             // AdmissionPathway enum
    $table->string('status');              // PolicyStatus enum
    $table->json('rules');                 // AdmissionRule[] VO (JSON cast)
    $table->text('description')->nullable();
    $table->timestamps();

    $table->morphsIndex('policyable');
});
```

#### `database/migrations/2024_01_01_000007_create_eligibility_policies_table.php`

```php
Schema::create('eligibility_policies', function (Blueprint $table) {
    $table->id();
    $table->string('eligibletable_type');  // MorphTo: Scholarship, Programme, or AdmissionCycle
    $table->unsignedBigInteger('eligibletable_id');
    $table->string('qualification_type');  // QualificationType enum
    $table->json('criteria');              // EligibilityCriterion[] VO (JSON cast)
    $table->text('description')->nullable();
    $table->timestamps();

    $table->morphsIndex('eligibletable');
});
```

#### `database/migrations/2024_01_01_000008_create_accreditation_records_table.php`

```php
Schema::create('accreditation_records', function (Blueprint $table) {
    $table->id();
    $table->string('accreditable_type');   // MorphTo: Institution or Programme
    $table->unsignedBigInteger('accreditable_id');
    $table->foreignId('education_authority_id')->constrained()->cascadeOnDelete();
    $table->string('status');              // AccreditationStatus enum
    $table->string('programme_name')->nullable(); // For programme-specific accreditation
    $table->json('validity_period')->nullable(); // ValidityPeriod VO
    $table->date('accredited_at');
    $table->date('expires_at')->nullable();
    $table->timestamps();

    $table->morphsIndex('accreditable');
});
```

#### `database/migrations/2024_01_01_000009_create_information_sources_table.php`

```php
Schema::create('information_sources', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('type');                // SourceType enum
    $table->string('verification_status'); // SourceVerificationStatus enum
    $table->string('url')->nullable();
    $table->text('contact_details')->nullable();
    $table->text('notes')->nullable();
    $table->timestamp('verified_at')->nullable();
    $table->timestamps();
    $table->softDeletes();

    $table->index('verification_status');
});
```

### 5.2 Supporting Entity Migrations

#### `database/migrations/2024_01_01_000010_create_qualifications_table.php`

```php
Schema::create('qualifications', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('type');                // QualificationType enum
    $table->string('country_code', 2);
    $table->string('status')->default('active');
    $table->text('description')->nullable();
    $table->timestamps();
    $table->softDeletes();

    $table->index(['type', 'country_code']);
});
```

#### `database/migrations/2024_01_01_000011_create_scholarship_providers_table.php`

```php
Schema::create('scholarship_providers', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('type');                // ProviderType enum
    $table->string('country_code', 2)->nullable();
    $table->string('website_url')->nullable();
    $table->text('description')->nullable();
    $table->timestamps();
    $table->softDeletes();
});
```

#### `database/migrations/2024_01_01_000012_create_education_authorities_table.php`

```php
Schema::create('education_authorities', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    $table->string('type');                // AuthorityType enum
    $table->string('country_code', 2);
    $table->json('jurisdiction');          // AuthorityJurisdiction VO
    $table->string('website_url')->nullable();
    $table->timestamps();
    $table->softDeletes();

    $table->index(['type', 'country_code']);
});
```

### 5.3 Domain Model Signatures

#### `app/Domain/Models/Institution.php`

```php
namespace App\Domain\Models;

use App\Domain\Enums\{InstitutionType, InstitutionOwnership, InstitutionStatus};
use App\Domain\ValueObjects\{Address, ContactInfo, GeographicCoordinates, Country};
use App\Domain\Casts\{LocationCast, MonetaryAmountCast};
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{HasMany, MorphMany};
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\Tags\HasTags;
use Spatie\Activitylog\Traits\LogsActivity;

class Institution extends Model implements HasMedia
{
    use InteractsWithMedia, HasTags, LogsActivity;

    protected $casts = [
        'type' => InstitutionType::class,
        'ownership_type' => InstitutionOwnership::class,
        'status' => InstitutionStatus::class,
        'address' => LocationCast::class,
        'coordinates' => 'array', // GeographicCoordinates
        'contact_info' => 'array', // ContactInfo
    ];

    // Domain operations (called from Actions or directly per Action Criterion)
    public function establish(): void { /* ... */ }
    public function rename(string $newName): void { /* ... */ }
    public function suspend(): void { /* ... */ }
    public function reactivate(): void { /* ... */ }
    public function close(): void { /* ... */ }
    public function publishAdmissionPolicy(AdmissionPolicy $policy): void { /* ... */ }
    public function recordAccreditation(AccreditationRecord $record): void { /* ... */ }

    // Relationships
    public function programmes(): HasMany { /* ... */ }
    public function admissionPolicies(): MorphMany { /* ... */ }
    public function accreditationRecords(): MorphMany { /* ... */ }
    public function admissionCycles(): HasMany { /* ... */ }
}
```

#### `app/Domain/Models/Programme.php`

```php
namespace App\Domain\Models;

use App\Domain\Enums\{AwardType, ProgrammeLevel, ProgrammeStatus, ModeOfStudy, Discipline};
use App\Domain\ValueObjects\{Duration, Money};
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, MorphMany};
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Programme extends Model implements HasMedia
{
    use InteractsWithMedia;

    protected $casts = [
        'award_type' => AwardType::class,
        'level' => ProgrammeLevel::class,
        'status' => ProgrammeStatus::class,
        'mode_of_study' => ModeOfStudy::class,
        'duration' => 'array', // Duration VO
        'tuition_range' => 'array', // Money range
    ];

    // Domain operations
    public function introduce(): void { /* ... */ }
    public function suspendAdmission(): void { /* ... */ }
    public function resumeAdmission(): void { /* ... */ }
    public function discontinue(): void { /* ... */ }
    public function reassignTo(int $newInstitutionId): void { /* ... */ }
    public function publishAdmissionPolicy(AdmissionPolicy $policy): void { /* ... */ }

    // URL accessor
    public function getUrlAttribute(): string
    {
        return "/institutions/{$this->institution->slug}/programmes/{$this->slug}";
    }

    // Relationships
    public function institution(): BelongsTo { /* ... */ }
    public function admissionPolicies(): MorphMany { /* ... */ }
    public function accreditationRecords(): MorphMany { /* ... */ }
}
```

#### `app/Domain/Models/Scholarship.php`

```php
namespace App\Domain\Models;

use App\Domain\Enums\{ScholarshipStatus, ScholarshipCategory};
use App\Domain\ValueObjects\{ScholarshipAmount, Money};
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{BelongsTo, BelongsToMany, MorphMany};

class Scholarship extends Model
{
    protected $casts = [
        'status' => ScholarshipStatus::class,
        'category' => ScholarshipCategory::class,
        'amount' => 'array', // ScholarshipAmount VO
    ];

    // Domain operations
    public function announce(): void { /* ... */ }
    public function openApplications(): void { /* ... */ }
    public function closeApplications(): void { /* ... */ }
    public function withdraw(): void { /* ... */ }
    public function expire(): void { /* ... */ }
    public function targetProgrammes(array $programmeIds): void { /* ... */ }

    // Relationships
    public function institution(): BelongsTo { /* ... */ }
    public function scholarshipProvider(): BelongsTo { /* ... */ }
    public function programmes(): BelongsToMany { /* ... */ }
    public function eligibilityPolicies(): MorphMany { /* ... */ }
}
```

#### `app/Domain/Models/AdmissionCycle.php`, `InformationSource.php`, `AdmissionPolicy.php`, `EligibilityPolicy.php`, `AccreditationRecord.php`, `Qualification.php`, `ScholarshipProvider.php`, `EducationAuthority.php`

(These follow the same pattern: Eloquent model with enum casts, VO casts, domain operations as named methods, and relationships. Full signatures follow the patterns established above and in Doc 20 Section 26.)

### 5.4 Value Objects

| # | File | Class | Cast | Equality |
|---|---|---|---|---|
| 1 | `app/Domain/ValueObjects/Address.php` | `Address` (readonly) | `LocationCast` | Value equality |
| 2 | `app/Domain/ValueObjects/AdmissionRule.php` | `AdmissionRule` (readonly) | `AdmissionRuleCast` | Value equality |
| 3 | `app/Domain/ValueObjects/AdmissionStatus.php` | `AdmissionStatus` (computed) | None (not persisted) | Value equality |
| 4 | `app/Domain/ValueObjects/ContactInfo.php` | `ContactInfo` (readonly) | `array` cast | Value equality |
| 5 | `app/Domain/ValueObjects/Country.php` | `Country` (readonly, demoted entity) | `string` cast (ISO 3166-1 alpha-2) | Value equality |
| 6 | `app/Domain/ValueObjects/Currency.php` | `Currency` (readonly) | `string` cast (ISO 4217) | Value equality |
| 7 | `app/Domain/ValueObjects/Duration.php` | `Duration` (readonly: value + unit) | `array` cast | Value equality |
| 8 | `app/Domain/ValueObjects/EligibilityCriterion.php` | `EligibilityCriterion` (readonly) | `array` cast | Value equality |
| 9 | `app/Domain/ValueObjects/GeographicCoordinates.php` | `GeographicCoordinates` (readonly: lat + lng) | `array` cast | Value equality |
| 10 | `app/Domain/ValueObjects/Money.php` | `Money` (readonly: amount + currency) | `MonetaryAmountCast` | Value equality |
| 11 | `app/Domain/ValueObjects/ScholarshipAmount.php` | `ScholarshipAmount` (extends Money with coverage) | `MonetaryAmountCast` | Value equality |

All value objects are `readonly class` with constructor-promoted properties. No setters. Equality via `isSameAs()` method or `__toString()`.

### 5.5 Domain Enums

| # | File | Enum | Type | Values |
|---|---|---|---|---|
| 1 | `app/Domain/Enums/InstitutionType.php` | `InstitutionType` | `string` | University, Polytechnic, CollegeOfEducation, Monotechnic, InnovationEnterprise, SecondarySchool, Vocational, Other |
| 2 | `app/Domain/Enums/InstitutionOwnership.php` | `InstitutionOwnership` | `string` | Federal, State, Private, Religious, Military, Other |
| 3 | `app/Domain/Enums/InstitutionStatus.php` | `InstitutionStatus` | `string` | Operational, Suspended, Closed |
| 4 | `app/Domain/Enums/AwardType.php` | `AwardType` | `string` | BSc, BA, BEng, BTech, MSc, MA, PhD, ND, HND, NCE, Diploma, Certificate, Other |
| 5 | `app/Domain/Enums/ProgrammeLevel.php` | `ProgrammeLevel` | `string` | Undergraduate, Postgraduate, Doctoral, Diploma, Certificate |
| 6 | `app/Domain/Enums/ProgrammeStatus.php` | `ProgrammeStatus` | `string` | Active, AdmissionSuspended, Discontinued |
| 7 | `app/Domain/Enums/ModeOfStudy.php` | `ModeOfStudy` | `string` | FullTime, PartTime, Distance, Online, Sandwich, Other |
| 8 | `app/Domain/Enums/Discipline.php` | `Discipline` | `string` | Engineering, Medicine, Law, Business, Education, Sciences, Arts, Agriculture, Other |
| 9 | `app/Domain/Enums/ScholarshipStatus.php` | `ScholarshipStatus` | `string` | Announced, ApplicationsOpen, ApplicationsClosed, Withdrawn, Expired |
| 10 | `app/Domain/Enums/ScholarshipCategory.php` | `ScholarshipCategory` | `string` | Merit, NeedBased, Athletic, Research, Government, Corporate, International, Other |
| 11 | `app/Domain/Enums/CycleStatus.php` | `CycleStatus` | `string` | Announced, Active, Closed, Archived |
| 12 | `app/Domain/Enums/AccreditationStatus.php` | `AccreditationStatus` | `string` | Full, Interim, Denied, Revoked, NotAccredited |
| 13 | `app/Domain/Enums/AdmissionPathway.php` | `AdmissionPathway` | `string` | UTME, DirectEntry, PostUTME, International, Transfer, Other |
| 14 | `app/Domain/Enums/QualificationType.php` | `QualificationType` | `string` | OLevel, ALevel, ND, HND, Bachelors, Masters, PhD, SAT, IB, Other |
| 15 | `app/Domain/Enums/SourceType.php` | `SourceType` | `string` | Official, Media, Community, Research, Government, Other |
| 16 | `app/Domain/Enums/SourceVerificationStatus.php` | `SourceVerificationStatus` | `string` | Unverified, Verified, Unreliable, Deprecated |

### 5.6 Domain Events (29)

All events are plain PHP classes (no shared interface — F2 correction from Doc 20).

| # | File | Event | Payload | Listeners |
|---|---|---|---|---|
| 1 | `app/Domain/Events/InstitutionEstablished.php` | InstitutionEstablished | institutionId, name, type | UpdateSearchIndex, LogActivity |
| 2 | `app/Domain/Events/InstitutionRenamed.php` | InstitutionRenamed | institutionId, oldName, newName | UpdateSearchIndex, LogActivity |
| 3 | `app/Domain/Events/InstitutionSuspended.php` | InstitutionSuspended | institutionId | UpdateSearchIndex, ProgrammeStatusCascade |
| 4 | `app/Domain/Events/InstitutionReactivated.php` | InstitutionReactivated | institutionId | UpdateSearchIndex, ProgrammeStatusRestore |
| 5 | `app/Domain/Events/InstitutionClosed.php` | InstitutionClosed | institutionId | UpdateSearchIndex, ProgrammeDiscontinueCascade, ScholarshipFlag |
| 6 | `app/Domain/Events/InstitutionsMerged.php` | InstitutionsMerged | survivingId, absorbedId | SearchRebuild, ProgrammeReassignment |
| 7 | `app/Domain/Events/InstitutionAccredited.php` | InstitutionAccredited | institutionId, authorityId, status | TrustSignal, UpdateSearchIndex |
| 8 | `app/Domain/Events/ProgrammeIntroduced.php` | ProgrammeIntroduced | programmeId, institutionId | UpdateSearchIndex, LogActivity |
| 9 | `app/Domain/Events/ProgrammeAdmissionSuspended.php` | ProgrammeAdmissionSuspended | programmeId | UpdateSearchIndex |
| 10 | `app/Domain/Events/ProgrammeAdmissionResumed.php` | ProgrammeAdmissionResumed | programmeId | UpdateSearchIndex |
| 11 | `app/Domain/Events/ProgrammeDiscontinued.php` | ProgrammeDiscontinued | programmeId | UpdateSearchIndex, ScholarshipFlag |
| 12 | `app/Domain/Events/ProgrammeAccredited.php` | ProgrammeAccredited | programmeId, authorityId | TrustSignal, UpdateSearchIndex |
| 13 | `app/Domain/Events/ScholarshipAnnounced.php` | ScholarshipAnnounced | scholarshipId | UpdateSearchIndex, CandidateNotification |
| 14 | `app/Domain/Events/ScholarshipApplicationsOpened.php` | ScholarshipApplicationsOpened | scholarshipId | UpdateSearchIndex, CandidateNotification |
| 15 | `app/Domain/Events/ScholarshipApplicationsClosed.php` | ScholarshipApplicationsClosed | scholarshipId | UpdateSearchIndex |
| 16 | `app/Domain/Events/ScholarshipWithdrawn.php` | ScholarshipWithdrawn | scholarshipId | UpdateSearchIndex, ApplicantNotification |
| 17 | `app/Domain/Events/ScholarshipExpired.php` | ScholarshipExpired | scholarshipId | UpdateSearchIndex |
| 18 | `app/Domain/Events/ScholarshipTargetsUpdated.php` | ScholarshipTargetsUpdated | scholarshipId | UpdateSearchIndex |
| 19 | `app/Domain/Events/AdmissionCycleAnnounced.php` | AdmissionCycleAnnounced | cycleId, institutionId | UpdateSearchIndex |
| 20 | `app/Domain/Events/AdmissionCycleActivated.php` | AdmissionCycleActivated | cycleId | ReadModelUpdate |
| 21 | `app/Domain/Events/AdmissionCyclePhaseAdvanced.php` | AdmissionCyclePhaseAdvanced | cycleId, fromPhase, toPhase | ReadModelUpdate, NotificationDispatch |
| 22 | `app/Domain/Events/AdmissionCycleClosed.php` | AdmissionCycleClosed | cycleId | ReadModelUpdate |
| 23 | `app/Domain/Events/InformationSourceVerified.php` | InformationSourceVerified | sourceId | TrustSignalRecalc |
| 24 | `app/Domain/Events/InformationSourceMarkedUnreliable.php` | InformationSourceMarkedUnreliable | sourceId | TrustSignalRecalc |
| 25 | `app/Domain/Events/InformationSourceDeprecated.php` | InformationSourceDeprecated | sourceId | TrustSignalCascade, DataProvenanceFlag |
| 26 | `app/Domain/Events/QualificationDeprecated.php` | QualificationDeprecated | qualificationId | PolicyCreationGuard |
| 27–29 | (Admission policy published events for Institution, Programme, Scholarship) | — | — | UpdateSearchIndex, OpportunityFeed |

### 5.7 Domain Actions (20)

| # | File | Action | Phase | Entry Points |
|---|---|---|---|---|
| 1 | `app/Domain/Actions/Institutions/CreateInstitution.php` | CreateInstitution | 1a | HTTP, Filament, Import |
| 2 | `app/Domain/Actions/Institutions/SuspendInstitution.php` | SuspendInstitution | 1a | HTTP, Filament |
| 3 | `app/Domain/Actions/Institutions/CloseInstitution.php` | CloseInstitution | 1a | HTTP, Filament |
| 4 | `app/Domain/Actions/Institutions/MergeInstitutions.php` | MergeInstitutions | 1a | Filament |
| 5 | `app/Domain/Actions/Programmes/CreateProgramme.php` | CreateProgramme | 1a | HTTP, Filament, Import |
| 6 | `app/Domain/Actions/Programmes/DiscontinueProgramme.php` | DiscontinueProgramme | 1a | HTTP, Filament |
| 7 | `app/Domain/Actions/Programmes/PublishAdmissionPolicy.php` | PublishAdmissionPolicy | 1a | HTTP, Filament |
| 8 | `app/Domain/Actions/Programmes/RecordAccreditation.php` | RecordAccreditation | 1a | Filament |
| 9 | `app/Domain/Actions/Scholarships/AnnounceScholarship.php` | AnnounceScholarship | 1a | HTTP, Filament |
| 10 | `app/Domain/Actions/Scholarships/OpenScholarshipApplications.php` | OpenScholarshipApplications | 1a | Filament, Scheduler |
| 11 | `app/Domain/Actions/Scholarships/ExpireScholarship.php` | ExpireScholarship | 1a | Scheduler |
| 12 | `app/Domain/Actions/Scholarships/TargetScholarshipProgrammes.php` | TargetScholarshipProgrammes | 1a | Filament |
| 13 | `app/Domain/Actions/AdmissionCycles/AnnounceAdmissionCycle.php` | AnnounceAdmissionCycle | 1a | Filament |
| 14 | `app/Domain/Actions/AdmissionCycles/ActivateAdmissionCycle.php` | ActivateAdmissionCycle | 1a | HTTP, Filament, Scheduler |
| 15 | `app/Domain/Actions/AdmissionCycles/AdvanceAdmissionCyclePhase.php` | AdvanceAdmissionCyclePhase | 1a | Filament, Scheduler |
| 16 | `app/Domain/Actions/InformationSources/RegisterInformationSource.php` | RegisterInformationSource | 1a | Filament, Import |
| 17 | `app/Domain/Actions/InformationSources/VerifyInformationSource.php` | VerifyInformationSource | 1a | Filament |
| 18 | `app/Domain/Actions/InformationSources/MarkSourceUnreliable.php` | MarkSourceUnreliable | 1a | Filament |
| 19 | `app/Domain/Actions/Imports/ImportInstitutionData.php` | ImportInstitutionData | 1a | Filament, Console |
| 20 | `app/Domain/Actions/Scheduled/ExpireScholarships.php` | ExpireScholarships | 1a | Scheduler |

### 5.8 Domain Queries (15)

| # | File | Query | Phase |
|---|---|---|---|
| 1 | `app/Domain/Queries/Institutions/GetInstitutionDetails.php` | GetInstitutionDetails | 1a |
| 2 | `app/Domain/Queries/Institutions/SearchInstitutions.php` | SearchInstitutions | 1e |
| 3 | `app/Domain/Queries/Institutions/GetInstitutionAccreditationStatus.php` | GetInstitutionAccreditationStatus | 1a |
| 4 | `app/Domain/Queries/Institutions/GetInstitutionsByIds.php` | GetInstitutionsByIds | 2c |
| 5 | `app/Domain/Queries/Programmes/GetProgrammeDetails.php` | GetProgrammeDetails | 1a |
| 6 | `app/Domain/Queries/Programmes/IsProgrammeAdmitting.php` | IsProgrammeAdmitting | 1c |
| 7 | `app/Domain/Queries/Programmes/SearchProgrammes.php` | SearchProgrammes | 1e |
| 8 | `app/Domain/Queries/Scholarships/GetScholarshipDetails.php` | GetScholarshipDetails | 1a |
| 9 | `app/Domain/Queries/Scholarships/IsScholarshipApplicableTo.php` | IsScholarshipApplicableTo | 1c |
| 10 | `app/Domain/Queries/Scholarships/SearchScholarships.php` | SearchScholarships | 1e |
| 11 | `app/Domain/Queries/AdmissionCycles/IsAdmissionOpen.php` | IsAdmissionOpen | 1c |
| 12 | `app/Domain/Queries/AdmissionCycles/GetCurrentCyclePhase.php` | GetCurrentCyclePhase | 1c |
| 13 | `app/Domain/Queries/InformationSources/IsSourceReliable.php` | IsSourceReliable | 1a |
| 14 | `app/Domain/Queries/InformationSources/GetTrustSignal.php` | GetTrustSignal | 1c |
| 15 | `app/Domain/Queries/Opportunities/GetOpportunityFeed.php` | GetOpportunityFeed | 1c |

### 5.9 Domain Services (1)

| File | Service | Purpose |
|---|---|---|
| `app/Domain/Services/InstitutionMerger.php` | InstitutionMerger | Cross-aggregate merge: loads 2 Institution aggregates + all their Programmes, reassigns programmes, fires InstitutionsMerged event. Called by `MergeInstitutions` Action. |

### 5.10 Domain Exceptions (3)

| File | Exception | Purpose |
|---|---|---|
| `app/Domain/Exceptions/InvalidStateTransitionException.php` | InvalidStateTransitionException | Thrown when a lifecycle operation is invoked in the wrong state |
| `app/Domain/Exceptions/InvariantViolationException.php` | InvariantViolationException | Thrown when a domain invariant would be violated |
| `app/Domain/Exceptions/InstitutionMergeException.php` | InstitutionMergeException | Thrown when merge preconditions are not met |

---

## 6. Content Layer — Models, Migrations, Traits, Enums

### 6.1 Content Migrations

#### `database/migrations/2024_01_01_000020_create_articles_table.php`

```php
Schema::create('articles', function (Blueprint $table) {
    $table->id();
    $table->string('title');
    $table->string('slug')->unique();
    $table->string('status');              // ContentStatus enum
    $table->text('body')->nullable();
    $table->string('category')->nullable();
    $table->string('news_source')->nullable();
    $table->boolean('is_breaking')->default(false);
    $table->timestamp('published_at')->nullable();
    $table->string('seo_title')->nullable();
    $table->string('seo_description')->nullable();
    $table->string('canonical_url')->nullable();
    $table->boolean('noindex')->default(false);
    $table->string('author_name')->nullable();
    $table->string('source_url')->nullable();
    $table->string('domain_entity_type')->nullable(); // Polymorphic: Institution, Programme, Scholarship
    $table->unsignedBigInteger('domain_entity_id')->nullable();
    $table->unsignedBigInteger('institution_id')->nullable(); // Explicit FK for hot path
    $table->json('meta')->nullable();
    $table->unsignedInteger('save_count')->default(0);
    $table->unsignedInteger('like_count')->default(0);
    $table->timestamps();
    $table->softDeletes();

    $table->index(['status', 'published_at']);
    $table->index('slug');
    $table->index('institution_id');
    $table->morphsIndex('domain_entity');
});
```

#### `database/migrations/2024_01_01_000021_create_guides_table.php`

```php
Schema::create('guides', function (Blueprint $table) {
    $table->id();
    $table->string('title');
    $table->string('slug')->unique();
    $table->string('status');
    $table->text('body')->nullable();
    $table->string('category')->nullable();
    $table->unsignedInteger('reading_time_minutes')->nullable();
    $table->unsignedInteger('section_count')->default(0);
    $table->timestamp('published_at')->nullable();
    $table->string('seo_title')->nullable();
    $table->string('seo_description')->nullable();
    $table->string('canonical_url')->nullable();
    $table->boolean('noindex')->default(false);
    $table->string('author_name')->nullable();
    $table->string('source_url')->nullable();
    $table->string('domain_entity_type')->nullable();
    $table->unsignedBigInteger('domain_entity_id')->nullable();
    $table->unsignedBigInteger('institution_id')->nullable();
    $table->json('meta')->nullable();
    $table->unsignedInteger('save_count')->default(0);
    $table->unsignedInteger('like_count')->default(0);
    $table->timestamps();
    $table->softDeletes();

    $table->index(['status', 'published_at']);
    $table->index('slug');
    $table->index('institution_id');
});
```

#### `database/migrations/2024_01_01_000022_create_guide_sections_table.php`

```php
Schema::create('guide_sections', function (Blueprint $table) {
    $table->id();
    $table->foreignId('guide_id')->constrained()->cascadeOnDelete();
    $table->string('title');
    $table->text('body')->nullable();
    $table->unsignedInteger('sort_order')->default(0);
    $table->timestamps();

    $table->index(['guide_id', 'sort_order']);
});
```

#### `database/migrations/2024_01_01_000023_create_educational_resources_table.php`

```php
Schema::create('educational_resources', function (Blueprint $table) {
    $table->id();
    $table->string('title');
    $table->string('slug')->unique();
    $table->string('status');
    $table->string('resource_type');       // ResourceType enum
    $table->text('body')->nullable();
    $table->string('discipline')->nullable();
    $table->string('academic_level')->nullable();
    $table->unsignedInteger('download_count')->default(0);
    $table->timestamp('published_at')->nullable();
    $table->string('seo_title')->nullable();
    $table->string('seo_description')->nullable();
    $table->string('canonical_url')->nullable();
    $table->boolean('noindex')->default(false);
    $table->string('author_name')->nullable();
    $table->string('source_url')->nullable();
    $table->string('domain_entity_type')->nullable();
    $table->unsignedBigInteger('domain_entity_id')->nullable();
    $table->unsignedBigInteger('institution_id')->nullable();
    $table->json('meta')->nullable();
    $table->unsignedInteger('save_count')->default(0);
    $table->unsignedInteger('like_count')->default(0);
    $table->timestamps();
    $table->softDeletes();

    $table->index(['status', 'published_at']);
    $table->index(['resource_type', 'discipline']);
    $table->index('slug');
});
```

#### `database/migrations/2024_01_01_000024_create_exam_preparations_table.php`

```php
Schema::create('exam_preparations', function (Blueprint $table) {
    $table->id();
    $table->string('title');
    $table->string('slug')->unique();
    $table->string('status');
    $table->string('prep_type');           // PrepType enum
    $table->string('exam_body')->nullable();
    $table->string('subject')->nullable();
    $table->year('year')->nullable();
    $table->unsignedInteger('download_count')->default(0);
    $table->text('body')->nullable();
    $table->timestamp('published_at')->nullable();
    $table->string('seo_title')->nullable();
    $table->string('seo_description')->nullable();
    $table->string('canonical_url')->nullable();
    $table->boolean('noindex')->default(false);
    $table->string('author_name')->nullable();
    $table->string('source_url')->nullable();
    $table->string('domain_entity_type')->nullable();
    $table->unsignedBigInteger('domain_entity_id')->nullable();
    $table->unsignedBigInteger('institution_id')->nullable();
    $table->json('meta')->nullable();
    $table->unsignedInteger('save_count')->default(0);
    $table->unsignedInteger('like_count')->default(0);
    $table->timestamps();
    $table->softDeletes();

    $table->index(['status', 'published_at']);
    $table->index(['prep_type', 'exam_body', 'year']);
    $table->index('slug');
});
```

### 6.2 Content Model Signatures

#### `app/Content/Models/Article.php`

```php
namespace App\Content\Models;

use App\Content\Concerns\{HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags};
use App\Content\Enums\ContentStatus;
use App\Domain\Models\Institution;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\{MorphTo, BelongsTo};

class Article extends Model
{
    use HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags;

    protected $casts = [
        'status' => ContentStatus::class,
        'is_breaking' => 'boolean',
        'noindex' => 'boolean',
        'published_at' => 'datetime',
    ];

    // Content → Domain references (unidirectional)
    public function domainEntity(): MorphTo { return $this->morphTo(); }
    public function institution(): BelongsTo { return $this->belongsTo(Institution::class); }
}
```

(`Guide.php`, `EducationalResource.php`, `ExamPreparation.php` follow the same pattern with their respective traits and type-specific casts.)

### 6.3 Content Traits (8)

| # | File | Trait | Methods | Boot Method |
|---|---|---|---|---|
| 1 | `app/Content/Concerns/HasSlug.php` | `HasSlug` | `getSlugSource(): string` | `bootHasSlug()` — auto-generates slug on creating |
| 2 | `app/Content/Concerns/IsPublishable.php` | `IsPublishable` | `publish()`, `unpublish()`, `archive()`, `isPublished(): bool` | `bootIsPublishable()` — adds global scope for published |
| 3 | `app/Content/Concerns/HasSeoMeta.php` | `HasSeoMeta` | `getSeoTitle()`, `getSeoDescription()`, `getCanonicalUrl()`, `getOpenGraphImage()` | None |
| 4 | `app/Content/Concerns/HasMedia.php` | `HasMedia` | (delegates to `InteractsWithMedia`) | None — uses Spatie Media Library |
| 5 | `app/Content/Concerns/HasProvenance.php` | `HasProvenance` | `getAuthor()`, `getSourceUrl()` | None |
| 6 | `app/Content/Concerns/IsSearchable.php` | `IsSearchable` | `toSearchableArray()`, `searchableAs()` | `bootIsSearchable()` — dispatches Typesense sync on save |
| 7 | `app/Content/Concerns/HasTags.php` | `HasTags` | (delegates to Spatie Tags) | None |
| 8 | `app/Content/Concerns/HasSections.php` | `HasSections` | `sections()`, `addSection()`, `reorderSections()` | None — Guide only |

**Trait Collision Mitigation:** Every trait boot method is named `boot{TraitName}()` (Laravel convention). Trait methods that could collide (e.g., `publish()`) are prefixed with the concern name only when ambiguity exists — `publishContent()` vs `publish()`. In practice, `IsPublishable::publish()` does not collide with any domain method because content models never mix with domain operations.

### 6.4 Content Enums (3)

| # | File | Enum | Values |
|---|---|---|---|
| 1 | `app/Content/Enums/ContentStatus.php` | `ContentStatus:string` | Draft, Published, Archived |
| 2 | `app/Content/Enums/ResourceType.php` | `ResourceType:string` | ProjectTopic, SeminarTopic, ResearchMaterial, StudyResource, Other |
| 3 | `app/Content/Enums/PrepType.php` | `PrepType:string` | PastQuestion, ExamTip, SubjectReview, StudyPack |

### 6.5 Content Actions (8)

| # | File | Action | Phase |
|---|---|---|---|
| 1 | `app/Content/Actions/CreateArticle.php` | CreateArticle | 1b |
| 2 | `app/Content/Actions/PublishArticle.php` | PublishArticle | 1b |
| 3 | `app/Content/Actions/CreateGuide.php` | CreateGuide | 1b |
| 4 | `app/Content/Actions/PublishGuide.php` | PublishGuide | 1b |
| 5 | `app/Content/Actions/CreateEducationalResource.php` | CreateEducationalResource | 1b |
| 6 | `app/Content/Actions/PublishEducationalResource.php` | PublishEducationalResource | 1b |
| 7 | `app/Content/Actions/CreateExamPreparation.php` | CreateExamPreparation | 2d |
| 8 | `app/Content/Actions/PublishExamPreparation.php` | PublishExamPreparation | 2d |

### 6.6 Content Queries (8)

| # | File | Query | Phase |
|---|---|---|---|
| 1 | `app/Content/Queries/GetPublishedArticles.php` | GetPublishedArticles | 1b |
| 2 | `app/Content/Queries/GetArticleBySlug.php` | GetArticleBySlug | 1b |
| 3 | `app/Content/Queries/GetArticlesForInstitution.php` | GetArticlesForInstitution | 1c |
| 4 | `app/Content/Queries/GetGuidesByCategory.php` | GetGuidesByCategory | 1b |
| 5 | `app/Content/Queries/GetGuideBySlug.php` | GetGuideBySlug | 1b |
| 6 | `app/Content/Queries/GetEducationalResourcesByType.php` | GetEducationalResourcesByType | 1b |
| 7 | `app/Content/Queries/GetEducationalResourceBySlug.php` | GetEducationalResourceBySlug | 1b |
| 8 | `app/Content/Queries/GetExamPrepsByExamBody.php` | GetExamPrepsByExamBody | 2d |

---

## 7. Reference Data Layer — Models, Migrations, Seeders

### 7.1 Reference Data Migrations

| # | Migration | Table | Columns |
|---|---|---|---|
| 1 | `create_countries_table` | `countries` | id, iso_alpha2, iso_alpha3, name, region, subregion, timestamps |
| 2 | `create_currencies_table` | `currencies` | id, iso_code, name, symbol, exchange_rate_hint, timestamps |
| 3 | `create_qualification_equivalencies_table` | `qualification_equivalencies` | id, source_qualification_id, target_qualification_id, country_code, notes, timestamps |
| 4 | `create_tuition_fee_ranges_table` | `tuition_fee_ranges` | id, country_code, programme_level, currency_code, min_amount, max_amount, timestamps |
| 5 | `create_cost_of_living_indices_table` | `cost_of_living_indices` | id, country_code, city, housing_index, food_index, transport_index, overall_index, timestamps |
| 6 | `create_visa_requirement_summaries_table` | `visa_requirement_summaries` | id, country_code, summary_text, official_source_url, last_verified_at, timestamps |

### 7.2 Reference Data Models

| # | File | Model | Has Events? | Has Invariants? |
|---|---|---|---|---|
| 1 | `app/Reference/Models/Country.php` | Country | No | No |
| 2 | `app/Reference/Models/Currency.php` | Currency | No | No |
| 3 | `app/Reference/Models/QualificationEquivalency.php` | QualificationEquivalency | No | No |
| 4 | `app/Reference/Models/TuitionFeeRange.php` | TuitionFeeRange | No | No |
| 5 | `app/Reference/Models/CostOfLivingIndex.php` | CostOfLivingIndex | No | No |
| 6 | `app/Reference/Models/VisaRequirementSummary.php` | VisaRequirementSummary | No | No |

All reference data models are simple Eloquent models with Filament admin resources for CRUD. No domain events. No invariants. Managed by admins via seeders and Filament.

### 7.3 Reference Data Seeders

| # | File | Purpose |
|---|---|---|
| 1 | `database/seeders/CountrySeeder.php` | ISO 3166-1 country list (~250 rows) |
| 2 | `database/seeders/CurrencySeeder.php` | ISO 4217 currency list (~180 rows) |
| 3 | `database/seeders/NigeriaReferenceDataSeeder.php` | Nigerian education authorities (NUC, NBTE, NCCE, JAMB, WAEC, NECO, NABTEB), qualifications, admission pathways |
| 4 | `database/seeders/VisaRequirementSeeder.php` | Student visa summaries for top destinations (UK, US, Canada, Germany, Australia) |

---

## 8. Auth and RBAC — Models, Migrations, Policies, Spatie Configuration

### 8.1 Auth Migrations

Spatie Permission package creates its own migrations. Additional migrations:

#### `database/migrations/2024_01_01_000030_create_organization_members_table.php`

```php
Schema::create('organization_members', function (Blueprint $table) {
    $table->id();
    $table->string('organization_type');   // Institution, EducationAuthority
    $table->unsignedBigInteger('organization_id');
    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->foreignId('role_id')->constrained('roles')->cascadeOnDelete();
    $table->timestamps();

    $table->morphsIndex('organization');
    $table->unique(['organization_type', 'organization_id', 'user_id', 'role_id']);
});
```

### 8.2 Roles (7)

| Role | Spatie Role Name | Permissions |
|---|---|---|
| Super Admin | `super-admin` | All permissions |
| Institution Admin | `institution-admin` | manage institution, manage programmes, manage admissions, manage scholarships, publish articles, manage members |
| Content Editor | `content-editor` | create articles, edit articles, publish articles, create guides, edit guides, publish guides, create resources, edit resources, publish resources |
| Content Contributor | `content-contributor` | create articles, edit own articles, create resources, edit own resources |
| Community Moderator | `community-moderator` | edit questions, delete questions, edit answers, delete answers, close questions |
| Registered User | `registered-user` | save items, follow items, like items, ask questions, answer questions |
| Guest | (no role) | browse (read-only) |

### 8.3 Policies (7)

| # | File | Policy | Model | Key Methods |
|---|---|---|---|---|
| 1 | `app/Policies/InstitutionPolicy.php` | InstitutionPolicy | Institution | view, update, delete, publish, manageMembers |
| 2 | `app/Policies/ProgrammePolicy.php` | ProgrammePolicy | Programme | view, update, delete, publish |
| 3 | `app/Policies/ScholarshipPolicy.php` | ScholarshipPolicy | Scholarship | view, update, delete, publish |
| 4 | `app/Policies/ArticlePolicy.php` | ArticlePolicy | Article | view, create, update, delete, publish |
| 5 | `app/Policies/GuidePolicy.php` | GuidePolicy | Guide | view, create, update, delete, publish |
| 6 | `app/Policies/EducationalResourcePolicy.php` | EducationalResourcePolicy | EducationalResource | view, create, update, delete, publish |
| 7 | `app/Policies/ExamPreparationPolicy.php` | ExamPreparationPolicy | ExamPreparation | view, create, update, delete, publish |

---

## 9. Engagement Layer — Models, Migrations, Polymorphic Relationships

### 9.1 Engagement Migrations

#### `database/migrations/2024_01_01_000040_create_saves_table.php`

```php
Schema::create('saves', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->string('savable_type');
    $table->unsignedBigInteger('savable_id');
    $table->timestamps();

    $table->unique(['user_id', 'savable_type', 'savable_id']);
    $table->index(['savable_type', 'savable_id']);
});
```

`follows` and `likes` tables follow the same polymorphic pattern with `followable_type/followable_id` and `likeable_type/likeable_id` respectively.

### 9.2 Engagement on User Model

```php
// app/Models/User.php additions
public function saves(): MorphToMany { /* ... */ }
public function follows(): MorphToMany { /* ... */ }
public function likes(): MorphToMany { /* ... */ }

// Convenience methods
public function saveItem(Model $item): void { /* ... */ }
public function unsaveItem(Model $item): void { /* ... */ }
public function isFollowing(Model $item): bool { /* ... */ }
public function isInstitutionAdmin(Institution $institution): bool { /* ... */ }
public function isSuperAdmin(): bool { /* ... */ }
public function isContentEditor(): bool { /* ... */ }
```

---

## 10. Community Module — Models, Migrations, Actions, Queries

### 10.1 Community Migrations

| # | Migration | Table | Key Columns |
|---|---|---|---|
| 1 | `create_community_questions_table` | `community_questions` | id, user_id, title, slug, body, subject_type, subject_id, vote_count, answer_count, view_count, is_closed, timestamps |
| 2 | `create_community_answers_table` | `community_answers` | id, question_id, user_id, body, vote_count, is_accepted, timestamps |
| 3 | `create_community_comments_table` | `community_comments` | id, commentable_type, commentable_id, user_id, body, timestamps |
| 4 | `create_community_votes_table` | `community_votes` | id, user_id, votable_type, votable_id, value (+1/-1), timestamps |

### 10.2 Community Models

| # | File | Model |
|---|---|---|
| 1 | `app/Community/Models/Question.php` | Question |
| 2 | `app/Community/Models/Answer.php` | Answer |
| 3 | `app/Community/Models/Comment.php` | Comment |

### 10.3 Community Actions (3)

| # | File | Action |
|---|---|---|
| 1 | `app/Community/Actions/AskQuestion.php` | AskQuestion |
| 2 | `app/Community/Actions/AnswerQuestion.php` | AnswerQuestion |
| 3 | `app/Community/Actions/VoteOnAnswer.php` | VoteOnAnswer |

### 10.4 Community Queries (2)

| # | File | Query |
|---|---|---|
| 1 | `app/Community/Queries/GetQuestionsBySubject.php` | GetQuestionsBySubject |
| 2 | `app/Community/Queries/GetQuestionBySlug.php` | GetQuestionBySlug |

**Phase:** Community module is Phase 2a, feature-flagged off by default (`FEATURE_COMMUNITY=false`).

---

## 11. Study Abroad Module — Queries, Livewire, Reference Data

### 11.1 Study Abroad Queries (5)

| # | File | Query |
|---|---|---|
| 1 | `app/StudyAbroad/Queries/GetCountriesWithInstitutions.php` | GetCountriesWithInstitutions |
| 2 | `app/StudyAbroad/Queries/GetCountryDetails.php` | GetCountryDetails |
| 3 | `app/StudyAbroad/Queries/GetQualificationEquivalencies.php` | GetQualificationEquivalencies |
| 4 | `app/StudyAbroad/Queries/GetTuitionFeeRanges.php` | GetTuitionFeeRanges |
| 5 | `app/StudyAbroad/Queries/GetCostOfLivingIndex.php` | GetCostOfLivingIndex |

### 11.2 Study Abroad Livewire Components (3)

| # | File | Component |
|---|---|---|
| 1 | `app/StudyAbroad/Livewire/CountryPage.php` | CountryPage |
| 2 | `app/StudyAbroad/Livewire/CompareDestinations.php` | CompareDestinations |
| 3 | `app/StudyAbroad/Livewire/ScholarshipListing.php` | ScholarshipListing |

**Key architectural rule:** Study Abroad has NO Actions, NO Models (uses existing Institution/Programme + Reference data), and NO Events. It is a pure read/presentation module. Phase: 2b.

---

## 12. Search Infrastructure — Typesense Collections, Scout Configuration, Listeners

### 12.1 Typesense Collections (7)

| # | Collection | Source Model | Key Fields | Sort |
|---|---|---|---|---|
| 1 | `institutions` | Institution | name, type, country, state, city, ownership_type | name asc |
| 2 | `programmes` | Programme + Institution | name, award, duration, institution_name, disciplines, level | _text_match desc, institution_name asc |
| 3 | `scholarships` | Scholarship + Institution | title, amount, eligibility_summary, institution_name, category | application_closes_at asc |
| 4 | `articles` | Article | title, body, category, institution_name, published_at | published_at desc |
| 5 | `guides` | Guide | title, category, institution_name | title asc |
| 6 | `educational_resources` | EducationalResource | title, resource_type, discipline, academic_level | title asc |
| 7 | `exam_preparations` | ExamPreparation | title, prep_type, exam_body, subject, year | year desc |

### 12.2 Scout Configuration

```php
// config/scout.php
'driver' => env('SCOUT_DRIVER', 'typesense'),

'typesense' => [
    'api-key' => env('TYPESENSE_API_KEY'),
    'host' => env('TYPESENSE_HOST', 'localhost'),
    'port' => env('TYPESENSE_PORT', 8108),
    'protocol' => env('TYPESENSE_PROTOCOL', 'http'),
    'max-records-per-batch' => 1000,
],
```

### 12.3 Search Indexer Classes (7)

| # | File | Indexer |
|---|---|---|
| 1 | `app/Search/Indexers/InstitutionIndexer.php` | InstitutionIndexer |
| 2 | `app/Search/Indexers/ProgrammeIndexer.php` | ProgrammeIndexer |
| 3 | `app/Search/Indexers/ScholarshipIndexer.php` | ScholarshipIndexer |
| 4 | `app/Search/Indexers/ArticleIndexer.php` | ArticleIndexer |
| 5 | `app/Search/Indexers/GuideIndexer.php` | GuideIndexer |
| 6 | `app/Search/Indexers/EducationalResourceIndexer.php` | EducationalResourceIndexer |
| 7 | `app/Search/Indexers/ExamPreparationIndexer.php` | ExamPreparationIndexer |

### 12.4 Search Listener

| File | Listener | Trigger |
|---|---|---|
| `app/Search/Listeners/SyncToTypesense.php` | SyncToTypesense | Any domain event that changes searchable data — dispatches queued Typesense sync job |

### 12.5 Search Livewire Component

| File | Component | Purpose |
|---|---|---|
| `app/Livewire/Public/GlobalSearch.php` | GlobalSearch | Typesense-powered search with auto-suggest, faceted filtering, instant results |

Phase: 1e.

---

## 13. SEO Infrastructure — Sitemaps, Structured Data, Meta Tags, Middleware

### 13.1 Sitemap Generation

| File | Purpose |
|---|---|
| `app/SEO/Sitemaps/GenerateSitemaps.php` | Scheduled command to generate all 7 partitioned sitemaps |

Sitemap partitions: `sitemap-institutions.xml`, `sitemap-programmes.xml`, `sitemap-scholarships.xml`, `sitemap-articles.xml`, `sitemap-guides.xml`, `sitemap-resources.xml`, `sitemap-exam-prep.xml`.

### 13.2 Structured Data Classes (5)

| # | File | Schema.org Type | Model |
|---|---|---|---|
| 1 | `app/SEO/StructuredData/InstitutionSchema.php` | `CollegeOrUniversity` | Institution |
| 2 | `app/SEO/StructuredData/ProgrammeSchema.php` | `EducationalOccupationalProgram` | Programme |
| 3 | `app/SEO/StructuredData/ScholarshipSchema.php` | `DatedMoneySpecification` | Scholarship |
| 4 | `app/SEO/StructuredData/ArticleSchema.php` | `NewsArticle` / `Article` | Article / Guide |
| 5 | `app/SEO/StructuredData/LearningResourceSchema.php` | `LearningResource` | EducationalResource / ExamPreparation |

### 13.3 SEO Blade Component

| File | Purpose |
|---|---|
| `resources/views/components/seo/meta.blade.php` | Renders `<title>`, `<meta name="description">`, `<link rel="canonical">`, Open Graph tags, Twitter Card tags, JSON-LD structured data |

### 13.4 URL Redirects Migration

```php
Schema::create('url_redirects', function (Blueprint $table) {
    $table->id();
    $table->string('from_path')->unique();
    $table->string('to_path');
    $table->unsignedSmallInteger('status_code')->default(301);
    $table->timestamps();
});
```

### 13.5 SEO Middleware

| File | Purpose |
|---|---|
| `app/Http/Middleware/SeoMiddleware.php` | Adds noindex/nofollow headers for user-specific pages, paginated pages beyond page 1, and draft content |

Phase: 1f.

---

## 14. Notification Infrastructure — Notification Classes, Channels, Scheduling

### 14.1 Notification Classes (5)

| # | File | Notification | Channels | Trigger |
|---|---|---|---|---|
| 1 | `app/Notifications/AdmissionCycleOpened.php` | AdmissionCycleOpened | Database + Email + WebPush | AdmissionCycleActivated event |
| 2 | `app/Notifications/ScholarshipDeadlineApproaching.php` | ScholarshipDeadlineApproaching | Database + Email + SMS | Scheduler (7 days / 1 day before) |
| 3 | `app/Notifications/NewArticlePublished.php` | NewArticlePublished | Database + WebPush | NewArticlePublished event |
| 4 | `app/Notifications/CommunityAnswerReceived.php` | CommunityAnswerReceived | Database + Email | AnswerQuestion action |
| 5 | `app/Notifications/ProgrammeAdmissionStatusChanged.php` | ProgrammeAdmissionStatusChanged | Database + Email | Programme admission status change |

### 14.2 Scheduler Commands (2)

| # | Command | Schedule | Purpose |
|---|---|---|---|
| 1 | `app/Console/Commands/ExpireOverdueScholarships.php` | Daily at 00:00 | Expires scholarships past their deadline |
| 2 | `app/Console/Commands/SendScholarshipReminders.php` | Daily at 08:00 | Sends deadline reminders (7-day and 1-day) |

Phase: 1i.

---

## 15. Admin Panel — Filament Resources, Pages, Widgets

### 15.1 Filament Resources (11)

| # | File | Resource | Model | Phase |
|---|---|---|---|---|
| 1 | `app/Admin/Filament/Resources/InstitutionResource.php` | InstitutionResource | Institution | 1a |
| 2 | `app/Admin/Filament/Resources/ProgrammeResource.php` | ProgrammeResource | Programme | 1a |
| 3 | `app/Admin/Filament/Resources/ScholarshipResource.php` | ScholarshipResource | Scholarship | 1a |
| 4 | `app/Admin/Filament/Resources/AdmissionCycleResource.php` | AdmissionCycleResource | AdmissionCycle | 1a |
| 5 | `app/Admin/Filament/Resources/InformationSourceResource.php` | InformationSourceResource | InformationSource | 1a |
| 6 | `app/Admin/Filament/Resources/QualificationResource.php` | QualificationResource | Qualification | 1a |
| 7 | `app/Admin/Filament/Resources/ScholarshipProviderResource.php` | ScholarshipProviderResource | ScholarshipProvider | 1a |
| 8 | `app/Admin/Filament/Resources/EducationAuthorityResource.php` | EducationAuthorityResource | EducationAuthority | 1a |
| 9 | `app/Admin/Filament/Resources/ArticleResource.php` | ArticleResource | Article | 1b |
| 10 | `app/Admin/Filament/Resources/GuideResource.php` | GuideResource | Guide | 1b |
| 11 | `app/Admin/Filament/Resources/EducationalResourceResource.php` | EducationalResourceResource | EducationalResource | 1b |

### 15.2 Filament Pages

| File | Page | Purpose |
|---|---|---|
| `app/Admin/Filament/Pages/Dashboard.php` | Dashboard | Overview: institution count, programme count, recent activity, pending verification |

### 15.3 Key Filament Configuration

- **Auth guard:** `web` (same as public site)
- **Middleware:** `auth`, `verified`
- **Navigation:** Grouped by concern: Domain, Content, Reference Data, Community
- **Resource form:** Uses Tiptap editor for rich text (body fields)
- **Media upload:** Spatie Media Library Filament plugin for image/file uploads
- **Invokes Actions:** Filament resource `beforeCreate()` / `beforeSave()` hooks invoke domain Actions — business logic is never in Filament hooks

---

## 16. Public Site — Controllers, Livewire Components, Blade Templates, Routes

### 16.1 Controllers (7)

| # | File | Controller | Route | Phase |
|---|---|---|---|---|
| 1 | `app/Http/Controllers/InstitutionPageController.php` | InstitutionPageController | `/institutions/{slug}` | 1c |
| 2 | `app/Http/Controllers/ProgrammePageController.php` | ProgrammePageController | `/institutions/{inst}/programmes/{slug}` | 1c |
| 3 | `app/Http/Controllers/ScholarshipPageController.php` | ScholarshipPageController | `/scholarships/{slug}` | 1c |
| 4 | `app/Http/Controllers/ArticlePageController.php` | ArticlePageController | `/news/{slug}` | 1d |
| 5 | `app/Http/Controllers/GuidePageController.php` | GuidePageController | `/guides/{slug}` | 1d |
| 6 | `app/Http/Controllers/ResourcePageController.php` | ResourcePageController | `/resources/{slug}` | 1d |
| 7 | `app/Http/Controllers/ExamPrepPageController.php` | ExamPrepPageController | `/exam-prep/{slug}` | 2d |

All controllers are thin routing veneers. They invoke Query classes and return Blade views. No business logic in controllers.

### 16.2 Livewire Components (Public)

| # | File | Component | Page | Phase |
|---|---|---|---|---|
| 1 | `app/Livewire/Public/GlobalSearch.php` | GlobalSearch | Global search bar | 1e |
| 2 | `app/Livewire/Public/InstitutionProgrammeList.php` | InstitutionProgrammeList | Institution detail → Programmes tab | 1c |
| 3 | `app/Livewire/Public/ArticleFeed.php` | ArticleFeed | News section | 1d |
| 4 | `app/Livewire/Public/ResourceBrowser.php` | ResourceBrowser | Resources section | 1d |
| 5 | `app/Livewire/Public/ExamPrepBrowser.php` | ExamPrepBrowser | Exam Prep section | 2d |
| 6 | `app/Livewire/Public/RelatedContent.php` | RelatedContent | Lazy-loaded on detail pages | 1c |

### 16.3 Livewire Components (Authenticated)

| # | File | Component | Purpose | Phase |
|---|---|---|---|---|
| 1 | `app/Livewire/Authenticated/Dashboard.php` | Dashboard | User dashboard | 1h |
| 2 | `app/Livewire/Authenticated/SavedItems.php` | SavedItems | Saved items list | 1h |
| 3 | `app/Livewire/Authenticated/FollowingItems.php` | FollowingItems | Followed items | 1h |

### 16.4 Blade Templates (Key Pages)

| # | Template | Purpose | Rendering |
|---|---|---|---|
| 1 | `resources/views/institutions/show.blade.php` | Institution detail page (SEO-critical) | Server-rendered Blade |
| 2 | `resources/views/programmes/show.blade.php` | Programme detail page (SEO-critical) | Server-rendered Blade |
| 3 | `resources/views/scholarships/show.blade.php` | Scholarship detail page (SEO-critical) | Server-rendered Blade |
| 4 | `resources/views/articles/show.blade.php` | Article detail page (SEO-critical) | Server-rendered Blade |
| 5 | `resources/views/guides/show.blade.php` | Guide detail page with TOC | Server-rendered Blade |
| 6 | `resources/views/resources/show.blade.php` | Educational resource detail | Server-rendered Blade |
| 7 | `resources/views/home.blade.php` | Homepage (SEO-critical) | Server-rendered Blade |
| 8 | `resources/views/search/results.blade.php` | Search results | Livewire |

### 16.5 Route Definitions

```php
// routes/web.php

use App\Http\Controllers\{InstitutionPageController, ProgrammePageController, ScholarshipPageController, ArticlePageController, GuidePageController, ResourcePageController};

// Homepage
Route::get('/', HomeController::class)->name('home');

// Domain entities
Route::get('/institutions', [InstitutionPageController::class, 'index'])->name('institutions.index');
Route::get('/institutions/{slug}', InstitutionPageController::class)->name('institutions.show');
Route::get('/institutions/{institution}/programmes/{slug}', ProgrammePageController::class)->name('programmes.show');
Route::get('/scholarships/{slug}', ScholarshipPageController::class)->name('scholarships.show');

// Content
Route::get('/news', [ArticlePageController::class, 'index'])->name('articles.index');
Route::get('/news/{slug}', ArticlePageController::class)->name('articles.show');
Route::get('/guides/{slug}', GuidePageController::class)->name('guides.show');
Route::get('/resources/{slug}', ResourcePageController::class)->name('resources.show');

// Study Abroad (feature-flagged)
Route::middleware('feature:study-abroad')->group(function () {
    Route::get('/study-abroad', [StudyAbroadController::class, 'index'])->name('study-abroad.index');
    Route::get('/study-abroad/{country}', [StudyAbroadController::class, 'show'])->name('study-abroad.show');
});

// Community (feature-flagged)
Route::middleware('feature:community')->group(function () {
    Route::get('/community/questions/{slug}', [CommunityQuestionController::class, 'show'])->name('community.questions.show');
});

// Compare (session-based, no model)
Route::get('/compare', [CompareController::class, 'index'])->name('compare.index');
```

---

## 17. Domain Events and Listeners — Complete Wiring

### 17.1 Event-Listener Mapping (in `app/Providers/EventServiceProvider.php`)

```php
protected $listen = [
    // Institution events
    InstitutionEstablished::class => [SyncToTypesense::class, LogActivity::class],
    InstitutionRenamed::class => [SyncToTypesense::class, LogActivity::class],
    InstitutionSuspended::class => [SyncToTypesense::class, ProgrammeStatusCascade::class],
    InstitutionReactivated::class => [SyncToTypesense::class, ProgrammeStatusRestore::class],
    InstitutionClosed::class => [SyncToTypesense::class, ProgrammeDiscontinueCascade::class, ScholarshipFlag::class],
    InstitutionsMerged::class => [SearchRebuild::class, ProgrammeReassignment::class],
    InstitutionAccredited::class => [TrustSignal::class, SyncToTypesense::class],

    // Programme events
    ProgrammeIntroduced::class => [SyncToTypesense::class, LogActivity::class],
    ProgrammeAdmissionSuspended::class => [SyncToTypesense::class],
    ProgrammeAdmissionResumed::class => [SyncToTypesense::class],
    ProgrammeDiscontinued::class => [SyncToTypesense::class, ScholarshipFlag::class],
    ProgrammeAccredited::class => [TrustSignal::class, SyncToTypesense::class],

    // Scholarship events
    ScholarshipAnnounced::class => [SyncToTypesense::class, CandidateNotification::class],
    ScholarshipApplicationsOpened::class => [SyncToTypesense::class, CandidateNotification::class],
    ScholarshipApplicationsClosed::class => [SyncToTypesense::class],
    ScholarshipWithdrawn::class => [SyncToTypesense::class, ApplicantNotification::class],
    ScholarshipExpired::class => [SyncToTypesense::class],
    ScholarshipTargetsUpdated::class => [SyncToTypesense::class],

    // Admission Cycle events
    AdmissionCycleAnnounced::class => [SyncToTypesense::class],
    AdmissionCycleActivated::class => [ReadModelUpdate::class],
    AdmissionCyclePhaseAdvanced::class => [ReadModelUpdate::class, DispatchNotifications::class],
    AdmissionCycleClosed::class => [ReadModelUpdate::class],

    // Information Source events
    InformationSourceVerified::class => [TrustSignalRecalc::class],
    InformationSourceMarkedUnreliable::class => [TrustSignalRecalc::class],
    InformationSourceDeprecated::class => [TrustSignalCascade::class, DataProvenanceFlag::class],
];
```

### 17.2 Listener Classes (6)

| # | File | Listener | Purpose |
|---|---|---|---|
| 1 | `app/Listeners/SyncToTypesense.php` | SyncToTypesense | Dispatches queued Typesense index sync job |
| 2 | `app/Listeners/UpdateReadModel.php` | UpdateReadModel | Updates denormalized read models |
| 3 | `app/Listeners/DispatchNotifications.php` | DispatchNotifications | Triggers Laravel notifications |
| 4 | `app/Listeners/RecalculateTrustSignal.php` | RecalculateTrustSignal | Recalculates trust scores |
| 5 | `app/Listeners/LogActivity.php` | LogActivity | Spatie Activity Log integration |
| 6 | `app/Listeners/ProgrammeStatusCascade.php` | ProgrammeStatusCascade | Cascades institution status to programmes |

---

## 18. Domain Actions — Complete Wiring

Each Action follows this pattern:

```php
namespace App\Domain\Actions\Institutions;

use App\Domain\Models\Institution;
use App\Domain\Events\InstitutionEstablished;

class CreateInstitution
{
    public function execute(InstitutionData $data): Institution
    {
        // 1. Validate preconditions (Action Criterion)
        // 2. Execute domain operation
        // 3. Dispatch domain event
        // 4. Return result
    }
}
```

Actions are invoked from:
- **Controllers/Livewire:** `app(CreateInstitution::class)->execute($data);`
- **Filament Resources:** In `beforeCreate()` hook
- **Console Commands:** In scheduler commands
- **Import Jobs:** In batch processing

---

## 19. Domain Queries — Complete Wiring

Each Query follows this pattern:

```php
namespace App\Domain\Queries\Institutions;

use App\Domain\Models\Institution;

class GetInstitutionDetails
{
    public function get(string $slug): Institution
    {
        return Institution::query()
            ->where('slug', $slug)
            ->with(['programmes', 'accreditationRecords', 'admissionCycles'])
            ->firstOrFail();
    }
}
```

Queries are invoked from:
- **Controllers:** `$institution = app(GetInstitutionDetails::class)->get($slug);`
- **Livewire Components:** Same pattern
- **Filament Pages:** For relation managers and widgets

---

## 20. Feature Flags — Configuration and Middleware

### 20.1 Feature Flag Configuration

```php
// config/features.php
return [
    'community' => env('FEATURE_COMMUNITY', false),
    'study-abroad' => env('FEATURE_STUDY_ABROAD', true),
    'notifications-webpush' => env('FEATURE_NOTIFICATIONS_WEBPUSH', false),
    'notifications-sms' => env('FEATURE_NOTIFICATIONS_SMS', false),
    'exam-preparation' => env('FEATURE_EXAM_PREPARATION', true),
];
```

### 20.2 Feature Flag Middleware

```php
// app/Http/Middleware/FeatureFlag.php
class FeatureFlag
{
    public function handle(Request $request, Closure $next, string $feature): Response
    {
        if (!config("features.{$feature}")) {
            abort(404);
        }
        return $next($request);
    }
}
```

### 20.3 Feature Flag Blade Directive

```blade
@feature('community')
    <x-community-link />
@endfeature
```

### 20.4 Feature Flag Registration

```php
// app/Http/Kernel.php
protected $middlewareAliases = [
    'feature' => \App\Http\Middleware\FeatureFlag::class,
];
```

---

## 21. Shared Blade Components and Design Tokens

### 21.1 Design Token System (Tailwind CSS 4)

| Token Category | Variables | Notes |
|---|---|---|
| Colors | `--color-primary`, `--color-secondary`, `--color-accent`, `--color-success`, `--color-warning`, `--color-error` | Nigerian green/white palette |
| Typography | `--font-heading`, `--font-body`, `--font-mono` | Inter (body), Playfair Display (headings), JetBrains Mono (code) |
| Spacing | Tailwind defaults | No customization needed |
| Border radius | `--radius-sm`, `--radius-md`, `--radius-lg` | 4px, 8px, 12px |

### 21.2 Key Blade Components

| # | Component | Purpose |
|---|---|---|
| 1 | `<x-seo::meta>` | SEO meta tags + structured data |
| 2 | `<x-domain::institution-card>` | Institution card for listing/search |
| 3 | `<x-domain::programme-card>` | Programme card |
| 4 | `<x-domain::scholarship-card>` | Scholarship card |
| 5 | `<x-content::article-card>` | Article card for news feed |
| 6 | `<x-content::guide-card>` | Guide card with reading time |
| 7 | `<x-content::resource-card>` | Educational resource card with download count |
| 8 | `<x-product::comparison-table>` | Comparison table for compare feature |
| 9 | `<x-product::save-button>` | Save/bookmark button (Alpine.js) |
| 10 | `<x-product::share-buttons>` | Social sharing buttons (client-side) |

---

## 22. Package Integration Checklist — Adopt Now (17 Packages)

| # | Package | Install Command | Post-Install Steps | Phase |
|---|---|---|---|---|
| 1 | spatie/laravel-permission | `composer require spatie/laravel-permission:^6.0` | `php artisan vendor:publish`, run migrations, seed roles | 1g |
| 2 | spatie/laravel-medialibrary | `composer require spatie/laravel-medialibrary:^11.0` | `php artisan vendor:publish`, configure filesystems | 1b |
| 3 | spatie/laravel-tags | `composer require spatie/laravel-tags:^4.0` | `php artisan vendor:publish`, run migrations | 1b |
| 4 | spatie/laravel-activitylog | `composer require spatie/laravel-activitylog:^4.0` | `php artisan vendor:publish`, configure | 1a |
| 5 | spatie/laravel-sitemap | `composer require spatie/laravel-sitemap:^7.0` | Configure sitemap routes | 1f |
| 6 | spatie/laravel-honeypot | `composer require spatie/laravel-honeypot:^4.0` | Add middleware to form routes | 1a |
| 7 | spatie/laravel-backup | `composer require spatie/laravel-backup:^8.0` | Configure backup schedule, S3/cleanups | 1a |
| 8 | spatie/laravel-webhook-client | `composer require spatie/laravel-webhook-client:^3.0` | Configure webhook routes/signatures | 2 |
| 9 | spatie/laravel-personal-data-export | `composer require spatie/laravel-personal-data-export:^4.0` | Configure export jobs | 1g |
| 10 | maatwebsite/excel | `composer require maatwebsite/excel:^3.1` | Configure import temp disk | 1a |
| 11 | minimolabs/laravel-webpush | `composer require minimolabs/laravel-webpush:^1.0` | Configure VAPID keys, run migrations | 1i |
| 12 | laravel/socialite | `composer require laravel/socialite:^5.0` | Configure OAuth providers (Google) | 1g |
| 13 | laravel/pulse | `composer require laravel/pulse:^1.0` | `php artisan pulse:install`, configure dashboard | 1a |
| 14 | spatie/laravel-sluggable | `composer require spatie/laravel-sluggable:^3.0` | Add trait to models (or use custom HasSlug) | 1b |
| 15 | spatie/laravel-searchable | `composer require spatie/laravel-searchable:^3.0` | Configure search result transformers | 1e |
| 16 | laravel/scout | `composer require laravel/scout:^10.0` | `php artisan vendor:publish`, configure Typesense driver | 1e |
| 17 | spatie/laravel-data | `composer require spatie/laravel-data:^4.0` | Configure data namespaces | 1a |

---

## 23. Test Architecture — Unit, Feature, Browser

### 23.1 Test Structure

```
tests/
├── Unit/
│   ├── Domain/
│   │   ├── Models/
│   │   │   ├── InstitutionTest.php          — Lifecycle transitions, invariants
│   │   │   ├── ProgrammeTest.php            — Lifecycle, reassignment
│   │   │   ├── ScholarshipTest.php          — Lifecycle, targeting
│   │   │   ├── AdmissionCycleTest.php       — Phase transitions
│   │   │   └── InformationSourceTest.php    — Verification lifecycle
│   │   ├── ValueObjects/
│   │   │   ├── MoneyTest.php
│   │   │   ├── DurationTest.php
│   │   │   ├── AdmissionStatusTest.php
│   │   │   └── CountryTest.php
│   │   └── Enums/
│   │       └── AllEnumsHaveExpectedValuesTest.php
│   └── Content/
│       ├── Models/
│       │   ├── ArticleTest.php              — Publishing lifecycle
│       │   ├── GuideTest.php                — Section management
│       │   └── EducationalResourceTest.php  — Type enum behaviour
│       └── Concerns/
│           ├── HasSlugTest.php
│           ├── IsPublishableTest.php
│           └── HasSeoMetaTest.php
├── Feature/
│   ├── Actions/
│   │   ├── CreateInstitutionTest.php
│   │   ├── MergeInstitutionsTest.php
│   │   └── ...
│   ├── Queries/
│   │   ├── GetInstitutionDetailsTest.php
│   │   └── ...
│   ├── Livewire/
│   │   ├── GlobalSearchTest.php
│   │   └── InstitutionProgrammeListTest.php
│   └── Http/
│       ├── InstitutionPageTest.php
│       └── ArticlePageTest.php
└── Browser/
    └── HomepageTest.php                      — Dusk tests for critical user flows
```

### 23.2 Test Framework

- **Pest** (not PHPUnit) — more expressive, less boilerplate
- **Pest Plugins:** `pest-plugin-livewire`, `pest-plugin-laravel`
- **Factory:** Laravel factories with Faker
- **Database:** In-memory SQLite for unit tests; test PostgreSQL database for feature tests

### 23.3 Critical Test Scenarios

| # | Test | Concern | Type |
|---|---|---|---|
| 1 | Institution lifecycle: Operational → Suspended → Closed | State transition | Unit |
| 2 | Institution close cascades to programmes | Cross-aggregate invariant | Feature |
| 3 | Institution merge reassigns all programmes | INV-P1 preservation | Feature |
| 4 | Programme slug unique within institution | Composite unique constraint | Feature |
| 5 | Content → Domain unidirectional dependency | Architecture invariant | Static analysis |
| 6 | Article publishing lifecycle: Draft → Published → Archived | Content trait | Unit |
| 7 | RBAC: Institution Admin can edit own institution only | Scoped authorization | Feature |
| 8 | Typesense sync on domain event | Event-listener wiring | Feature |
| 9 | SEO: Canonical URL on slug change | URL redirect | Feature |
| 10 | Feature flag: Community routes return 404 when disabled | Feature flag middleware | Feature |

---

## 24. Database Migration Sequence — Ordered and Dependency-Aware

### 24.1 Migration Order (Foreign Key Dependencies)

| Order | Migration | Dependencies |
|---|---|---|
| 1 | `create_users_table` | None (Breeze) |
| 2 | `create_roles_table` + permission tables | None (Spatie) |
| 3 | `create_education_authorities_table` | None |
| 4 | `create_qualifications_table` | None |
| 5 | `create_scholarship_providers_table` | None |
| 6 | `create_institutions_table` | None |
| 7 | `create_programmes_table` | institutions |
| 8 | `create_scholarships_table` | institutions, scholarship_providers |
| 9 | `create_scholarship_programme_table` | scholarships, programmes |
| 10 | `create_admission_cycles_table` | institutions, education_authorities |
| 11 | `create_admission_policies_table` | admission_cycles, institutions/programmes (morph) |
| 12 | `create_eligibility_policies_table` | scholarships/programmes/cycles (morph) |
| 13 | `create_accreditation_records_table` | education_authorities, institutions/programmes (morph) |
| 14 | `create_information_sources_table` | None |
| 15 | `create_articles_table` | None (institution_id FK optional) |
| 16 | `create_guides_table` | None |
| 17 | `create_guide_sections_table` | guides |
| 18 | `create_educational_resources_table` | None |
| 19 | `create_exam_preparations_table` | None |
| 20 | `create_organization_members_table` | users, roles |
| 21 | `create_saves_table` | users |
| 22 | `create_follows_table` | users |
| 23 | `create_likes_table` | users |
| 24 | `create_community_questions_table` | users |
| 25 | `create_community_answers_table` | community_questions, users |
| 26 | `create_community_comments_table` | users |
| 27 | `create_community_votes_table` | users |
| 28 | `create_countries_table` | None |
| 29 | `create_currencies_table` | None |
| 30 | `create_qualification_equivalencies_table` | qualifications |
| 31 | `create_tuition_fee_ranges_table` | None |
| 32 | `create_cost_of_living_indices_table` | None |
| 33 | `create_visa_requirement_summaries_table` | None |
| 34 | `create_url_redirects_table` | None |
| 35 | `create_media_table` | None (Spatie) |
| 36 | `create_tags_table` + `taggables` | None (Spatie) |
| 37 | `create_activities_table` | None (Spatie) |
| 38 | `create_notifications_table` | None (Laravel) |
| 39 | `create_jobs_table` + `failed_jobs` | None (Laravel) |

**Total: 39 migrations** (48 tables including pivot and Spatie-managed tables).

---

## 25. Implementation Phases — Sequenced with File Lists

### Phase 1a: Domain Layer (4 weeks)

**Goal:** All domain models, migrations, Filament admin, Actions, Queries, Events, and Listeners working end-to-end.

| Step | Files | Deliverable |
|---|---|---|
| 1 | Laravel project + Breeze + all 17 packages | Working Laravel app with auth |
| 2 | 12 domain migrations | `php artisan migrate` succeeds |
| 3 | 11 domain models with casts, relationships, domain operations | Unit tests pass |
| 4 | 11 value objects + 16 enums | VO equality tests pass |
| 5 | 29 domain events | Event classes exist |
| 6 | 20 domain Actions | Feature tests pass for each Action |
| 7 | 15 domain Queries | Feature tests pass for each Query |
| 8 | 1 domain service (InstitutionMerger) | Merge feature test passes |
| 9 | 6 Listeners wired in EventServiceProvider | Event dispatch → listener invoked test passes |
| 10 | 8 Filament resources (domain) + Dashboard | Admin panel CRUD works |
| 11 | 5 Policies + Spatie Permission roles | Authorization tests pass |
| 12 | Reference data seeders | `php artisan db:seed` populates countries, currencies, Nigerian data |

**Done when:** `php artisan migrate && php artisan db:seed && pest` all succeed. Admin panel can CRUD all domain entities. Domain Actions enforce invariants. Events trigger listeners.

### Phase 1b: Content Layer (2 weeks)

| Step | Files | Deliverable |
|---|---|---|
| 1 | 5 content migrations | Tables created |
| 2 | 4 content models + 1 child (GuideSection) | Model tests pass |
| 3 | 8 content traits | Trait unit tests pass (isolation) |
| 4 | 3 content enums | Enum values correct |
| 5 | 8 content Actions | Feature tests pass |
| 6 | 8 content Queries | Feature tests pass |
| 7 | 3 Filament resources (Article, Guide, EducationalResource) + Tiptap editor | Content CRUD in admin works |
| 8 | Media collections configured | Image upload + conversion works |

**Done when:** Admin can create, edit, publish articles, guides, and educational resources. Traits provide slug auto-generation, publishing lifecycle, and SEO metadata defaults.

### Phase 1c: Public Site — Domain Pages (3 weeks)

| Step | Files | Deliverable |
|---|---|---|
| 1 | 3 page controllers (Institution, Programme, Scholarship) | Routes resolve |
| 2 | 3 Blade templates (show pages) | Pages render with domain data |
| 3 | Institution detail page with tabbed navigation | Tabs render, lazy-load works |
| 4 | Programme detail page (institution-scoped URL) | URL pattern correct |
| 5 | Livewire components: InstitutionProgrammeList, RelatedContent | Dynamic content loads |
| 6 | Homepage template | Hero search, featured institutions, latest news |
| 7 | Shared Blade components (institution-card, programme-card, scholarship-card) | Components render correctly |

**Done when:** All domain entity pages are accessible at their canonical URLs. Pages are server-rendered with correct meta tags. Livewire lazy-loading works for tabs.

### Phase 1d: Public Site — Content Pages (2 weeks)

| Step | Files | Deliverable |
|---|---|---|
| 1 | 3 page controllers (Article, Guide, Resource) | Routes resolve |
| 2 | 3 Blade templates (show pages) | Pages render with content data |
| 3 | Guide detail page with TOC and section navigation | Section links work |
| 4 | Livewire components: ArticleFeed, ResourceBrowser | Filtering and pagination work |
| 5 | Shared Blade components (article-card, guide-card, resource-card) | Components render |
| 6 | News listing page with category filters | Filtering works |

**Done when:** All content pages render at their canonical URLs. Guide sections have working TOC. Article feed is filterable.

### Phase 1e: Search Integration (1 week)

| Step | Files | Deliverable |
|---|---|---|
| 1 | Typesense Docker container running | Typesense accessible |
| 2 | Scout + Typesense driver configured | `php artisan scout:import` succeeds |
| 3 | 7 Search Indexers | `toSearchableArray()` returns correct data |
| 4 | SyncToTypesense listener wired | Domain event → Typesense update |
| 5 | GlobalSearch Livewire component | Search returns results with facets |
| 6 | Search bar in header | Auto-suggest works |

**Done when:** Typesense returns relevant results for institutions, programmes, scholarships, and content. Faceted filtering works. Search updates are near-real-time after domain events.

### Phase 1f: SEO Integration (1 week)

| Step | Files | Deliverable |
|---|---|---|
| 1 | `<x-seo::meta>` Blade component | Meta tags render correctly |
| 2 | 5 Structured Data classes | JSON-LD renders on pages |
| 3 | Sitemap generation command + 7 partitioned sitemaps | `/sitemap.xml` returns valid XML |
| 4 | URL redirects table + 301 redirect logic | Slug changes redirect correctly |
| 5 | SeoMiddleware for noindex/nofollow | Correct pages have noindex |
| 6 | robots.txt | Disallows correct paths |

**Done when:** All public pages have correct meta tags, structured data, and canonical URLs. Sitemaps are valid. Old URLs redirect to new canonicals.

### Phase 1g: Auth + RBAC (1 week)

| Step | Files | Deliverable |
|---|---|---|
| 1 | Breeze auth scaffolding (login, register, password reset) | Auth flows work |
| 2 | Socialite (Google OAuth) | Social login works |
| 3 | Spatie Permission roles + permissions seeded | Roles exist in DB |
| 4 | OrganizationMember pivot + migration | Scoped membership works |
| 5 | 5 Policies registered | Authorization works in controllers and Filament |
| 6 | Feature flag middleware registered | Feature-flagged routes work |

**Done when:** Users can register, login, and be assigned roles. Institution Admin can manage their institution only. Content Editors can publish content. Feature flags gate access.

### Phase 1h: Engagement (1 week)

| Step | Files | Deliverable |
|---|---|---|
| 1 | 3 engagement migrations (saves, follows, likes) | Tables created |
| 2 | Polymorphic relationships on User model | `saveItem()`, `followItem()`, `likeItem()` work |
| 3 | Engagement counter cache updates | Counts increment on engagement |
| 4 | Livewire: SavedItems, FollowingItems, Dashboard | Authenticated pages work |
| 5 | Save/Follow/Like Blade components + Alpine.js | UI interactions work without reload |

**Done when:** Users can save, follow, and like any domain or content entity. Counter caches update. Dashboard shows saved items.

### Phase 1i: Notifications (1 week)

| Step | Files | Deliverable |
|---|---|---|
| 1 | 5 Notification classes | Notifications dispatch correctly |
| 2 | Database + Email channels | In-app + email notifications work |
| 3 | WebPush channel (feature-flagged) | Opt-in push notifications work |
| 4 | Scheduler commands for scholarship reminders | Reminders fire at 7-day and 1-day |
| 5 | Unsubscribe links in all emails | One-click unsubscribe works |

**Done when:** Admission cycle opening triggers notifications. Scholarship deadline reminders fire on schedule. Users can opt-in/out of channels.

### Phase 2a: Community Module (3 weeks)

Feature-flagged. Only enabled when `FEATURE_COMMUNITY=true`.

| Step | Files | Deliverable |
|---|---|---|
| 1 | 4 community migrations | Tables created |
| 2 | 3 community models | Model tests pass |
| 3 | 3 community Actions | Feature tests pass |
| 4 | 2 community Queries | Feature tests pass |
| 5 | Community Filament resources (moderation) | Admin can moderate |
| 6 | Community Livewire components (ask, answer, vote) | Q&A flows work |
| 7 | Community Blade templates | Pages render at `/community/questions/{slug}` |

### Phase 2b: Study Abroad Module (2 weeks)

Feature-flagged. Only enabled when `FEATURE_STUDY_ABROAD=true`.

| Step | Files | Deliverable |
|---|---|---|
| 1 | 6 reference data migrations + seeders | Reference data populated |
| 2 | 6 reference data models + Filament resources | Admin can manage reference data |
| 3 | 5 Study Abroad Queries | Queries return correct data |
| 4 | 3 Study Abroad Livewire components | Country page, compare, scholarship listing work |
| 5 | Study Abroad Blade templates + routes | Pages render at `/study-abroad/{country}` |

### Phase 2c: Comparison (1 week)

| Step | Files | Deliverable |
|---|---|---|
| 1 | CompareInstitutions, CompareProgrammes, CompareScholarships Livewire | Comparison UI works |
| 2 | ComparisonAttribute VO | Comparison table renders |
| 3 | Session-based comparison state | Items persist across pages |

### Phase 2d: Exam Preparation (1 week)

| Step | Files | Deliverable |
|---|---|---|
| 1 | ExamPreparation Filament resource | CRUD works |
| 2 | ExamPrepPageController + Blade template | Pages render |
| 3 | ExamPrepBrowser Livewire | Filtering by exam body, year, subject |
| 4 | Download tracking | Download count increments |

### Phase 3: Advanced Features (TBD)

- Reputation/karma system (Community)
- Badge system (Community)
- AI-powered recommendations (Product)
- API for third parties
- Mobile app (same API)

---

## 26. Implementation Verification Checklist

### 26.1 Phase 1a Verification

- [ ] `php artisan migrate` succeeds with zero errors
- [ ] `php artisan db:seed` populates all reference data
- [ ] All 11 domain model unit tests pass
- [ ] All 20 domain action feature tests pass
- [ ] All 15 domain query feature tests pass
- [ ] Institution lifecycle: Operational → Suspended → Closed (unit test)
- [ ] Institution close cascades to programmes (feature test)
- [ ] MergeInstitutions preserves INV-P1 (feature test)
- [ ] All 29 events dispatch correctly (feature test)
- [ ] Filament admin CRUD works for all domain entities
- [ ] Spatie Permission roles seeded correctly
- [ ] OrganizationMember scoped authorization works

### 26.2 Phase 1b Verification

- [ ] 5 content migrations run successfully
- [ ] Article publishing lifecycle: Draft → Published → Archived
- [ ] HasSlug auto-generates slug on create
- [ ] IsPublishable adds global scope for published content
- [ ] HasSeoMeta returns sensible defaults
- [ ] HasMedia attaches and converts images
- [ ] Guide sections are ordered correctly
- [ ] Filament content CRUD works with Tiptap editor

### 26.3 Phase 1c Verification

- [ ] Institution page renders at `/institutions/{slug}`
- [ ] Programme page renders at `/institutions/{inst}/programmes/{slug}`
- [ ] Scholarship page renders at `/scholarships/{slug}`
- [ ] Institution tabs load independently (Livewire lazy)
- [ ] Programme URL is institution-scoped (not global)
- [ ] Homepage renders with hero search and featured content

### 26.4 Phase 1e Verification

- [ ] Typesense is running and accessible
- [ ] `php artisan scout:import "App\Domain\Models\Institution"` succeeds
- [ ] Global search returns results across all entity types
- [ ] Faceted filtering works (institution type, programme level, etc.)
- [ ] Domain event → Typesense sync → updated search results (within 5 seconds)

### 26.5 Phase 1f Verification

- [ ] All pages have `<title>` and `<meta name="description">`
- [ ] JSON-LD structured data renders on institution, programme, scholarship, article pages
- [ ] Sitemap partitions are valid XML with correct URLs
- [ ] Canonical URLs are correct and unique
- [ ] Slug change creates 301 redirect

### 26.6 Phase 1g Verification

- [ ] User registration and login works
- [ ] Google OAuth login works
- [ ] Institution Admin can edit their institution only (not others)
- [ ] Content Editor can publish content
- [ ] Content Contributor can create but not publish
- [ ] Feature-flagged routes return 404 when disabled

### 26.7 Architecture Invariant Verification (All Phases)

- [ ] No file in `app/Domain/` imports from `App\Content`, `App\Community`, `App\StudyAbroad`, `App\Product`
- [ ] No domain model references content models (grep check)
- [ ] No Action has "search index update" as sole justification
- [ ] No Action has "authorization only" as sole justification
- [ ] No god table (single content table with type discriminator)
- [ ] All polymorphic relationships have composite indexes
- [ ] All slug columns have unique indexes (or composite unique with institution_id)

---

## 27. Anti-Patterns and Forbidden Code

### 27.1 FORBIDDEN Patterns

| # | Anti-Pattern | Detection | Consequence |
|---|---|---|---|
| 1 | Domain model importing Content namespace | `rg "use App\\\\Content" app/Domain/` | Code review rejection |
| 2 | God table (single `contents` table with type discriminator) | Schema review | Revert migration |
| 3 | Repository pattern (interface between Eloquent and domain) | `rg "interface.*Repository" app/` | Code review rejection (ADR-04) |
| 4 | Event sourcing (event store, projections) | `rg "EventSourcing\|EventProjector" app/` | Code review rejection (ADR-02) |
| 5 | SPA (React, Vue, Inertia) in public site | `package.json` check | Revert dependency |
| 6 | Filament in public site | `rg "Filament" app/Livewire/` | Code review rejection |
| 7 | Nigerian-specific entity (JambRequirement, OLevelRequirement) | `rg "JambRequirement\|OLevelRequirement" app/` | Code review rejection |
| 8 | ABAC (Attribute-Based Access Control) | `rg "ABAC\|AttributePolicy" app/` | Code review rejection |
| 9 | Business logic in Filament Resource hooks | Manual review | Refactor to Action |
| 10 | Business logic in Livewire components | `rg "invariant\|validate.*business" app/Livewire/` | Refactor to Action or Query |
| 11 | Domain event with shared interface | `rg "implements DomainEvent" app/Domain/Events/` | Remove interface (F2 correction) |
| 12 | Model in `App\Models\` namespace (should be `App\Domain\Models\`) | `rg "namespace App\\\\Models" app/` | Fix namespace (F1 correction) |

### 27.2 SHOULD AVOID Patterns

| # | Pattern | When to Avoid | Alternative |
|---|---|---|---|
| 1 | Eager-loading all relationships | Large detail pages | Lazy-load via Livewire |
| 2 | Server-side rendering of search results | SEO pages | Link to Blade pages from Typesense results |
| 3 | Counter queries (COUNT(*)) on every page load | Engagement counts | Counter cache columns |
| 4 | Synchronous Typesense updates | Save operations | Queue + retry |
| 5 | Manual slug management | Content creation | HasSlug trait auto-generation |

---

## 28. Architectural Drift Guards

### 28.1 Code Review Checklist (Every PR)

1. Does any file in `app/Domain/` import from outside `app/Domain/`? → REJECT
2. Does any Action exist without meeting the Action Criterion (4 conditions)? → REJECT
3. Does any content model exist without distinct behaviour justification? → REJECT
4. Is business logic in a controller, Livewire component, or Filament hook? → REFACTOR
5. Are domain events plain PHP classes (no shared interface)? → VERIFY
6. Are namespace imports consistent with the dependency rules in Section 4? → VERIFY
7. Does every new migration have a corresponding rollback? → VERIFY
8. Does every new model have a corresponding test? → VERIFY

### 28.2 Automated Guards (Future — Deferred to Implementation)

| Guard | Tool | Trigger |
|---|---|---|
| Namespace import boundary | PHPStan custom rule | `composer analyse` |
| No repository pattern | PHPStan custom rule | `composer analyse` |
| No god table | Migration schema check | CI pipeline |
| Domain purity | `rg "use App\\\\Content" app/Domain/` | Pre-commit hook |
| Action Criterion compliance | Static analysis of Action class | `composer analyse` |

---

## 29. Blueprint Closure

### 29.1 What This Blueprint Provides

This document provides the complete translation from architecture to implementation for StudyNexus. Every architectural decision from Documents 20–23 has a corresponding implementation specification in this document:

| Architectural Concept | Blueprint Section | Implementation Form |
|---|---|---|
| 5 Aggregate Roots | Section 5.1, 5.3 | Migrations + Models with domain operations |
| 3 Child Entities | Section 5.1, 5.3 | Migrations + Models with parent relationships |
| 3 Supporting Entities | Section 5.2, 5.3 | Migrations + Models |
| 28 Value Objects | Section 5.4 | Readonly PHP classes + Custom casts |
| 16 Enums | Section 5.5 | PHP Backed Enums |
| 29 Domain Events | Section 5.6 | Plain PHP classes (no interface) |
| 20 Domain Actions | Section 5.7 | Action classes with execute() methods |
| 15 Domain Queries | Section 5.8 | Query classes with get()/search() methods |
| 1 Domain Service | Section 5.9 | InstitutionMerger |
| 4 Content Models | Section 6.1–6.2 | Migrations + Models with traits |
| 8 Content Traits | Section 6.3 | PHP traits in Concerns/ |
| 3 Content Enums | Section 6.4 | PHP Backed Enums |
| 6 Reference Data Models | Section 7.1–7.2 | Simple Eloquent models + Filament resources |
| 7 Roles + Spatie Permission | Section 8.2–8.3 | Role seeder + Policy classes |
| 3 Engagement features | Section 9.1–9.2 | Polymorphic migrations + User model methods |
| 3 Community Models | Section 10.1–10.2 | Migrations + Models (Phase 2, feature-flagged) |
| Study Abroad Module | Section 11.1–11.2 | Queries + Livewire (Phase 2, feature-flagged) |
| 7 Typesense Collections | Section 12.1–12.3 | Scout config + Indexer classes |
| SEO Infrastructure | Section 13.1–13.5 | Sitemaps + Structured Data + Blade component |
| 5 Notification Classes | Section 14.1 | Laravel notifications |
| 11 Filament Resources | Section 15.1 | Admin CRUD |
| 7 Page Controllers | Section 16.1 | Thin routing veneers |
| 9+ Livewire Components | Section 16.2–16.3 | Dynamic UI |
| 48 Tables | Section 24.1 | 39 ordered migrations |
| 31 ADRs | Doc 23 Section 31 | 29 Accepted, 2 Deferred |

### 29.2 What Remains After This Blueprint

Nothing. Every design decision is made. Every file path is specified. Every migration column is listed. Every class signature is defined. Every package version is pinned. Every test is identified.

**The next action is: `composer create-project laravel/laravel studynexus "12.*"`**

### 29.3 The Architecture-to-Code Bridge Is Closed

Document 20 froze the domain. Document 21 validated the freeze. Document 22 reviewed the ecosystem. Document 23 produced the final architecture with a verdict of READY FOR IMPLEMENTATION. This document (24) translates that architecture into concrete, sequenced, verifiable implementation steps.

The bridge between architecture and code is now closed. Implementation begins.

---

*End of Document 24. Pre-Implementation Blueprint. Architecture-to-code translation complete.*
