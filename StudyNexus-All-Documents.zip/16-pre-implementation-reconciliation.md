# Document 25: Pre-Implementation Reconciliation

**StudyNexus — Adversarial Reconciliation & Implementation Readiness Review**

| Field | Value |
|---|---|
| Date | 2026-08-08 |
| Status | ADVERSARIAL RECONCILIATION COMPLETE |
| Subject | Document 24 (Pre-Implementation Blueprint) |
| Reviewer | StudyNexus Architecture Team |
| Method | Every section of Document 24 attacked against Documents 20–23 and current ecosystem |
| Verdict | CONDITIONAL GO — 12 required changes, 8 recommendations, 0 rejected architectural decisions |

> "This review does not rubber-stamp. It attacks. Where Document 24 is wrong, it says so. Where it is over-engineered, it removes. Where it is missing, it adds. But it does not casually reopen the frozen domain — only genuine proof of model insufficiency justifies domain change."

---

## Table of Contents

1. Executive Verdict
2. Changes Required to Document 24
3. Changes Recommended
4. Decisions Confirmed
5. Decisions Rejected
6. New Decisions
7. Current Canonical Tech Stack
8. Current Package Matrix
9. Current Frontend Architecture
10. Current Authorization Architecture
11. Current Search Architecture
12. Current SEO Architecture
13. Current Engagement Architecture
14. Current Notification Architecture
15. Current Community Architecture
16. Current Content Architecture
17. Current Study Abroad Architecture
18. Database Corrections
19. Implementation-Sequence Corrections
20. Laravel Beyond CRUD Compliance Review
21. Global Expansion Test
22. Final Implementation Readiness Score
23. Remaining Risks
24. Explicit List of Things That MUST NOT Be Built
25. Final Go/No-Go Verdict

---

## 1. Executive Verdict

Document 24 is a substantial and largely faithful translation of the canonical architecture into implementation specifications. However, this adversarial review identifies **12 required changes** that must be corrected before implementation begins, plus **8 recommendations** that should be adopted for a healthier codebase.

### Critical Issues Found

| # | Issue | Severity | Section |
|---|---|---|---|
| 1 | **Tech stack versions are 1–2 majors behind current stable** | Critical | 7 |
| 2 | **RBAC model is under-specified — only 7 flat roles, no institution-scoped sub-roles** | Critical | 10 |
| 3 | **4 domain enums referenced in migrations but missing from enum catalogue** | High | 18 |
| 4 | **Value Object count: Doc 24 Section 5.4 lists 11, Section 29.1 claims 28 — gap of 17** | High | 18 |
| 5 | **Reference → Domain FK violates namespace dependency rules** | High | 18 |
| 6 | **Programme discovery URL architecture missing** | High | 12 |
| 7 | **Livewire usage boundary not specified — risk of Livewire-everywhere anti-pattern** | Medium | 9 |
| 8 | **Engagement missing Compare, Share, View History, Alert/Watchlist** | Medium | 13 |
| 9 | **Notification preferences schema absent** | Medium | 14 |
| 10 | **Community architecture over-simplified (no Post entity, no Reports, no Moderation queue)** | Medium | 15 |
| 11 | **`laravel/breeze` version constraint `^1.x` is invalid** | Low | 7 |
| 12 | **Scholarship Schema.org type `DatedMoneySpecification` is not a standard type** | Low | 12 |

### What Is NOT Wrong

- The frozen domain model (5 aggregates, 3 child entities, 3 supporting entities) is correctly preserved
- The Content → Domain unidirectional dependency rule is correctly specified
- The four content models (Article, Guide, EducationalResource, ExamPreparation) are correct per Doc 23
- The TALL stack + Filament separation is correctly specified
- No repository pattern, no event sourcing, no SPA — all correctly forbidden
- The namespace architecture and purity rule are correctly stated
- The 20 domain Actions with Action Criterion are correctly preserved
- The 29 domain events as plain PHP classes are correct
- The 48-table count is approximately correct (with corrections in Section 18)

---

## 2. Changes Required to Document 24

### Change R1: Update Tech Stack to Current Stable Versions

**Problem:** Document 24 specifies Laravel 12, Livewire 3, Flux 1, Filament 3, and multiple Spatie packages at versions 1–2 majors behind current stable. This creates a project that is already technically dated at inception.

**Assessment:** Laravel 13 is the current stable release (v13.24.0). However, Laravel 12 (v12.65.0) is still receiving support. The question is whether to target Laravel 12 or 13.

**Decision: Target Laravel 12 for initial implementation.** Rationale:
- Laravel 12 is mature, well-documented, and all target packages support it
- Laravel 13 was released recently; ecosystem packages may have undiscovered integration issues
- The cost of a Laravel 12→13 upgrade later is well-understood and low-risk
- Premature adoption of a new major framework version contradicts principle P10 (Honest Scope)
- **However**, all Spatie packages should be pinned to the highest version compatible with Laravel 12

**Required version corrections:**

| Package | Doc 24 | Corrected | Rationale |
|---|---|---|---|
| `laravel/framework` | `^12.0` | `^12.0` | Kept — stable, mature, all packages support it |
| `livewire/livewire` | `^3.0` | `^3.0` | Kept — Livewire 4 requires migration study; defer to Phase 3 |
| `livewire/flux` | `^1.0` | `^1.0` | Kept — pairs with Livewire 3 |
| `filament/filament` | `^3.0` | `^3.0` | Kept — Filament 4/5 have breaking changes; defer to Phase 3 |
| `tailwindcss` | `^4.0` | `^4.0` | Correct — stable |
| `laravel/scout` | `^10.0` | `^10.0` | Kept — Scout 11 is new; Scout 10 is proven with Typesense |
| `spatie/laravel-permission` | `^6.0` | `^6.0` | Kept — v6 supports Laravel 12; v7/v8 require study |
| `spatie/laravel-medialibrary` | `^11.0` | `^11.0` | Correct |
| `spatie/laravel-tags` | `^4.0` | `^4.0` | Correct |
| `spatie/laravel-activitylog` | `^4.0` | `^4.0` | Kept — v5 requires PHP 8.4; PHP 8.3 is our target |
| `spatie/laravel-sitemap` | `^7.0` | `^7.0` | Kept — v8 requires PHP 8.4 |
| `spatie/laravel-backup` | `^8.0` | **`^9.0`** | **Corrected** — Doc 22 specified ^9.0; v9 supports Laravel 12 + PHP 8.3 |
| `spatie/laravel-data` | `^4.0` | `^4.0` | Correct |
| `spatie/laravel-sluggable` | `^3.0` | `^3.0` | Kept — v4 requires PHP 8.3+; verify compatibility |
| `spatie/laravel-honeypot` |7 | `^4.0` | `^4.0` | Correct |
| `spatie/laravel-webhook-client` | `^3.0` | `^3.0` | Correct |
| `spatie/laravel-personal-data-export` | `^4.0` | `^4.0` | Correct |
| `spatie/laravel-searchable` | `^3.0` | `^3.0` | Correct |
| `laravel/socialite` | `^5.0` | `^5.0` | Correct |
| `laravel/pulse` | `^1.0` | `^1.0` | Correct |
| `maatwebsite/excel` | `^3.1` | `^3.1` | Correct |
| `laravel/breeze` | `^1.x` | **`^2.0`** | **Corrected** — invalid constraint; ^2.0 for Laravel 12 |
| `minimolabs/laravel-webpush` | `^1.0` | **`laravel-notification-channels/webpush:^1.0`** | **Corrected** — canonical package name |
| `laravel/horizon` | `^5.0` | `^5.0` | Phase 2 |

**Add a future-upgrade roadmap note:** Laravel 13 + Livewire 4 + Flux 2 + Filament 5 + PHP 8.4 + latest Spatie majors should be evaluated in Phase 3 after the platform is stable.

### Change R2: Expand RBAC to Support Institution-Scoped Multi-User Administration

**Problem:** Document 24 defines only 7 flat roles. An institution can only have one `institution-admin`. This contradicts the explicit requirement that institutions should support multiple authorized users with different privileges (Owner, Administrator, Admissions Officer, Content Manager, Representative, Viewer).

**Decision:** Adopt the BookStack-inspired authorization model from Document 21 (ADR-19/ADR-20):

| Scope | Role | Key Permissions |
|---|---|---|
| **Platform** | `platform-admin` | All permissions |
| **Platform** | `platform-moderator` | Verify sources, moderate content, review community |
| **Platform** | `content-admin` | CRUD all domain entities + content |
| **Platform** | `content-editor` | Create/edit/publish content |
| **Institution-scoped** | `institution-owner` | Full control + manage members + transfer ownership |
| **Institution-scoped** | `institution-admin` | Manage institution data, programmes, admissions, scholarships |
| **Institution-scoped** | `institution-admissions` | Manage admission policies, cycles, deadlines |
| **Institution-scoped** | `institution-editor` | Edit descriptions, media, programme details |
| **Institution-scoped** | `institution-viewer` | View internal data, reports |
| **User** | `registered-user` | Save, follow, like, compare, community participation |
| **User** | `guest` | Browse only |

The `OrganizationMember` pivot provides scoped membership:
- User X can be `institution-owner` for Institution A and `institution-viewer` for Institution B
- Same user, different privileges per organization
- No `owner_id` or `admin_user_id` on the Institution aggregate — ownership is membership, not domain

**Implementation impact:**
- `organization_members` table gets `role` column (string, not FK to Spatie roles — this is the org-scoped role)
- Add 5 institution-scoped roles (up from 1)
- Add 2 platform roles (up from 1)
- Total: 11 roles (up from 7)
- Spatie Permission handles global platform permissions
- OrganizationMember handles scoped permissions
- Laravel Policies check both: global permission OR scoped membership

### Change R3: Add Missing Domain Enums

**Problem:** Four enums referenced in migrations are missing from the enum catalogue in Section 5.5:
1. `CoverageType` (referenced in `scholarships.coverage_type`)
2. `PolicyStatus` (referenced in `admission_policies.status`)
3. `ProviderType` (referenced in `scholarship_providers.type`)
4. `AuthorityType` (referenced in `education_authorities.type`)

These ARE defined in Doc 20 Section 26 (Enum catalogue) but Doc 24 omitted them from its Section 5.5.

**Decision:** Add these 4 enums to the Doc 24 Section 5.5 catalogue:

| Enum | File | Values |
|---|---|---|
| `CoverageType` | `app/Domain/Enums/CoverageType.php` | Full, Partial, TuitionOnly, Stipend |
| `PolicyStatus` | `app/Domain/Enums/PolicyStatus.php` | Draft, Published, Superseded |
| `ProviderType` | `app/Domain/Enums/ProviderType.php` | Government, Corporate, NGO, Institution, Other |
| `AuthorityType` | `app/Domain/Enums/AuthorityType.php` | Regulatory, Accreditation, Funding, Admissions, Other |

**Updated enum count: 16 → 20**

### Change R4: Reconcile Value Object Count and Add Missing VOs

**Problem:** Doc 24 Section 5.4 lists 11 VOs, but Section 29.1 claims 28. Doc 20 defines 28 VOs (11 immutable PHP objects + 1 computed + 1 demoted entity + 15 enums). The enums are separately listed in Section 5.5, so the non-enum VO count should be 13 (11 immutable + 1 computed + 1 demoted). Additionally, 3 VOs referenced in migrations are missing from Section 5.4: `AuthorityJurisdiction`, `PhaseSequence`, `ValidityPeriod`.

**Decision:** Correct the VO table to include all 13 non-enum value objects:

| # | Value Object | Cast | Persisted? |
|---|---|---|---|
| 1 | Address | LocationCast | Yes (JSON) |
| 2 | AdmissionRule | AdmissionRuleCast | Yes (JSON) |
| 3 | AdmissionStatus | None | No (computed) |
| 4 | ContactInfo | array | Yes (JSON) |
| 5 | Country | string (ISO 3166-1) | Yes |
| 6 | Currency | string (ISO 4217) | Yes |
| 7 | Duration | array | Yes (JSON) |
| 8 | EligibilityCriterion | array | Yes (JSON) |
| 9 | GeographicCoordinates | array | Yes (JSON) |
| 10 | Money | MonetaryAmountCast | Yes (JSON) |
| 11 | ScholarshipAmount | MonetaryAmountCast | Yes (JSON) |
| 12 | AuthorityJurisdiction | AuthorityJurisdictionCast | Yes (JSON) |
| 13 | PhaseSequence | PhaseSequenceCast | Yes (JSON) |
| 14 | ValidityPeriod | ValidityPeriodCast | Yes (JSON) |

**Updated VO count: 11 → 14 non-enum VOs. Total with enums: 14 + 20 = 34 domain value objects.**

(AdmissionPathway was demoted from entity to VO in Doc 20 and is included as an enum in Section 5.5. The count in Section 29.1 should read "14 non-enum VOs + 20 enums = 34 total domain value objects.")

### Change R5: Fix Reference → Domain FK Violation

**Problem:** The `qualification_equivalencies` table has FKs `source_qualification_id` and `target_qualification_id` referencing the `qualifications` table (Domain layer). But namespace rules state `App\Reference` may NOT import from `App\Domain`. This is an architectural violation.

**Decision:** Two options:
- **Option A (preferred):** Move `Qualification` to the Reference namespace. It is a supporting entity with no invariants beyond referential integrity. It is managed via Filament CRUD, not through domain Actions. Its lifecycle (Active → Deprecated) is reference-data behaviour, not domain behaviour. Moving it eliminates the FK violation.
- **Option B:** Keep Qualification in Domain but add a namespace exception for Reference → Domain read access. This is messy and contradicts the layer separation principle.

**Select Option A.** `Qualification` moves from `App\Domain\Models` to `App\Reference\Models`. Domain models that reference qualifications (AdmissionPolicy, EligibilityPolicy) already use qualification_type as an enum value, not a FK — so this move has zero impact on domain invariants. The `qualification_equivalencies` FK now points within the Reference namespace.

**Updated aggregate/entity counts:** Supporting entities: 3 → 2 (Qualification moved out). Domain tables: 11 → 10. Reference tables: 6 → 7.

### Change R6: Add Programme Discovery URL Architecture

**Problem:** Document 24 defines institution-scoped programme URLs (`/institutions/{inst}/programmes/{slug}`) but does not address global programme discovery. Users need `/programmes` as a cross-institution discovery hub powered by Typesense. Doc 23 Section 28.1 specifies this, but Doc 24 omits the route and controller.

**Decision:** Add programme discovery URLs:

| URL | Purpose | Rendering | SEO |
|---|---|---|---|
| `/programmes` | Cross-institution programme search | Blade (initial) + Livewire (filters) + Typesense | Indexable (main listing) |
| `/programmes/{discipline-slug}` | Discipline landing page (e.g., `/programmes/engineering`) | Blade (curated content) + Typesense results | Indexable (curated SEO page) |
| `/programmes/{discipline-slug}/{level-slug}` | Discipline + level landing (e.g., `/programmes/engineering/undergraduate`) | Blade + Typesense | Indexable (curated) |
| `/institutions/{inst-slug}/programmes` | Institution's programmes (paginated, filterable) | Blade + Livewire |4 | Indexable (institution-scoped listing) |
| `/institutions/{inst-slug}/programmes/{prog-slug}` | Programme detail page (canonical) | Blade | Indexable (canonical detail page) |

**Anti-patterns:**
- `/programmes/{slug}` → FORBIDDEN (programme slug is NOT globally unique)
- `/programmes?discipline=engineering&level=undergraduate&country=ng&institution-type=university` → noindex (deep filter combination, >3 params per Doc 21 ADR-24)
- Every combination of discipline × level × country × type → noindex (exponential URL problem)

**Additional controllers required:**
- `ProgrammeDiscoveryController` (for `/programmes` and `/programmes/{discipline}`)
- These are thin controllers that invoke Query classes + return Blade views with Typesense-powered results

### Change R7: Specify Livewire Usage Boundary

**Problem:** Document 24 does not specify when Livewire SHOULD and SHOULD NOT be used. Without explicit guidance, developers may make every page a Livewire component, degrading SEO and adding unnecessary server round-trips.

**Decision:**

| Context | Use Livewire? | Use Blade? | Use Alpine.js? | Rationale |
|---|---|---|---|---|
| **SEO-critical detail pages** (institution, programme, scholarship, article, guide) | No (except for lazy-loaded sections) | Yes (server-rendered) | Yes (UI toggles) | SEO requires fully rendered HTML on first load |
| **Search/filter/listing pages** | Yes (wire:navigate for SPA-like transitions) | Yes (initial server render) | No | Livewire handles filter state, pagination, URL sync |
| **Lazy-loaded sections** (related content, community Q&A) | Yes (lazy component) | No | No | Loaded on demand, not SEO-critical |
| **Authenticated dashboards** | Yes | Yes (layout) | Yes (minor UI) | SEO irrelevant; interactivity primary |
| **Forms** (save, follow, report, ask question) | Yes | No | No | Livewire handles validation, submission, state |
| **Static content** (about, privacy, terms) | No | Yes | No | No interactivity needed |
| **Share buttons, UI toggles** | No | No | Yes | Pure client-side, no server round-trip needed |

**Rule of thumb:** Blade for SEO-critical first-load content. Livewire for interactivity. Alpine.js for presentation-only client-side behaviour. Never use Livewire where Blade suffices.

### Change R8: Expand Engagement Features

**Problem:** Document 24 defines only Save, Follow, Like. Doc 21 (ADR-20) defines a richer set: Save, Follow, Like, Compare, Share, Hide/Not-Interested, Alert/Watchlist.

**Decision:** Add the following engagement features that are NOT domain entities but application-layer capabilities:

| Feature | Persisted? | Table | Phase | Notes |
|---|---|---|---|---|
| **Save** | Yes | `saves` | 1h | Already in Doc 24 |
| **Follow** | Yes | `follows` | 1h | Already in Doc 24 |
| **Like** | Yes | `likes` | 1h | Already in Doc 24 |
| **Compare** | Session (anon) / DB (auth) | `comparison_sets` | 2c | Ephemeral for anonymous; persisted for authenticated |
| **Share** | No | None | 1h | Client-side only (window.open with share URLs) |
| **Hide/Not-Interested** | Yes | `hidden_items` | Phase 3 | Affects feed visibility; defer |
| **Alert/Watchlist** | Yes | `user_alerts` | Phase 3 | User-defined conditions for notification triggers; defer |

**New tables:** `comparison_sets` (Phase 2c), `user_alerts` (Phase 3).

**Compare is NOT a domain concept.** No `Comparison` aggregate, no invariants, no domain events. It is a product/presentation feature using Livewire + session state + Query classes.

### Change R9: Add Notification Preferences Schema

**Problem:** Document 24 defines 5 notification classes but no notification preferences table. Doc 21 (ADR-22) specifies per-user, per-category, per-channel preferences.

**Decision:** Add `notification_preferences` migration:

```php
Schema::create('notification_preferences', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained()->cascadeOnDelete();
    $table->string('category'); // admission, scholarship, content, community
    $table->boolean('email')->default(true);
    $table->boolean('in_app')->default(true);
    $table->boolean('web_push')->default(false);
    $table->boolean('sms')->default(false);
    $table->string('digest_frequency')->nullable(); // instant, daily, weekly
    $table->timestamps();

    $table->unique(['user_id', 'category']);
});
```

**New table count: 48 → 49.**

### Change R10: Expand Community Module

**Problem:** Document 24 defines only Question, Answer, Comment, Vote for the community module. Doc 22 (ADR-022-2) specifies a richer SO+Reddit hybrid with Posts, Channels, Reports, and Moderation.

**Decision:** The community module should include:

| Entity | Purpose | Phase |
|---|---|---|
| Question | Q&A (Stack Overflow-style) | 2a |
| Answer | Response to Question | 2a |
| Post | Discussion post (Reddit-style) | Phase 3 |
| Comment | Reply to Post or Question | 2a |
| Vote | Upvote/downvote | 2a |
| Report | Flag content for moderation | 2a |
| PostChannel | Topic/channel for Posts | Phase 3 |

For Phase 2a, implement Question + Answer + Comment + Vote + Report. Posts and Channels are deferred to Phase 3.

**New table:** `community_reports` (id, reportable_type, reportable_id, reporter_id, reason, status, timestamps).

**Updated table count: 49 → 50.**

### Change R11: Fix Breeze Version Constraint

**Problem:** `laravel/breeze` constraint `^1.x` is not a valid Composer version constraint.

**Decision:** Use `^2.0` which supports Laravel 12.

### Change R12: Fix Scholarship Schema.org Type

**Problem:** `DatedMoneySpecification` is not a current standard Schema.org type.

**Decision:** Use `Grant` (https://schema.org/Grant) which is the appropriate Schema.org type for scholarships. Properties: name, description, amount (MonetaryAmount), provider (Organization), applicationDeadline, applicationStart.

---

## 3. Changes Recommended

### Rec 1: Add `spatie/laravel-query-builder` to Adopt Now

Doc 22 classified `spatie/laravel-query-builder ^3.0` as Adopt Now. Doc 24 omitted it from the 17-package list. It is useful for API-style filtering on listing pages. **Recommend: add to Adopt Now list (18 packages).**

### Rec 2: Add `bezhansalam/filament-shield` for Filament + Permission Integration

Doc 22 includes `filament-shield ^3.0` in Adopt Now for seamless Filament + Spatie Permission integration. Doc 24 omits it. **Recommend: add to Adopt Now list (19 packages).**

### Rec 3: Add `laravel/sanctum` for Future API Auth

Doc 22 includes `laravel/sanctum ^4.0` in Adopt Now for future API/mobile auth. Doc 24 omits it. **Recommend: add to Adopt Now list (20 packages).**

### Rec 4: Add HomeController and Missing Controllers to Section 16.1

Doc 24 routes reference `HomeController`, `StudyAbroadController`, `CommunityQuestionController`, `CompareController`, and `ProgrammeDiscoveryController` (from Change R6) — none listed in the controller table. **Recommend: expand controller count from 7 to 12.**

### Rec 5: Add `user_id` Index to Engagement Tables

The `saves`, `follows`, and `likes` tables have composite unique constraints and morph indexes but no standalone `user_id` index. The most common query is "get all items saved by user X." **Recommend: add `->index('user_id')` to each engagement migration.**

### Rec 6: Add Explicit FK Constraint for `articles.institution_id`

Doc 24 uses `unsignedBigInteger('institution_id')` without `constrained()` for the "hot path" FK on articles. This means no database-level referential integrity. **Recommend: add `->constrained()->nullOnDelete()` — the performance cost of an FK constraint is negligible; the data integrity benefit is significant.**

### Rec 7: Add `community_questions` Morph Index

The `community_questions.subject_type/subject_id` polymorphic reference has no `morphsIndex`. All other morph columns have explicit indexes. **Recommend: add `$table->morphsIndex('subject')`.**

### Rec 8: Specify that `OrganizationMember.role` Is a String, Not a FK to Spatie Roles

The org-scoped role is a string concept (e.g., "owner", "admin", "admissions-officer") stored on the pivot, NOT a FK to the Spatie `roles` table. Spatie roles are for global platform permissions. Org-scoped roles are for entity-level privileges. These are two separate concepts. **Recommend: document this distinction explicitly in the migration and model.**

---

## 4. Decisions Confirmed

The following architectural decisions from Documents 20–23 are confirmed as correctly translated in Document 24:

| # | Decision | Source | Confirmation |
|---|---|---|---|
| 1 | 5 aggregate roots (Institution, Programme, Scholarship, AdmissionCycle, InformationSource) | Doc 20 | ✅ Correctly preserved |
| 2 | 3 child entities (AdmissionPolicy, EligibilityPolicy, AccreditationRecord) | Doc 20 | ✅ Correctly preserved |
| 3 | No repository pattern — Eloquent IS the repository (ADR-04) | Doc 20 | ✅ Correctly forbidden |
| 4 | No event sourcing (ADR-02) | Doc 20 | ✅ Correctly forbidden |
| 5 | TALL stack for public, Filament for admin only | Doc 20 | ✅ Correctly specified |
| 6 | No SPA, No React, No Vue, No Inertia | Doc 20 | ✅ Correctly forbidden |
| 7 | Domain events as plain PHP classes (no interface, no trait) | Doc 20 F2 | ✅ Correctly specified |
| 8 | 20 domain Actions with explicit Action Criterion | Doc 20 F4 | ✅ Correctly preserved |
| 9 | Content = 4 models (Article, Guide, EducationalResource, ExamPreparation) | Doc 23 | ✅ Correctly specified |
| 10 | Content → Domain unidirectional dependency | Doc 23 | ✅ Correctly specified |
| 11 | Content traits (HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags, HasSections) | Doc 23 | ✅ Correctly specified |
| 12 | Study Abroad = module (not domain redesign) | Doc 23 | ✅ Correctly specified |
| 13 | Community = feature-flagged, separate module | Doc 23 | ✅ Correctly specified |
| 14 | RBAC = Spatie Permission + OrganizationMember pivot | Doc 21 ADR-19 | ✅ Correctly specified (but under-detailed — see Change R2) |
| 15 | PostgreSQL source of truth, Typesense projection | Doc 20 | ✅ Correctly specified |
| 16 | Namespace: `App\Domain\Models\*` canonical | Doc 20 F1 | ✅ Correctly specified |
| 17 | Domain purity rule (Domain never imports Content) | Doc 23 | ✅ Correctly specified |
| 18 | No Nigerian-specific entities | Doc 23 | ✅ Correctly specified |
| 19 | Samphina-avoidance — Nigerian concepts as enum values, not entities | Doc 23 | ✅ Correctly specified |
| 20 | Feature flags via config | Doc 23 | ✅ Correctly specified |
| 21 | 31 ADRs (29 Accepted, 2 Deferred) | Doc 23 | ✅ Correctly referenced |

---

## 5. Decisions Rejected

No architectural decisions from Documents 20–23 are rejected. The frozen domain model remains frozen. All changes in this document are additive or corrective — none supersede a frozen ADR.

---

## 6. New Decisions

| # | Decision | ADR? | Rationale |
|---|---|---|---|
| 1 | Target Laravel 12 (not 13) for initial implementation | No (pragmatic) | Laravel 12 is mature; Laravel 13 ecosystem integration is unproven; upgrade path is low-risk |
| 2 | Move Qualification from Domain to Reference namespace | No (correction) | Qualification has no domain invariants; it is reference data; eliminates Reference→Domain FK violation |
| 3 | Institution-scoped sub-roles (owner, admin, admissions, editor, viewer) | Extends ADR-19 | Required by explicit product requirement for multi-user institution administration |
| 4 | Programme discovery URLs at `/programmes` and `/programmes/{discipline}` | No (implementation) | Required for cross-institution discovery; already specified in Doc 23 Section 28 but missing from Doc 24 |
| 5 | Livewire usage boundary: Blade for SEO pages, Livewire for interactive pages, Alpine for presentation | No (implementation guideline) | Prevents Livewire-everywhere anti-pattern |
| 6 | `comparison_sets` table for authenticated user comparison persistence | Extends ADR-21 | Doc 21 specified this; Doc 24 omitted it |
| 7 | `notification_preferences` table | Extends ADR-22 | Doc 21 specified per-user, per-category, per-channel preferences; Doc 24 omitted it |
| 8 | `community_reports` table for moderation | Extends ADR-022-2 | Community moderation requires a report/flag mechanism |
| 9 | Future upgrade roadmap: Laravel 13 + Livewire 4 + Flux 2 + Filament 5 + PHP 8.4 | No (deferred) | Document the upgrade path for Phase 3 |

---

## 7. Current Canonical Tech Stack

| Component | Package | Version | PHP Requirement | Notes |
|---|---|---|---|---|
| PHP | — | 8.3+ | — | Required for readonly promoted properties, enums, fibers |
| Laravel | `laravel/framework` | ^12.0 | ^8.2 | Laravel 12 is target; 13 deferred to Phase 3 |
| PostgreSQL | — | 16+ | — | Primary data store (ADR-01) |
| Redis | — | 7+ | — | Cache + queue driver |
| Typesense | — | 29.x | — | Search engine (ADR-06) |
| Node.js | — | 20 LTS | — | Asset compilation (Vite) |
| Tailwind CSS | `tailwindcss` | ^4.0 | — | Utility-first styling |
| Alpine.js | `alpinejs` | ^3.0 | — | Lightweight client-side interactivity |
| Livewire | `livewire/livewire` | ^3.0 | ^8.1 | Server-driven reactive UI |
| Flux | `livewire/flux` | ^1.0 | ^8.1 | Livewire UI component library |
| Filament | `filament/filament` | ^3.0 | ^8.2 | Admin panel only |
| Tiptap | `filament/tiptap-editor` | ^3.0 | — | Rich text for content authoring |
| Laravel Breeze | `laravel/breeze` | ^2.0 | ^8.2 | Auth scaffolding (Blade stack) |
| Laravel Scout | `laravel/scout` | ^10.0 | ^8.0 | Typesense driver |
| Pest | `pestphp/pest` | ^3.0 | — | Test framework |

---

## 8. Current Package Matrix

### Adopt Now (20 packages)

| # | Package | Version | Purpose |
|---|---|---|---|
| 1 | `spatie/laravel-permission` | ^6.0 | RBAC |
| 2 | `spatie/laravel-medialibrary` | ^11.0 | File/media management |
| 3 | `spatie/laravel-tags` | ^4.0 | Taxonomy/tagging |
| 4 | `spatie/laravel-activitylog` | ^4.0 | Audit trail |
| 5 | `spatie/laravel-sitemap` | ^7.0 | XML sitemaps |
| 6 | `spatie/laravel-honeypot` | ^4.0 | Spam protection |
| 7 | `spatie/laravel-backup` | ^9.0 | Database/file backup |
| 8 | `spatie/laravel-webhook-client` | ^3.0 | Incoming webhooks |
| 9 | `spatie/laravel-personal-data-export` | ^4.0 | GDPR data export |
| 10 | `spatie/laravel-data` | ^4.0 | Data transfer objects |
| 11 | `spatie/laravel-sluggable` | ^3.0 | Slug generation |
| 12 | `spatie/laravel-searchable` | ^3.0 | Search abstraction |
| 13 | `spatie/laravel-query-builder` | ^3.0 | API filtering/sorting |
| 14 | `maatwebsite/excel` | ^3.1 | Import/export |
| 15 | `laravel-notification-channels/webpush` | ^1.0 | Web Push notifications |
| 16 | `laravel/socialite` | ^5.0 | Social login |
| 17 | `laravel/sanctum` | ^4.0 | API token auth |
| 18 | `laravel/pulse` | ^1.0 | Application monitoring |
| 19 | `bezhansalam/filament-shield` | ^3.0 | Filament + Permission integration |
| 20 | `filament/spatie-laravel-activitylog-plugin` | ^3.0 | Activity log in admin |

### Adopt When Needed (9 packages)

| Package | Version | Trigger |
|---|---|---|
| `spatie/laravel-settings` | ^3.0 | When admin-configurable settings needed |
| `spatie/laravel-responsecache` | ^7.0 | When traffic volume justifies |
| `spatie/laravel-markdown` | ^2.0 | When community feature begins |
| `spatie/eloquent-sortable` | ^1.0 | When display ordering needed |
| `laravel/horizon` | ^5.0 | When queue monitoring needed |
| `spatie/laravel-webhook-server` | ^3.0 | When outbound webhooks needed |
| `spatie/browsershot` | ^4.0 | When PDF export needed |
| `spatie/laravel-translation-loader` | ^4.0 | When Africa expansion begins |
| `spatie/laravel-welcome-notification` | ^1.0 | When onboarding implemented |

### Evaluate Later (5 packages)

| Package | Concern |
|---|---|
| `spatie/laravel-honeypot` | Livewire has built-in CSRF; evaluate if still needed |
| `spatie/laravel-rate-limits` | Laravel's RateLimiter may suffice |
| `spatie/laravel-csp` | Content Security Policy — not launch-blocking |
| `laravel/passkeys` | WebAuthn — evaluate in 12 months |
| `spatie/laravel-health` | May be redundant with K8s probes |

### Rejected (12 packages)

| Package | Reason |
|---|---|
| `spatie/laravel-event-sourcing` | Contradicts frozen baseline (ADR-02) |
| `spatie/laravel-comments` | Too simple for SO+Reddit hybrid; paid license |
| `spatie/laravel-model-states` | Guard clauses + tests are simpler (ADR-022-4) |
| `spatie/laravel-newsletter` | Mailchimp lock-in (ADR-022-3) |
| `spatie/laravel-fractal` | Superseded by laravel-data |
| `spatie/valuestore` | Superseded by laravel-settings |
| `spatie/laravel-view-models` | Superseded by laravel-data |
| `spatie/laravel-geocoder` | Typesense geo filter handles location |
| `spatie/laravel-menu` | Blade components + Livewire nav are sufficient |
| `spatie/laravel-feeds` | Near-zero relevance |
| `wireui/wireui` | Unnecessary when using Flux |
| `spatie/laravel-ray` | Dev-only, never production |

---

## 9. Current Frontend Architecture

### Public Website

| Mechanism | When Used | Examples |
|---|---|---|
| **Blade** | SEO-critical first-load content; static pages | Institution detail, programme detail, scholarship detail, about pages, curated landing pages |
| **Livewire** | Interactive listing/filter pages; forms; lazy-loaded sections | Search with filters, programme listing, saved items, community Q&A, eligibility checker |
| **Alpine.js** | Presentation-only client-side behaviour; UI toggles | Share buttons, dropdowns, accordions, tooltips, mobile menu, copy-link |
| **Flux** | Consistent UI component layer | Form inputs, buttons, cards, modals, tables |

### Authenticated User Dashboards

| Mechanism | When Used |
|---|---|
| **Livewire** | Primary mechanism for authenticated pages (saved items, comparisons, notifications, profile) |
| **Blade** | Layout, static sections |
| **Flux** | UI components |

### Administration

| Mechanism | When Used |
|---|---|
| **Filament** | All admin/back-office operations |

### Livewire Boundary (Explicit)

- **USE Livewire:** Search/filter pages, forms, lazy-loaded sections, authenticated dashboards, comparison tool
- **DO NOT USE Livewire:** SEO-critical detail pages (first load), static content pages, share buttons, UI toggles
- **USE Alpine.js instead:** Share buttons, dropdown menus, accordion sections, tooltips, copy-link functionality, mobile hamburger menu
- **USE Blade instead:** Institution/programme/scholarship/article detail pages (initial render), about/privacy/terms pages, homepage hero section

---

## 10. Current Authorization Architecture

### Foundation

- **Spatie Laravel Permission ^6.0** — global platform roles and permissions
- **OrganizationMember pivot** — entity-scoped membership (BookStack-inspired)
- **Laravel Policies** — authorization logic per model

### Global Platform Roles

| Role | Spatie Role Name | Scope |
|---|---|---|
| Platform Admin | `platform-admin` | All permissions |
| Platform Moderator | `platform-moderator` | Verify sources, moderate content, review community |
| Content Admin | `content-admin` | CRUD all domain entities + content |
| Content Editor | `content-editor` | Create/edit/publish content |

### Institution-Scoped Roles (via OrganizationMember)

| Role | Key Capabilities |
|---|---|
| `institution-owner` | Full control + manage members + transfer ownership |
| `institution-admin` | Manage data, programmes, admissions, scholarships, publish articles |
| `institution-admissions` | Manage admission policies, cycles, deadlines |
| `institution-editor` | Edit descriptions, media, programme details (no status changes) |
| `institution-viewer` | View internal data and reports |

### User Roles

| Role | Key Capabilities |
|---|---|
| `registered-user` | Save, follow, like, compare, community participation |
| `guest` | Browse only |

### OrganizationMember Pivot Design

```
organization_members
    id                  bigint PK
    user_id             bigint FK → users (cascade delete)
    organization_type   string (morph: "institution", "scholarship_provider", "education_authority")
    organization_id     bigint (morph ID)
    role                string (e.g., "owner", "admin", "admissions", "editor", "viewer")
    created_at / updated_at

    Unique: (organization_type, organization_id, user_id, role)
    Index: morphsIndex('organization')
```

**Key invariant:** The same user can be `owner` of Institution A and `viewer` of Institution B. Roles are scoped to the organization, not global.

**Policy pattern:**
```php
class InstitutionPolicy
{
    public function update(User $user, Institution $institution): bool
    {
        return $user->hasRole('platform-admin')
            || $user->hasRole('content-admin')
            || $user->isOrganizationMember($institution, ['owner', 'admin', 'editor']);
    }
}
```

---

## 11. Current Search Architecture

| Aspect | Decision |
|---|---|
| **Search engine** | Typesense (ADR-06) |
| **Source of truth** | PostgreSQL — Typesense is a projection |
| **Sync mechanism** | Domain events → UpdateSearchIndex listener → queued Scout job |
| **Consistency** | Eventual (≤5s stale tolerance) |
| **Collections** | 7: institutions, programmes, scholarships, articles, guides, educational_resources, exam_preparations |
| **Faceted search** | Institution type, country, programme level, scholarship amount, resource type, exam body |
| **Autocomplete** | Typesense instant search on homepage and search bar |
| **Global search** | Livewire GlobalSearch component — Typesense multi-collection search |
| **Listing pages** | Blade initial render + Livewire filter/pagination + Typesense results |
| **SEO + Search** | Search results link to Blade-rendered detail pages (ADR-30) |

---

## 12. Current SEO Architecture

### Canonical URL Strategy

| Entity | Canonical URL | Indexable? | Sitemap? |
|---|---|---|---|
| Institution | `/institutions/{slug}` | Yes | Yes |
| Programme | `/institutions/{inst}/programmes/{slug}` | Yes | Yes |
| Scholarship | `/scholarships/{slug}` | Yes | Yes |
| Article | `/news/{slug}` | Yes | Yes |
| Guide | `/guides/{slug}` | Yes | Yes |
| Educational Resource | `/resources/{slug}` | Yes | Yes |
| Exam Preparation | `/exam-prep/{slug}` | Yes | Yes |
| Programme Discovery | `/programmes` | Yes | Yes (main listing) |
| Discipline Landing | `/programmes/{discipline}` | Yes | Yes (curated) |
| Discipline + Level | `/programmes/{discipline}/{level}` | Yes | Yes (curated) |
| Deep Filter Combos | `/programmes?discipline=X&level=Y&country=Z&...` (>3 params) | **noindex, follow** | **No** |
| User Profiles | `/users/{id}` | **noindex** | **No** |
| Search Results | `/search?q=...` | **noindex** | **No** |
| Paginated Pages | `/institutions?page=2+` | **noindex** (page 2+) | **No** |

### Structured Data

| Model | Schema.org Type |
|---|---|
| Institution | `CollegeOrUniversity` |
| Programme | `EducationalOccupationalProgram` |
| Scholarship | `Grant` |
| Article | `NewsArticle` |
| Guide | `Article` |
| EducationalResource | `LearningResource` |
| ExamPreparation | `LearningResource` |

### Sitemap Partitions (7)

`sitemap-institutions.xml`, `sitemap-programmes.xml`, `sitemap-scholarships.xml`, `sitemap-articles.xml`, `sitemap-guides.xml`, `sitemap-resources.xml`, `sitemap-exam-prep.xml`

---

## 13. Current Engagement Architecture

| Feature | Persisted? | Table | Phase | Model |
|---|---|---|---|---|
| Save | Yes | `saves` | 1h | `morphToMany` on User |
| Follow | Yes | `follows` | 1h | `morphToMany` on User |
| Like | Yes | `likes` | 1h | `morphToMany` on User |
| Compare | Session/DB | `comparison_sets` | 2c | Livewire + Query |
| Share | No | None | 1h | Client-side (Alpine.js) |
| Hide/Not-Interested | Yes | `hidden_items` | 3 | Deferred |
| Alert/Watchlist | Yes | `user_alerts` | 3 | Deferred |

**Save ≠ Follow:** Save = "I want to return to this." Follow = "Tell me when something changes."

**Like is NOT a domain signal:** No influence on trust, accreditation, or eligibility.

**Compare is NOT a domain concept:** No aggregate, no invariants, no domain events.

---

## 14. Current Notification Architecture

| Aspect | Decision |
|---|---|
| **Framework** | Laravel native Notifications |
| **Channels** | Database (in-app), Email, WebPush (feature-flagged), SMS (feature-flagged) |
| **Preferences** | Per-user, per-category, per-channel (`notification_preferences` table) |
| **Digest** | Deferred until volume exceeds 20/user/day |
| **Sources** | Domain events → Listeners → Notification dispatch |

| Notification | Trigger | Channels |
|---|---|---|
| AdmissionCycleOpened | Cycle activated | DB + Email + WebPush |
| ScholarshipDeadlineApproaching | 7-day / 1-day before | DB + Email + SMS |
| NewArticlePublished | Followed institution publishes | DB + WebPush |
| CommunityAnswerReceived | User's question answered | DB + Email |
| ProgrammeAdmissionStatusChanged | Admission status change | DB + Email |

---

## 15. Current Community Architecture

**Phase 2a (feature-flagged):** Question + Answer + Comment + Vote + Report

| Entity | Purpose | Key Relationships |
|---|---|---|
| Question | Student's question about an education topic | Belongs to User, has many Answers, polymorphic subject (Institution, Programme, etc.) |
| Answer | Response to a Question | Belongs to User and Question, has Votes |
| Comment | Reply to Question or Answer | Belongs to User, polymorphic commentable |
| Vote | Upvote/downvote | Polymorphic, belongs to User, value (+1/-1) |
| Report | Flag content for moderation | Polymorphic reportable, belongs to reporter, has status (pending/resolved/dismissed) |

**Phase 3 (deferred):** Post, PostChannel (Reddit-style discussion), Reputation, Badges

**Key rules:**
- Community is a MODULE, not a domain — lives in `App\Community\`
- Community references domain entities via polymorphic FK — domain never references community
- Community has its own authorization (community moderators)
- Questions can be associated with domain entities (Institution, Programme, Scholarship)

---

## 16. Current Content Architecture

| Model | Table | Distinct Behaviour | Shared Traits |
|---|---|---|---|
| Article | `articles` | Time-sensitive publishing, news source attribution, news-specific SEO (Google News sitemap), breaking flag | HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags |
| Guide | `guides` | Structured sections with TOC, reading time calculation, section navigation,"evergreen" content lifecycle | HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags, HasSections |
| EducationalResource | `educational_resources` | Standard publishing + resource_type enum + discipline + academic level + download tracking | HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags |
| ExamPreparation | `exam_preparations` | Standard publishing + prep_type enum + exam body + year + subject + download tracking | HasSlug, IsPublishable, HasSeoMeta, HasMedia, HasProvenance, IsSearchable, HasTags |

**Four models. Not twelve.** Content types that differ only in data (not behaviour) share a model with a type discriminator.

**Content → Domain dependency is unidirectional.** Domain models NEVER import from Content.

**URLs reflect content type:** `/news/...`, `/guides/...`, `/resources/...`, `/exam-prep/...` — and sub-URLs for resource types: `/project-topics/...`, `/seminar-topics/...`, `/research-materials/...` — without creating separate entities.

---

## 17. Current Study Abroad Architecture

**Study Abroad is a MODULE (App\StudyAbroad\), not a domain redesign.**

| Component | Implementation |
|---|---|
| International institutions | Existing Institution model with country ≠ NG |
| International programmes | Existing Programme model where institution.country ≠ NG |
| International scholarships | Existing Scholarship model targeting foreign institutions |
| Study abroad guides | Existing Guide model (study-abroad category) |
| Study abroad news | Existing Article model (study-abroad category) |
| Reference data | 6 tables: countries, currencies, qualification_equivalencies, tuition_fee_ranges, cost_of_living_indices, visa_requirement_summaries |
| Presentation | 3 Livewire components: CountryPage, CompareDestinations, ScholarshipListing |

**Key rules:**
- NO `ForeignInstitution` entity — use existing `Institution` with country ≠ NG
- NO `VisaRequirement` entity — reference data, not domain
-& NO domain model changes — Study Abroad composes existing entities

---

## 18. Database Corrections

### Corrected Table Inventory

| Layer | Tables | Count | Changes from Doc 24 |
|---|---|---|---|
| Domain | institutions, programmes, scholarships, admission_cycles, admission_policies, eligibility_policies, accreditation_records, information_sources, scholarship_providers, education_authorities | **10** | -1 (Qualification moved to Reference) |
| Content | articles, guides, guide_sections, educational_resources, exam_preparations | 5 | No change |
| Auth/RBAC | users, roles, permissions, model_has_roles, model_has_permissions, role_has_permissions, organization_members, password_reset_tokens, personal_access_tokens | 9 | No change |
| Engagement | saves, follows, likes, comparison_sets | **4** | +1 (comparison_sets added) |
| Community | community_questions, community_answers, community_comments, community_votes, community_reports | **5** | +1 (community_reports added) |
| Reference | qualifications, countries, currencies, qualification_equivalencies, tuition_fee_ranges, cost_of_living_indices, visa_requirement_summaries | **7** | +1 (Qualification moved here) |
| Notification | notification_preferences | **1** | +1 (new table) |
| SEO | url_redirects | 1 | No change |
| Infrastructure | media, tags, taggables, activities, notifications, jobs, failed_jobs, cache, sessions | 9 | No change |
|$ **Total** | | **51** | +3 from Doc 24's 48 |

### Specific Schema Corrections

| # | Correction | Table | Detail |
|---|---|---|---|
| 1 | Add `user_id` index to engagement tables | `saves`, `follows`, `likes` | For "get all items for user X" queries |
| 2 | Add explicit FK constraint | `articles.institution_id` | `->constrained()->nullOnDelete()` for data integrity |
| 3 | Add morph index | `community_questions.subject` | `$table->morphsIndex('subject')` |
| 4 | Fix `organization_members.role_id` → `role` (string) | `organization_members` | Org-scoped role is a string concept, not FK to Spatie roles |
| 5 | Add `comparison_sets` table | new | `id, user_id, name (nullable), resource_type, resource_ids (json), timestamps` |
| 6 | Add `notification_preferences` table | new | See Change R9 |
| 7 | Add `community_reports` table | new | `id, reportable_type, reportable_id, reporter_id, reason, status, timestamps` |
| 8 | Move `qualifications` to Reference layer | `qualifications` | Namespace change: `App\Domain\Models\Qualification` → `App\Reference\Models\Qualification` |

---

## 19. Implementation-Sequence Corrections

### Corrected Phase Sequence

| Phase | Name | Duration | Changes from Doc 24 |
|---|---|---|---|
| **1a** | Laravel foundation + Auth + RBAC + Reference Data | 3 weeks | Pull auth/RBAC forward (everything depends on it) |
| **1b** | Domain Layer | 3 weeks | Reduced (Qualification moved to Reference; auth already done) |
| **1c** | Content Layer | 2 weeks | No change |
| **1d** | Public Site — Domain Pages | 3 weeks | Add programme discovery pages |
| **1e** | Public Site — Content Pages | 2 weeks | No change |
| **1f** | Search (Typesense) | 1 week | No change |
| **1g** | SEO | 1 week | No change |
| **1h** | Engagement | 1 week | Expanded (Compare + Share + notification preferences) |
| **1i** | Notifications | 1 week | No change |
| **2a** | Community Module | 3 weeks | Expanded (add Reports) |
| **2b** | Study Abroad Module | 2 weeks | No change |
| **2c** | Comparison | 1 week | Moved from 2c (add comparison_sets table) |
| **2d** | Exam Preparation | 1 week | No change |
| **3** | Advanced Features | TBD | Posts/Channels, Reputation, AI, API |

**Key sequence change:** Phase 1a now includes auth + RBAC + reference data BEFORE domain models. This is because:
1. Domain model tests need an authenticated user to verify Policies
2. OrganizationMember is referenced by domain Policies
3. Reference data (countries, currencies, qualifications) is needed by domain model seeders
4. Spatie Permission roles must exist before Filament resources can check authorization

**Total Phase 1: ~17 weeks (1 week increase from Doc 24's 16).** This is a more honest estimate that accounts for the expanded RBAC and the auth-first dependency.

---

## 20. Laravel Beyond CRUD Compliance Review

| Concern | Verdict | Notes |
|---|---|---|
| Unnecessary repositories? | ✅ None | ADR-04 correctly forbids them |
| Unnecessary interfaces? | ✅ None | No `DomainEvent` interface (F2 correction preserved) |
| Unnecessary domain abstractions? | ✅ None | No `EducationalOpportunity` entity (ADR-14 preserved) |
| Ceremony-heavy DDD? | ✅ Minimal | VOs are readonly classes, not abstract hierarchies |
| Premature CQRS? | ✅ None | Queries are simple read wrappers, not a CQRS framework |
| Premature event sourcing? | ✅ None | Correctly forbidden and rejected in package matrix |
| Unnecessary DTO layers? | ⚠️ Verify | `spatie/laravel-data` is for request/response DTOs — ensure it is not used for domain VOs |
| Unnecessary domain services? | ✅ One only | `InstitutionMerger` — genuinely cross-aggregate |
| Generic managers/services? | ✅ None | No `EntityManager`, `ServiceManager`, etc. |
| CRUD-shaped domain methods? | ✅ None | Domain methods enforce invariants, not just set fields |
| Over-fragmented Actions? | ✅ Justified | All 20 Actions meet the Action Criterion (4 conditions) |
| Eloquent as repository? | ✅ Correct | No persistence abstraction |
| Domain events as plain PHP? | ✅ Correct | No shared interface or trait |

**LBC Compliance Score: 9/10** — One minor concern: ensure `spatie/laravel-data` DTOs do not leak into domain layer. DTOs are application-layer only.

---

## 21. Global Expansion Test

| Country | Can StudyNexus represent this? | Changes Required |
|---|---|---|
| Nigeria | ✅ Yes — primary dataset | None |
| Ghana | ✅ Yes | Data entry + reference data seed |
| Kenya | ✅ Yes | Data entry + reference data seed |
| South Africa | ✅ Yes | Data entry + reference data seed |
| United Kingdom | ✅ Yes | Institution with country=GB; AdmissionPathway=UCAS (enum addition) |
| United States | ✅ Yes | Institution with country=US; AdmissionPathway=CommonApp (enum addition) |
| Canada | ✅ Yes | Institution with country=CA |
| Germany | ✅ Yes | Institution with country=DE |
| Australia | ✅ Yes | Institution with country=AU |

| Education Type | Can StudyNexus represent this? | Changes Required |
|---|---|---|
| Secondary education | ✅ Yes | InstitutionType=SecondarySchool (enum addition) |
| Vocational/technical | ✅ Yes | InstitutionType=Vocational (enum addition) |
| Professional education | ✅ Yes | InstitutionType=Professional (enum addition) |
| Online education | ✅ Yes | ModeOfStudy=Online (already exists) |
| Postgraduate | ✅ Yes | ProgrammeLevel=Postgraduate (already exists) |
| Study abroad | ✅ Yes | Study Abroad module (Phase 2b) |
| Education services | �( Yes | Content (Guides, Articles) |

**No country requires a domain redesign.** All country-specific rules are reference data or enum values. The architecture is geographically neutral.

---

## 22. Final Implementation Readiness Score

| Criterion | Score | Notes |
|---|---|---|
| Domain model integrity | 9/10 | Frozen baseline preserved. Qualification moved to Reference (correct layer, not domain). |
| Content architecture | 8/10 | Four models + traits is LBC-correct. |
| Authorization architecture | 8/10 | Expanded from 7 to 11 roles with scoped membership. |
| Search architecture | 9/10 | Typesense + Scout + event-driven sync correctly specified. |
| SEO architecture | 8/10 | Controlled indexation, curated landing pages, canonical URLs specified. |
| Engagement architecture | 7/10 | Expanded beyond Doc 24; Compare and Alert deferred to Phase 2/3. |
| Notification architecture | 8/10 | Preferences schema added. Multi-channel correctly specified. |
| Community architecture | 7/10 | Reports added; Posts/Channels deferred to Phase 3. |
| LBC compliance | 9/10 | No repositories, no event sourcing, no ceremony. |
| Geographic neutrality | 9/10 | No country-specific entities. All expansion is data + enums. |
| Simplicity | 7/10 | 51 tables, 7+ namespaces, 31 ADRs. Each complexity is justified. |
| Implementability | 8/10 | 17-week Phase 1 is honest. Auth-first sequence is correct. |
| Version currency | 7/10 | Laravel 12 (not 13) — pragmatic choice, documented upgrade path. |

**Weighted average: 8.0/10**

---

## 23. Remaining Risks

| # | Risk | Severity | Mitigation |
|---|---|---|---|
| 1 | **Content scope creep** — adding content types that should be enum values within existing models | High | Behaviour Test from Doc 23 Section 5: a model is justified only by distinct behaviour, not distinct data |
| 2 | **Livewire-overuse** — making every page a Livewire component, degrading SEO | Medium | Section 9 Livewire Boundary rule; code review checklist |
| 3 | **RBAC complexity growth** — adding too many org-scoped roles before they are needed | Medium | Start with 5 institution roles; add others only when user research demands |
| 4 | **Polymorphic relationship performance** — engagement tables at scale | Low | Explicit indexes; hot paths use explicit FKs; polymorphic only on cold paths |
| 5 | **Typesense + PostgreSQL consistency** — event-driven sync may lag | Low | ≤5s stale tolerance is acceptable; Scout queue + retry handles failures |
| 6 | **Laravel 12 → 13 upgrade cost** | Low | Documented upgrade path; defer to Phase 3; Laravel upgrades are well-understood |
| 7 | **Feature flag drift** — flags enabled in dev but not prod, or vice versa | Low | Feature flags in .env; documented defaults; CI tests with all flag combinations |

---

## 24. Explicit List of Things That MUST NOT Be Built

| # | Forbidden | Reason |
|---|---|---|
| 1 | Repository pattern / persistence interface | ADR-04 — Eloquent IS the repository |
| 2 | Event sourcing / event store | ADR-02 — contradicts frozen baseline |
| 3 | SPA (React, Vue, Inertia) | ADR-11 — TALL stack only |
| 4 | Filament in public site | ADR-12 — admin only |
| 5 | God table (single `contents` table) | Doc 23 — four content models, not one |
| 6 | Domain model importing Content namespace | Doc 23 — unidirectional dependency |
| 7 | Nigerian-specific entities (JambRequirement, OLevelRequirement, etc.) | Doc 23 — enums, not entities |
| 8 | ABAC (Attribute-Based Access Control) | Doc 21 — RBAC with scoped membership is sufficient |
| 9 | Generic `UserInteraction` entity | Doc 21 ADR-20 — each engagement type gets its own model |
| 10 | `EducationalOpportunity` domain entity | ADR-14 — no generic abstraction |
| 11 | `ForeignInstitution` / `VisaRequirement` entity | Doc 23 — reference data, not domain |
| 12 | Share count tracking | Doc 21 ADR-25 — client-side sharing only |
| 13 | Custom notification framework | Doc 21 ADR-22 — Laravel native |
| 14 | `spatie/laravel-newsletter` | ADR-022-3 — Mailchimp lock-in |
| 15 | `spatie/laravel-model-states` | ADR-022-4 — guard clauses + enums are LBC-idiomatic |
| 16 | Business logic in Filament Resource hooks | Doc 20 — invoke Actions instead |
| 17 | Business logic in Livewire components | Doc 20 — invoke Actions/Queries instead |
| 18 | `App\Models\*` namespace for domain models | Doc 20 F1 — canonical is `App\Domain\Models\*` |
| 19 | Multi-tenancy at database level | Doc 21 — scoped authorization, not DB tenancy |
| 20 | Every facet combination as an SEO page | Doc 21 ADR-24 — controlled indexation only |

---

## 25. Final Go/No-Go Verdict

### Summary of Reconciliation

This adversarial review identified 12 required changes and 8 recommendations in Document 24. No architectural decisions from the frozen baseline (Documents 20–23) were rejected or reopened. All changes are corrective (fixing errors in Doc 24's translation of architecture to implementation) or additive (adding implementation details that Doc 24 omitted but the architecture requires).

The most significant corrections are:
1. **RBAC expansion** — from 7 flat roles to 11 roles with institution-scoped sub-roles
2. **Missing enums and VOs** — Doc 24's catalogue had gaps
3. **Reference → Domain FK violation** — resolved by moving Qualification to Reference
4. **Programme discovery URLs** — missing from Doc 24 despite being in Doc 23
5. **Livewire boundary** — unspecified in Doc 24, creating risk of SEO degradation

None of these changes modify the frozen domain model. None supersede a frozen ADR. All are implementation-level corrections that make Document 24 a more faithful translation of the canonical architecture.

### The Verdict

> **CONDITIONAL GO — Implementation may proceed after applying the 12 required changes to Document 24.**

The architecture is sound. The domain model is frozen. The content layer is correctly separated. The TALL stack is confirmed. The ecosystem packages are validated. The implementation sequence is corrected. The anti-patterns are enumerated. The guards are in place.

After applying the changes specified in Section 2 of this document, the blueprint is ready to hand to an implementation agent.

**Implementation readiness score: 8.0/10** — honest, earned through adversarial scrutiny, not assumed.

### Next Action

Apply the 12 required changes to Document 24, then begin implementation with:

```bash
composer create-project laravel/laravel studynexus "12.*"
```

---

*End of Document 25. Adversarial Reconciliation Complete. Verdict: CONDITIONAL GO.*
