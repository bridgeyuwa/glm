# StudyNexus — Domain Discovery: Topic 4
# Behaviour Discovery

**Date:** 2026-08-07
**Status:** Awaiting Approval
**Prerequisite:** Topic 1 (Core Domain Entities), Topic 2 Revision (Aggregate Boundaries), Topic 3 (Entity Attributes & Value Objects), Architectural Review (14), Domain Integrity Review (16), Resolution Analysis (17), Consolidation (13)
**Business Discovery Status:** Frozen (immutable)
**Objective:** Discover actual domain behaviour for every entity. Challenge every operation. Reject CRUD. Protect invariants. Map cross-aggregate interactions. Produce the final behavioural model that directly informs domain architecture.

---

## SECTION 1 — BEHAVIOUR DISCOVERY METHOD

### The Ten-Question Filter

Every candidate behaviour must pass through ten questions before acceptance. This filter eliminates CRUD disguised as domain operations, operations that belong to application orchestration, and behaviours that have no invariant to protect. The method is applied uniformly across all aggregates, child entities, and supporting entities — no entity receives special dispensation.

**Q1: Is this actually a domain action?** A domain action changes state in a way that a domain expert would recognise as meaningful business activity. If the only justification is "users need to be able to change this field," it is CRUD, not domain behaviour. Domain actions have names from the ubiquitous language — "publish admission policy," not "update policy record." The distinction is not cosmetic; it determines whether the operation encodes a business rule or merely persists data.

**Q2: What business rule makes the action meaningful?** Every domain action exists because some business rule would be violated without it. If no business rule necessitates the action, it is either CRUD or application convenience. The business rule provides the *why* — the action provides the *how*. An action without a business rule is an implementation detail leaking into the domain.

**Q3: Which aggregate protects that rule?** The aggregate that owns the invariant is the aggregate that performs the action. If the action protects an invariant on Aggregate A, it must be an operation on Aggregate A — not a service, not a controller, and not Aggregate B reaching across boundaries. This question frequently reveals misplaced operations that were assigned to the wrong aggregate for convenience.

**Q4: What state changes?** A domain action must produce at least one identifiable state change. If nothing changes — no attribute, no lifecycle state, no child entity — then the operation is a query, not a command. Queries belong to read models, not to domain aggregates. This question also catches operations that are really event publications with no local state change, which is a code smell in pragmatic DDD.

**Q5: What must be true before the operation?** Preconditions are not arbitrary validations — they are the guards that protect the aggregate's invariants. Every precondition must trace to a specific invariant or lifecycle constraint. If a precondition exists solely to prevent bad UI input (e.g., "name must not be empty"), it is validation, not a domain precondition.

**Q6: What must be true afterward?** Postconditions define the invariant guarantee. After the operation, the aggregate must be in a consistent state — all invariants must hold. If an operation can leave the aggregate in an inconsistent state, either the operation is wrong or the invariant is wrong.

**Q7: Does the operation produce a meaningful domain event?** Not every state change warrants a domain event. A domain event represents a business fact that other parts of the system might need to react to. If no downstream consumer cares about this state change — and we cannot invent one merely to justify the event — then no event is needed. Event-driven architecture is a tool, not a religion.

**Q8: Does the operation require another aggregate?** Operations that require loading a second aggregate to execute are cross-aggregate interactions. These require careful handling: either the second aggregate's data is passed in (reference), the operation is split into eventual-consistency steps, or a domain service coordinates. The answer to this question determines the cross-aggregate interaction pattern.

**Q9: Can eventual consistency be acceptable?** If the answer is yes, the operation can emit a domain event and let the downstream aggregate react asynchronously. If the answer is no, the operation must be coordinated synchronously — either through a domain service or by restructuring the aggregates. This question prevents over-engineering for consistency where it is not required by the business.

**Q10: Is this merely CRUD?** The final, most important question. If the operation is indistinguishable from "create a record," "update a field," or "delete a row" — if it has no business rule, no precondition beyond field validation, no postcondition beyond "the field now has the new value" — it is CRUD. CRUD operations belong in application services, not in domain aggregates. The aggregate's public API must speak the ubiquitous language, not the database schema.

### Classification of Rejected Operations

Operations rejected by the ten-question filter fall into four categories:

1. **Pure CRUD** — persisted by application services without domain logic (e.g., updating an institution's website URL).
2. **Application orchestration** — coordinate domain operations but contain no domain logic themselves (e.g., importing accreditation data from an external source).
3. **Read-model concerns** — queries and projections that serve the UI or search but change no domain state (e.g., listing programmes by institution).
4. **Premature generalisation** — operations that might become relevant in a future phase but have no current business justification (e.g., programme versioning, policy branching).

Rejected operations are not discarded — they are allocated to the appropriate layer. The domain layer contains only operations that pass the filter.

---

## SECTION 2 — EDUCATIONAL INSTITUTION

### Existing Operations Review

The consolidation document lists seven operations for Educational Institution: `establish`, `rename`, `publishAdmissionPolicy`, `recordAccreditation`, `suspend`, `close`, `mergeWith`. Each is evaluated below.

### `establish` — Establish a New Institution

**Q1:** Yes. Creating an institution in the domain requires type, name, and registration identifier — these are not arbitrary fields, they are the institution's identity. **Q2:** INV-I1 (institution has valid type within regulatory framework) and INV-I4 (institution always has current official name). **Q3:** Institution aggregate. **Q4:** Institution transitions from non-existent to Established; type, name, and registration identifier are set. **Q5:** Type must be valid within the applicable regulatory framework; name must be non-empty; registration identifier must be provided. **Q6:** INV-I1 holds (valid type); INV-I4 holds (has name); institution is in Established state. **Q7:** `InstitutionEstablished` — downstream, this may trigger default accreditation checks or notification to education authorities. **Q8:** No — the institution is self-contained at creation. **Q9:** N/A. **Q10:** No — this is not "insert a row." It creates an entity with identity and invariants, enforcing INV-I1 at the moment of creation.

**Verdict: ACCEPTED.**

### `rename` — Change Official Name

**Q1:** Yes. Institutions are renamed through official acts — University of Ife became Obafemi Awolowo University; University of Lagos was briefly renamed Moshood Abiola University before reverting. This is a business event, not a field update. **Q2:** INV-I4 (institution always has current official name). **Q3:** Institution aggregate. **Q4:** Official name changes; a record of the previous name may be retained for historical reference. **Q5:** Institution must exist and not be closed; new name must be non-empty and distinct from current name. **Q6:** INV-I4 holds with the new name. **Q7:** `InstitutionRenamed` — downstream, search indexes must be updated; cached displays must be invalidated. **Q8:** No. **Q9:** Yes — search index updates are eventual consistency. **Q10:** No — the invariant INV-I4 and the business significance of official renaming distinguish this from CRUD.

**Verdict: ACCEPTED.**

### `publishAdmissionPolicy` — Publish Institutional Admission Policy

**Q1:** Yes. Publishing an admission policy is a significant business action — it defines the rules for an entire admission cycle at the institutional level. Institutions like UNILAG publish their post-UTME requirements as institutional policy. **Q2:** INV-I3 (only one active institutional Admission Policy per Admission Cycle). **Q3:** Institution aggregate — it owns the one-per-cycle invariant. **Q4:** A new Admission Policy child entity is created or an existing draft is promoted to published; the previous active policy for the same cycle (if any) is superseded. **Q5:** Institution must be operational (not closed/suspended); Admission Cycle must be identified; policy rules must be internally consistent. **Q6:** Exactly one active policy exists for the given cycle; the superseded policy (if any) is no longer active. **Q7:** `InstitutionalAdmissionPolicyPublished` — downstream, programmes may reference this; opportunity search must reflect updated requirements. **Q8:** Admission Cycle identity is required — but as a reference, not as loaded aggregate state. The Institution only needs the cycle's identity to associate the policy. **Q9:** Search index updates are eventual consistency. **Q10:** No — the one-per-cycle supersession rule is genuine domain logic.

**Verdict: ACCEPTED.** Note: This operation creates/manages a child entity (Admission Policy) within the Institution aggregate boundary, exactly as the child entity classification dictates.

### `recordAccreditation` — Record an Accreditation Event

**Q1:** Yes. Recording accreditation is a business fact — "NUC granted full accreditation to UNILAG on 2023-06-01." The institution does not grant its own accreditation; it records the fact that an external authority has acted. **Q2:** INV-I2 (accredited only by authority with jurisdiction over its type). **Q3:** Institution aggregate — it owns the jurisdiction invariant. **Q4:** A new Accreditation Record child entity is created. **Q5:** Granting authority must have jurisdiction over this institution's type; accreditation status, effective period, and granting authority must all be provided. **Q6:** INV-I2 holds; the new record is added to the institution's accreditation history; the institution's current accreditation status may change (derived from most recent record). **Q7:** `InstitutionAccredited` — downstream, trust signals are updated; programme accreditation status may need re-evaluation. **Q8:** Education Authority is referenced but not loaded — jurisdiction is checked via reference data. **Q9:** Trust signal updates are eventual consistency. **Q10:** No — the jurisdiction invariant and the immutable-fact nature of the record distinguish this from CRUD.

**Verdict: ACCEPTED.** Note: This is *recording a fact*, not *managing accreditation*. StudyNexus does not grant accreditation — it records that an authority has granted it.

### `suspend` — Suspend Operations

**Q1:** Yes. Institutional suspension is a serious regulatory action — the NUC can suspend an institution's operational licence, preventing all business operations. **Q2:** INV-I5 (closed institution cannot perform business operations) — suspended institutions similarly cannot perform business operations. **Q3:** Institution aggregate. **Q4:** Lifecycle state changes from Operational to Suspended. **Q5:** Institution must be Operational; reason must be provided. **Q6:** Institution is Suspended; no admission policies can be published; no accreditation can be recorded while suspended. **Q7:** `InstitutionSuspended` — downstream, all programmes under this institution should reflect the suspension; opportunity search must exclude or flag this institution. **Q8:** No. **Q9:** Programme-level effects are eventual consistency. **Q10:** No — the cascade of restrictions makes this more than a state flag update.

**Verdict: ACCEPTED.**

### `close` — Close Permanently

**Q1:** Yes. Permanent closure is the terminal state for an institution — it cannot be reversed. When a Nigerian university's licence is permanently revoked, it ceases all operations. **Q2:** INV-I5 (closed institution cannot perform business operations). **Q3:** Institution aggregate. **Q4:** Lifecycle state changes to Closed; this is a terminal state. **Q5:** Institution must exist and not already be closed; confirmation required (this is an irreversible action). **Q6:** INV-I5 holds; no business operations are possible on a closed institution. **Q7:** `InstitutionClosed` — downstream, all programmes should be marked discontinued; all scholarships targeting this institution should be flagged; search must exclude. **Q8:** No. **Q9:** Downstream effects are eventual consistency. **Q10:** No — irreversibility and cascading business impact distinguish this from CRUD.

**Verdict: ACCEPTED.**

### `mergeWith` — Merge With Another Institution

**Q1:** Yes. Institutional mergers are real business events — the Nigerian government has merged polytechnics and colleges of education into new universities. This is not a database merge; it is a business reorganisation with identity implications. **Q2:** INV-I4 (institution always has current official name) — the merged institution may take a new name; all programmes must be reassigned. **Q3:** Initiating Institution aggregate. **Q4:** The initiating institution absorbs the target; the target institution is closed; programmes are reassigned; accreditation records transfer. **Q5:** Both institutions must exist and not be closed; the target institution must be Operational or Suspended; the user must have authority to merge. **Q6:** The initiating institution contains all programmes from both; the target institution is Closed; accreditation records are transferred. **Q7:** `InstitutionsMerged` — downstream, massive search index rebuild; programme ownership updates; accreditation re-evaluation. **Q8:** Yes — the target Institution aggregate must be accessed. This is a genuine cross-aggregate operation. **Q9:** No — the merge must be transactionally consistent. If it fails partway, neither institution should be in an inconsistent state. **Q10:** No — this is a complex business reorganisation, not a CRUD operation.

**Verdict: ACCEPTED.** Cross-aggregate interaction: requires domain service or application orchestration for transactional coordination.

### Discovered Additional Behaviour: `reactivate`

An institution that was suspended should be able to resume operations. The NUC can restore a suspended licence. Without `reactivate`, the lifecycle is Established → Operational → Suspended → (dead end unless closed). This creates an orphaned state where a suspended institution can never return to operational status, which contradicts real-world practice.

**Q1-Q10 evaluation:** Yes, domain action; protects the rule that only suspended institutions can reactivate; changes state from Suspended to Operational; precondition: institution must be Suspended; postcondition: institution is Operational; produces `InstitutionReactivated` event; no cross-aggregate requirement; eventual consistency for downstream; not CRUD.

**Verdict: ACCEPTED.**

### Rejected Behaviours

- **`updateLocation`** — Changing an institution's location (city, country) is a data update with no invariant. Location is optional (frozen decision F8-equivalent). There is no business rule that restricts what location an institution can have. This is CRUD delegated to application service. **REJECTED.**
- **`updateWebsite`**, **`updateContactInfo`** — Pure data updates with no invariants. **REJECTED.**
- **`addProgramme`** — Programme is its own aggregate root. Institutions do not "add programmes" — programmes are introduced with a reference to their owning institution. The foreign key direction is Programme → Institution, not Institution → Programme. **REJECTED as Institution operation.** This is a Programme operation (`introduce`).
- **`changeType`** — Changing an institution's type (e.g., from Polytechnic to University) is a real business event in Nigeria (polytechnic upgrade), but it has massive cascading implications: accreditation from one authority becomes invalid, award levels change, admission policies may be incompatible. This is too consequential to model as a simple attribute update. However, in practice, type changes in Nigerian regulation are *established as new institutions* — the Federal Government establishes a *new* university, not a type-changed polytechnic. The old polytechnic is closed. This is better modelled as `close` + `establish`, not `changeType`. **REJECTED as a single operation.** If a future business case requires in-place type change, it must be modelled as a dedicated domain action with explicit cascade handling.

---

## SECTION 3 — PROGRAMME

### The Central Question: Where Does "Is Currently Accepting Applications" Live?

This is the single most important behavioural question in the entire domain. The answer determines the interaction pattern between Programme, Admission Cycle, and Admission Policy — and therefore determines whether the domain model can support the core use case of "discover programmes currently accepting applications."

The existing invariant INV-P3 states: "Programme admission status = (lifecycle Admitting) ∧ (cycle in Admission Period)." This is a *derived* property that depends on two separate aggregates: the Programme's own lifecycle state, and the Admission Cycle's current phase. No single aggregate owns all the data to compute this.

**Three possible designs:**

**Design A — Programme decides unilaterally.** Programme has an `openAdmission(cycle)` and `closeAdmission(cycle)` command. The Programme explicitly transitions its own admission state per cycle. The Admission Cycle's phase is advisory — the Programme decides when it is accepting applications. *Problem:* This violates INV-P3's intent. A programme could open admission before the cycle's admission period begins, or fail to close when the cycle ends. The Programme does not know the cycle's current phase without querying across aggregates.

**Design B — Admission Cycle drives programmes.** When the Admission Cycle transitions to its admission phase, it commands all associated programmes to open admission. When it transitions past the admission phase, it commands them to close. *Problem:* This violates aggregate boundaries — the Admission Cycle aggregate cannot reach into Programme aggregates to change their state. It also assumes all programmes in a cycle open and close simultaneously, which is false — UNILAG may start accepting applications on a different date than UI within the same JAMB cycle.

**Design C — Programme publishes policy; read model derives status.** The Programme's domain operation is `publishAdmissionPolicy(cycle, rules)`, which associates admission rules with a cycle. The Programme has a lifecycle state (`Admitting` or `Suspended`). Whether the programme is *currently* accepting applications is a *query* answered by a read model that evaluates: `programme.lifecycle == Admitting AND cycle.isInAdmissionPeriod() AND programme.hasActivePolicyFor(cycle)`. The Programme aggregate does not compute this — the read model does. *This is the correct design.*

**Why Design C is correct:** INV-P3 is a *query invariant*, not a *command invariant*. It defines a derived property that the domain must be able to answer, but no single aggregate owns all the inputs. The Programme protects its own lifecycle state. The Admission Cycle protects its own phase. The Programme owns its admission policies. The conjunction is a projection — a read model. This is not a weakness; it is the natural consequence of proper aggregate boundaries. Aggregates protect consistency; read models answer queries. The question "is this programme currently accepting applications?" is a query, and queries belong to read models.

**Critical consequence:** `isAdmitting()` is NOT a domain operation on Programme. It is a query method, and in Laravel Beyond CRUD terms, it belongs in a Query class, not an Action class. The existing operation list includes `isAdmitting` — this must be reclassified from domain operation to read-model query.

### Existing Operations Review

### `introduce` — Introduce a New Programme

**Q1:** Yes. Introducing a programme is a significant business event — it creates a new educational opportunity that did not exist before. "UNILAG introduces B.Sc. in Data Science" is a headline, not a database insert. **Q2:** INV-P1 (programme belongs to exactly one Institution) and INV-P4 (programme award level valid for Institution type). **Q3:** Programme aggregate. **Q4:** Programme transitions from non-existent to Introduced; institution reference, programme name, and award level are set. **Q5:** Institution must exist and be operational; award level must be valid for the institution's type. **Q6:** INV-P1 holds (has exactly one institution); INV-P4 holds (award level valid for type). **Q7:** `ProgrammeIntroduced` — downstream, opportunity search can include the new programme; education authorities may be notified. **Q8:** Institution is referenced for validation (institution type determines valid award levels). The Institution aggregate is not loaded — institution type is passed in as context. **Q9:** N/A. **Q10:** No — the invariants INV-P1 and INV-P4 are enforced at creation.

**Verdict: ACCEPTED.**

### `publishAdmissionPolicy` — Publish Admission Policy for a Cycle

**Q1:** Yes. Publishing admission requirements for a specific admission cycle is the primary way a programme communicates what it expects from applicants. This is how "UNILAG Computer Science requires 5 O'level credits including Mathematics and English, plus UTME score ≥ 250" enters the system. **Q2:** INV-P2 (only one active Admission Policy per Admission Cycle). **Q3:** Programme aggregate — it owns the one-per-cycle invariant. **Q4:** A new Admission Policy child entity is created or promoted; previous active policy for the same cycle is superseded. **Q5:** Programme must be in Admitting state; Admission Cycle must be identified; policy rules must be internally consistent. **Q6:** Exactly one active policy for the given cycle; superseded policy (if any) is no longer active. **Q7:** `ProgrammeAdmissionPolicyPublished` — downstream, opportunity search reflects updated requirements. **Q8:** Admission Cycle identity is referenced but not loaded as aggregate. **Q9:** Search updates are eventual consistency. **Q10:** No — supersession logic is genuine domain behaviour.

**Verdict: ACCEPTED.**

### `suspendAdmission` — Suspend Admission

**Q1:** Yes. A programme may temporarily suspend admission — e.g., due to accreditation issues, capacity constraints, or regulatory directive. This is different from discontinuing the programme entirely. **Q2:** INV-P3 component — suspended programme is not accepting applications regardless of cycle state. **Q3:** Programme aggregate. **Q4:** Lifecycle state changes from Admitting to Suspended. **Q5:** Programme must be in Admitting state; reason should be provided. **Q6:** Programme is Suspended; `isAdmitting` query returns false regardless of cycle state. **Q7:** `ProgrammeAdmissionSuspended` — downstream, search must exclude or flag this programme. **Q8:** No. **Q9:** Yes — search updates are eventual consistency. **Q10:** No — the state change has real business meaning and affects the derived admission status.

**Verdict: ACCEPTED.**

### `resumeAdmission` — Resume Admission

**Q1:** Yes. Mirror of suspend — a programme that was suspended can resume admitting students when the issue is resolved. **Q2:** Programme lifecycle completeness — without resume, a suspended programme can only be discontinued, creating a dead end. **Q3:** Programme aggregate. **Q4:** State changes from Suspended to Admitting. **Q5:** Programme must be in Suspended state. **Q6:** Programme is Admitting; derived admission status depends on cycle and policy. **Q7:** `ProgrammeAdmissionResumed`. **Q8:** No. **Q9:** Yes. **Q10:** No.

**Verdict: ACCEPTED.**

### `discontinue` — Discontinue Permanently

**Q1:** Yes. Programme discontinuation is a terminal business event — the programme will no longer accept students, ever. "UNILAG discontinues B.Sc. in Petroleum Engineering" is a business decision with lasting impact. **Q2:** INV-P6 (discontinued programme cannot perform business operations). **Q3:** Programme aggregate. **Q4:** Lifecycle state changes to Discontinued (terminal). **Q5:** Programme must not already be Discontinued; confirmation required (irreversible). **Q6:** INV-P6 holds; no admission policies can be published; no accreditation can be recorded. **Q7:** `ProgrammeDiscontinued` — downstream, search must exclude; scholarships targeting this programme must be flagged. **Q8:** No. **Q9:** Downstream effects are eventual consistency. **Q10:** No — irreversibility and cascading impact.

**Verdict: ACCEPTED.**

### `recordAccreditation` — Record Accreditation Event

Identical analysis to Institution's `recordAccreditation`, but for programme-level accreditation. Programme-level accreditation is common in Nigeria (NUC accredits specific programmes, not just institutions) and universal (ABET accredits engineering programmes in the US). The jurisdiction check (INV-P5) is the critical invariant.

**Verdict: ACCEPTED.**

### `isAdmitting` — Is Programme Currently Accepting Applications?

As determined above, this is a **read-model query**, not a domain operation. It should be removed from the Programme's domain behaviour list and reclassified as a query in the Opportunity Discovery read model.

**Verdict: RECLASSIFIED AS QUERY.** The Programme aggregate exposes its lifecycle state and its policies. The read model combines this with Admission Cycle phase data to answer `isAdmitting`.

### Discovered Additional Behaviour: `associateWithCycle`

Programmes must be associated with Admission Cycles to publish policies. But does this association happen as a side effect of `publishAdmissionPolicy` (which already takes a cycle reference), or is it a separate operation? In Nigeria, a programme participates in the JAMB cycle by default — but in other systems, a programme must explicitly opt in to a cycle. The association is implicitly created when a policy is published for that cycle. No separate operation is needed.

**Verdict: NOT NEEDED — association is implicit in `publishAdmissionPolicy`.**

### Rejected Behaviours

- **`changeAwardLevel`** — Changing a programme's award level (e.g., from B.Sc. to M.Sc.) is not a field update; it creates a fundamentally different programme. In practice, institutions introduce a *new* programme at the new level. **REJECTED.** Modelled as `introduce` new + `discontinue` old.
- **`updateDescription`**, **`updateDuration`** — Pure CRUD with no invariants. **REJECTED.**
- **`removeFromCycle`** — Removing a programme's association with a cycle after policies have been published would violate the policy-cycle relationship. If this business need arises, it should be modelled as a suspension of the policy for that cycle, not removal of the association. **REJECTED.**

---

## SECTION 4 — SCHOLARSHIP

### Existing Operations Review

### `announce` — Announce a New Scholarship

**Q1:** Yes. Announcing a scholarship is a public business event — "Shell announces 2024 Undergraduate Scholarship." The scholarship becomes visible to potential applicants. **Q2:** INV-S1 (scholarship has exactly one Provider) and INV-S5 (applications cannot open without published Eligibility Policy) — announcement establishes the scholarship with a provider but does not yet allow applications. **Q3:** Scholarship aggregate. **Q4:** Scholarship transitions from non-existent to Announced; provider is set; application period may be defined. **Q5:** Provider must be identified; scholarship name must be provided; application period must be defined or definable. **Q6:** INV-S1 holds; scholarship is in Announced state; applications are closed. **Q7:** `ScholarshipAnnounced` — downstream, opportunity search can include the scholarship. **Q8:** Scholarship Provider is referenced but not loaded as aggregate. **Q9:** Search updates are eventual consistency. **Q10:** No — the lifecycle constraint (announced before open) is genuine domain logic.

**Verdict: ACCEPTED.**

### `publishEligibilityPolicy` — Publish Eligibility Criteria

**Q1:** Yes. Publishing eligibility criteria defines who can apply — "must be a Nigerian undergraduate in Engineering with CGPA ≥ 3.5." This is the prerequisite for opening applications. **Q2:** INV-S2 (only one active Eligibility Policy per period) and INV-S5 (applications cannot open without published policy). **Q3:** Scholarship aggregate — it owns both invariants. **Q4:** A new Eligibility Policy child entity is created or promoted; previous active policy for the same period is superseded. **Q5:** Scholarship must be in Announced or Open state; policy rules must be internally consistent. **Q6:** INV-S2 holds; INV-S5 precondition for `openApplications` is now satisfied. **Q7:** `ScholarshipEligibilityPolicyPublished`. **Q8:** No. **Q9:** No — the policy must be persisted before applications can open; this is a sequential dependency. **Q10:** No — supersession and the gate on application opening are genuine domain logic.

**Verdict: ACCEPTED.**

### `openApplications` — Open Application Window

**Q1:** Yes. Opening applications is a significant business event — it changes the scholarship from "announced" to "open for applications." **Q2:** INV-S3 (applications opened only when Scholarship in "announced" state) and INV-S5 (applications cannot open without published Eligibility Policy). **Q3:** Scholarship aggregate. **Q4:** Lifecycle state changes from Announced to Open; application window is now active. **Q5:** Scholarship must be in Announced state; must have at least one published Eligibility Policy for the current period. **Q6:** Scholarship is in Open state; applications can be submitted. **Q7:** `ScholarshipApplicationsOpened` — downstream, notification to eligible candidates; search reflects open status. **Q8:** No. **Q9:** Notification is eventual consistency. **Q10:** No — the INV-S3 and INV-S5 guards are genuine domain logic.

**Verdict: ACCEPTED.**

### `closeApplications` — Close Application Window

**Q1:** Yes. Closing applications ends the window for submissions. **Q2:** INV-S4 (applications closed only when Scholarship in "open" state). **Q3:** Scholarship aggregate. **Q4:** Lifecycle state changes from Open to Closed. **Q5:** Scholarship must be in Open state. **Q6:** Scholarship is in Closed state; no applications can be submitted. **Q7:** `ScholarshipApplicationsClosed`. **Q8:** No. **Q9:** Yes. **Q10:** No — INV-S4 guard.

**Verdict: ACCEPTED.**

### `withdraw` — Withdraw Scholarship

**Q1:** Yes. A scholarship may be withdrawn by its provider — funding is rescinded, the programme is cancelled. This is distinct from the application window closing; it means the scholarship will not be awarded at all. **Q2:** The invariant that a withdrawn scholarship cannot accept applications or be awarded. **Q3:** Scholarship aggregate. **Q4:** Lifecycle state changes to Withdrawn (terminal or semi-terminal). **Q5:** Scholarship must not already be Withdrawn; reason should be provided. **Q6:** Scholarship is Withdrawn; no applications can be opened; existing applications are effectively voided. **Q7:** `ScholarshipWithdrawn`. **Q8:** No. **Q9:** Notification to applicants is eventual consistency. **Q10:** No — the cascade of application voiding is genuine business logic.

**Verdict: ACCEPTED.**

### `targetProgrammes` / `targetInstitutions` — Define Applicability

**Q1:** Yes. Many scholarships are scoped to specific programmes or institutions — "NNPC Undergraduate Scholarship for Engineering students at Federal Universities." Defining applicability is not a data update; it determines which candidates can apply. **Q2:** The invariant that applicability must be defined before or during the application period. **Q3:** Scholarship aggregate. **Q4:** Target programme/institution references are added or replaced. **Q5:** Scholarship must be in Announced or Open state (cannot target after closing). **Q6:** Applicability is defined; `isApplicableTo` can be evaluated. **Q7:** `ScholarshipTargetsUpdated`. **Q8:** Programme/Institution identities are referenced but not loaded. **Q9:** Yes. **Q10:** No — applicability scoping is genuine domain logic.

**Verdict: ACCEPTED.**

### `isApplicableTo` — Check if Scholarship Applies to a Programme/Institution

This is a **query**, not a domain operation. It evaluates the scholarship's targeting rules against a given programme or institution. It changes no state. In Laravel Beyond CRUD terms, this is a Query class.

**Verdict: RECLASSIFIED AS QUERY.**

### Discovered Additional Behaviour: `expire`

Scholarships that were announced or open but whose application period has passed without explicit closure should transition to Expired. This is a time-based lifecycle event. However, this may be better handled by a scheduled application service that checks application deadlines rather than a domain operation triggered by time — aggregates should not contain time-based self-transitions. The Scholarship should expose an `expire()` method that the application service can call when the deadline has passed, but the trigger is external.

**Verdict: ACCEPTED as domain operation `expire`, triggered by application service.**

### Discovered Additional Behaviour: `publishEligibilityPolicy` for New Period

When a scholarship runs annually, a new eligibility policy must be published for each period. The existing `publishEligibilityPolicy` already handles this through the period parameter and the INV-S2 supersession rule. No additional operation is needed.

### Rejected Behaviours

- **`updateProvider`** — Changing a scholarship's provider is an unusual business event. If it occurs, it should be modelled as withdraw + new scholarship, not an in-place update. The provider is part of the scholarship's identity (Scholarship Name + Offering Provider + Application Period). **REJECTED.**
- **`updateCoverageType`**, **`updateCoverageAmount`** — Pure data updates with no invariants. **REJECTED.**
- **`reopenApplications`** — Allowing an application window to reopen after closing creates complexity (what happens to applications submitted during the first window? are they still valid?). If a provider needs to extend, they should close + announce a new period. **REJECTED for MVP.** May be revisited if business case emerges.

---

## SECTION 5 — ADMISSION CYCLE

### The Critical Behavioural Question: How Does Programme-Cycle Interaction Work?

The relationship between Programme and Admission Cycle is the most architecturally significant interaction in the domain. Three patterns exist in real-world education systems:

**Pattern 1 — Centralised Cycle (Nigeria, Kenya).** A single national authority defines the cycle, and all programmes participate. JAMB defines the UTME cycle; all Nigerian tertiary programmes participate within it. KUCCPS defines the placement cycle in Kenya. The cycle has defined phases that all participants follow. Programme admission timing is constrained by the cycle's phases — programmes cannot offer admission before the cycle's admission period opens.

**Pattern 2 — Decentralised Cycle (US, UK, Australia).** Each institution defines its own admission timeline. UCAS in the UK provides a common application platform, but institutions set their own deadlines. In the US, Common App is a platform, not a cycle controller — each university decides when its applications open and close. There is no single cycle that governs all programmes.

**Pattern 3 — Rolling/Continuous (Germany, many graduate programmes globally).** There is no discrete cycle. Programmes accept applications on a rolling basis — apply anytime, decisions are made continuously. Some programmes have multiple intake periods per year (e.g., Fall and Spring intake in the US).

The domain model must support all three patterns. Admission Mode on Programme (Cyclic, Rolling, Multiple-Intake) already captures this. The Admission Cycle aggregate is relevant for Pattern 1 only — for Pattern 2 and 3, the Programme manages its own timeline.

### This means: Admission Cycle is NOT the universal temporal axis of the domain.

A Programme with Admission Mode = Rolling has no Admission Cycle association. A Programme with Admission Mode = Multiple-Intake may have multiple intake periods but not necessarily a single governing cycle. Only a Programme with Admission Mode = Cyclic is associated with an Admission Cycle.

### State Machine Design

The Admission Cycle's state machine is:

```
Upcoming → Active → Closed → Archived
```

Within `Active`, the cycle advances through a configurable phase sequence (INV-C2: no backwards, no skipping). The phases themselves are data — Nigerian national cycle might have: Registration → Examination → Results → Admission → Verification, while a Ghanaian cycle might have: Application → Selection → Placement → Admission.

**`announce`** — Creates the cycle with start/end dates and phase sequence. Transitions to Upcoming. **Q1-Q10:** Yes; INV-C1 (defined start and end dates) and INV-C2 (phase sequence); Admission Cycle aggregate; sets identity and phase configuration; requires period, defining authority, and phase sequence; cycle exists in Upcoming state; `AdmissionCycleAnnounced`; no cross-aggregate; N/A; not CRUD. **ACCEPTED.**

**`activate`** — When the start date arrives, the cycle transitions to Active, and the current phase is set to the first phase in the sequence. **Q1-Q10:** Yes; INV-C1 (cycle is time-bounded); Admission Cycle aggregate; state changes to Active, current phase set; cycle must be in Upcoming; cycle is Active with first phase; `AdmissionCycleActivated`; no cross-aggregate; N/A; not CRUD. **ACCEPTED.**

**`advancePhase`** — Moves to the next phase in the sequence. **Q1-Q10:** Yes; INV-C2 (phase transitions follow defined sequence); Admission Cycle aggregate; current phase changes; current phase must not be the last phase; next phase in sequence is now current; `AdmissionCyclePhaseAdvanced`; no cross-aggregate; downstream effects (search, notifications) are eventual consistency; not CRUD. **ACCEPTED.**

**`close`** — Closes the cycle after the final phase is complete. **Q1-Q10:** Yes; INV-C3 (cycle is time-bounded); Admission Cycle aggregate; state changes to Closed; cycle must be in Active state and current phase must be the last phase; cycle is Closed; `AdmissionCycleClosed`; no cross-aggregate; downstream effects are eventual consistency; not CRUD. **ACCEPTED.**

**`archive`** — Archives the cycle for historical reference. Terminal state. **ACCEPTED.**

**`isAdmissionOpen`** — Query: is the cycle currently in its admission period phase? This is a **query**, not a domain operation. The cycle exposes its current phase; the read model determines whether the current phase corresponds to the admission period. **RECLASSIFIED AS QUERY.**

### Nigerian Phase Names Are Data, Not Domain

The domain invariant is INV-C2: phases advance in sequence, never backwards, never skipping. The *names* and *number* of phases are configuration data. "Registration," "Examination," "Results," "Admission," "Verification" are Nigerian JAMB cycle phases. A Kenyan KUCCPS cycle might have "Application," "Placement," "Admission." A UK UCAS cycle might have "Application," "Decisions," "Reply," "Confirmation," "Clearing." The domain model stores a phase sequence; the specific phases are data.

### Cross-Aggregate Effect: When Cycle Phase Changes

When an Admission Cycle advances to its "Admission" phase, programmes in Cyclic mode that have published policies for this cycle become "currently accepting applications" (per the read model). This is **not** a domain operation on Programme — it is a derived property that changes because the cycle's phase changed. The read model must be updated, but no Programme aggregate is loaded or modified. This is pure eventual consistency: the `AdmissionCyclePhaseAdvanced` event triggers a read model rebuild.

---

## SECTION 6 — INFORMATION SOURCE

### Distinguishing Source Registration from Data Acquisition

Information Source models the *provenance* of information — where data came from. It does not model the *content* of the information or the *process* of acquiring it. These are three distinct concerns:

1. **Source Registration** (domain) — "JAMB official website" is registered as a source with type=Official, reference=URL.
2. **Data Acquisition** (application) — A scraper visits the JAMB website and extracts programme data. This is an application orchestration concern, not domain behaviour.
3. **Verification & Provenance** (domain) — The source's reliability status (Verified, Unreliable, Deprecated) affects the trust signal of all information derived from it.

### State Machine

```
Registered → Verified → Unreliable → Deprecated
                 ↑          ↓
                 └──────────┘ (re-verification after being marked unreliable)
```

A source can oscillate between Verified and Unreliable (a source that was having technical problems may be fixed). But once Deprecated, it cannot return — deprecation is the terminal state for sources.

### Operations

**`register`** — Registers a new information source. **Q1-Q10:** Yes; INV-IS3 (every registered source has a retrievable reference); Information Source aggregate; sets identity, type, and reference; name, type, and reference must be provided; INV-IS3 holds; `InformationSourceRegistered`; no cross-aggregate; N/A; not CRUD (enforces INV-IS3). **ACCEPTED.**

**`verify`** — Marks a source as verified after reliability assessment. **Q1-Q10:** Yes; INV-IS1 (source cannot be simultaneously verified and unreliable); Information Source aggregate; status changes to Verified; source must be in Registered or Unreliable state; source is Verified; `InformationSourceVerified`; no cross-aggregate; downstream trust signal recalculation is eventual consistency; not CRUD. **ACCEPTED.**

**`markUnreliable`** — Marks a verified source as unreliable. **Q1-Q10:** Yes; INV-IS1; Information Source aggregate; status changes to Unreliable; source must be in Verified state; source is Unreliable; `InformationSourceMarkedUnreliable`; no cross-aggregate; downstream trust signal recalculation is eventual consistency; not CRUD. **ACCEPTED.**

**`deprecate`** — Marks a source as deprecated (no longer used). **Q1-Q10:** Yes; INV-IS2 (deprecated source cannot be verified); Information Source aggregate; status changes to Deprecated (terminal); source must be in Registered, Verified, or Unreliable state; source is Deprecated; `InformationSourceDeprecated`; no cross-aggregate; downstream — information referencing this source must be flagged; not CRUD. **ACCEPTED.**

**`isReliable`** — Query: is the source currently reliable? This depends on the source's verification status. **RECLASSIFIED AS QUERY.**

### Challenging Aggregate Root Classification

Is Information Source genuinely an aggregate root? The invariants it protects (INV-IS1 through INV-IS3) are real but modest — they prevent inconsistent status combinations and ensure a reference exists. The aggregate has four operations and a clear lifecycle. The key justification for aggregate root status is the **cascading effect** on trust: when a source is marked unreliable, every entity whose data was derived from that source must have its trust signal recalculated. This cascade crosses aggregate boundaries, and the source must be its own consistency boundary so that its status change is atomic. If the source were a child entity of something else, we would need to load the parent to change the source's status, which is incorrect — source reliability is independent of any parent.

**Verdict: Aggregate root classification CONFIRMED.**

### Rejected Behaviours

- **`acquireData`** — Data acquisition is application orchestration (scheduling, scraping, parsing, error handling). Not domain behaviour. **REJECTED.**
- **`updateLastFetchTime`** — CRUD. **REJECTED.**
- **`recordExtractionError`** — Application logging concern, not domain. **REJECTED.**

---

## SECTION 7 — ADMISSION POLICY

### Nature of Admission Policy

Admission Policy is a child entity — it does not act autonomously. All operations on Admission Policy are driven by its parent (Programme or Institution). The child entity classification means Admission Policy has no independent public API — it is manipulated through the parent's operations.

### Lifecycle States

```
Draft → Published → Superseded
                  → Withdrawn
```

**Published policies are immutable.** Once a programme publishes its admission requirements for a cycle, those requirements cannot be changed in-place. If the programme needs to update requirements, it publishes a new policy for the same cycle, which *supersedes* the previous one. This is a critical domain rule: admission requirements must be stable once published because candidates make decisions based on them. In-place modification would violate the trust relationship between the institution and applicants.

### Supersession

When `programme.publishAdmissionPolicy(cycle, newRules)` is called, and an active policy already exists for that cycle:
1. The existing active policy is transitioned to Superseded.
2. A new policy is created in Published state.
3. The new policy becomes the active policy for that cycle.

This is enforced by INV-P2 / INV-I3 (only one active policy per cycle). The supersession is atomic within the aggregate boundary — the Programme never has zero or two active policies for a cycle during the operation.

### Withdrawal

A programme may withdraw its admission policy for a cycle — this means it is no longer admitting students through that cycle. Withdrawal transitions the policy to Withdrawn state. If the programme later decides to admit, it must publish a new policy.

### What Admission Policy Contains

An Admission Policy contains a collection of Admission Rules (value objects). Each rule specifies a requirement: qualification thresholds (e.g., "UTME score ≥ 250"), subject combinations (e.g., "Mathematics, Physics, Chemistry"), or other criteria. The policy's internal consistency (rules must not contradict each other) is a validation concern, not a domain invariant — it is enforced at the application layer when the policy is constructed.

### No Independent Operations

Admission Policy has no domain operations independent of its parent. The parent's `publishAdmissionPolicy` creates and publishes it. There is no `admissionPolicy.publish()` or `admissionPolicy.update()` — these would violate the child entity contract. The only state transitions (Draft → Published, Published → Superseded, Published → Withdrawn) are driven by parent operations.

**Verdict: No independent behaviours. All state changes driven by parent (Programme or Institution). This is correct for a child entity.**

---

## SECTION 8 — ELIGIBILITY POLICY

### Comparison With Admission Policy

| Aspect | Admission Policy | Eligibility Policy |
|--------|-----------------|-------------------|
| Parent | Programme or Institution | Scholarship |
| Protects invariant | INV-P2 / INV-I3 (one active per cycle) | INV-S2 (one active per period) |
| Gate on | Programme admission | Scholarship applications |
| Contents | Admission Rules (qualification thresholds, subject combinations) | Eligibility Rules (CGPA thresholds, field of study, nationality, gender) |
| Lifecycle | Draft → Published → Superseded/Withdrawn | Draft → Published → Superseded/Withdrawn |
| Immutability after publication | Yes | Yes |
| Supersession mechanism | Same | Same |

The structural similarity is undeniable. Both are child entities with Draft → Published → Superseded/Withdrawn lifecycles, both enforce one-active-per-period, both are immutable after publication, both use supersession for updates. The question is whether this similarity justifies a shared abstraction.

### Why a Shared Abstraction Is Rejected

1. **The rules are semantically different.** Admission Rules describe what credentials an applicant must hold to be admitted (qualification thresholds, subject combinations). Eligibility Rules describe what characteristics an applicant must have to be eligible for a scholarship (CGPA, field of study, nationality, financial need). These are different domain concepts that happen to share a structural pattern. A shared `Policy` abstraction would conflate admission and eligibility — two distinct ubiquitous language terms.

2. **The business rules are different.** Admission Policy gates programme admission within an admission cycle. Eligibility Policy gates scholarship applications within a period. The guard operations (`publishAdmissionPolicy` vs `publishEligibilityPolicy`) live on different aggregates (Programme/Institution vs Scholarship) and enforce different downstream constraints (admission status vs application status).

3. **The frozen decision is explicit.** Decision #2: "Admission Policy ≠ Eligibility Policy — do not create shared Policy abstraction." This was made with full knowledge of the structural similarity and was chosen deliberately to preserve semantic clarity. Behaviour discovery provides no contrary evidence — if anything, the difference in rule semantics and guard operations reinforces the decision.

4. **Structural similarity ≠ domain abstraction.** Two things having the same lifecycle pattern does not make them the same domain concept. If it did, we would abstract Institution, Programme, and Scholarship into a single "Announceable Entity" because they all have announcement lifecycles. This is the kind of premature generalisation that pragmatic DDD explicitly rejects.

**Verdict: No shared abstraction. Similarity is structural, not semantic. Frozen decision #2 UPHELD.**

---

## SECTION 9 — ACCREDITATION RECORD

### The Fundamental Tension: Immutable Fact vs. Lifecycle Entity

The frozen decision (#10) states: "Accreditation Record is immutable historical fact." But real-world accreditation has lifecycle: grants, renewals, suspensions, revocations, and reinstatements. If the record is immutable, how do we model revocation?

**Resolution: Each accreditation *event* is an immutable record. Lifecycle is derived from the sequence of records.**

This is the event-sourcing pattern applied to accreditation: we do not mutate a record; we append a new record that represents the new state. The entity's *current* accreditation status is derived from its most recent record.

### How Real-World Accreditation Events Map

| Real-World Event | Domain Model |
|-----------------|--------------|
| NUC grants full accreditation to Programme X | `programme.recordAccreditation(authority=NUC, status=Full, period=2023-2028)` → Creates new Accreditation Record |
| NUC renews accreditation | `programme.recordAccreditation(authority=NUC, status=Full, period=2028-2033)` → Creates new record; previous record's period end is implicit |
| NUC places Programme X on interim accreditation | `programme.recordAccreditation(authority=NUC, status=Interim, period=2024-2026)` → Creates new record |
| NUC revokes accreditation | `programme.recordAccreditation(authority=NUC, status=Revoked, period=effective)` → Creates new record |
| Professional body ABET accredits same programme | `programme.recordAccreditation(authority=ABET, status=Full, period=2025-2031)` → Separate record, different authority |

Each call to `recordAccreditation` creates a new Accreditation Record. No record is ever modified. The Programme derives its current accreditation status from its collection of records: the most recent record from each relevant authority determines the current status.

### Accreditation Record as Child Entity

Accreditation Record is a child entity of Programme or Institution. It has identity (Accredited Entity + Granting Authority + Effective Period Start) because multiple records exist for the same entity from the same or different authorities. But it has no autonomous behaviour — it is created by the parent's `recordAccreditation` operation and never independently modified.

### What About Expiration?

Accreditation periods have end dates. When an accreditation period expires, does a new record need to be created with status=Expired? In practice, expiration is a *derived* state: if the most recent record for an authority has a period that has ended, and no subsequent record exists, the accreditation has expired. This is a query, not a command. No domain operation is needed — the read model detects expiration by comparing the period end date to the current date.

### Challenge: Should Accreditation Record Be a Value Object Instead?

If records are immutable and have no lifecycle, could they be value objects? No — because they have identity (the same programme can have multiple records from the same authority over time, distinguished by effective period start). Value objects are compared by value; two accreditation records with the same programme, authority, and status but different periods are different records, not the same value. Identity is required.

**Verdict: Accreditation Record is an IMMUTABLE child entity. No mutations. No independent operations. Lifecycle is derived from the sequence of records. Frozen decision #10 UPHELD and REINFORCED.**

---

## SECTION 10 — QUALIFICATION

### What Behaviour Does Qualification Genuinely Have?

Qualification represents credential types — WAEC SSCE, JAMB UTME, NCE, ND, HND, B.Sc., IELTS, TOEFL, SAT, ACT, GRE. These are reference classifications used in admission rules and eligibility rules. They are defined by external authorities (WAEC, JAMB, ETS, College Board) and StudyNexus does not create, modify, or manage them.

**Candidate behaviours:**

**`introduce`** — Adding a new qualification type to the reference framework (e.g., when expanding to Ghana, adding "WASSCE" as distinct from "SSCE"). **Q1:** Is this a domain action? Marginally — it adds a classification to the reference framework. **Q2:** INV-9 (qualification recognized by at least one Education Authority). **Q3:** No aggregate protects this — Qualification is a supporting entity with no invariants beyond INV-9. **Q10:** This is CRUD — adding a row to a reference table. **REJECTED as domain behaviour.** This is an application service (reference data management).

**`deprecate`** — Marking a qualification as no longer actively used (e.g., "NCE" if Nigeria phases out Colleges of Education). **Q1:** Yes — deprecation affects the validity of admission rules that reference this qualification. **Q2:** The invariant that deprecated qualifications should not be used in new policies (but existing policies are not retroactively invalidated). **Q3:** Qualification (supporting entity). **Q4:** Status changes to Deprecated. **Q5:** Qualification must exist and not already be deprecated. **Q6:** Qualification is Deprecated; new admission/eligibility policies should not reference it. **Q7:** `QualificationDeprecated`. **Q8:** No. **Q9:** Yes. **Q10:** No — the downstream effect on policy creation is genuine.

**Verdict: `deprecate` is the only domain behaviour.** Qualification is otherwise reference data managed by application services. This confirms its supporting entity classification.

### Challenge: Should Qualification Be Demoted to Value Object?

Qualification has identity (Qualification Name + Defining Authority) because it is referenced by admission rules and eligibility rules. If it were a value object, these rules would need to embed the full qualification description, which would duplicate data and make it impossible to deprecate a qualification centrally. Identity is justified for reference purposes.

**Verdict: Supporting entity classification CONFIRMED.** Only behaviour: `deprecate`. All other operations are reference data CRUD (application services).

---

## SECTION 11 — SCHOLARSHIP PROVIDER

### Challenging Its Existence

Scholarship Provider is the weakest entity in the model — it has no invariants and no domain behaviour. It exists because:
1. Scholarships reference a provider (INV-S1: scholarship has exactly one Provider).
2. Provider identity is part of Scholarship's identity (Scholarship Name + Offering Provider + Application Period).
3. Users search for scholarships by provider ("Shell scholarships," "PTDF scholarships").

These are all *reference* reasons, not *behaviour* reasons. Scholarship Provider is referenced by Scholarship but does not act in the domain.

### Does Scholarship Provider Have Any Behaviour?

**`establish`** — Adding a new provider. This is reference data CRUD. **REJECTED.**

**`mergeWith`** — If two providers merge (e.g., Total and Elf merging in Nigeria). This is a business event that affects all scholarships referencing the old provider. But is it a domain action on Scholarship Provider, or an application orchestration that updates scholarship references? The actual domain rule is that a scholarship's provider identity is part of the scholarship's identity — changing it effectively creates a new scholarship. Provider merger is better modelled as: old provider marked inactive + scholarships updated with new provider reference (application orchestration, not domain behaviour on Provider). **REJECTED as domain behaviour on Provider.**

**`deprecate`** — Marking a provider as no longer active. Same pattern as Qualification. **MARGINALLY ACCEPTED** — deprecation prevents new scholarships from referencing this provider, which is a weak but real domain rule.

### Verdict: Scholarship Provider BARELY Retains Supporting Entity Status

It has one marginal behaviour (`deprecate`). Without it, Scholarship would need to validate provider existence and status, which crosses the reference boundary. The entity exists as a referential integrity guard — it ensures that scholarship provider references point to real, non-deprecated entities. This is not a strong justification for entity status, but demoting to value object would lose the deprecation capability. **Supporting entity classification UPHELD, but flagged as the weakest entity in the model.**

---

## SECTION 12 — EDUCATION AUTHORITY

### What the Real-World Authority Does vs. What StudyNexus Models

In the real world, Nigeria's NUC:
- Grants and revokes institutional licences
- Accredits programmes
- Sets minimum standards for university education
- Approves the establishment of new universities
- Conducts verification and resource assessment
- Publishes guidelines and circulars

StudyNexus does NOT perform any of these actions. StudyNexus **records** that the NUC has performed them. The Education Authority entity in StudyNexus is a reference entity that:
1. Is referenced by Accreditation Records (who granted the accreditation)
2. Is referenced by Qualifications (who defines/awards the qualification)
3. Is referenced by Admission Cycles (who defines the cycle)
4. Is referenced by Admission Pathways (who defines the pathway)
5. Has a jurisdiction that determines what it can accredit (INV-I2, INV-P5, INV-10)
6. Has an authority type collection (e.g., NUC = {Regulatory, Accrediting})

### Behaviour Analysis

**`register`** — Adding a new authority to the reference framework. CRUD. **REJECTED as domain behaviour.**

**`deprecate`** — Marking an authority as no longer active. Same pattern as Qualification. **MARGINALLY ACCEPTED.**

**Jurisdiction validation** — When an Institution calls `recordAccreditation`, it checks that the granting authority has jurisdiction. Where does this check live? The check is a *query* on Education Authority's jurisdiction data. The Programme/Institution does not load the Authority aggregate — it queries the reference framework. This is an application-layer validation, not a domain operation on Education Authority.

**Verdict: Education Authority has one marginal behaviour (`deprecate`).** It is otherwise reference data. The jurisdiction check is a query on reference data, not a domain operation on the Authority. Supporting entity classification CONFIRMED.

---

## SECTION 13 — ADMISSION PATHWAY

### The Most Important Unresolved Classification

Admission Pathway represents the *route* by which a candidate gains admission. In Nigeria, pathways include:
- **UTME** — JAMB Unified Tertiary Matriculation Examination (direct entry to university)
- **Direct Entry** — For candidates with advanced qualifications (HND, NCE, A'Level) who enter at 200-level
- **Post-UTME** — Institution-specific screening after UTME
- **Inter-University Transfer** — Transferring from one university to another

In the UK:
- **UCAS Application** — Standard undergraduate application
- **UCAS Adjustment** — For applicants who exceed their offer conditions
- **UCAS Clearing** — For applicants without confirmed places after main cycle
- **Direct to Institution** — Some institutions accept direct applications

In the US:
- **Early Decision** — Binding early application
- **Early Action** — Non-binding early application
- **Regular Decision** — Standard application timeline
- **Transfer Admission** — From another institution
- **Rolling Admission** — Applications reviewed as received

### Does Admission Pathway Have Identity?

The current identity definition is: Pathway Name + Defining Authority. "UTME" defined by JAMB has identity. "Direct Entry" defined by JAMB has different identity. "Early Decision" defined by Common App has different identity. Identity exists because the same pathway name in different systems means different things.

### Does Admission Pathway Have Invariants?

**Challenge:** What business rule would be violated if Admission Pathway were removed from the model? If admission policies simply listed their rules without referencing a pathway, would anything break?

In Nigeria, the pathway determines which admission rules apply: UTME candidates have different requirements than Direct Entry candidates. The Admission Policy for a programme may have different rules per pathway. This is a real business rule — the pathway is a discriminator that determines which set of admission rules applies.

But this discriminator role could be fulfilled by a simple string or value object within the Admission Policy. The policy could have a `pathwayType` field rather than referencing an Admission Pathway entity.

### Arguments for Entity Status

1. **Pathways are defined by authorities.** JAMB defines UTME and Direct Entry. These are not free-text — they are official designations with defined semantics. An entity with authority-defined identity is more than a string.
2. **Pathways are referenced by multiple programmes.** If 200 programmes reference "UTME" as a pathway, changing "UTME" to "Unified Tertiary Matriculation Examination" is a single update to the entity, not 200 string updates.
3. **Pathways have jurisdiction.** UTME only applies within Nigeria's JAMB-governed cycle. An entity can model this jurisdiction; a value object cannot.
4. **Pathways may have their own rules.** Direct Entry requires advanced qualifications; UTME requires O'levels. These rules are attributes of the pathway, not of individual programme policies.

### Arguments Against Entity Status

1. **No invariants.** There is no business rule that Admission Pathway protects independently. The pathway is referenced by Admission Policy, but the Policy enforces its own rules.
2. **No autonomous behaviour.** Pathways do not have lifecycles in StudyNexus — they are defined by authorities and referenced by policies. A pathway does not "open" or "close"; the cycle opens and programmes use pathways within the cycle.
3. **Reference data pattern.** Pathways look like reference data — a fixed set of options defined by authorities, used as discriminators in policies.
4. **Jurisdiction is on the authority, not the pathway.** The fact that UTME applies in Nigeria is because JAMB defines it, and JAMB's jurisdiction is Nigeria. The pathway inherits jurisdiction from its defining authority; it does not have its own.

### Critical Realisation: Pathway Rules Belong in Admission Policy

The strongest argument for entity status was #4: pathways have their own rules (Direct Entry requires advanced qualifications). But on reflection, these rules are *general* rules that apply to all programmes using that pathway — they are constraints on the *candidate's eligibility to use the pathway*, not on the *programme's admission criteria*. In StudyNexus's domain, these general pathway rules should be embedded in the Admission Policy as top-level rules, with pathway-specific rules as sub-collections. The Admission Policy for "Computer Science at UNILAG for 2024/2025 via UTME" includes both the pathway's general rules (must have O'levels, must have sat UTME) and the programme's specific rules (UTME score ≥ 250, subject combination = Math/Physics/Chemistry).

This means the pathway's "rules" are actually *shared fragments* that get included in policies — they are not autonomous behaviour on the Pathway entity.

### Verdict: DEMOTE TO VALUE OBJECT

Admission Pathway should be demoted from supporting entity to a **Value Object** within Admission Policy. The pathway is a discriminator that identifies which set of rules applies — it has identity within the context of a policy (pathway name + defining authority) but no autonomous lifecycle, no invariants, and no behaviour. The reference data (list of valid pathways per authority) is managed by the application layer.

**This OVERRIDES the provisional supporting entity classification.** The resolution analysis that promoted it to supporting entity did not have the benefit of behaviour discovery — now that we can confirm it has no behaviour, the demotion is justified.

**Frozen decision #3 is REVISED:** Admission Pathway is a Value Object, not a supporting entity. It retains its identity components (Pathway Name + Defining Authority) as value object equality criteria. Valid pathway values are reference data managed by the application layer.

---

## SECTION 14 — CROSS-AGGREGATE INTERACTIONS

### Mapping All Cross-Aggregate Interactions

Every interaction that requires more than one aggregate is mapped below. Each is classified by: initiating aggregate, target aggregate, reason, invariant involved, consistency requirement, and whether a domain event is appropriate.

### 1. Programme ↔ Admission Cycle

**Interaction:** Programme publishes admission policy for a specific Admission Cycle.

**Initiating aggregate:** Programme (calls `publishAdmissionPolicy(cycleId, rules)`)
**Target:** Admission Cycle (referenced by identity, not loaded)
**Reason:** The policy must be associated with a cycle; INV-P2 (one active policy per cycle) requires the Programme to know which cycle the policy applies to.
**Invariant:** INV-P2
**Consistency:** The Programme only needs the cycle's identity, not its current state. The policy is published regardless of the cycle's current phase — a programme can publish requirements before the cycle opens. This is weak consistency: the Programme does not validate the cycle's existence or state at publish time.
**Domain event:** `ProgrammeAdmissionPolicyPublished` — the read model uses this to update the "currently accepting applications" projection by combining programme lifecycle, policy existence, and cycle phase.
**Resolution:** No domain service needed. Programme holds cycle ID as a reference. The read model joins Programme + Admission Cycle data at query time.

### 2. Institution ↔ Admission Cycle

**Interaction:** Institution publishes institutional admission policy for a specific Admission Cycle.

Identical pattern to Programme ↔ Admission Cycle. Institution holds cycle ID as reference. INV-I3 is the one-per-cycle invariant on Institution.

**Resolution:** No domain service needed. Same reference pattern.

### 3. Scholarship ↔ Programme

**Interaction:** Scholarship targets specific programmes (e.g., "NNPC Scholarship for Engineering students").

**Initiating aggregate:** Scholarship (calls `targetProgrammes(programmeIds)`)
**Target:** Programme (referenced by identity, not loaded)
**Reason:** Applicability scoping — the scholarship only applies to certain programmes.
**Invariant:** None on Programme side — the Programme does not know which scholarships target it. This is a unidirectional reference.
**Consistency:** Eventual consistency. When a scholarship targets a programme, the read model must update the programme's "available scholarships" projection. If the programme is later discontinued, the scholarship's target becomes stale — the read model detects this.
**Domain event:** `ScholarshipTargetsUpdated`
**Resolution:** No domain service needed. Scholarship holds programme IDs as references.

### 4. Scholarship ↔ Institution

Same pattern as Scholarship ↔ Programme. Scholarship holds institution IDs as references. Unidirectional.

### 5. Institution ↔ Programme (Merge)

**Interaction:** When two institutions merge, all programmes from the target institution must be reassigned to the initiating institution.

**Initiating aggregate:** Institution (calls `mergeWith(targetInstitutionId)`)
**Target:** Programme (multiple — all programmes of the target institution)
**Reason:** Programme belongs to exactly one Institution (INV-P1). When the target institution closes, its programmes must be reassigned or discontinued.
**Invariant:** INV-P1
**Consistency:** **Strong consistency required.** If the merge succeeds, all programmes must be reassigned. If it fails partway, neither institution should be in an inconsistent state.
**Domain event:** `InstitutionsMerged` — downstream, all programme ownership references are updated.
**Resolution:** This is the most complex cross-aggregate interaction in the domain. It requires a **domain service** (`InstitutionMerger`) or **application orchestration** that: (1) loads both institutions, (2) loads all programmes of the target institution, (3) reassigns each programme to the initiating institution, (4) transfers accreditation records, (5) closes the target institution, (6) all within a transaction or saga.

### 6. Information Source → All Sourced Information

**Interaction:** When an Information Source is marked unreliable or deprecated, all information derived from it must have its trust signal recalculated.

**Initiating aggregate:** Information Source
**Target:** All entities that reference this source (Institutions, Programmes, Scholarships — via their data's provenance)
**Reason:** Trust cascade — unreliable source produces unreliable information.
**Invariant:** INV-IS1, INV-IS2
**Consistency:** Eventual consistency — trust signal recalculation can happen asynchronously.
**Domain event:** `InformationSourceMarkedUnreliable` / `InformationSourceDeprecated` — downstream, a read model recalculates trust signals for all affected entities.
**Resolution:** No domain service needed. The event triggers an application-layer process that recalculates trust signals.

### 7. Programme ↔ Education Authority (Accreditation Jurisdiction)

**Interaction:** When a Programme records accreditation, it must validate that the granting authority has jurisdiction.

**Initiating aggregate:** Programme (calls `recordAccreditation(authorityId, ...)`)
**Target:** Education Authority (queried for jurisdiction)
**Reason:** INV-P5 (accreditation only from authority with jurisdiction)
**Invariant:** INV-P5, INV-10
**Consistency:** The jurisdiction check is a *validation* before the operation — it must pass synchronously. But it only queries reference data; it does not modify the Authority.
**Domain event:** None for the jurisdiction check itself. `ProgrammeAccredited` after the record is created.
**Resolution:** The jurisdiction check is an **application-layer validation** that queries the reference framework. It is not a domain service — it is a guard clause that must pass before the domain operation executes.

### 8. Admission Cycle Phase Advance → Read Model Update

**Interaction:** When an Admission Cycle advances to its admission phase, the read model must update to show which programmes are currently accepting applications.

**Initiating aggregate:** Admission Cycle
**Target:** Read model (not a domain aggregate)
**Reason:** The derived property "isAdmitting" changes for all associated programmes.
**Invariant:** None — this is a read-model concern, not a domain invariant.
**Consistency:** Eventual consistency — the read model can be updated asynchronously.
**Domain event:** `AdmissionCyclePhaseAdvanced`
**Resolution:** No domain service needed. The event triggers read model rebuild.

### Summary: Domain Services Required

Only one interaction requires a domain service or application orchestration: **Institution Merge** (#5). All other cross-aggregate interactions are handled through:
- **Reference IDs** (Programme holds cycle ID, Scholarship holds programme IDs)
- **Application-layer validation** (jurisdiction check before `recordAccreditation`)
- **Eventual consistency via domain events** (trust signal recalculation, read model updates)

This is an excellent result for pragmatic DDD — the domain has minimal cross-aggregate coupling and only one complex orchestration scenario.

---

## SECTION 15 — STATE MACHINES

### Educational Institution

```
                     establish()
  [non-existent] ──────────────────► [Operational]
                                         │
                          rename()       │  publishAdmissionPolicy()
                          recordAccreditation()
                                         │
                            suspend()    │
                                         ▼
                                    [Suspended]
                                         │
                           reactivate()  │  close()
                                         │    │
                                         ▼    ▼
                                    [Operational] [Closed]  ← terminal
                                                        (also reachable from Operational)

  mergeWith() — initiating institution absorbs target; target → [Closed]
```

**States:** Operational, Suspended, Closed
**Forbidden transitions:** Closed → any state (terminal), Operational → Operational (no-op rename is rejected), Suspended → Closed directly (must reactivate first? No — a suspended institution CAN be closed. Corrected: Suspended → Closed is allowed.)
**Revised forbidden transitions:** Closed → any state (terminal)

### Programme

```
                     introduce()
  [non-existent] ──────────────────► [Admitting]
                                         │
                   publishAdmissionPolicy()
                   recordAccreditation()
                                         │
                          suspendAdmission()
                                         ▼
                                    [Suspended]
                                         │
                          resumeAdmission()  discontinue()
                                         │           │
                                         ▼           ▼
                                    [Admitting]  [Discontinued]  ← terminal
```

**States:** Admitting, Suspended, Discontinued
**Forbidden transitions:** Discontinued → any state (terminal), Admitting → Admitting (no-op)
**Note:** `introduce()` sets state to Admitting, not "Introduced." A programme that has been introduced is inherently admitting — it exists to admit students. If it cannot admit immediately, it should be introduced as Suspended. This is a design choice: the initial state is Admitting, and `suspendAdmission()` is called immediately if the programme is not yet ready to accept applications.

### Scholarship

```
                     announce()
  [non-existent] ──────────────────► [Announced]
                                         │
                  publishEligibilityPolicy()
                  targetProgrammes()
                  targetInstitutions()
                                         │
                          openApplications()  withdraw()
                                         │           │
                                         ▼           ▼
                                       [Open]    [Withdrawn]  ← terminal
                                         │
                          closeApplications()
                                         │
                                         ▼
                                      [Closed]
                                         │
                                      expire()
                                         │
                                         ▼
                                     [Expired]  ← terminal
```

**States:** Announced, Open, Closed, Expired, Withdrawn
**Forbidden transitions:** Withdrawn → any state, Expired → any state, Open → Announced, Closed → Open (for MVP — see Section 4 rejection of `reopenApplications`), Announced → Closed (must open first), Announced → Expired (must open first)

### Admission Cycle

```
                     announce()
  [non-existent] ──────────────────► [Upcoming]
                                         │
                                      activate()
                                         │
                                         ▼
                                      [Active]
                                         │
                                   advancePhase()
                                         │
                                         ▼
                                      [Closed]
                                         │
                                      archive()
                                         │
                                         ▼
                                     [Archived]  ← terminal
```

**States:** Upcoming, Active, Closed, Archived
**Within Active:** Current phase advances through the configured phase sequence. INV-C2: no backwards, no skipping.
**Forbidden transitions:** Archived → any state, Closed → Active, Upcoming → Closed (must activate first), Active phase regression

### Information Source

```
                     register()
  [non-existent] ──────────────────► [Registered]
                                         │
                                      verify()
                                         │
                                         ▼
                                      [Verified]
                                         │
                    markUnreliable() ────┤──── deprecate()
                         │               │         │
                         ▼               │         ▼
                     [Unreliable]        │     [Deprecated] ← terminal
                         │               │
                      verify()           │
                         │               │
                         ▼               │
                      [Verified] ◄───────┘

  Also: Registered → Deprecated (skip verify)
        Unreliable → Deprecated
```

**States:** Registered, Verified, Unreliable, Deprecated
**Forbidden transitions:** Deprecated → any state, Registered → Unreliable (must verify first — a source cannot be unreliable before it has been verified), Verified → Verified (no-op)

### Admission Policy (Child Entity)

```
  [Draft] ──publish──► [Published] ──supersede──► [Superseded]
                            │
                         withdraw
                            │
                            ▼
                        [Withdrawn]
```

**Driven by parent operations:** Programme/Institution `publishAdmissionPolicy` creates in Published state and supersedes any previous active policy. No independent operations.

### Eligibility Policy (Child Entity)

Same lifecycle as Admission Policy. Driven by Scholarship `publishEligibilityPolicy`.

### Accreditation Record (Child Entity)

```
  [Created] — immutable after creation, no lifecycle transitions
```

Each record is an immutable fact. The parent entity derives current accreditation status from its collection of records.

---

## SECTION 16 — DOMAIN EVENTS

### Event Selection Criteria

A domain event is emitted only when:
1. The state change represents a business fact that downstream consumers might need to react to.
2. At least one concrete downstream reaction can be identified (not hypothetical).
3. The event carries sufficient information for the reaction without requiring the consumer to reload the aggregate.

### Canonical Domain Events

| Event | Emitted By | Fact That Occurred | Downstream Reactions |
|-------|-----------|-------------------|---------------------|
| `InstitutionEstablished` | Institution | A new institution has been established | Search index update; authority notification |
| `InstitutionRenamed` | Institution | An institution's official name has changed | Search index update; display invalidation |
| `InstitutionSuspended` | Institution | An institution's operations have been suspended | Programme status cascade; search exclusion/flag |
| `InstitutionReactivated` | Institution | A suspended institution has resumed operations | Programme status restoration; search inclusion |
| `InstitutionClosed` | Institution | An institution has been permanently closed | Programme discontinuation cascade; scholarship flag; search exclusion |
| `InstitutionsMerged` | Institution | Two institutions have merged | Programme reassignment; accreditation transfer; search rebuild |
| `InstitutionAccredited` | Institution | An accreditation event has been recorded for an institution | Trust signal update; search update |
| `InstitutionalAdmissionPolicyPublished` | Institution | An institutional admission policy has been published | Search update; opportunity feed update |
| `ProgrammeIntroduced` | Programme | A new programme has been introduced | Search index update; authority notification |
| `ProgrammeAdmissionPolicyPublished` | Programme | A programme's admission policy has been published | Search update; opportunity feed update |
| `ProgrammeAdmissionSuspended` | Programme | A programme's admission has been suspended | Search exclusion/flag |
| `ProgrammeAdmissionResumed` | Programme | A programme's admission has been resumed | Search inclusion |
| `ProgrammeDiscontinued` | Programme | A programme has been permanently discontinued | Scholarship targeting flag; search exclusion |
| `ProgrammeAccredited` | Programme | An accreditation event has been recorded for a programme | Trust signal update; search update |
| `ScholarshipAnnounced` | Scholarship | A new scholarship has been announced | Search index update; eligible candidate notification |
| `ScholarshipEligibilityPolicyPublished` | Scholarship | An eligibility policy has been published | Eligible candidate recalculation |
| `ScholarshipApplicationsOpened` | Scholarship | Applications are now being accepted | Eligible candidate notification; search update |
| `ScholarshipApplicationsClosed` | Scholarship | Applications are no longer being accepted | Search update |
| `ScholarshipWithdrawn` | Scholarship | A scholarship has been withdrawn | Applicant notification; search exclusion |
| `ScholarshipExpired` | Scholarship | A scholarship's application period has expired | Search update |
| `AdmissionCycleAnnounced` | Admission Cycle | A new admission cycle has been announced | Search update; programme association |
| `AdmissionCycleActivated` | Admission Cycle | An admission cycle has become active | Read model: derive programme admission status |
| `AdmissionCyclePhaseAdvanced` | Admission Cycle | A cycle has advanced to its next phase | Read model: derive programme admission status; notifications |
| `AdmissionCycleClosed` | Admission Cycle | An admission cycle has been closed | Read model: mark all cyclic programmes as no longer accepting |
| `InformationSourceVerified` | Information Source | A source has been verified as reliable | Trust signal recalculation for all derived information |
| `InformationSourceMarkedUnreliable` | Information Source | A source has been marked unreliable | Trust signal recalculation for all derived information |
| `InformationSourceDeprecated` | Information Source | A source has been deprecated | Trust signal cascade; data provenance flag |
| `QualificationDeprecated` | Qualification | A qualification type has been deprecated | Policy creation validation (prevent use in new policies) |

### Rejected Events

- `InstitutionLocationChanged` — No downstream reaction beyond search index, which is a projection concern, not a domain event concern. Search index updates can be triggered by any persistence change.
- `ProgrammeDescriptionUpdated` — Pure CRUD, no domain significance.
- `ScholarshipCoverageUpdated` — Pure CRUD, no domain significance.
- Any event for Scholarship Provider or Education Authority — their changes have no direct domain consequences beyond reference integrity, which is application-layer concern.

---

## SECTION 17 — INVARIANT REGISTER

### Canonical Invariant Register

Each invariant is assessed for: whether it is genuine domain invariant vs. database validation / FK integrity / UI validation / implementation convenience; whether it is universal vs. jurisdiction-dependent; severity of violation.

| ID | Aggregate | Invariant | Protecting Behaviour | Severity | Universal? | Challenge & Verdict |
|----|-----------|-----------|---------------------|----------|------------|---------------------|
| INV-I1 | Institution | Institution has valid type within regulatory framework | `establish` | CRITICAL | Yes | **Genuine.** Institution type determines which authorities have jurisdiction, which award levels are valid, and which accreditation applies. A university cannot be created with type=null or type=invalid. Universal — every educational system categorises institutions. |
| INV-I2 | Institution | Accredited only by authority with jurisdiction over its type | `recordAccreditation` | HIGH | Yes | **Genuine.** The jurisdiction check is a real business rule, not a FK constraint. The form of jurisdiction varies (by type in Nigeria, by region in US, by subject for professional bodies), but the invariant — accreditation requires jurisdiction — is universal. |
| INV-I3 | Institution | Only one active institutional Admission Policy per Admission Cycle | `publishAdmissionPolicy` | HIGH | Yes | **Genuine.** An institution cannot have two conflicting active admission policies for the same cycle. Supersession ensures exactly one is active. Universal — applies to any system with cycle-based admission. |
| INV-I4 | Institution | Institution always has current official name | `establish`, `rename` | MEDIUM | Yes | **Genuine.** An institution without a name cannot exist in the domain. However, "always has current official name" is somewhat tautological — it is really "name is non-empty and cannot be removed." The invariant is valid but simple. |
| INV-I5 | Institution | Closed institution cannot perform business operations | `close`, `suspend` | CRITICAL | Yes | **Genuine.** A closed institution is a terminal state with real business consequences — no policies, no accreditation, no programmes. Universal. |
| INV-P1 | Programme | Programme belongs to exactly one Institution | `introduce` | CRITICAL | Yes | **Genuine.** A programme without an institution is meaningless — it must exist within an institutional context. This is not a FK constraint; it is a domain identity rule (programme identity includes owning institution). Universal. |
| INV-P2 | Programme | Only one active Admission Policy per Admission Cycle | `publishAdmissionPolicy` | HIGH | Yes | **Genuine.** Same reasoning as INV-I3. Universal. |
| INV-P3 | Programme | Programme admission status = (lifecycle Admitting) ∧ (cycle in Admission Period) | Read model query | HIGH | Yes | **Genuine, but NOT a command invariant — it is a query invariant.** No single aggregate enforces this at write time. The read model computes it from Programme state + Admission Cycle phase + Policy existence. This is correct — derived properties belong to read models. |
| INV-P4 | Programme | Programme award level valid for Institution type | `introduce` | HIGH | Jurisdiction-dependent | **Genuine.** Which award levels are valid for which institution types varies by country (Nigeria: University → B.Sc/M.Sc/Ph.D, Polytechnic → ND/HND). The check is jurisdiction-dependent, but the invariant — award level must be valid for type — is universal. |
| INV-P5 | Programme | Programme accreditation only from authority with jurisdiction | `recordAccreditation` | HIGH | Yes | **Genuine.** Same as INV-I2 but at programme level. Universal. |
| INV-P6 | Programme | Discontinued programme cannot perform business operations | `discontinue` | CRITICAL | Yes | **Genuine.** Same as INV-I5. Universal. |
| INV-S1 | Scholarship | Scholarship has exactly one Provider | `announce` | CRITICAL | Yes | **Genuine.** Provider is part of identity. Universal. |
| INV-S2 | Scholarship | Only one active Eligibility Policy per period | `publishEligibilityPolicy` | HIGH | Yes | **Genuine.** Same pattern as INV-P2. Universal. |
| INV-S3 | Scholarship | Applications opened only when Scholarship in "announced" state | `openApplications` | HIGH | Yes | **Genuine.** Lifecycle guard. Universal. |
| INV-S4 | Scholarship | Applications closed only when Scholarship in "open" state | `closeApplications` | HIGH | Yes | **Genuine.** Lifecycle guard. Universal. |
| INV-S5 | Scholarship | Applications cannot open without published Eligibility Policy | `openApplications` | HIGH | Yes | **Genuine.** Business rule — cannot accept applications without eligibility criteria. Universal. |
| INV-C1 | Admission Cycle | Cycle has defined start and end dates | `announce` | MEDIUM | Yes | **Genuine.** A cycle without dates is meaningless. Simple but valid. |
| INV-C2 | Admission Cycle | Phase transitions follow defined sequence (no backwards, no skipping) | `advancePhase` | HIGH | Yes | **Genuine.** This is the Admission Cycle's primary invariant. Universal. |
| INV-C3 | Admission Cycle | Cycle is time-bounded | `close` | MEDIUM | Yes | **Genuine.** Cycles do not run forever. Universal. |
| INV-IS1 | Information Source | Source cannot be simultaneously verified and unreliable | `verify`, `markUnreliable` | HIGH | Yes | **Genuine.** Mutual exclusion of verification states. Universal. |
| INV-IS2 | Information Source | Deprecated source cannot be verified | `deprecate` | HIGH | Yes | **Genuine.** Terminal state constraint. Universal. |
| INV-IS3 | Information Source | Every registered source has a retrievable reference | `register` | MEDIUM | Yes | **Genuine.** A source without a reference cannot be checked. Universal. |
| INV-2 | Accreditation Record | Granted by exactly one Education Authority | `recordAccreditation` (on parent) | HIGH | Yes | **Genuine.** Each record has one authority. Multiple records from multiple authorities are allowed. Universal. |
| INV-9 | Qualification | Recognized by at least one Education Authority | Application service (reference data) | LOW | Yes | **Weak.** This is closer to reference data validation than domain invariant. No aggregate protects this — it is enforced when reference data is loaded. **Downgraded to reference data constraint.** |
| INV-10 | Accreditation Record | Subject within granting authority's jurisdiction | `recordAccreditation` (on parent) | HIGH | Yes | **Genuine.** Same as INV-I2/INV-P5 from the record's perspective. Universal. |

### Challenged Invariants

**INV-P3 challenge:** INV-P3 is not a command invariant — no aggregate enforces it at write time. Should it be in the invariant register at all? Yes, but classified as a **query invariant** (enforced by read model, not by aggregate). This distinction is important for implementation: the read model must be consistent, but eventual consistency is acceptable — a programme may briefly appear as "not admitting" between the cycle phase advance and the read model update.

**INV-9 challenge:** INV-9 is a reference data constraint, not a domain invariant. No aggregate operation depends on it. A qualification not recognized by any authority simply never appears in admission rules. **Reclassified as reference data constraint.**

---

## SECTION 18 — DOMAIN SERVICES

### Definition

A domain service contains domain logic that does not naturally belong to any single aggregate or value object. Domain services are stateless and operate on aggregates passed to them. They are not repositories, not application services, and not a dumping ground for logic that is hard to place.

### Candidate 1: Institution Merge Orchestration

**Situation:** When two institutions merge, programmes must be reassigned, accreditation records transferred, and the target institution closed. This requires loading and modifying multiple Programme aggregates, which cannot be done from within the Institution aggregate.

**Analysis:** The Institution's `mergeWith` operation records the intent and changes the initiating institution's state. The actual programme reassignment requires iterating over programmes — this is orchestration that loads multiple Programme aggregates and calls `reassignTo(newInstitutionId)` on each. This is a **domain service** because it coordinates a domain-significant operation across multiple aggregates, enforcing INV-P1 (each programme must belong to exactly one institution after the merge).

**Verdict: DOMAIN SERVICE — `InstitutionMerger`**
- Input: initiating institution ID, target institution ID
- Operations: load both institutions, load target's programmes, reassign each programme, transfer accreditation records, close target institution
- Invariant enforced: INV-P1 (programme ownership consistency)
- Transactional: Yes — the merge must be atomic

### Candidate 2: Accreditation Jurisdiction Validation

**Situation:** When recording accreditation, the granting authority's jurisdiction must be validated (INV-I2, INV-P5, INV-10).

**Analysis:** This is a validation query on reference data (Education Authority's jurisdiction). It does not modify any aggregate. It is a guard clause that must pass before the domain operation executes. This is an **application-layer validation**, not a domain service.

**Verdict: APPLICATION-LAYER VALIDATION.** Not a domain service. The Programme/Institution's `recordAccreditation` method receives the authority ID; the application layer validates jurisdiction before calling the domain operation.

### Candidate 3: "Is Programme Currently Admitting?" Computation

**Situation:** INV-P3 requires combining Programme lifecycle, Admission Cycle phase, and Policy existence.

**Analysis:** This is a **read-model query**, not a domain service. No aggregates are modified. The query is answered by a projection that joins Programme + Admission Cycle data.

**Verdict: READ-MODEL QUERY.** Not a domain service.

### Candidate 4: Scholarship Applicability Evaluation

**Situation:** Determining whether a scholarship applies to a given programme or institution (`isApplicableTo`).

**Analysis:** This is a query on the Scholarship's targeting rules. No aggregates are modified. The Scholarship exposes its targeting rules; the query evaluates them against a given programme/institution.

**Verdict: QUERY.** Not a domain service.

### Candidate 5: Admission Cycle Effect on Programmes

**Situation:** When an Admission Cycle phase advances, should a domain service notify all associated programmes?

**Analysis:** No. The cycle phase advance changes no Programme state. The derived "isAdmitting" property changes because the cycle's phase changed, but this is a read-model update, not a domain operation on Programme. The `AdmissionCyclePhaseAdvanced` event triggers a read model rebuild.

**Verdict: DOMAIN EVENT + READ MODEL UPDATE.** Not a domain service.

### Summary: Only One Domain Service

**`InstitutionMerger`** — the only domain service in the model. All other cross-aggregate interactions are handled through references, application-layer validation, or eventual consistency via domain events. This minimal domain service footprint is a strong signal that the aggregate boundaries are well-drawn.

---

## SECTION 19 — APPLICATION VS DOMAIN RESPONSIBILITIES

### Clear Boundary Definition

The boundary between domain and application is determined by a simple rule: **if the logic protects a domain invariant, it belongs to the domain layer; if it orchestrates domain operations, queries reference data, or serves the UI, it belongs to the application layer.**

### Classification of Common Operations

| Operation | Classification | Rationale |
|-----------|---------------|-----------|
| Publish admission policy for a programme | **DOMAIN** (Programme.publishAdmissionPolicy) | Enforces INV-P2 (one active per cycle), performs supersession |
| Determine if a programme is currently admitting | **QUERY** (read model) | No state change; derived from multiple aggregates |
| Import accreditation data from external source | **APPLICATION** | Orchestrates: fetch data → validate jurisdiction → call Programme.recordAccreditation |
| Verify information source reliability | **DOMAIN** (InformationSource.verify) | Enforces INV-IS1, changes state |
| Send notification when scholarship opens | **APPLICATION** | Reaction to domain event; notification is not a domain concern |
| Evaluate if a candidate meets eligibility criteria | **QUERY** (read model or query service) | No state change; evaluates rules against candidate data |
| Generate search index for opportunity discovery | **APPLICATION** (projection) | Read model concern; triggered by domain events |
| Collect scholarship data from provider website | **APPLICATION** | Data acquisition orchestration (scrape → parse → validate → store) |
| Check accreditation jurisdiction before recording | **APPLICATION** (validation) | Reference data query before domain operation |
| Deprecate a qualification | **DOMAIN** (Qualification.deprecate) | Enforces the rule that deprecated qualifications cannot be used in new policies |
| Import reference data (qualifications, authorities, pathways) | **APPLICATION** | Reference data CRUD; no domain invariants |
| Schedule scholarship expiration check | **APPLICATION** | Time-based trigger; calls Scholarship.expire when deadline has passed |
| Reassign programme to new institution (during merge) | **DOMAIN SERVICE** (InstitutionMerger) | Enforces INV-P1 across multiple aggregates |
| Update opportunity search index after policy publication | **APPLICATION** (projection) | Read model update triggered by domain event |
| Validate admission policy rules are internally consistent | **APPLICATION** (validation) | Internal consistency is validation, not invariant protection |
| Record that NUC has accredited a programme | **DOMAIN** (Programme.recordAccreditation) | Creates immutable Accreditation Record; enforces INV-P5 |

### Anti-Patterns to Avoid

1. **Domain service that is really application orchestration.** If a "domain service" is calling repositories, sending notifications, or coordinating non-domain operations, it is an application service in disguise.

2. **Aggregate that knows about queries.** An aggregate should never call a read model or query service to make a decision. All information needed for a domain operation must be passed in or already owned by the aggregate.

3. **Domain event that triggers domain operations.** Domain events should trigger application-layer reactions (projections, notifications, read model updates), not other domain operations. If a domain event must trigger another domain operation, the two operations should be coordinated by a domain service or application service instead.

4. **Validation masquerading as invariant.** Field-level validation (non-empty, format checks, range checks) is application-layer validation. Domain invariants are business rules that would be meaningful to a domain expert, not a developer.

---

## SECTION 20 — LARAVEL BEYOND CRUD MAPPING

### How Discovered Behaviours Map to Laravel Beyond CRUD

Laravel Beyond CRUD (Brent Roose & Freek Van der Herten) organises code by domain action, not by model/controller. The key building blocks are:

- **Actions** — Domain commands that perform a single business operation on an aggregate
- **Queries** — Read-model queries that answer questions without modifying state
- **Domain Events** — Facts that have occurred, consumed by listeners
- **Models** — Eloquent models for persistence (not domain logic carriers)
- **State** — Machine implementations for entity lifecycles

### Action Mapping

| Domain Operation | Laravel Action Class | Aggregate |
|-----------------|---------------------|-----------|
| establish institution | `EstablishInstitutionAction` | Institution |
| rename institution | `RenameInstitutionAction` | Institution |
| publish institutional admission policy | `PublishInstitutionalAdmissionPolicyAction` | Institution |
| record institutional accreditation | `RecordInstitutionAccreditationAction` | Institution |
| suspend institution | `SuspendInstitutionAction` | Institution |
| reactivate institution | `ReactivateInstitutionAction` | Institution |
| close institution | `CloseInstitutionAction` | Institution |
| merge institutions | `MergeInstitutionsAction` | Domain Service |
| introduce programme | `IntroduceProgrammeAction` | Programme |
| publish programme admission policy | `PublishProgrammeAdmissionPolicyAction` | Programme |
| suspend programme admission | `SuspendProgrammeAdmissionAction` | Programme |
| resume programme admission | `ResumeProgrammeAdmissionAction` | Programme |
| discontinue programme | `DiscontinueProgrammeAction` | Programme |
| record programme accreditation | `RecordProgrammeAccreditationAction` | Programme |
| announce scholarship | `AnnounceScholarshipAction` | Scholarship |
| publish eligibility policy | `PublishEligibilityPolicyAction` | Scholarship |
| open scholarship applications | `OpenScholarshipApplicationsAction` | Scholarship |
| close scholarship applications | `CloseScholarshipApplicationsAction` | Scholarship |
| withdraw scholarship | `WithdrawScholarshipAction` | Scholarship |
| expire scholarship | `ExpireScholarshipAction` | Scholarship |
| target programmes/institutions | `SetScholarshipTargetsAction` | Scholarship |
| announce admission cycle | `AnnounceAdmissionCycleAction` | Admission Cycle |
| activate admission cycle | `ActivateAdmissionCycleAction` | Admission Cycle |
| advance admission cycle phase | `AdvanceAdmissionCyclePhaseAction` | Admission Cycle |
| close admission cycle | `CloseAdmissionCycleAction` | Admission Cycle |
| archive admission cycle | `ArchiveAdmissionCycleAction` | Admission Cycle |
| register information source | `RegisterInformationSourceAction` | Information Source |
| verify information source | `VerifyInformationSourceAction` | Information Source |
| mark information source unreliable | `MarkInformationSourceUnreliableAction` | Information Source |
| deprecate information source | `DeprecateInformationSourceAction` | Information Source |
| deprecate qualification | `DeprecateQualificationAction` | Qualification |
| deprecate scholarship provider | `DeprecateScholarshipProviderAction` | Scholarship Provider |
| deprecate education authority | `DeprecateEducationAuthorityAction` | Education Authority |

### Query Mapping

| Domain Query | Laravel Query Class | Source |
|-------------|---------------------|--------|
| Is programme currently admitting? | `IsProgrammeAdmittingQuery` | Read model: Programme + Admission Cycle + Policy |
| Is scholarship applicable to programme? | `IsScholarshipApplicableQuery` | Scholarship targeting rules |
| Is admission cycle in admission period? | `IsAdmissionCycleInAdmissionPeriodQuery` | Admission Cycle current phase |
| Is information source reliable? | `IsInformationSourceReliableQuery` | Information Source status |
| Get current accreditation status | `GetCurrentAccreditationStatusQuery` | Most recent Accreditation Record |
| Get active admission policy for cycle | `GetActiveAdmissionPolicyQuery` | Programme/Institution + Cycle |
| Get active eligibility policy for period | `GetActiveEligibilityPolicyQuery` | Scholarship + Period |

### Domain Event Mapping

Each event from Section 16 maps to a Laravel event class with a corresponding listener. Listeners handle:
- Read model / search index projections
- Notification dispatch
- Trust signal recalculation (for Information Source events)

### Key Principle: Actions Are Thin Orchestration Over Domain Logic

The Action classes are not fat controllers. Each Action:
1. Validates input (application-layer validation)
2. Loads the aggregate (via repository)
3. Calls the domain method on the aggregate
4. Persists the aggregate (via repository)
5. Dispatches domain events

The domain logic lives in the aggregate. The Action is the application service that coordinates the domain operation with infrastructure concerns (persistence, event dispatch).

---

## SECTION 21 — GLOBAL BEHAVIOUR TEST

### Testing Against 9 Countries

Each behaviour is tested against Nigeria, Ghana, Kenya, South Africa, UK, US, Canada, Germany, and Australia. The goal is to identify behaviours that are: universally valid, require jurisdictional configuration, are Nigeria-specific terminology, or incorrectly assume one country's admission process.

### Institution Behaviours

| Behaviour | Nigeria | Ghana | Kenya | S.Africa | UK | US | Canada | Germany | Australia | Verdict |
|-----------|---------|-------|-------|----------|----|----|--------|---------|-----------|---------|
| establish | Federal/State/Private | Public/Private | Public/Private | Public/Private | University/College | Public/Private/For-profit | Public/Private | Staatlich/Privat | Public/Private | **Universal** — type values vary but operation is universal |
| rename | Yes (e.g., UNIFE→OAU) | Rare | Rare | Rare | Yes (e.g., polytechnic→university) | Rare | Rare | Rare | Rare | **Universal** — business event |
| suspend | NUC can suspend | GTEC can suspend | CUEA can suspend | DHET can suspend | OfS can de-register | Regional accreditor can sanction | Provincial authority | Länder can withdraw approval | TEQSA can sanction | **Universal** |
| close | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | **Universal** |
| mergeWith | Yes (poly→univ) | Yes (merger into GTEC) | Yes | Yes (mergers) | Yes | Yes | Yes | Yes | Yes | **Universal** |
| publishAdmissionPolicy | Institutional post-UTME | Institutional requirements | Institutional requirements | Institutional requirements | Institutional requirements | Institutional requirements | Institutional requirements | Institutional requirements | Institutional requirements | **Universal** — every institution publishes requirements |
| recordAccreditation | NUC/NBTE/NCCE | GTEC | CUEA | CHE/HEQC | QAA/OfS | Regional accreditors | provincial | Akkreditierungsrat | TEQSA | **Universal** — jurisdiction varies but operation is universal |

### Programme Behaviours

| Behaviour | Nigeria | Ghana | Kenya | S.Africa | UK | US | Canada | Germany | Australia | Verdict |
|-----------|---------|-------|-------|----------|----|----|--------|---------|-----------|---------|
| introduce | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | **Universal** |
| publishAdmissionPolicy | Per JAMB cycle | Per GTEC cycle | Per KUCCPS cycle | Per cycle | Per UCAS cycle or rolling | Per cycle or rolling | Per cycle or rolling | Per cycle or rolling | Per cycle or rolling | **Universal** — but Admission Mode varies |
| suspendAdmission | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes (Zulassungsstop) | Yes | **Universal** |
| discontinue | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | Yes | **Universal** |
| recordAccreditation | Programme-level (NUC) | Programme-level (GTEC) | Programme-level | Programme-level (HEQC) | Programme-level (PSRB) | Programme-level (ABET) | Programme-level | Programm-Akkreditierung | Programme-level | **Universal** |

### Critical Finding: Admission Mode Is Essential for Global Applicability

The Programme's Admission Mode (Cyclic, Rolling, Multiple-Intake) is the key to global applicability:

- **Nigeria, Ghana, Kenya:** Most programmes are Cyclic (governed by a national admission cycle)
- **UK:** Undergraduate programmes are Cyclic (UCAS), but postgraduate programmes are often Rolling
- **US:** Mix of Cyclic (with Early Decision/Regular Decision phases) and Rolling Admission
- **Germany:** Many programmes are Rolling (no fixed cycle); some restricted programmes (NC) are Cyclic
- **Australia:** Mix of Cyclic (main intakes) and Rolling (some programmes)

Without Admission Mode, the model would force all programmes into a cycle-based pattern, which is incorrect for rolling and multiple-intake programmes. **The Admission Mode VO is critical for global applicability.**

### Scholarship Behaviours

| Behaviour | Verdict | Notes |
|-----------|---------|-------|
| announce | Universal | Scholarships exist worldwide |
| publishEligibilityPolicy | Universal | Eligibility criteria are universal |
| openApplications | Universal | Application windows are universal |
| closeApplications | Universal | |
| withdraw | Universal | Providers can withdraw worldwide |
| targetProgrammes/targetInstitutions | Universal | Scoping is universal (though some scholarships are open to all) |

### Admission Cycle Behaviours

| Behaviour | Nigeria | Ghana | Kenya | UK | US | Germany | Verdict |
|-----------|---------|-------|-------|----|----|---------|---------|
| announce | JAMB cycle | GTEC cycle | KUCCPS cycle | UCAS cycle | Common App cycle (optional) | Semester dates | **Universal for Cyclic mode** — not applicable for Rolling |
| activate | Yes | Yes | Yes | Yes | Yes | Yes | **Universal for Cyclic mode** |
| advancePhase | Yes (Registration→Exam→Results→Admission) | Yes | Yes | Yes (Apply→Decisions→Reply→Clearing) | Yes (Early→Regular→Waitlist) | Yes (Application→Selection) | **Universal for Cyclic mode** — phase names are data |
| close | Yes | Yes | Yes | Yes | Yes | Yes | **Universal for Cyclic mode** |

**Critical finding:** Admission Cycle operations are **not universal across all programmes** — they only apply to programmes with Admission Mode = Cyclic. Programmes with Rolling or Multiple-Intake mode have no cycle association. This is already captured in the model but must be explicit: Admission Cycle is relevant only when Programme.AdmissionMode = Cyclic.

### Nigeria-Specific Terminology Found

1. **"Post-UTME"** — This is Nigerian terminology for institution-specific screening after the JAMB UTME. The universal concept is "institution-specific admission screening" or "supplementary assessment." The domain model uses Admission Pathway (now a VO) — "Post-UTME" is a value instance, not a domain concept.

2. **"Direct Entry"** — Nigerian term for advanced-level entry (200-level). The universal concept is "advanced standing admission" or "advanced entry pathway." Again, an Admission Pathway VO value instance.

3. **"UTME"** — JAMB's specific examination. The universal concept is "centralised entrance examination" — an Admission Pathway VO value instance.

None of these terms appear in the domain model as concepts — they are data values of the Admission Pathway VO. **No model changes needed.**

---

## SECTION 22 — FUTURE STUDY ABROAD TEST

### Testing Behaviours Against International Study Use Cases

The question is whether the current domain behaviours can *eventually* support international study — not whether they support it now, and without creating new entities.

### Use Case 1: Applying to Foreign Institutions

**Current support:** Programme is globally valid. A Nigerian student discovering programmes at UK universities uses the same Programme entity — the programme belongs to a UK Institution, has an Admission Mode (Cyclic via UCAS), and has Admission Policies with Admission Rules. The Scholarship entity works identically for international scholarships (Chevening, Commonwealth). **SUPPORTED without modification.**

### Use Case 2: International Programme Requirements

**Current support:** Admission Policy with Admission Rules can express any requirement — including "IELTS score ≥ 6.5" or "GRE score ≥ 320." The Qualification entity already supports international qualifications (IELTS, TOEFL, GRE, SAT). The Admission Rule VO is flexible enough to express qualification thresholds for any qualification type. **SUPPORTED without modification.**

### Use Case 3: Language Requirements

**Current support:** Language requirements are qualification thresholds — "IELTS ≥ 6.5" is a Qualification (IELTS) + Qualification Threshold (≥ 6.5). No "LanguageRequirement" entity is needed. Language proficiency is a type of qualification in the domain model. **SUPPORTED without modification.**

### Use Case 4: Standardized Tests

**Current support:** Standardized tests (SAT, ACT, GRE, GMAT, UTME) are Qualifications. Test scores are Qualification Thresholds within Admission Rules. **SUPPORTED without modification.**

### Use Case 5: Visa Requirements

**Current support:** The current model does NOT include visa or immigration requirements. These are outside StudyNexus's domain — they belong to the applicant's personal context and are managed by immigration authorities. The frozen constraint says "Do NOT create Visa entities or Immigration aggregates." However, a future Eligibility Rule type could reference "visa eligibility for country X" as a boolean criterion — this would be a new Eligibility Rule type, not a new entity. **NOT SUPPORTED but extensibility path exists through Eligibility Rule types.**

### Use Case 6: Proof of Funds

**Current support:** Financial requirements for international students (e.g., "proof of funds ≥ $40,000 for US student visa") are not modelled. Like visa requirements, these are in the applicant's personal context. A future Eligibility Rule type for financial thresholds could be added. **NOT SUPPORTED but extensibility path exists through Eligibility Rule types.**

### Use Case 7: Country-Specific Admission Pathways

**Current support:** Admission Pathway (demoted to VO) can represent any pathway — "UCAS Application," "Common App," "Direct to Institution," "Early Decision," "Clearing." These are value instances of the VO, defined by the Admission Pathway's defining authority. **SUPPORTED without modification.**

### Use Case 8: International Student Eligibility

**Current support:** Eligibility Policy with Eligibility Rules can express "must be a citizen of [country list]" or "must not be a domestic student" through existing rule types. The Eligibility Rule VO is flexible enough to include nationality/residency criteria. **SUPPORTED without modification.**

### Use Case 9: Application Deadlines

**Current support:** For Cyclic programmes, the Admission Cycle defines the timeline. For Rolling programmes, the Programme has its own timeline. Deadlines are part of the Admission Policy (validity period). **SUPPORTED without modification.**

### Use Case 10: Credential Evaluation / Recognition

**Current support:** When a Nigerian student applies to a US university, the US university may require credential evaluation (e.g., WES evaluation of Nigerian transcripts). This is a type of Qualification — "WES Evaluation of WAEC SSCE" could be modelled as a Qualification defined by the WES authority. The Admission Rule would specify the required evaluation as a Qualification Threshold. **SUPPORTED without modification.**

### Summary

The current domain model supports 8 of 10 international study use cases without modification. The 2 unsupported cases (visa requirements, proof of funds) are explicitly out of scope per the constraint, but extensibility paths exist through Eligibility Rule types. **No model changes needed for eventual study-abroad support.** This is a strong validation of the domain model's global applicability.

---

## SECTION 23 — BEHAVIOUR GAP ANALYSIS

### Missing Behaviours

1. **Institution `reactivate`** — Previously missing. Discovered in Section 2. A suspended institution cannot return to operational status without this operation. **ADDED.**

2. **Scholarship `expire`** — Previously missing. Discovered in Section 4. Scholarships whose application period has passed need explicit lifecycle closure. **ADDED.**

3. **Programme `reassignTo`** — Needed during institution merge. A programme must be able to change its owning institution when institutions merge. This is not a general-purpose operation (programmes should not freely switch institutions) — it is only valid in the context of a merge. **ADDED as internal operation, only called by InstitutionMerger domain service.**

4. **Admission Cycle `activate`** — The existing operation list had `announce` and `advancePhase` but no explicit activation when the start date arrives. `announce` creates the cycle in Upcoming state; something must transition it to Active. **ADDED.**

### Redundant Behaviours

1. **`isAdmitting` on Programme** — This is a query, not a domain operation. It has been reclassified. **REMOVED from domain operations.**

2. **`isApplicableTo` on Scholarship** — Query, not domain operation. **REMOVED from domain operations.**

3. **`isReliable` on Information Source** — Query, not domain operation. **REMOVED from domain operations.**

4. **`isAdmissionOpen` on Admission Cycle** — Query, not domain operation. **REMOVED from domain operations.**

### Behaviours Belonging to Wrong Aggregates

1. **No behaviours found on wrong aggregates.** The existing operation assignments are correct. Programme publishes its own admission policies; Scholarship publishes its own eligibility policies; Information Source manages its own verification status. No corrections needed.

### Entities Without Meaningful Behaviour

1. **Scholarship Provider** — Only `deprecate`. The weakest entity in the model. It exists as a referential integrity guard for Scholarship's INV-S1. Its supporting entity classification is upheld but remains on thin ice.

2. **Education Authority** — Only `deprecate`. Same pattern as Scholarship Provider. Its primary role is as reference data with jurisdiction information. Supporting entity classification upheld.

3. **Qualification** — Only `deprecate`. Same pattern. Supporting entity classification upheld.

All three supporting entities share the same behavioural profile: they exist as reference data with a single `deprecate` operation. This pattern is consistent and intentional — they are reference entities that participate in the domain through identity and deprecation, not through autonomous behaviour.

### Aggregate Roots Without Sufficient Invariants

1. **Information Source** — Has three invariants (INV-IS1 through INV-IS3). These are real but modest. The aggregate root classification is justified by the cascading trust effect, not by the complexity of its invariants. **No change.**

2. **Admission Cycle** — Has three invariants (INV-C1 through INV-C3). INV-C2 (phase sequence) is the strongest. The aggregate root classification is justified by the temporal integrity of the cycle and the cross-aggregate effect on programme admission status. **No change.**

### Invariants Without Protecting Behaviour

1. **INV-P3** — The query invariant "isAdmitting = (lifecycle Admitting) ∧ (cycle in Admission Period) ∧ (has active policy)" is not protected by any aggregate operation. It is derived by the read model. This is correct for a query invariant, but it must be explicitly documented as such. **Documented as query invariant.**

2. **INV-9** — "Qualification recognized by at least one Education Authority" is a reference data constraint with no protecting behaviour. **Reclassified as reference data constraint.**

### State Transitions Without Commands

1. **Scholarship Announced → Expired** — A scholarship can expire, but only after it has been opened and closed. The state machine in Section 4 shows that Expired is only reachable from Closed. If a scholarship is Announced but never opens, it should still eventually expire (the application period has passed without opening). This means Announced → Expired should be an allowed transition for the `expire` operation when the application deadline has passed. **State machine corrected to allow Announced → Expired.**

2. **Institution Suspended → Closed** — A suspended institution should be closeable (e.g., if the suspension leads to permanent revocation). **Already allowed in revised state machine.**

### Commands Without Business Justification

1. **No commands found without business justification.** All accepted operations trace to specific invariants or business rules. The ten-question filter has eliminated CRUD candidates.

### Adversarial Challenges

**Challenge 1: Is Admission Cycle really an aggregate root?** In many countries (US, Germany, Australia), institutions define their own timelines. The Admission Cycle aggregate is only relevant for centralised admission systems (Nigeria, Kenya, UK UCAS). In decentralised systems, each programme manages its own timeline through Admission Mode = Rolling/Multiple-Intake. Is an aggregate root justified if it only applies to one admission pattern?

**Response:** Admission Cycle is an aggregate root because: (1) it protects a real invariant (INV-C2, phase sequence), (2) it has an independent lifecycle with meaningful business operations, (3) it is referenced by Programme and Institution for cycle-based admission, and (4) even in decentralised systems, institutions may define their own cycles (a US university with Early Decision + Regular Decision has a cycle). The aggregate is universally relevant for any admission system with discrete phases; it is simply not used by programmes with Rolling admission. **Classification upheld.**

**Challenge 2: Should Admission Policy and Eligibility Policy have a shared base?** The structural similarity (Draft → Published → Superseded/Withdrawn, one-active-per-period, immutable after publication) is undeniable. A `Policy` base class or trait would reduce code duplication.

**Response:** Code duplication is an implementation concern, not a domain concern. In the domain layer, Admission Policy and Eligibility Policy are distinct concepts with different semantics, different parents, and different downstream effects. A shared base would conflate them at the implementation level. The Laravel Beyond CRUD approach would handle this through separate Action classes; any shared code would live in a utility or trait at the implementation layer, not as a domain abstraction. **Frozen decision #2 upheld.**

**Challenge 3: Is `recordAccreditation` really domain behaviour?** It "just" creates a child entity. Isn't this CRUD?

**Response:** `recordAccreditation` enforces INV-I2/INV-P5 (jurisdiction check) and creates an immutable record with a specific identity (Accredited Entity + Granting Authority + Effective Period Start). The jurisdiction check is a real business rule that would be violated if any authority could accredit any entity. The immutable-fact nature of the record means it cannot be updated or deleted — it can only be appended. These constraints distinguish it from CRUD. **Classification upheld.**

---

## SECTION 24 — FINAL BEHAVIOUR MODEL

### Aggregate Roots (5)

#### Educational Institution

**Identity:** Official Name + Institution Type + Registration Identifier
**Invariants:** INV-I1 (valid type), INV-I2 (jurisdiction for accreditation), INV-I3 (one active policy per cycle), INV-I4 (always has name), INV-I5 (closed cannot operate)
**State Machine:** Operational ⇄ Suspended → Closed (terminal)
**Domain Operations:** establish, rename, publishAdmissionPolicy, recordAccreditation, suspend, reactivate, close, mergeWith
**Domain Events:** InstitutionEstablished, InstitutionRenamed, InstitutionalAdmissionPolicyPublished, InstitutionAccredited, InstitutionSuspended, InstitutionReactivated, InstitutionClosed, InstitutionsMerged
**Child Entities:** Admission Policy (institution-level), Accreditation Record (institution-level)

#### Programme

**Identity:** Programme Name + Owning Institution + Award Level
**Invariants:** INV-P1 (belongs to one Institution), INV-P2 (one active policy per cycle), INV-P3 (query: admission status derived), INV-P4 (award level valid for type), INV-P5 (jurisdiction for accreditation), INV-P6 (discontinued cannot operate)
**State Machine:** Admitting ⇄ Suspended → Discontinued (terminal)
**Domain Operations:** introduce, publishAdmissionPolicy, suspendAdmission, resumeAdmission, discontinue, recordAccreditation, reassignTo (internal, for merge only)
**Domain Events:** ProgrammeIntroduced, ProgrammeAdmissionPolicyPublished, ProgrammeAdmissionSuspended, ProgrammeAdmissionResumed, ProgrammeDiscontinued, ProgrammeAccredited
**Child Entities:** Admission Policy (programme-level), Accreditation Record (programme-level)
**Value Objects:** Admission Mode (Cyclic | Rolling | Multiple-Intake)

#### Scholarship

**Identity:** Scholarship Name + Offering Provider + Application Period
**Invariants:** INV-S1 (exactly one Provider), INV-S2 (one active policy per period), INV-S3 (open only from Announced), INV-S4 (close only from Open), INV-S5 (cannot open without policy)
**State Machine:** Announced → Open → Closed → Expired (terminal); any state → Withdrawn (terminal); Announced → Expired (application period passed without opening)
**Domain Operations:** announce, publishEligibilityPolicy, openApplications, closeApplications, withdraw, expire, targetProgrammes, targetInstitutions
**Domain Events:** ScholarshipAnnounced, ScholarshipEligibilityPolicyPublished, ScholarshipApplicationsOpened, ScholarshipApplicationsClosed, ScholarshipWithdrawn, ScholarshipExpired
**Child Entities:** Eligibility Policy

#### Admission Cycle

**Identity:** Period/Year + Defining Authority
**Invariants:** INV-C1 (defined dates), INV-C2 (phase sequence), INV-C3 (time-bounded)
**State Machine:** Upcoming → Active → Closed → Archived (terminal); within Active, current phase advances through configurable sequence
**Domain Operations:** announce, activate, advancePhase, close, archive
**Domain Events:** AdmissionCycleAnnounced, AdmissionCycleActivated, AdmissionCyclePhaseAdvanced, AdmissionCycleClosed
**Note:** Only applicable when Programme.AdmissionMode = Cyclic

#### Information Source

**Identity:** Source Name + Source Type + Retrievable Reference
**Invariants:** INV-IS1 (not simultaneously verified and unreliable), INV-IS2 (deprecated cannot be verified), INV-IS3 (every source has reference)
**State Machine:** Registered → Verified ⇄ Unreliable; any non-deprecated → Deprecated (terminal)
**Domain Operations:** register, verify, markUnreliable, deprecate
**Domain Events:** InformationSourceVerified, InformationSourceMarkedUnreliable, InformationSourceDeprecated

### Child Entities (3)

#### Admission Policy (child of Programme or Institution)
**Identity:** Governed Entity + Applicable Admission Cycle
**Lifecycle:** Draft → Published → Superseded | Withdrawn
**Immutable after publication; superseded by parent's publishAdmissionPolicy**
**Contains:** Collection of Admission Rules (VOs), Admission Pathway (VO) discriminator

#### Eligibility Policy (child of Scholarship)
**Identity:** Owning Scholarship + Applicable Period
**Lifecycle:** Draft → Published → Superseded | Withdrawn
**Immutable after publication; superseded by parent's publishEligibilityPolicy**
**Contains:** Collection of Eligibility Rules (VOs)

#### Accreditation Record (child of Programme or Institution)
**Identity:** Accredited Entity + Granting Authority + Effective Period Start
**Lifecycle:** None — immutable after creation
**Contains:** Granting Authority reference, Accreditation Status, Validity Period, source reference

### Supporting Entities (3)

#### Qualification
**Identity:** Qualification Name + Defining Authority
**Behaviour:** deprecate
**Event:** QualificationDeprecated
**Otherwise:** Reference data managed by application services

#### Scholarship Provider
**Identity:** Official Name
**Behaviour:** deprecate
**Otherwise:** Reference data managed by application services
**Flag:** Weakest entity in model — exists primarily as referential integrity guard

#### Education Authority
**Identity:** Abbreviation or Official Name
**Behaviour:** deprecate
**Otherwise:** Reference data with jurisdiction data, managed by application services

### Demoted Entity

#### Admission Pathway → **Value Object**
**Identity (as VO equality):** Pathway Name + Defining Authority
**No lifecycle, no invariants, no behaviour**
**Role:** Discriminator within Admission Policy (identifies which set of rules applies)
**Valid values:** Reference data managed by application layer
**Previous classification:** Supporting entity (provisional)
**Reason for demotion:** No invariant, no behaviour, no autonomous lifecycle — only used as discriminator within policies

### Key Value Objects (selected)

| Value Object | Purpose | Used By |
|-------------|---------|---------|
| Admission Mode | Cyclic / Rolling / Multiple-Intake | Programme |
| Admission Rule | Qualification threshold, subject combination, etc. | Admission Policy |
| Eligibility Rule | CGPA threshold, field of study, nationality, etc. | Eligibility Policy |
| Admission Pathway | Discriminator for rule sets within a policy | Admission Policy |
| Qualification Threshold | Qualification + comparison + value | Admission Rule, Eligibility Rule |
| Subject Combination | Required subject set | Admission Rule |
| Trust Signal | Derived trustworthiness indicator | Read model (not stored) |
| Authority Jurisdiction | Defines what an authority can accredit | Education Authority (reference data) |
| Phase Sequence | Ordered list of cycle phases | Admission Cycle |
| Validity Period | Start date + end date | Accreditation Record, Admission Policy, Eligibility Policy |
| Coverage Type | Full / Partial / Tuition-only / Stipend | Scholarship |
| Monetary Amount | Currency + amount | Scholarship |
| Duration | Period of study | Programme |
| Institution Type | Classification within regulatory framework | Institution |
| Award Level | Degree/qualification level | Programme |

### Domain Services (1)

**InstitutionMerger** — Coordinates institution merge: reassigns programmes, transfers accreditation, closes target institution. Enforces INV-P1 across multiple Programme aggregates. Only domain service in the model.

### Cross-Aggregate Interactions

| Interaction | Pattern | Consistency |
|-------------|---------|-------------|
| Programme ↔ Admission Cycle | Reference ID (Programme holds cycle ID) | Eventual (read model joins) |
| Institution ↔ Admission Cycle | Reference ID | Eventual (read model joins) |
| Scholarship → Programme/Institution | Reference IDs (targeting) | Eventual (read model joins) |
| Institution merge → Programmes | Domain service (InstitutionMerger) | Strong (transactional) |
| Information Source → derived information | Domain event (trust cascade) | Eventual |
| Programme → Education Authority (jurisdiction) | Application-layer validation | Synchronous (guard clause) |

### Domain Events (27)

As listed in Section 16. All events are business facts emitted by aggregates, consumed by application-layer listeners for: read model projections, search index updates, notification dispatch, trust signal recalculation.

### Queries (7)

As listed in Section 20. All queries are read-model concerns that derive information from one or more aggregates without modifying state.

### Application Responsibilities

- Reference data management (Qualification, Scholarship Provider, Education Authority CRUD)
- Data import and acquisition (scraping, parsing, validation)
- Jurisdiction validation (before recordAccreditation)
- Search index / read model projections (triggered by domain events)
- Notification dispatch (triggered by domain events)
- Time-based lifecycle triggers (scholarship expiration, cycle activation)
- Policy rule validation (internal consistency checks)

### Rejected Behaviours

- All CRUD operations (field updates without invariant protection)
- `isAdmitting`, `isApplicableTo`, `isReliable`, `isAdmissionOpen` — reclassified as queries
- `addProgramme` on Institution — Programme is its own aggregate
- `changeType` on Institution — modelled as close + establish
- `reopenApplications` on Scholarship — complexity without current business justification
- `acquireData` on Information Source — application orchestration
- Shared Policy abstraction — structural similarity does not justify domain abstraction

### Unresolved Questions

1. **Should Scholarship Provider be further demoted?** It is the weakest entity with only `deprecate`. If referential integrity can be enforced at the application layer (not database FK), it could become a Value Object. However, losing `deprecate` capability and centralised identity management are real costs. **Resolved for now: retain as supporting entity. Revisit if implementation profiling shows no deprecation use case.**

2. **Should Admission Cycle support "per-institution" cycles?** In the US, each university may define its own cycle (Early Decision in November, Regular Decision in January). Currently, Admission Cycle has a single Defining Authority. A university-defined cycle would have Defining Authority = the institution itself. Is this a valid use of the model? **Yes — the Admission Cycle's Defining Authority is not restricted to national-level authorities. A university is an Education Authority for its own cycle. This is supported without model changes.**

3. **Should programmes in Rolling mode have any time structure?** Rolling admission means applications are accepted continuously, but most rolling programmes still have "priority deadlines" or "recommended deadlines." Should these be modelled as soft boundaries on the Admission Policy's Validity Period? **Yes — the Validity Period VO on Admission Policy can express "priority deadline" without changing the model. The Programme remains in Rolling mode; the deadline is informational, not a phase gate.**

---

## SECTION 25 — READINESS FOR DOMAIN ARCHITECTURE

### Assessment

The behaviour discovery process has:

1. **Applied the ten-question filter** to every candidate operation, eliminating CRUD and reclassifying queries.
2. **Discovered missing behaviours** (reactivate, expire, activate, reassignTo) and added them.
3. **Resolved the Programme↔Admission Cycle interaction** — the most architecturally significant question — by designating "isAdmitting" as a read-model query, not a domain operation.
4. **Demoted Admission Pathway** from supporting entity to value object based on behavioural evidence.
5. **Confirmed all five aggregate root classifications** against behavioural criteria.
6. **Confirmed the Admission Policy ≠ Eligibility Policy decision** with no shared abstraction.
7. **Confirmed Accreditation Record immutability** and derived lifecycle from record sequence.
8. **Identified exactly one domain service** (InstitutionMerger), indicating well-drawn aggregate boundaries.
9. **Mapped all cross-aggregate interactions** with appropriate consistency patterns.
10. **Tested all behaviours against 9 countries** and confirmed global applicability.
11. **Tested against 10 study-abroad use cases** and confirmed 8/10 supported without modification.
12. **Performed adversarial gap analysis** and corrected all identified gaps.

### Mandatory Revisions

1. **Demote Admission Pathway from supporting entity to Value Object.** This is the only structural change to the canonical model. The entity had no invariants, no behaviour, and no autonomous lifecycle — it serves as a discriminator within Admission Policies, which is a VO role.

2. **Reclassify `isAdmitting`, `isApplicableTo`, `isReliable`, `isAdmissionOpen` from domain operations to read-model queries.** These are not behaviour changes (they were always queries) but their classification in the operation list was incorrect.

3. **Add `reactivate` to Institution, `expire` to Scholarship, `activate` to Admission Cycle, `reassignTo` to Programme (internal).** These are additions to the operation list, not structural changes.

4. **Reclassify INV-P3 as a query invariant** (enforced by read model, not by aggregate command). This is a documentation change, not a model change.

5. **Reclassify INV-9 as a reference data constraint** rather than a domain invariant. This is a documentation change; no model change.

6. **Correct Scholarship state machine** to allow Announced → Expired transition (scholarship announced but never opened whose application period has passed).

### Entity Count After Revisions

- Aggregate Roots: 5 (unchanged)
- Child Entities: 3 (unchanged)
- Supporting Entities: 3 (was 4 — Admission Pathway demoted to VO)
- **Total entities: 11** (was 12)

### Verdict

## **READY FOR DOMAIN ARCHITECTURE**

The domain model has been rigorously tested through behaviour discovery. All operations have been validated against the ten-question filter. All aggregate boundaries have been confirmed against behavioural criteria. Cross-aggregate interactions have been mapped with appropriate consistency patterns. The model is globally applicable and extensible for study-abroad use cases. The single structural change (Admission Pathway demotion) and five operational corrections are minor and do not require re-evaluation of the aggregate boundaries or invariant structure.

The model can proceed to domain architecture (Laravel Beyond CRUD implementation planning) with confidence. The 27 domain events, 7 queries, 1 domain service, and 30+ domain operations provide a complete behavioural specification for implementation.

---
