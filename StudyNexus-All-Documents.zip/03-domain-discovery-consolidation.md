# StudyNexus — Domain Discovery Consolidation & Pre-Behaviour Freeze

**Date:** 2026-08-07
**Status:** Pre-Behaviour Readiness Assessment
**Scope:** Final consolidation of Topics 1–3, Architectural Review, Domain Integrity Review, and Domain Resolution Analysis
**Objective:** Actively challenge the current domain model. Do NOT simply summarize previous documents. Identify every remaining weakness, validate every boundary, and confirm readiness for Behaviour Discovery.
**Authority Order:** Business Discovery (frozen) → Topic 1 → Topic 2 (revised) → Topic 3 → Architectural Review (14) → Integrity Review (16) → Resolution Analysis (17) → **This Document**

---

## 1. Canonical Entity Register

### Challenge: Are all 12 entities justified? Should any be promoted, demoted, or removed?

The Resolution Analysis accepted Admission Pathway as a new supporting entity (from open question OQ-D3-1 and integrity review RI-1). The model now has 12 entities. Each is challenged below against the invariant-justification criterion from Laravel Beyond CRUD.

| # | Entity | Classification | Invariants Protected | Business Operations | Challenge & Verdict |
|---|--------|---------------|---------------------|-------------------|---------------------|
| 1 | Educational Institution | Aggregate Root | INV-I1 through INV-I5 | establish, rename, publishAdmissionPolicy, recordAccreditation, suspend, close, mergeWith | **Confirmed.** Five invariants, seven operations, strong consistency boundary (policies + accreditation records). Demotion would violate INV-I3 (one active policy per cycle). |
| 2 | Programme | Aggregate Root | INV-P1 through INV-P6 | introduce, publishAdmissionPolicy, suspendAdmission, resumeAdmission, discontinue, recordAccreditation, isAdmitting | **Confirmed.** Six invariants, seven operations. INV-P2 (one active policy per cycle) is Programme's invariant, not Institution's — Programme must be its own aggregate. |
| 3 | Scholarship | Aggregate Root | INV-S1 through INV-S5 | announce, publishEligibilityPolicy, openApplications, closeApplications, withdraw, targetProgrammes, targetInstitutions, isApplicableTo | **Confirmed.** Five invariants, eight operations. INV-S5 (cannot open applications without published policy) is the strongest invariant — Scholarship must enforce this atomically. |
| 4 | Admission Cycle | Aggregate Root | INV-C1 through INV-C3 | announce, advancePhase, isAdmissionOpen | **Challenged: Is Admission Cycle still universally justified?** The Resolution Analysis established that Admission Cycle is no longer a universal temporal axis (programmes with Rolling or Multiple-Intake admission modes bypass it). **Verdict: Confirmed as aggregate root for cyclic admission mode, but with reduced scope.** For rolling/multiple-intake programmes, Admission Cycle is optional. This does not demote it — when present, it still protects INV-C2 (sequential phase transitions), which is a real invariant. |
| 5 | Information Source | Aggregate Root | INV-IS1 through INV-IS3 | register, verify, markUnreliable, deprecate, isReliable | **Confirmed.** Three invariants, five operations. INV-IS1 (cannot be simultaneously verified and unreliable) is a real business rule with cascading trust consequences. |
| 6 | Admission Policy | Child Entity | INV-I3, INV-P2 | (lifecycle managed by parent) | **Confirmed.** Identity is entity+cycle-scoped. Cannot exist independently — its publication is the parent aggregate's business operation. |
| 7 | Eligibility Policy | Child Entity | INV-S2 | (lifecycle managed by parent) | **Confirmed.** Identity is scholarship+period-scoped. Cannot exist independently. |
| 8 | Accreditation Record | Child Entity | INV-2, INV-10 | (immutable; created by parent) | **Confirmed.** Immutable historical fact. Each record is created, never modified. Cannot be a standalone aggregate — its jurisdiction check (INV-10) must be atomic with the parent's recording operation. |
| 9 | Qualification | Supporting Entity | INV-9 | (minimal lifecycle: deprecation) | **Challenged: Should Qualification remain a supporting entity or be promoted?** Qualification is referenced by Admission Rules (within Admission Policy), Eligibility Rules (within Eligibility Policy), and Qualification Thresholds. It has identity (Name + Defining Authority) but no meaningful business operations in StudyNexus — we don't "manage" qualifications, we reference them. **Verdict: Confirmed as supporting entity.** Promotion to aggregate root would be anemic — no operations beyond deprecation. References are resolved at read time. |
| 10 | Scholarship Provider | Supporting Entity | (none — purely structural) | (minimal lifecycle) | **Challenged: No invariants.** Scholarship Provider exists only to normalize the Provider reference on Scholarship (INV-S1). It has no business operations that StudyNexus performs. **Verdict: Confirmed as supporting entity for MVP.** This is the weakest entity in the model. If Scholarship Provider later gains operations (e.g., provider verification workflow, provider-managed scholarship portal), it would be promoted. For MVP, it is reference data with identity. |
| 11 | Education Authority | Supporting Entity | (none in StudyNexus — jurisdiction is a VO) | (minimal lifecycle) | **Challenged: No invariants in StudyNexus.** Education Authority is referenced by four entity types (Institution, Programme, Qualification, Admission Cycle) but StudyNexus does not manage authority workflows. **Verdict: Confirmed as supporting entity for MVP.** Same reasoning as Scholarship Provider. The jurisdiction check (INV-I2, INV-P5, INV-10) is performed by the referencing aggregate, not by Education Authority itself. If Trust & Accreditation later develops authority verification workflows, promotion would be justified. |
| 12 | Admission Pathway | Supporting Entity | (none — structural reference) | (minimal lifecycle) | **Challenged: Is Admission Pathway truly justified?** The Resolution Analysis accepted it based on ubiquitous language coverage (A3-8) and cross-country validity. But Admission Pathway has no invariants and no operations in StudyNexus. It exists only to make Admission Rules more expressive (pathway-qualified qualification references). **Verdict: Accepted as supporting entity with reservation.** The value is linguistic clarity, not invariant protection. If Behaviour Discovery shows that pathway-aware rules add no behavioural complexity (i.e., pathways are just labels on rules), Admission Pathway could be demoted to a value object. This is a Behaviour Discovery question, not a Domain Discovery question. |

### Consolidated Entity Register

| # | Entity | Classification | Invariants | Operations | Status |
|---|--------|---------------|:----------:|:----------:|--------|
| 1 | Educational Institution | Aggregate Root | 5 | 7 | Confirmed |
| 2 | Programme | Aggregate Root | 6 | 7 | Confirmed |
| 3 | Scholarship | Aggregate Root | 5 | 8 | Confirmed |
| 4 | Admission Cycle | Aggregate Root | 3 | 3 | Confirmed (reduced scope — not universal) |
| 5 | Information Source | Aggregate Root | 3 | 5 | Confirmed |
| 6 | Admission Policy | Child Entity | 2 | (parent-managed) | Confirmed |
| 7 | Eligibility Policy | Child Entity | 1 | (parent-managed) | Confirmed |
| 8 | Accreditation Record | Child Entity | 2 | (immutable) | Confirmed |
| 9 | Qualification | Supporting Entity | 1 | Minimal | Confirmed |
| 10 | Scholarship Provider | Supporting Entity | 0 | Minimal | Confirmed (weakest) |
| 11 | Education Authority | Supporting Entity | 0 | Minimal | Confirmed (no invariants in StudyNexus) |
| 12 | Admission Pathway | Supporting Entity | 0 | Minimal | Accepted with reservation (Behaviour Discovery may demote) |

---

## 2. Canonical Value Object Register

### Challenge: Are all 27 VOs justified? Should any be promoted to entities or removed?

The Resolution Analysis accepted Admission Mode as a new value object on Programme. Country was rejected as a domain VO and accepted as reference data (ISO wrapper). The current count is 27 VOs: 13 domain-meaningful + 12 enum-like + 2 new (Admission Mode, plus Admission Pathway VO was rejected in favour of entity).

| # | Value Object | Type | Used By | Domain Purpose | Challenge & Verdict |
|---|-------------|------|---------|---------------|---------------------|
| 1 | Admission Rule | Domain-Meaningful | Admission Policy | Atomic admission criterion (qualification + threshold + subjects) | **Confirmed.** Complex structure, domain meaning, equality by value. |
| 2 | Eligibility Rule | Domain-Meaningful | Eligibility Policy | Atomic eligibility criterion (qualification + threshold + condition) | **Confirmed.** Distinct from Admission Rule per DD3-8 — non-qualification criteria (geographic, demographic, financial-need) are unique to eligibility. |
| 3 | Subject Combination | Domain-Meaningful | Admission Rule | Set of required/recommended subjects with combination semantics | **Confirmed.** Groups related concepts with invariant (1 ≤ N ≤ count for Best-N-Of). |
| 4 | Qualification Threshold | Domain-Meaningful | Admission/Eligibility Rule | Minimum requirement on a qualification | **Confirmed.** Replaces Cut-off Mark (DD3-4, F11). Universal concept. |
| 5 | Validity Period | Domain-Meaningful | Accreditation Record, Admission Policy, Eligibility Policy, Scholarship | Time-bounded effectiveness | **Confirmed.** Groups start + end dates. Invariant: start ≤ end. |
| 6 | Trust Signal | Domain-Meaningful | All entities (via provenance) | Computed trust assessment | **Confirmed.** Per A6-8: implementation-neutral. Computed, not stored. |
| 7 | Institution Type | Enum-like | Educational Institution | Classification of institution | **Confirmed.** Values are data per F6. The VO itself has domain meaning (affects jurisdiction). |
| 8 | Award Level | Enum-like | Programme | Classification of programme award | **Confirmed.** Values are data per F7. Affects admission pathways. |
| 9 | Monetary Amount | Domain-Meaningful | Programme (Tuition Fee), Scholarship (Value) | Amount + currency | **Confirmed.** Prevents cross-currency comparison errors. Currency is part of identity. |
| 10 | Duration | Domain-Meaningful | Programme | Study duration (value + unit) | **Confirmed.** Different units (years, semesters, credit hours) across countries. |
| 11 | Location | Domain-Meaningful | Educational Institution | Geographic location | **Challenged: Location is now optional (Resolution Analysis).** If optional, is it still a domain-meaningful VO or a presentation concern? **Verdict: Confirmed as domain VO, optional.** Location affects discoverability (A3-3) and jurisdiction. Institutions without physical location (online-only) are valid. Optionality is a multiplicity change, not a conceptual demotion. |
| 12 | Authority Jurisdiction | Domain-Meaningful | Education Authority | Jurisdiction type + criteria | **Confirmed.** Per F2, F5. Determines what an authority can accredit. Invariant enforcement is real. |
| 13 | Phase Sequence | Domain-Meaningful | Admission Cycle | Ordered list of phases | **Confirmed.** Per F9. Immutable once announced. INV-C2 depends on it. |
| 14 | Accreditation Status | Enum-like | Accreditation Record | Lifecycle classification | **Confirmed.** Values vary by country (data). |
| 15 | Policy Status | Enum-like | Admission/Eligibility Policy | Lifecycle classification | **Confirmed.** |
| 16 | Programme Status | Enum-like | Programme | Lifecycle classification | **Confirmed.** |
| 17 | Scholarship Status | Enum-like | Scholarship | Lifecycle classification | **Confirmed.** |
| 18 | Institution Status | Enum-like | Educational Institution | Lifecycle classification | **Confirmed.** |
| 19 | Source Reliability | Enum-like | Information Source | Lifecycle classification | **Confirmed.** |
| 20 | Information Category | Enum-like | Information Source | Business concept per A3-7 | **Confirmed.** |
| 21 | Authority Type | Enum-like | Education Authority | Classification of authority role | **Challenged: Resolution Analysis made Authority Type a collection, not a single value.** **Verdict: Confirmed as enum-like VO used as a collection.** NUC = {Regulatory, Accrediting}; JAMB = {Coordinating, Examining, Admissions}. The VO itself is unchanged; the multiplicity on Education Authority changed. |
| 22 | Provider Type | Enum-like | Scholarship Provider | Classification of provider | **Confirmed.** |
| 23 | Ownership Type | Enum-like | Educational Institution | Classification of ownership | **Confirmed.** |
| 24 | Delivery Mode | Enum-like | Programme | How programme is delivered | **Confirmed.** |
| 25 | Qualification Status | Enum-like | Qualification | Lifecycle classification | **Confirmed.** |
| 26 | **Admission Mode** | **Enum-like (NEW)** | **Programme** | **Cyclic, Rolling, Multiple-Intake** | **Accepted per Resolution Analysis.** This is the single change that makes Programme valid for all 9 test countries. Without it, the model cannot represent rolling admission (UK, US, Canada, Germany, Australia) or multiple-intake (some Kenyan and South African programmes). **Verdict: Confirmed.** |
| 27 | Coverage Type | Enum-like | Scholarship | How scholarship value is interpreted | **Confirmed.** Full Tuition, Partial Tuition, Stipend, Book Allowance, Mixed. |

### Rejected Value Objects (Confirmed Rejections)

| Rejected VO | Reason Rejected | Challenge to Rejection | Verdict |
|-------------|----------------|----------------------|---------|
| Cut-off Mark | Subsumed by Qualification Threshold (F11) | Nigerian terminology is legitimate | **Rejection confirmed.** Threshold is the universal concept; Cut-off Mark is Nigerian localization. |
| Minimum Score | Subsumed by Qualification Threshold | — | **Rejection confirmed.** |
| Grade | Subsumed by Qualification Threshold's minimum value (String type) | — | **Rejection confirmed.** |
| Institution Name | Temporal tracking required (not value semantics) | — | **Rejection confirmed.** Name changes are business events with history. |
| Programme Name | Not a VO — identity component with rare renaming | — | **Rejection confirmed.** |
| Contact Information | Presentation concern | — | **Rejection confirmed.** |
| Admission Pathway (as VO) | Promoted to supporting entity | Could entity be overkill? | **Entity confirmed.** Pathways have identity and cross-reference from Admission Rules. A VO cannot be referenced from rules. |
| Educational Level | Premature generalization | Would it unify Award Level + Qualification Level? | **Rejection confirmed.** The levels serve different purposes. |
| Currency | Part of Monetary Amount | Should currency be a standalone VO? | **Rejection confirmed.** Currency is a component of Monetary Amount, not independently meaningful. |
| Accreditation Type | Enum-like VO already exists | — | **Rejection confirmed.** Already modelled. |
| Country (as domain VO) | Resolution Analysis: rejected as domain VO, accepted as reference data | Country is type-safe and used in 3+ places | **Rejection confirmed for domain VO.** Country is reference data (ISO 3166-1 alpha-2 wrapper) with no domain behaviour. Used on Education Authority, Scholarship Provider, and Location. Not a domain concept — it's a geographic identifier. |

---

## 3. Relationship Matrix

### Challenge: Are all relationships correct? Any missing relationships? Any spurious relationships?

| From | To | Relationship | Cardinality | Challenge | Verdict |
|------|----|-------------|-------------|-----------|---------|
| Programme | Educational Institution | Belongs to | N:1 | Is this a hard reference or a read-model convenience? | **Hard reference.** INV-P1 requires Programme to belong to exactly one Institution. This is enforced by `introduce()`. |
| Scholarship | Scholarship Provider | Offered by | N:1 | Should Scholarship reference Provider, or Provider reference Scholarships? | **Scholarship references Provider.** INV-S1 (exactly one provider) is Scholarship's invariant. Direction is correct. |
| Admission Policy | Programme or Institution | Governed by | N:1 (polymorphic) | Is the dual parent clean? | **Confirmed.** Polymorphic parent is the Laravel Beyond CRUD solution. A shared "Policy" abstraction with subtypes would be premature generalization. |
| Eligibility Policy | Scholarship | Belongs to | N:1 | — | **Confirmed.** |
| Accreditation Record | Programme or Institution | Accredited by | N:1 (polymorphic) | Same dual-parent question | **Confirmed.** Same pattern as Admission Policy. |
| Accreditation Record | Education Authority | Granted by | N:1 | Could a record have multiple granting authorities? | **Confirmed.** INV-2: exactly one per record. Multiple accreditations = multiple records. |
| Qualification | Education Authority | Defined by | N:1 | Could a qualification be defined by multiple authorities? | **Confirmed.** Per F8: authority-scoped identity. WAEC SSCE is defined by WAEC alone. If another authority defines an equivalent, it is a different Qualification entity. |
| Admission Cycle | Education Authority | Defined by | N:1 | — | **Confirmed.** Per F10: scope emerges from defining authority. |
| Scholarship | Institution | Targets | M:N (optional) | Should targeting be criteria-based? | **Confirmed for MVP.** OQ-R2 from integrity review: criteria-based targeting deferred. Explicit lists are sufficient for Nigerian scholarships. |
| Scholarship | Programme | Targets | M:N (optional) | Same question | **Confirmed for MVP.** |
| Admission Cycle | Institution | Participates | M:N | Is this bidirectional? | **Unidirectional from Cycle to Institution.** Institution does not need to know which cycles it participates in — this is a query concern. Cycle owns the participation list. |
| Admission Cycle | Programme | Participates | M:N | Same question | **Unidirectional from Cycle to Programme.** |
| Admission Rule | Qualification | References | N:1 | — | **Confirmed.** |
| Admission Rule | Admission Pathway | Qualified by | N:1 (optional) | **NEW relationship** | **Accepted.** Admission Rules can be pathway-qualified: "ND/HND holders may enter at 200-level" is a Direct Entry pathway rule. |
| Education Authority | Qualification | Defines | 1:N | — | **Confirmed.** |

### Missing Relationships Identified

| Missing Relationship | Severity | Action |
|---------------------|:--------:|--------|
| Admission Rule → Admission Pathway (optional) | **High** | **Added.** This is the relationship that makes Admission Pathway useful. Without it, pathways are orphaned reference data. |
| Programme → Admission Mode (VO) | **High** | **Added.** This is how the model distinguishes cyclic from rolling admission. |
| Institution → Country (reference data) | **Medium** | **Already present via Location VO.** Country is a component of Location. No separate relationship needed. |

---

## 4. Aggregate Boundary Audit

### Challenge: Is every aggregate boundary justified by invariants, not by identity, searchability, or lifecycle?

This section applies the Laravel Beyond CRUD test rigorously to every aggregate root.

#### Educational Institution

| Test | Result | Evidence |
|------|--------|----------|
| What invariants does it protect? | 5 invariants (INV-I1 through INV-I5) | Type validity, accreditation jurisdiction, one active policy per cycle, always has a name, closed = no operations |
| What business operations does it perform? | 7 operations | establish, rename, publishAdmissionPolicy, recordAccreditation, suspend, close, mergeWith |
| What consistency boundary does it define? | Institutional-level admission policies and accreditation records must be consistent with the institution's type and status | Publishing a policy must supersede the previous; recording accreditation must check jurisdiction |
| Is it anemic? | No | Rich operations, enforced invariants, domain events (name changes) |
| **Verdict** | **Boundary justified by invariants** | |

#### Programme

| Test | Result | Evidence |
|------|--------|----------|
| What invariants does it protect? | 6 invariants (INV-P1 through INV-P6) | Single institution, one active policy per cycle, admission status derivation, valid award level, accreditation jurisdiction, discontinued = no operations |
| What business operations does it perform? | 7 operations | introduce, publishAdmissionPolicy, suspendAdmission, resumeAdmission, discontinue, recordAccreditation, isAdmitting |
| What consistency boundary does it define? | Programme-level admission policies and accreditation records must be consistent with programme's institution, award level, and status | Same pattern as Institution but at programme level |
| Is it anemic? | No | |
| **Verdict** | **Boundary justified by invariants** | |

#### Scholarship

| Test | Result | Evidence |
|------|--------|----------|
| What invariants does it protect? | 5 invariants (INV-S1 through INV-S5) | Exactly one provider, one active eligibility policy per period, application state machine, cannot open without published policy |
| What business operations does it perform? | 8 operations | announce, publishEligibilityPolicy, openApplications, closeApplications, withdraw, targetProgrammes, targetInstitutions, isApplicableTo |
| What consistency boundary does it define? | Eligibility policies, application state, and targeting must be consistent | INV-S5 is the strongest: you cannot open applications without a published policy — this must be atomic |
| Is it anemic? | No | |
| **Verdict** | **Boundary justified by invariants** | |

#### Admission Cycle

| Test | Result | Evidence |
|------|--------|----------|
| What invariants does it protect? | 3 invariants (INV-C1 through INV-C3) | Defined dates, sequential phase transitions, time-bounded |
| What business operations does it perform? | 3 operations | announce, advancePhase, isAdmissionOpen |
| What consistency boundary does it define? | Phase sequence must be followed — no skipping, no backwards | INV-C2 is the core: advancing a phase must be sequential |
| Is it anemic? | Borderline — operations are simple but the invariant is real | |
| **Verdict** | **Boundary justified, but with reduced scope.** Admission Cycle is not a universal axis — it applies only to programmes with Admission Mode = Cyclic. For Rolling and Multiple-Intake modes, the cycle is optional. This does not invalidate the boundary; it limits its applicability. | |

#### Information Source

| Test | Result | Evidence |
|------|--------|----------|
| What invariants does it protect? | 3 invariants (INV-IS1 through INV-IS3) | Cannot be simultaneously verified and unreliable, deprecated cannot be verified, every source has a retrievable reference |
| What business operations does it perform? | 5 operations | register, verify, markUnreliable, deprecate, isReliable |
| What consistency boundary does it define? | Reliability status must be consistent; verification/unreliable are mutually exclusive | INV-IS1 has cascading trust consequences across all entities referencing this source |
| Is it anemic? | No | |
| **Verdict** | **Boundary justified by invariants** | |

#### Aggregate Boundary Audit Summary

| Aggregate Root | Invariants | Operations | Boundary Justified? | Scope Note |
|---------------|:----------:|:----------:|:-------------------:|------------|
| Educational Institution | 5 | 7 | Yes | — |
| Programme | 6 | 7 | Yes | — |
| Scholarship | 5 | 8 | Yes | — |
| Admission Cycle | 3 | 3 | Yes | Reduced scope — cyclic admission only |
| Information Source | 3 | 5 | Yes | — |

**No aggregate boundaries require re-drawing.** All five are justified by real business invariants, not by identity or searchability. The only adjustment is Admission Cycle's reduced scope, which is a semantic clarification, not a structural change.

---

## 5. Domain Behaviour Preview

### Challenge: What behaviours does the domain model need to support? Are any behaviours impossible with the current model?

This section previews the domain behaviours that Behaviour Discovery will formalize, to check whether the current model can support them. This is not Behaviour Discovery — it is a structural feasibility check.

| Behaviour | Required By | Can Current Model Support It? | Gap |
|-----------|------------|:-----------------------------:|-----|
| Publish admission requirements for a programme for a cycle | A6-5, A6-7 | Yes | Programme.publishAdmissionPolicy(cycle, rules) |
| Publish admission requirements for an institution for a cycle | A6-5, A6-7 | Yes | Institution.publishAdmissionPolicy(cycle, rules) |
| Publish eligibility criteria for a scholarship | A6-7 | Yes | Scholarship.publishEligibilityPolicy(period, rules) |
| Determine if a programme is currently admitting | A6-7 | Yes | Programme.isAdmitting(cycle) — derived |
| Assess eligibility of a candidate against a programme's requirements | A6-7 | Yes (structurally) | Admission Rules contain qualifications + thresholds; Eligibility assessment is a Behaviour Discovery concern, but the model has the data to support it |
| Assess eligibility for a scholarship | A6-7 | Yes (structurally) | Same reasoning |
| Record an accreditation event | A3-2, A6-8 | Yes | Programme/Institution.recordAccreditation(authority, status, period) |
| Track admission cycle phase progression | A1-3 | Yes | Admission Cycle.advancePhase() |
| Compute trust signals for information | A6-8 | Yes | Trust Signal VO is computed from provenance + source state |
| Handle rolling admission (no cycle) | Global expansion | **Yes (post-resolution)** | Programme.AdmissionMode = Rolling. No Admission Cycle required. |
| Handle multiple intake periods per year | Global expansion | **Yes (post-resolution)** | Programme.AdmissionMode = Multiple-Intake. Multiple Admission Cycles per year, or cycle-independent. |
| Determine applicable admission pathway for a set of qualifications | A3-8 | **Yes (post-resolution)** | Admission Pathway entity + Admission Rule → Admission Pathway relationship |
| Compare programmes across institutions | A3-4 | Yes (structurally) | Comparable attributes: tuition, accreditation status, admission requirements, duration, delivery mode |
| Track information provenance | A2-7, A4-5 | Yes | Source Reference on policies, accreditation records, and via Information Source |
| Rename an institution (evolving identity) | DD2-5 | Yes | Institution.rename(newName, effectiveDate) — records in Name History |
| Deprecate a qualification | INV-9 | Yes | Qualification.Status = Deprecated. Cascading effect: Admission Rules referencing deprecated qualifications should flag warnings (Behaviour Discovery concern). |

### Behaviours That Are NOT Supported (and should not be)

| Behaviour | Why Not Supported | Correct? |
|-----------|------------------|:--------:|
| Apply for a scholarship | Application is a user action, not a domain operation on the Scholarship entity. StudyNexus is a discovery/decision-support platform, not an application platform (A0-3). | Yes |
| Apply for admission | Same reasoning. | Yes |
| Compare costs across currencies | Monetary Amount does not support conversion (A-D3-6). Cross-currency comparison is a product/presentation concern. | Yes |
| Verify an Education Authority's credentials | Education Authority has no invariants in StudyNexus. Verification is a Trust & Accreditation bounded context concern, not an Opportunity Discovery operation. Deferred to Stage 2. | Yes |

**Verdict: The current model can structurally support all required behaviours for Behaviour Discovery.** No behaviours are impossible. The model correctly excludes application workflows (out of scope) and cross-currency comparison (presentation concern).

---

## 6. Temporal Model Audit

### Challenge: Is temporal modelling correct? Are there entities that should be event-sourced but aren't? Are there time-bounded concepts that lack Validity Period?

#### Entities with Temporal Behaviour

| Entity | Temporal Pattern | Is It Correctly Modelled? | Challenge |
|--------|-----------------|:------------------------:|-----------|
| Educational Institution | Evolving identity (name changes tracked) | Yes | Name History is append-only. Each name change is a business event. Identity is the continuing legal entity, not the current name. **Confirmed.** |
| Programme | Mostly stable with lifecycle | Yes | Tuition fee changes are domain events (DD2-5) but historical tuition is deferred (OQ-D3-2). Current tuition is a single Monetary Amount. **Confirmed for MVP.** Historical tuition tracking can be added without structural change (collection of Tuition Records). |
| Scholarship | Period-scoped identity | Yes | Each period creates a distinct Scholarship entity. The same name may recur annually with different terms. **Confirmed.** |
| Admission Cycle | Time-bounded lifecycle with ordered phases | Yes | INV-C1 (defined dates), INV-C2 (sequential phases), INV-C3 (time-bounded). Phase Sequence is immutable. **Confirmed.** |
| Admission Policy | Versioned by supersession | Yes | Policies are superseded, not modified. Each new policy for a cycle is a new entity. Superseding Policy reference creates a chain. **Confirmed.** |
| Eligibility Policy | Versioned by supersession | Yes | Same pattern as Admission Policy. **Confirmed.** |
| Accreditation Record | Immutable historical fact | Yes | Each accreditation event creates a new record. Current status is derived from the most recent record. **Confirmed.** |
| Information Source | Lifecycle with verification tracking | Yes | Last Verified Date tracks currency. Reliability transitions are business decisions. **Confirmed.** |

#### Time-Bounded Concepts and Their Validity Periods

| Concept | Has Validity Period? | Correct? |
|---------|:-------------------:|:--------:|
| Admission Policy | Yes (Effective Period) | Yes |
| Eligibility Policy | Yes (Applicable Period) | Yes |
| Accreditation Record | Yes (Effective Period) | Yes |
| Scholarship | Yes (Application Period) | Yes |
| Admission Cycle | Yes (Start Date + End Date) | Yes |
| Trust Signal | No — computed at query time | Yes (Trust Signal is ephemeral — it changes when source state changes) |

#### Temporal Gaps Identified

| Gap | Severity | Action |
|-----|:--------:|--------|
| Programme tuition history not tracked | **Low** | Deferred to OQ-D3-2. Can be added as a collection of Tuition Records without structural change. Not required for MVP. |
| Admission Cycle phase history not tracked | **Low** | Phase transitions are sequential and the current phase index is stored. Full transition history would require event sourcing or a Phase Transition log. Not required for MVP — the current phase index is sufficient for all business queries. |
| Scholarship application deadline vs. application period | **Resolved** | DD3-11 added Application Deadline as a separate attribute. The period covers the full offering timeline; the deadline is the application cutoff. **No gap.** |

**Verdict: Temporal modelling is correct.** All time-bounded concepts have validity periods. Historical tracking is appropriately scoped (immutable records for accreditation, append-only for name history, supersession chains for policies). No entities require event sourcing for MVP.

---

## 7. Global Expansion Test

### Challenge: Does the model work in all 9 test countries without structural changes?

Test countries: Nigeria, Ghana, Kenya, South Africa, United Kingdom, United States, Germany, Canada, Australia

| Country | Key Structural Differences from Nigeria | Model Works? | Changes Required |
|---------|---------------------------------------|:------------:|-----------------|
| **Nigeria** | Baseline | Yes | None |
| **Ghana** | Single accreditor (GTEC) for all tertiary; no separate bodies per type | Yes | Reference data: add GTEC, Ghanaian institution types, Ghanaian qualifications (WASSCE), Ghanaian award levels. Jurisdiction data: GTEC has jurisdiction over all tertiary types. |
| **Kenya** | KUCCPS as centralized placement; KCSE as primary qualification | Yes | Reference data: add KUCCPS, KCSE, Kenyan institution types. KUCCPS defines a national cycle (Cyclic admission mode). |
| **South Africa** | Multiple qualification frameworks (NQF); SETAs as accrediting bodies | Yes | Reference data: add SAQA, NQF levels, SETAs. Admission varies by institution (some cyclic, some rolling — Admission Mode VO handles this). |
| **United Kingdom** | UCAS centralized application (not a national admission cycle); A-Levels; rolling offers; tariff points | **Yes (post-resolution)** | Admission Mode = Rolling for most programmes. UCAS is an Education Authority (Admissions type). UCAS defines a cycle-like process (Application → Offer → Reply → Confirmation) — this can be modelled as an Admission Cycle with UK-specific phases (F9). Reference data: add UCAS, QAA, OfS, A-Levels, UCAS tariff. |
| **United States** | No national admission cycle; regional accreditors; SAT/ACT; rolling admission | **Yes (post-resolution)** | Admission Mode = Rolling for most programmes. No national Admission Cycle. Regional accreditors (HLC, MSCHE, etc.) with geographic jurisdiction. Reference data: add regional accreditors, SAT, ACT, AP, US institution types, US award levels. |
| **Germany** | Numerus clausus (restricted programmes); diverse qualification paths (Abitur, Fachhochschulreife); semester-based intake | **Yes (post-resolution)** | Admission Mode = Cyclic for most (winter/summer semester). Some programmes have Numerus clausus (restrictive admission rules). Reference data: add German qualifications, German institution types (Universität, Fachhochschule). |
| **Canada** | Provincial education authorities; no national cycle; diverse qualifications by province | **Yes (post-resolution)** | Admission Mode = Rolling or Cyclic depending on programme. Provincial authorities (e.g., OUAC in Ontario). Reference data: add provincial authorities, Canadian qualifications. |
| **Australia** | ATAR ranking; state-level admission centres (VTAC, UAC, QTAC); semester-based | **Yes (post-resolution)** | Admission Mode = Cyclic (semester intake). State centres define cycles. Reference data: add ATAR, state centres, Australian institution types. |

### Structural Changes Required for Global Expansion

| Change | Type | Already Applied? |
|--------|------|:----------------:|
| Admission Mode VO on Programme | Value Object addition | **Yes** (Resolution Analysis) |
| Configurable Admission Cycle phases | Data, not structure | **Yes** (F9) |
| Jurisdiction-based accreditation invariants | Invariant rewording | **Yes** (F2, F5) |
| Authority-scoped qualification identity | Identity rewording | **Yes** (F8) |
| Country-varying values as reference data | Explicit classification | **Yes** (F6, F7) |
| Location optional on Institution | Multiplicity change | **Yes** (Resolution Analysis) |
| Admission Pathway as supporting entity | Entity addition | **Yes** (Resolution Analysis) |

**Total structural changes for 9-country expansion: 0.** All changes are reference data additions or value object additions that were already accepted in the Resolution Analysis. The domain model is globally valid.

---

## 8. Future Expansion Pressure Test

### Challenge: What happens when StudyNexus expands beyond its current scope?

#### 8.1 Study Abroad (Cross-Country Opportunity Discovery)

| Pressure Point | Current Model Handles It? | Gap | Change Required |
|---------------|:------------------------:|-----|-----------------|
| Student in Country A seeking opportunities in Country B | Yes — Programme and Institution are country-agnostic | Need to surface country as a primary search dimension | **Product/presentation change.** Country is already part of Location VO. |
| Cross-country qualification recognition | Partially — Qualification has Recognition Scope | No equivalence mapping between qualifications across countries | **Possible future entity: Qualification Equivalence** (e.g., "WAEC SSCE ≈ UK GCSE"). This is not needed for MVP — equivalence is advisory, not authoritative. |
| Visa/immigration requirements | No | Not in current model | **Correctly excluded.** Visa requirements are not educational domain concepts. They are external constraints on educational decisions. If needed later, they would be a separate bounded context. |

#### 8.2 Scholarships (Deep Feature Expansion)

| Pressure Point | Current Model Handles It? | Gap | Change Required |
|---------------|:------------------------:|-----|-----------------|
| Fellowship, Grant, Bursary subtypes | Yes — Scholarship entity is generic | Scholarship Type VO could distinguish them | **VO addition.** No structural change. The current model correctly avoids premature subtyping. |
| Criteria-based scholarship targeting | Partially — only explicit lists | OQ-R2 identified this gap | **Behaviour Discovery question.** Criteria-based targeting (by discipline, by location, by ownership type) is a query/filter concern, not a structural change. The Scholarship entity could gain a Targeting Criteria VO alongside explicit lists. |
| Scholarship application tracking | No — correctly excluded (application is out of scope per A0-3) | — | **No change.** StudyNexus is a discovery platform, not an application platform. |

#### 8.3 Non-Tertiary Education

| Pressure Point | Current Model Handles It? | Gap | Change Required |
|---------------|:------------------------:|-----|-----------------|
| Secondary schools as Educational Institutions | Partially — Institution Type VO can hold "Secondary School" | Tertiary-only assumption (HA-1) is implicit | **Resolution Analysis made it explicit.** The model works structurally — add secondary school types as reference data. The invariant "award level is valid for institution type" (INV-P4) would need new valid combinations. |
| Vocational/trade programmes | Same as above | — | **Same approach.** Add vocational institution types and award levels as reference data. |
| Primary education | Same as above | — | **Same approach, but unlikely in any near-term stage.** |

**Key insight:** The tertiary-only assumption is not a structural constraint — it is a data scoping decision. The domain model is education-level-agnostic. The assumption simply says "MVP data will be tertiary only." This is correct and does not require model changes for expansion.

#### 8.4 International Qualifications

| Pressure Point | Current Model Handles It? | Gap | Change Required |
|---------------|:------------------------:|-----|-----------------|
| IB Diploma, IGCSE as qualifications | Yes — Qualification entity with Defining Authority = IBO (international authority) | IBO is not a government agency — but Education Authority already covers non-governmental bodies (F1) | **No change.** IBO is an Education Authority with Authority Type = Standard-Setting, Is Governmental = false. |
| Qualification equivalence for cross-country comparison | No — as noted in 8.1 | Qualification Equivalence entity | **Deferred.** Advisory, not authoritative. |

#### 8.5 Services (Counselling, Application Assistance, Test Prep)

| Pressure Point | Current Model Handles It? | Gap | Change Required |
|---------------|:------------------------:|-----|-----------------|
| Educational services as discoverable opportunities | No — current model only covers programmes and scholarships | Services are a fundamentally different opportunity type | **Major expansion.** Would require a new aggregate root (Educational Service) with its own attributes, lifecycle, and invariants. This is a Stage 3+ concern and correctly out of scope for current discovery. |

### Future Expansion Pressure Test Summary

| Expansion | Structural Changes Required | Severity | When |
|-----------|:--------------------------:|:--------:|------|
| Study Abroad | 0 (reference data + possible Qualification Equivalence entity) | Low | Stage 2+ |
| Scholarships (deep) | 0–1 (Targeting Criteria VO) | Low | Stage 2+ |
| Non-Tertiary | 0 (reference data + explicit assumption removal) | Low | Stage 2+ |
| International Qualifications | 0–1 (Qualification Equivalence entity) | Low | Stage 2+ |
| Services | 1+ (Educational Service aggregate root) | **High** | Stage 3+ |

**The model is resilient to all near-term expansion pressures.** The only high-severity gap (Educational Services) is correctly deferred — it requires a fundamentally new aggregate root, which is a Stage 3+ concern.

---

## 9. Educational Opportunity Re-evaluation

### Challenge: Is "Educational Opportunity" a domain concept that needs explicit representation?

**Current state:** "Educational Opportunity" is a ubiquitous language term (A0-3: "discover educational opportunities") with no corresponding domain entity. Programme and Scholarship are the concrete opportunities. The Integrity Review identified this as a ubiquitous language gap (W2, OQ-R3).

**Challenge arguments FOR an Educational Opportunity entity:**
1. The platform's core mission (A0-3) uses this term as the primary concept
2. A common abstraction would enable unified search, comparison, and recommendation across programmes and scholarships
3. Users think in terms of "opportunities" — showing programmes and scholarships in separate silos may fragment the discovery experience
4. A unified "opportunity" concept could support future expansion (services, exchange programmes, internships) without requiring new search/comparison infrastructure per type

**Challenge arguments AGAINST an Educational Opportunity entity:**
1. Programme and Scholarship have fundamentally different structures, invariants, and lifecycles — a shared abstraction would be anemic or require premature generalization
2. Laravel Beyond CRUD: aggregate roots protect invariants — what invariant would "Educational Opportunity" protect? None. It would be a categorization abstraction, not a consistency boundary.
3. The model already supports unified discovery via read models and projections — search across programmes and scholarships is a product/query concern, not a domain concern
4. Adding an abstraction now, before Behaviour Discovery confirms the need, violates "Avoid Premature Generalization"

**Resolution:**

The Integrity Review correctly identified this as a **ubiquitous language gap, not a structural gap**. The term "Educational Opportunity" is how users and stakeholders talk about what StudyNexus provides. It is a **facade concept** — a unified interface to multiple concrete aggregates.

**Decision:** "Educational Opportunity" is acknowledged as a ubiquitous language term with no corresponding domain entity. It will be represented as:
- A **read model / projection** in the application layer (unified search across programmes and scholarships)
- A **category concept** in the presentation layer (filtering, comparison, recommendation)
- **Not** a domain entity, aggregate root, or value object

This is the Laravel Beyond CRUD solution: the domain model represents concrete business concepts (Programme, Scholarship); the application layer composes them into user-facing concepts (Educational Opportunity).

---

## 10. Policy Re-evaluation

### Challenge: Should Admission Policy and Eligibility Policy remain separate? Is the separation justified?

**Current state:** Admission Policy (child of Programme/Institution) and Eligibility Policy (child of Scholarship) are separate child entity types with similar but distinct structures. DD3-8 explicitly decided they should remain separate.

**Challenge arguments FOR merging:**
1. Both have nearly identical lifecycle: Draft → Published → Active → Superseded → Retired
2. Both contain collections of rules (Admission Rules vs. Eligibility Rules)
3. Both enforce "one active per scope" invariant
4. A shared "Policy" base type would reduce code duplication
5. The structural similarity is striking — Admission Policy has Admission Rules; Eligibility Policy has Eligibility Rules; both have Effective Period, Superseding Policy, Source Reference

**Challenge arguments AGAINST merging (affirming current decision):**
1. **Admission Rules and Eligibility Rules have fundamentally different structures.** Admission Rules are qualification-centric (qualification + threshold + subjects). Eligibility Rules include non-qualification criteria (geographic, demographic, financial-need, academic performance). Sharing a "Rule" abstraction would be premature generalization that loses the distinction.
2. **The parent types are different.** Admission Policy governs admission to a Programme/Institution for an Admission Cycle. Eligibility Policy governs eligibility for a Scholarship for a period. The scope, lifecycle triggers, and business meaning are different.
3. **The invariants are different.** Admission Policy enforces INV-P2 (one active per cycle) and INV-I3 (one active per cycle at institutional level). Eligibility Policy enforces INV-S2 (one active per period) and the stronger INV-S5 (cannot open applications without published policy).
4. **Laravel Beyond CRUD: share behaviour by composition, not inheritance.** If code duplication is a concern, extract shared lifecycle logic into a trait/module/event-sourced projection. Do not share by abstraction.
5. **Historical precedent:** In the Laravel Beyond CRUD philosophy, entities that happen to share lifecycle patterns but serve different business purposes should remain separate. The shared pattern is coincidental, not conceptual.

**Resolution: Admission Policy and Eligibility Policy remain separate.** The separation is justified by:
- Different rule structures (qualification-centric vs. condition-diverse)
- Different parent types and scopes
- Different invariants (especially INV-S5)
- Different business meaning (admission requirements vs. eligibility criteria)

The shared lifecycle (Draft → Published → Active → Superseded → Retired) is a **coincidental pattern**, not a conceptual identity. In implementation, this can be extracted into a shared trait/module without domain-level abstraction.

**Required action:** Document the separation rationale explicitly (RC-1 from Integrity Review). Future developers must not "fix" the structural similarity by introducing a shared Policy abstraction.

---

## 11. Information & Provenance Audit

### Challenge: Is the provenance model complete? Are there information flows that cannot be represented?

#### Current Provenance Model

| Entity | Provenance Mechanism | Correct? |
|--------|---------------------|:--------:|
| Admission Policy | Source Reference → Information Source | Yes |
| Eligibility Policy | Source Reference → Information Source | Yes |
| Accreditation Record | Source Reference → Information Source | Yes |
| Educational Institution | (none explicit) | **Gap** — see below |
| Programme | (none explicit) | **Gap** — see below |
| Scholarship | (none explicit) | **Gap** — see below |
| Admission Cycle | (none explicit) | **Gap** — see below |

#### Identified Gaps

**Gap: Aggregate roots (Institution, Programme, Scholarship, Admission Cycle) lack explicit provenance tracking.**

Currently, only child entities (policies and accreditation records) carry Source References. The aggregate roots themselves do not record where their information came from. This means:
- When an institution's operational status is updated, there is no record of who reported it or from what source
- When a programme's tuition fee changes, there is no provenance for the change
- When a scholarship's targeting is set, there is no provenance

**Challenge: Is this a real gap or an acceptable MVP simplification?**

In the current model, provenance is tracked at the **information unit** level (policies, accreditation records) — the most granular level where trust matters most. Aggregate-level attributes (name, status, tuition) are typically sourced from the institution's official website or authoritative announcements, which is implicit in the Information Source registry.

**Resolution:** This is an **acceptable MVP simplification**. Adding Source Reference to every mutable attribute on every aggregate root would significantly increase model complexity for marginal trust benefit. The pragmatic approach is:
1. Trust assessment at the entity level is based on the entity's accreditation status (from Accreditation Records, which have provenance) and the institution's official website (from Information Source registry)
2. Attribute-level provenance can be added later as a **Provenance Log** (separate aggregate) if Behaviour Discovery shows it is needed
3. The current model supports the core trust workflow: verify sources → compute trust signals → inform decisions

**However**, the model should be **extensible** to attribute-level provenance without structural redesign. The current model supports this — a Provenance Log aggregate can reference any entity + attribute combination.

#### Information Source Lifecycle Audit

| Transition | Invariant Enforced | Cascading Effect | Correct? |
|-----------|-------------------|-----------------|:--------:|
| Discovered → Verified | INV-IS1 (cannot be verified and unreliable simultaneously) | All information from this source gains higher trust | Yes |
| Verified → Unreliable | INV-IS1 | All information from this source loses trust; trust signals re-computed | Yes |
| Any → Deprecated | INV-IS2 (deprecated cannot be verified) | Source removed from trust calculations | Yes |
| Unreliable → Verified | INV-IS1 | Source regains trust; information re-assessed | Yes |

**Verdict: Provenance model is sufficient for MVP with known, acceptable gap on aggregate-level provenance.** The gap is extensible without structural change.

---

## 12. Laravel Beyond CRUD Architectural Fit

### Challenge: Does the domain model align with Laravel Beyond CRUD's pragmatic DDD philosophy, or does it carry classical DDD baggage?

#### Test 1: Are aggregates protecting invariants or just organizing data?

| Aggregate | Protects Invariants? | Organizes Data? | LBC Verdict |
|-----------|:-------------------:|:----------------:|:-----------:|
| Educational Institution | Yes (5 invariants) | Yes (policies + accreditation) | ✅ Correct — invariant protection is primary |
| Programme | Yes (6 invariants) | Yes (policies + accreditation) | ✅ Correct |
| Scholarship | Yes (5 invariants) | Yes (eligibility policies) | ✅ Correct |
| Admission Cycle | Yes (3 invariants) | Yes (participating entities) | ✅ Correct |
| Information Source | Yes (3 invariants) | No | ✅ Correct |

**No aggregates exist solely for data organization.** All five protect real business invariants.

#### Test 2: Are supporting entities justified, or are they classical DDD aggregate roots that were demoted without reason?

| Supporting Entity | Why Not Aggregate Root | LBC-Justified? |
|-------------------|----------------------|:--------------:|
| Qualification | No invariants to protect in StudyNexus; referenced, not managed | ✅ Yes — an aggregate root with no operations would be anemic |
| Scholarship Provider | No invariants; purely structural reference | ✅ Yes — weakest entity, but still needed for INV-S1 normalization |
| Education Authority | No invariants in StudyNexus; referenced by 4 entity types | ✅ Yes — if Trust & Accreditation later needs authority management, promotion is straightforward |
| Admission Pathway | No invariants; linguistic/reference clarity | ✅ Yes (with reservation) — if Behaviour Discovery shows pathways add no behavioural complexity, demote to VO |

#### Test 3: Are value objects preferred over unnecessary entities?

| Concept | Modelled As | LBC-Correct? |
|---------|------------|:------------:|
| Admission Rule | Value Object | ✅ Yes — defined by attributes, compared by value for eligibility |
| Eligibility Rule | Value Object | ✅ Yes — same reasoning |
| Subject Combination | Value Object | ✅ Yes — defined by contents |
| Qualification Threshold | Value Object | ✅ Yes — defined by attributes |
| Authority Jurisdiction | Value Object | ✅ Yes — defined by type + criteria, no independent lifecycle |
| Phase Sequence | Value Object | ✅ Yes — immutable, defined by contents |
| Monetary Amount | Value Object | ✅ Yes — amount + currency, equality by value |
| Admission Mode | Value Object (enum-like) | ✅ Yes — simple classification |
| Trust Signal | Value Object (computed) | ✅ Yes — never stored, computed at query time |

#### Test 4: Are there anemic aggregates?

| Aggregate | Has Behaviour? | Anemic? |
|-----------|:-------------:|:-------:|
| Educational Institution | 7 operations | No |
| Programme | 7 operations | No |
| Scholarship | 8 operations | No |
| Admission Cycle | 3 operations | Borderline — but phase invariant is real |
| Information Source | 5 operations | No |

**Admission Cycle is borderline** — its operations are simple (announce, advancePhase, isAdmissionOpen). However, INV-C2 (sequential phase transitions) is a genuine business invariant that requires enforcement. A simpler model (just dates + phase enum) would not protect this invariant. **Verdict: Not anemic — the invariant justifies the aggregate.**

#### Test 5: Is the model free of persistence concerns?

**Review of all entity attributes and value objects:** No attribute references Eloquent, migrations, database columns, API resources, or repository patterns. All classifications are domain-level (identity, mutable, value object, derived, country-varying, ubiquitous language). ✅

#### Test 6: Are derived attributes never stored?

| Derived Attribute | Stored? | Derived From | Verdict |
|------------------|:-------:|-------------|---------|
| Current Accreditation Status | No | Most recent Accreditation Record | ✅ |
| Admission Status | No | Programme lifecycle ∧ Cycle phase | ✅ |
| Is Applicable To Programme | No | Scholarship targeting rules | ✅ |
| Is Admission Open | No | Current phase index + Phase Sequence | ✅ |
| Is Reliable | No | Reliability status | ✅ |
| Trust Signal | No | Source state + provenance | ✅ |

**All derived attributes are computed, never stored.** ✅

#### Laravel Beyond CRUD Fit Summary

| Test | Result |
|------|--------|
| Aggregates protect invariants, not just organize data | ✅ Pass |
| Supporting entities justified (no anemic aggregate roots) | ✅ Pass |
| Value objects preferred over unnecessary entities | ✅ Pass |
| No anemic aggregates | ✅ Pass (Admission Cycle borderline but justified) |
| Free of persistence concerns | ✅ Pass |
| Derived attributes never stored | ✅ Pass |
| **Overall LBC Fit** | **✅ Excellent** |

---

## 13. Final Domain Model

### Aggregate Roots (5)

| # | Entity | Identity | Invariants | Key Operations |
|---|--------|----------|:----------:|---------------|
| 1 | Educational Institution | Official Name + Institution Type + Registration Identifier | 5 | establish, rename, publishAdmissionPolicy, recordAccreditation, suspend, close, mergeWith |
| 2 | Programme | Programme Name + Owning Institution + Award Level | 6 | introduce, publishAdmissionPolicy, suspendAdmission, resumeAdmission, discontinue, recordAccreditation, isAdmitting |
| 3 | Scholarship | Scholarship Name + Offering Provider + Application Period | 5 | announce, publishEligibilityPolicy, openApplications, closeApplications, withdraw, targetProgrammes, targetInstitutions, isApplicableTo |
| 4 | Admission Cycle | Period/Year + Defining Authority | 3 | announce, advancePhase, isAdmissionOpen |
| 5 | Information Source | Source Name + Source Type + Retrievable Reference | 3 | register, verify, markUnreliable, deprecate, isReliable |

### Child Entities (3)

| # | Entity | Parent | Identity |
|---|--------|--------|----------|
| 1 | Admission Policy | Programme or Institution | Governed Entity + Applicable Admission Cycle |
| 2 | Eligibility Policy | Scholarship | Owning Scholarship + Applicable Period |
| 3 | Accreditation Record | Programme or Institution | Accredited Entity + Granting Authority + Effective Period Start |

### Supporting Entities (4)

| # | Entity | Identity | Referenced By |
|---|--------|----------|---------------|
| 1 | Qualification | Qualification Name + Defining Authority | Admission Rules, Eligibility Rules, Qualification Thresholds |
| 2 | Scholarship Provider | Official Name | Scholarships |
| 3 | Education Authority | Abbreviation or Official Name | Accreditation Records, Qualifications, Admission Cycles |
| 4 | Admission Pathway | Pathway Name + Defining Authority | Admission Rules (pathway-qualified) |

### Value Objects (27)

#### Domain-Meaningful (14)

| # | Value Object | Contained Values | Used By |
|---|-------------|-----------------|---------|
| 1 | Admission Rule | qualification, threshold, subject combination, rule type, description | Admission Policy |
| 2 | Eligibility Rule | qualification, threshold, condition type, condition text, rule type | Eligibility Policy |
| 3 | Subject Combination | subjects (set), combination type | Admission Rule |
| 4 | Qualification Threshold | qualification ref, minimum value, comparator, scale | Admission Rule, Eligibility Rule |
| 5 | Validity Period | start date, end date | Accreditation Record, Admission Policy, Eligibility Policy, Scholarship |
| 6 | Trust Signal | provenance ref, verification status, last verified date, source reliability, information category | All entities (computed) |
| 7 | Monetary Amount | amount, currency | Programme (Tuition Fee), Scholarship (Value) |
| 8 | Duration | value, unit | Programme |
| 9 | Location | country, region, city, address | Educational Institution (optional) |
| 10 | Authority Jurisdiction | jurisdiction type, jurisdiction criteria | Education Authority |
| 11 | Phase Sequence | ordered list of phases | Admission Cycle |
| 12 | Institution Type | (enum values are data) | Educational Institution |
| 13 | Award Level | (enum values are data) | Programme |
| 14 | Admission Mode | Cyclic, Rolling, Multiple-Intake | Programme |

#### Enum-like (13)

| # | Value Object | Possible Values (examples; values are data) |
|---|-------------|---------------------------------------------|
| 1 | Accreditation Status | Granted, Interim, Partial, Renewed, Suspended, Revoked, Expired |
| 2 | Policy Status | Draft, Published, Active, Superseded, Retired |
| 3 | Programme Status | Introduced, Admitting, Suspended, Discontinued |
| 4 | Scholarship Status | Announced, Open, Closed, Expired, Withdrawn |
| 5 | Institution Status | Established, Operational, Suspended, Closed |
| 6 | Source Reliability | Discovered, Verified, Unreliable, Deprecated |
| 7 | Information Category | Official, Verified, Historical, Community-Contributed |
| 8 | Authority Type | Regulatory, Accrediting, Examining, Coordinating, Standard-Setting, Admissions (used as collection) |
| 9 | Provider Type | Government, NGO, Corporate, Foundation, Educational Institution, Professional Body, International Organization |
| 10 | Ownership Type | Public, Private, Public-Private, Faith-Based, Military |
| 11 | Delivery Mode | Full-Time, Part-Time, Distance, Blended, Online |
| 12 | Qualification Status | Recognized, Deprecated, Replaced |
| 13 | Coverage Type | Full Tuition, Partial Tuition, Stipend, Book Allowance, Mixed |

### Bounded Contexts

| Context | Entities | Purpose |
|---------|----------|---------|
| **Opportunity Discovery** | Educational Institution, Programme, Scholarship, Admission Cycle, Admission Policy, Eligibility Policy, Admission Pathway, Qualification | Core context — discovering and comparing educational opportunities |
| **Trust & Accreditation** | Information Source, Accreditation Record, Education Authority | Trust verification, provenance, and accreditation assessment |
| **Reference Framework** (Shared Kernel) | Qualification, Scholarship Provider, Education Authority, Institution Type, Award Level, Authority Type, all enum-like VOs, Country (reference data) | Shared reference data and type system used by both contexts |

### Key Invariants (Consolidated)

| ID | Invariant | Protected By |
|----|-----------|-------------|
| INV-I1 | An Institution has a valid type within its regulatory framework. | Institution.establish() |
| INV-I2 | An Institution can only be accredited by an Education Authority with jurisdiction over its type. | Institution.recordAccreditation() |
| INV-I3 | Only one active institutional Admission Policy per Admission Cycle. | Institution.publishAdmissionPolicy() |
| INV-I4 | An Institution always has a current official name. | Institution.establish(), Institution.rename() |
| INV-I5 | A closed institution cannot perform business operations. | Institution.close() |
| INV-P1 | A Programme belongs to exactly one Institution. | Programme.introduce() |
| INV-P2 | Only one active Admission Policy per Admission Cycle. | Programme.publishAdmissionPolicy() |
| INV-P3 | A Programme's admission status = (lifecycle is Admitting) ∧ (cycle is in Admission Period). | Programme.isAdmitting() |
| INV-P4 | A Programme's award level is valid for its Institution's type. | Programme.introduce() |
| INV-P5 | A Programme's accreditation can only be from an authority with jurisdiction over it. | Programme.recordAccreditation() |
| INV-P6 | A discontinued programme cannot perform business operations. | Programme.discontinue() |
| INV-S1 | A Scholarship has exactly one Provider. | Scholarship.announce() |
| INV-S2 | Only one active Eligibility Policy per period. | Scholarship.publishEligibilityPolicy() |
| INV-S3 | Applications can only be opened when the Scholarship is in "announced" state. | Scholarship.openApplications() |
| INV-S4 | Applications can only be closed when the Scholarship is in "open" state. | Scholarship.closeApplications() |
| INV-S5 | Applications cannot be opened without a published Eligibility Policy. | Scholarship.openApplications() |
| INV-C1 | A cycle has defined start and end dates. | AdmissionCycle.announce() |
| INV-C2 | Phase transitions follow the defined sequence (no backwards, no skipping). | AdmissionCycle.advancePhase() |
| INV-C3 | A cycle is time-bounded. | AdmissionCycle.announce() |
| INV-IS1 | A source cannot be simultaneously verified and unreliable. | InformationSource.verify(), InformationSource.markUnreliable() |
| INV-IS2 | A deprecated source cannot be verified. | InformationSource.verify() |
| INV-IS3 | Every registered source has a retrievable reference. | InformationSource.register() |
| INV-2 | An Accreditation Record is granted by exactly one Education Authority. | Parent.recordAccreditation() |
| INV-9 | A Qualification is recognized by at least one Education Authority. | Qualification establishment |
| INV-10 | An Accreditation Record's subject must fall within the granting authority's jurisdiction. | Parent.recordAccreditation() |

---

## 14. Decision Log

### Decisions from Previous Documents (Confirmed)

| Source | Decision ID | Decision | Consolidation Status |
|--------|-----------|----------|---------------------|
| Architectural Review | F1 | "Government Education Agency" renamed to "Education Authority" | **Confirmed.** Non-governmental authorities exist (ABET, QAA). Governmental is an attribute. |
| Architectural Review | F2, F5 | Invariants use jurisdiction, not Nigerian regulatory structure | **Confirmed.** Jurisdiction is data, not domain structure. |
| Architectural Review | F6, F7 | Institution Type and Award Level values are data, not hard-coded | **Confirmed.** Value objects remain; specific values are reference data. |
| Architectural Review | F8 | Qualification identity is authority-scoped, not national | **Confirmed.** WAEC SSCE is scoped to WAEC (regional), not "national." |
| Architectural Review | F9 | Admission Cycle phases are configurable | **Confirmed.** Sequential ordering (INV-C2) is the invariant; phase names are data. |
| Architectural Review | F10 | Admission Cycle scope from defining authority | **Confirmed.** Scope levels emerge from which authority defines the cycle. |
| Architectural Review | F11 | Cut-off Mark absorbed into Qualification Threshold | **Confirmed.** "Cut-off mark" is Nigerian terminology for a threshold with comparator ≥. |
| Topic 3 | DD3-1–DD3-11 | All Topic 3 domain decisions | **Confirmed.** Including: derived attributes never stored, country-varying values as reference data, Admission Rule ≠ Eligibility Rule, Monetary Amount groups amount + currency, Programme gains Faculty, Scholarship gains Application Deadline. |
| Resolution Analysis | RA-1 | Admission Pathway accepted as supporting entity | **Confirmed with reservation.** Behaviour Discovery may demote to VO if pathways add no behavioural complexity. |
| Resolution Analysis | RA-2 | Admission Mode (Cyclic/Rolling/Multiple-Intake) accepted as VO on Programme | **Confirmed.** Critical for global validity. |
| Resolution Analysis | RA-3 | Admission Cycle no longer universal temporal axis | **Confirmed.** Only required for Admission Mode = Cyclic. |
| Resolution Analysis | RA-4 | Country rejected as domain VO, accepted as reference data | **Confirmed.** ISO 3166-1 alpha-2 wrapper with no domain behaviour. |
| Resolution Analysis | RA-5 | Tertiary-only assumption made explicit | **Confirmed.** The model is structurally education-level-agnostic; the assumption is a data scope, not a model constraint. |
| Resolution Analysis | RA-6 | Location made optional on Institution | **Confirmed.** Online-only institutions are valid. |
| Resolution Analysis | RA-7 | Currency model confirmed (Monetary Amount with currency) | **Confirmed.** Cross-currency comparison is not a domain concern. |
| Resolution Analysis | RA-8 | Qualification confirmed as credential type, not credential instance | **Confirmed.** "WAEC SSCE" is the credential type; a candidate's actual SSCE result is not modelled (out of scope for discovery platform). |
| Resolution Analysis | RA-9 | Authority Type is a collection | **Confirmed.** NUC = {Regulatory, Accrediting}; JAMB = {Coordinating, Examining, Admissions}. |
| Resolution Analysis | RA-10 | Admission Policy ≠ Eligibility Policy separation confirmed | **Confirmed.** Different rule structures, different invariants, different business meaning. |
| Resolution Analysis | RA-11 | Two genuine bounded contexts identified | **Confirmed.** Opportunity Discovery and Trust & Accreditation, with Reference Framework as shared kernel. |

### New Decisions from Consolidation

| ID | Decision | Rationale |
|----|----------|-----------|
| CD-1 | **Admission Cycle aggregate root is retained with reduced scope.** It applies only to programmes with Admission Mode = Cyclic. For Rolling and Multiple-Intake modes, the cycle is optional. | The invariant (INV-C2: sequential phase transitions) is real and must be protected. Reduced scope does not invalidate the boundary. |
| CD-2 | **"Educational Opportunity" is acknowledged as a ubiquitous language term with no corresponding domain entity.** It will be a read model / projection in the application layer. | Per Laravel Beyond CRUD: the domain represents concrete concepts; the application composes them into user-facing concepts. An abstraction would be anemic (no invariants). |
| CD-3 | **Admission Policy and Eligibility Policy separation is confirmed with explicit rationale documentation.** The shared lifecycle is coincidental, not conceptual. | Different rule structures, different invariants, different business meaning. Future developers must not merge them. |
| CD-4 | **Aggregate-level provenance tracking is deferred.** The current provenance model (on child entities) is sufficient for MVP. | Provenance at the attribute level is granular enough for trust assessment. Aggregate-level provenance can be added as a Provenance Log aggregate if Behaviour Discovery requires it. |
| CD-5 | **Scholarship Provider is the weakest entity in the model.** It has no invariants and no operations. It is confirmed as a supporting entity for MVP, with the explicit note that promotion would be justified if provider verification workflows are introduced. | Honest assessment. Not a problem for MVP — the entity is needed for INV-S1 normalization. |
| CD-6 | **Admission Pathway's entity status is provisional.** If Behaviour Discovery shows that pathway-aware rules add no behavioural complexity (pathways are just labels), Admission Pathway should be demoted to a value object. | The Resolution Analysis accepted the entity based on ubiquitous language coverage. The behavioural justification is uncertain. |
| CD-7 | **The model is structurally education-level-agnostic.** The tertiary-only assumption is a data scope, not a model constraint. Adding non-tertiary institution types and award levels requires reference data only. | The model does not encode "tertiary" anywhere in its structure. All type constraints are data-driven (INV-I1, INV-P4). |

---

## 15. Pre-Behaviour Readiness Verdict

### Readiness Criteria

| # | Criterion | Assessment | Evidence |
|---|-----------|:----------:|----------|
| 1 | All entities justified by invariants or explicit structural need | ✅ | 5 aggregate roots protect real invariants; 3 child entities enforce consistency within parents; 4 supporting entities normalize references (weakest: Scholarship Provider, Admission Pathway) |
| 2 | All value objects justified by domain meaning, invariant enforcement, or concept grouping | ✅ | 14 domain-meaningful VOs + 13 enum-like VOs; 10 rejected VOs with explicit rationale |
| 3 | All aggregate boundaries justified by invariants (LBC test) | ✅ | Section 4 audit: all 5 aggregates protect real business invariants |
| 4 | No anemic aggregates | ✅ | Section 12 test: all aggregates have meaningful business operations |
| 5 | No derived attributes stored | ✅ | 7 derived attributes, all computed at query time |
| 6 | No persistence concerns in domain model | ✅ | No Eloquent, migration, API, or repository references |
| 7 | Global expansion works without structural changes | ✅ | Section 7 test: 0 structural changes for 9 countries |
| 8 | Future expansion pressure tested | ✅ | Section 8 test: all near-term expansions require 0 structural changes; only Services (Stage 3+) requires new aggregate root |
| 9 | Temporal modelling correct | ✅ | Section 6 audit: all time-bounded concepts have validity periods; no missing event sourcing |
| 10 | Provenance model sufficient for MVP | ✅ | Section 11 audit: child entities have provenance; aggregate-level provenance deferred as acceptable gap |
| 11 | Laravel Beyond CRUD architectural fit | ✅ | Section 12 test: all 6 LBC criteria pass |
| 12 | Bounded contexts identified | ✅ | 2 contexts + 1 shared kernel; implementation as single context for MVP with refactor seam at Stage 2 |
| 13 | All Integrity Review findings resolved | ✅ | 11 findings resolved in Resolution Analysis (17-domain-resolution-analysis.docx) |
| 14 | Tertiary-only assumption made explicit | ✅ | CD-7: data scope, not model constraint |
| 15 | Ubiquitous language gap acknowledged | ✅ | CD-2: "Educational Opportunity" is a facade concept, not a domain entity |
| 16 | Policy separation rationale documented | ✅ | CD-3: shared lifecycle is coincidental, not conceptual |

### Remaining Open Questions (Deferred to Behaviour Discovery)

| ID | Question | Impact on Model | Deferred Because |
|----|----------|-----------------|-----------------|
| OQ-D3-2 | Should Programme have tuition history? | If yes: Programme stores a collection of Tuition Records | Structural change is additive; not needed for MVP |
| OQ-D3-3 | Should Qualification Threshold's minimum value be typed? | If yes: typed value + scale reference | String is more flexible; comparison is application logic |
| OQ-D3-7 | Should Accreditation Record be truly immutable? | If no: mutable records for renewals | Current model (immutable) is simpler and provides audit trail |
| OQ-Pathway | Should Admission Pathway remain an entity or be demoted to VO? | If demoted: simpler model; if entity: pathway-qualified rules | Behaviour Discovery will determine if pathways add behavioural complexity |
| OQ-R2 | Should Scholarship support criteria-based targeting? | If yes: Targeting Criteria VO | Nigerian scholarships use explicit lists; criteria-based is a future need |
| OQ-R4 | Should Trust Signals be per-entity or per-attribute? | If per-attribute: finer-grained trust | Entity-level is pragmatic for MVP |

### Known Limitations (Accepted for MVP)

| Limitation | Impact | Mitigation |
|-----------|--------|-----------|
| Scholarship Provider has no invariants | Weakest entity; could become anemic if never promoted | Accept for MVP; promote if provider workflows emerge |
| Admission Pathway has no invariants | Provisional entity; may be demoted | Behaviour Discovery will determine |
| Aggregate-level provenance not tracked | Cannot trace where institution/programme data came from | Provenance on child entities is sufficient; add Provenance Log later if needed |
| No Qualification Equivalence mapping | Cannot compare qualifications across countries | Advisory, not authoritative; defer to Stage 2 |
| Single currency per Monetary Amount | No cross-currency comparison | Correct per A-D3-6; conversion is a product concern |
| Tuition Fee is a single amount | No fee breakdown (tuition + accommodation + fees) | A-D3-1: tuition is the primary comparison dimension; breakdowns are supplementary |

---

### VERDICT: **READY FOR BEHAVIOUR DISCOVERY**

**With the following provisions:**

1. **All 8 targeted revisions from the Resolution Analysis are applied** (Admission Pathway entity, Admission Mode VO, Admission Cycle scope reduction, Country as reference data, tertiary assumption explicit, Location optional, Authority Type collection, Policy separation documented).

2. **Two provisional decisions require Behaviour Discovery resolution:**
   - Admission Pathway: entity or value object? (OQ-Pathway)
   - Scholarship targeting: explicit lists or criteria-based? (OQ-R2)

3. **The domain model is structurally complete for Behaviour Discovery.** No entity additions, removals, promotions, or demotions are required before behaviour work begins. All aggregate boundaries are invariant-justified. All value objects serve domain purposes. The model is globally extensible with reference data changes only.

4. **Behaviour Discovery must respect these constraints:**
   - Do not introduce a shared Policy abstraction (CD-3)
   - Do not model "Educational Opportunity" as a domain entity (CD-2)
   - Do not add persistence concerns to the domain model
   - Do not promote supporting entities to aggregate roots without invariant justification
   - Do not store derived attributes
   - Admission Cycle applies only to Admission Mode = Cyclic

5. **The model's strengths substantially outweigh its limitations:**
   - ✅ Pragmatic aggregate boundaries justified by real invariants
   - ✅ Jurisdiction-based invariants (globally valid)
   - ✅ Authority-scoped identity (globally valid)
   - ✅ Derived attribute discipline (never stored)
   - ✅ Country-varying values as reference data (zero structural changes for expansion)
   - ✅ Admission Mode VO (handles cyclic, rolling, and multiple-intake)
   - ✅ No anemic aggregates
   - ✅ No premature generalization
   - ✅ Consistent with Business Discovery
   - ✅ Laravel Beyond CRUD architectural fit

**The Domain Discovery phase is complete. Proceed to Behaviour Discovery.**
