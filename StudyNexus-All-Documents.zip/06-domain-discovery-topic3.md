# StudyNexus — Domain Discovery: Topic 3
# Entity Attributes & Value Objects

**Date:** 2026-08-07
**Status:** Awaiting Approval
**Prerequisite:** Topic 1 (Core Domain Entities) — Approved with amendments; Topic 2 Revision (Aggregate Boundaries) — Approved; Architectural Review (14-architectural-review-global-domain.md) — Approved
**Business Discovery Status:** Frozen (immutable)

---

## Architectural Review Revisions Applied

The following revisions from the architectural review (Findings F1–F14) are applied throughout this document:

1. **"Government Education Agency" renamed to "Education Authority"** (F1). Governmental nature is an attribute, not the defining characteristic. Examples in Nigeria: JAMB, NUC, WAEC, NECO, NABTEB, NBTE, NCCE. Examples globally: ABET, UCAS, QAA, GTEC, KUCCPS.

2. **Invariant language uses jurisdiction, not Nigerian regulatory structure** (F2, F3, F5). INV-I2, INV-P5, INV-10 now express that the granting authority must have jurisdiction over the accredited entity. What defines jurisdiction is data, not domain structure.

3. **Qualification identity is authority-scoped, not national** (F8). A qualification is defined by the Education Authority that establishes it. Scope (national, regional, international, institutional) emerges from the authority's jurisdiction.

4. **Admission Cycle scope is determined by defining authority** (F10). Scope levels are not hard-coded — they emerge from which authority defines the cycle.

5. **Admission Cycle phases are configurable** (F9). The domain invariant is sequential ordering (INV-C2). Phase names and count are data. Nigerian national cycle phases (registration → examination → results → admission) are one configuration.

6. **"Cut-off Mark" absorbed into Qualification Threshold** (F11). "Cut-off mark" is Nigerian terminology for a Qualification Threshold where the qualification is a standardized assessment and the comparator is ≥.

7. **Institution Type and Award Level values are data, not hard-coded domain structure** (F6, F7). The value objects remain; their specific values vary by country.

8. **Nigerian instances expressed as examples, not definitions** (F12). All domain concepts stated in universal terms.

---

## Post-Revision Domain Model (Foundation)

### Aggregate Roots (5)
- Educational Institution
- Programme
- Scholarship
- Admission Cycle
- Information Source

### Child Entity Types (3)
- Admission Policy
- Eligibility Policy
- Accreditation Record

### Supporting Entities (3)
- Qualification
- Scholarship Provider
- Education Authority

### Key Invariants (Revised Wording)
| ID | Invariant (Revised) |
|----|---------------------|
| INV-I1 | An Institution has a valid type within its regulatory framework. |
| INV-I2 | An Institution can only be accredited by an Education Authority with jurisdiction over its type. |
| INV-I3 | Only one active institutional Admission Policy per Admission Cycle. |
| INV-I4 | An Institution always has a current official name. |
| INV-I5 | A closed institution cannot perform business operations. |
| INV-P1 | A Programme belongs to exactly one Institution. |
| INV-P2 | Only one active Admission Policy per Admission Cycle. |
| INV-P3 | A Programme's admission status = (lifecycle is Admitting) ∧ (cycle is in Admission Period). |
| INV-P4 | A Programme's award level is valid for its Institution's type. |
| INV-P5 | A Programme's accreditation can only be from an Education Authority with jurisdiction over it. |
| INV-P6 | A discontinued programme cannot perform business operations. |
| INV-S1–S5 | Scholarship invariants (unchanged). |
| INV-C1 | A cycle has defined start and end dates. |
| INV-C2 | Phase transitions follow the defined sequence (no backwards, no skipping). |
| INV-C3 | A cycle is time-bounded. |
| INV-IS1–IS3 | Information Source invariants (unchanged). |
| INV-2 | An Accreditation Record is granted by exactly one Education Authority. |
| INV-9 | A Qualification is recognized by at least one Education Authority. |
| INV-10 | An Accreditation Record's subject must fall within the granting authority's jurisdiction. |

---

## DD3-1: Entity-by-Entity Attribute Analysis

---

### Educational Institution (Aggregate Root)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Official Name | String | **Yes** (component) | Yes (renaming is a business event) | — | — | — | **Yes** | INV-I4: institution always has a current official name. Name changes are domain events (e.g., "University of Ife" → "Obafemi Awolowo University"). |
| 2 | Institution Type | Institution Type | **Yes** (component) | No | **Yes** | — | **Yes** (values vary by country) | **Yes** | INV-I1: institution has a valid type. Determines which authorities have jurisdiction (INV-I2). Type values are data per F6. |
| 3 | Registration Identifier | String | **Yes** (component) | No | — | — | **Yes** (format varies by authority) | **Yes** | The identifier issued by the relevant Education Authority (e.g., NUC registration number in Nigeria). Unique within the authority's jurisdiction. |
| 4 | Establishment Year | Integer | — | No | — | — | — | **Yes** | When the institution was officially established. Historical fact, never changes. |
| 5 | Ownership Type | Ownership Type | — | No | **Yes** | — | **Yes** (categories vary by country) | **Yes** | Public, Private, Public-Private, etc. Affects trust signals and funding context. Universal concept — every country categorizes institutions by ownership. |
| 6 | Location | Location | — | Yes (rare) | **Yes** | — | **Yes** (address structure varies) | **Yes** | Geographic location: country, region/state, city, address. Affects discoverability and jurisdiction. |
| 7 | Website URL | String | — | Yes | — | — | — | **Yes** | Primary official web presence. Used for provenance verification (A5-7: linking back to authoritative sources). |
| 8 | Operational Status | Institution Status | — | Yes (lifecycle transitions) | **Yes** | — | — | **Yes** | Lifecycle state: Established → Operational → Suspended → Closed. Every transition is a business event. |
| 9 | Name History | Collection of Name Change Records | — | Append-only | — | — | — | **Yes** | Domain knowledge: users search by former names (DD2-5 temporal insight). Each entry: previous name + new name + effective date + reason. |
| 10 | Current Accreditation Status | Accreditation Status | — | — | — | **Yes** | — | **Yes** | Derived from the most recent institutional Accreditation Record. Not stored — computed when needed. |

#### Identity Composition
- **Business identity** = Official Name (current) + Institution Type + Registration Identifier
- **Identity stability**: Evolving — name can change, but the continuing entity is the same. Identity is the continuing legal entity, not the current name.
- **Identity scope**: Authority-scoped — unique within the jurisdiction of the registering Education Authority.

#### Mutable Attributes
- Official Name (via `rename()` — a business event recorded in Name History)
- Location (rare — physical relocation or administrative boundary changes)
- Website URL (URL changes)
- Operational Status (lifecycle transitions via `suspend()`, `close()`, `mergeWith()`)

#### Attributes Belonging to Another Entity
- Accreditation Records → child entities within this aggregate (each record is a separate entity)
- Institutional-level Admission Policies → child entities within this aggregate
- Programmes → separate aggregate (referenced, not owned in the aggregate)

#### Country-Varying Attributes → Configuration/Reference Data
- **Institution Type values**: University, Polytechnic, College of Education, IEI (Nigeria); Research University, Liberal Arts College, Community College (US); University, College, FE College (UK). The value object remains; the specific values are data.
- **Registration Identifier format**: Determined by the Education Authority's identification scheme. Varies by country.
- **Ownership Type values**: Public, Private (universal); Public-Private, Faith-Based, Military, Tribal (country-specific).
- **Location structure**: States (Nigeria, US), Provinces (Kenya), Counties (UK), Regions (Ghana).

#### Presentation Concerns (Not Domain Attributes)
- Logo, branding, color scheme
- Social media links
- Photo gallery
- User ratings / reviews (not in MVP domain per A4-7)
- Popularity ranking (product feature, not domain concept)

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Official Name | A2-1 (Institutions as secondary users) | INV-I4, DD2-3 (evolving identity) |
| Institution Type | A2-9 (IEI definition) | INV-I1, F6 (values are data) |
| Registration Identifier | A2-5 (Agencies as strategic partners) | DD2-3 (identity component) |
| Location | A3-3 (Discoverability by region) | — |
| Operational Status | A3-2 (Trust — operational status affects reliability) | DD2-4 (lifecycle) |
| Current Accreditation Status | A3-2 (Trust), A6-8 (Trust Signals) | Derived from Accreditation Records |

---

### Programme (Aggregate Root)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Programme Name | String | **Yes** (component) | Yes (rare renaming) | — | — | — | **Yes** | "Computer Science", "Electrical Engineering". Renaming is an exceptional event (e.g., "Computer Engineering" → "Computer & Electrical Engineering"). |
| 2 | Owning Institution | Reference (Educational Institution) | **Yes** (component) | No | — | — | — | **Yes** | INV-P1: programme belongs to exactly one institution. Programme identity is institution-scoped (DD2-3). |
| 3 | Award Level | Award Level | **Yes** (component) | No | **Yes** | — | **Yes** (values vary by country) | **Yes** | INV-P4: award level must be valid for institution type. Determines admission pathways. Values like B.Sc., M.Sc. (universal) and ND, HND, NCE (Nigeria-specific) are data per F7. |
| 4 | Discipline | String | — | Yes (rare) | — | — | **Yes** (classification schemes vary) | **Yes** | Field of study: "Engineering", "Sciences", "Arts". Used for categorization, scholarship targeting, and comparison. Classification schemes vary by country and authority. |
| 5 | Programme Duration | Duration | — | Yes (rare) | **Yes** | — | **Yes** (units and norms vary) | **Yes** | Duration of study: value + unit (e.g., "4 years", "2 semesters"). Some programmes have variable duration. Norms vary (US: credit hours; UK/Nigeria: years). |
| 6 | Delivery Mode | Delivery Mode | — | Yes | **Yes** | — | — | **Yes** | Full-Time, Part-Time, Distance, Blended, Online. Affects eligibility and comparison. Universal concept. |
| 7 | Programme Status | Programme Status | — | Yes (lifecycle) | **Yes** | — | — | **Yes** | Introduced → Admitting → Suspended → Discontinued. Every transition is a business event. |
| 8 | Tuition Fee | Monetary Amount | — | Yes (annual changes) | **Yes** | — | **Yes** (currency varies) | **Yes** | Current tuition amount. Changes are domain events (DD2-5: evolving entity). Historical values are domain knowledge for comparison. |
| 9 | Admission Status | Boolean | — | — | — | **Yes** | — | **Yes** | INV-P3: derived from (lifecycle is Admitting) ∧ (cycle is in Admission Period). Not stored. |
| 10 | Current Accreditation Status | Accreditation Status | — | — | — | **Yes** | — | **Yes** | Derived from the most recent programme-level Accreditation Record. Not stored. |

#### Identity Composition
- **Business identity** = Programme Name + Owning Institution + Award Level
- **Identity stability**: Mostly stable — programme name rarely changes. Identity is institution-scoped.
- **Identity scope**: Institution-scoped — "Computer Science" is not unique; must be qualified by Institution + Award Level.

#### Mutable Attributes
- Programme Name (rare — via rename as business event)
- Discipline (rare — reclassification)
- Programme Duration (rare — curriculum revision)
- Delivery Mode (rare — programme restructure)
- Programme Status (lifecycle transitions)
- Tuition Fee (annual — domain event, historical values preserved)

#### Attributes Belonging to Another Entity
- Programme-level Admission Policies → child entities within this aggregate
- Programme-level Accreditation Records → child entities within this aggregate
- Owning Institution → separate aggregate (referenced)

#### Country-Varying Attributes → Configuration/Reference Data
- **Award Level values**: ND, HND, NCE (Nigeria); Associate's (US); Foundation Degree, HNC, PGCE (UK). Data per F7.
- **Programme Duration norms**: 4-year bachelor's (Nigeria, US); 3-year bachelor's (UK); variable by credits (US).
- **Tuition Fee currency**: NGN (Nigeria), KES (Kenya), GBP (UK), USD (US).
- **Discipline classification**: Varies by authority and country. No universal taxonomy.

#### Presentation Concerns (Not Domain Attributes)
- Programme description / marketing text
- Career prospects text
- Faculty profiles
- Curriculum detail (course list — deferred; may become domain concept later)
- Application count / competitiveness metrics

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Programme Name | A0-3 (discover educational opportunities) | DD2-3 (institution-scoped identity) |
| Owning Institution | A2-1 (Institutions) | INV-P1 |
| Award Level | A1-5, A2-8 (domain terminology) | INV-P4, F7 (values are data) |
| Tuition Fee | A3-4 (Comparison pain — inconsistent presentation) | DD2-5 (evolving entity) |
| Programme Status | A3-2 (Trust — status affects reliability) | DD2-4 (lifecycle) |
| Admission Status | A6-7 (Assess Eligibility) | INV-P3 (derived) |

---

### Scholarship (Aggregate Root)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Scholarship Name | String | **Yes** (component) | No | — | — | — | **Yes** | "Shell Undergraduate Scholarship", "PTDF Scholarship". Names are stable for a given offering period. |
| 2 | Offering Provider | Reference (Scholarship Provider) | **Yes** (component) | No | — | — | — | **Yes** | INV-S1: scholarship has exactly one provider. Identity is provider-scoped. |
| 3 | Application Period | Validity Period | **Yes** (component) | No | **Yes** | — | — | **Yes** | When the scholarship applies. "2024 Shell Scholarship" and "2025 Shell Scholarship" are distinct entities. |
| 4 | Scholarship Status | Scholarship Status | — | Yes (lifecycle) | **Yes** | — | — | **Yes** | Announced → Open → Closed → Expired, or Withdrawn. INV-S3, INV-S4 govern transitions. |
| 5 | Value | Monetary Amount | — | Yes (rare) | **Yes** | — | **Yes** (currency varies) | **Yes** | Financial value of the scholarship. Some scholarships cover full tuition (no fixed amount); others specify a monetary value. |
| 6 | Coverage Type | Coverage Type | — | No | **Yes** | — | — | **Yes** | Full Tuition, Partial Tuition, Stipend, Book Allowance, Mixed. Determines how value is interpreted. |
| 7 | Target Institutions | Collection of References | — | Yes (via targeting operations) | — | — | — | **Yes** | Institutions this scholarship targets. May be empty (open to all). |
| 8 | Target Programmes | Collection of References | — | Yes (via targeting operations) | — | — | — | **Yes** | Programmes this scholarship targets. May be empty (open to all). |
| 9 | Renewal Terms | String | — | No | — | — | — | **Yes** | Conditions for renewal (e.g., "maintain CGPA ≥ 3.5"). Free text because renewal conditions vary widely and are not standardized. |
| 10 | Is Applicable To Programme | Boolean | — | — | — | **Yes** | — | **Yes** | Derived from targeting rules (target institutions + target programmes). Not stored. |

#### Identity Composition
- **Business identity** = Scholarship Name + Offering Provider + Application Period
- **Identity stability**: Mostly stable. The same scholarship name may recur annually with different terms — each period is a distinct entity.
- **Identity scope**: Provider-scoped + Period-scoped.

#### Mutable Attributes
- Scholarship Status (lifecycle transitions via `openApplications()`, `closeApplications()`, `withdraw()`)
- Target Institutions (via `targetInstitutions()`)
- Target Programmes (via `targetProgrammes()`)
- Value (rare — provider may adjust)

#### Attributes Belonging to Another Entity
- Eligibility Policies → child entities within this aggregate
- Offering Provider → supporting entity (referenced)

#### Country-Varying Attributes → Configuration/Reference Data
- **Value currency**: NGN, KES, GBP, USD.
- **Coverage Type values**: May include country-specific categories (e.g., "Bursary" in Nigeria/UK, "Grant" in US).

#### Presentation Concerns (Not Domain Attributes)
- Scholarship description / marketing text
- Application instructions (how to apply — product/presentation concern)
- Past recipient testimonials
- Provider logo

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Scholarship Name | A2-4 (Scholarship Providers) | DD2-3 (provider-scoped identity) |
| Offering Provider | A2-4 | INV-S1 |
| Application Period | A4-2 (MVP scope) | DD2-4 (lifecycle) |
| Scholarship Status | A3-2 (Trust) | INV-S3, INV-S4, INV-S5 |
| Target Institutions/Programmes | A3-3 (Discoverability) | DD2-7 (cross-aggregate reference) |
| Value | A3-4 (Comparison — inconsistent financial presentation) | — |

---

### Admission Cycle (Aggregate Root)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Period/Year | String | **Yes** (component) | No | — | — | — | **Yes** | "2024/2025", "2025". The academic year or period the cycle covers. |
| 2 | Defining Authority | Reference (Education Authority) | **Yes** (component) | No | — | — | — | **Yes** | Per F10: scope is determined by the authority that defines the cycle. A national authority (e.g., JAMB) defines a national cycle; an institution defines an institutional cycle. Replaces hardcoded "scope level". |
| 3 | Phase Sequence | Phase Sequence | — | No (set at announcement) | **Yes** | — | **Yes** (phase names and count vary) | **Yes** | Per F9: the ordered list of phases for this cycle. INV-C2: transitions follow this sequence. Phase names are data — Nigeria's national cycle: [Registration Open, Examination Period, Results Released, Admission Period]; UK's UCAS: [Application, Offer, Reply, Confirmation]. |
| 4 | Current Phase Index | Integer | — | Yes (lifecycle transitions) | — | — | — | **Yes** | Position within the Phase Sequence. Transitions advance by exactly 1 (INV-C2). |
| 5 | Start Date | Date | — | No | — | — | — | **Yes** | INV-C1: cycle has defined start date. |
| 6 | End Date | Date | — | No | — | — | — | **Yes** | INV-C1, INV-C3: cycle is time-bounded. |
| 7 | Participating Institutions | Collection of References | — | Yes (during setup) | — | — | — | **Yes** | Institutions participating in this cycle. May be all institutions (national cycle) or a subset. |
| 8 | Participating Programmes | Collection of References | — | Yes (during setup) | — | — | — | **Yes** | Programmes with admission in this cycle. |
| 9 | Is Admission Open | Boolean | — | — | — | **Yes** | — | **Yes** | Derived from: current phase is the admission phase. Not stored. |

#### Identity Composition
- **Business identity** = Period/Year + Defining Authority
- **Identity stability**: Stable — once defined, a cycle's identity is fixed.
- **Identity scope**: Authority-scoped — the same period may have multiple cycles from different authorities (e.g., a national JAMB cycle and an institutional UNILAG cycle for the same year).

#### Mutable Attributes
- Current Phase Index (lifecycle transitions — advancing through phases)
- Participating Institutions (during setup; typically fixed once cycle is active)
- Participating Programmes (during setup)

#### Attributes Belonging to Another Entity
- Defining Authority → supporting entity (referenced)
- Participating Institutions/Programmes → separate aggregates (referenced)

#### Country-Varying Attributes → Configuration/Reference Data
- **Phase Sequence**: The specific phases and their names vary by country and cycle type. This is explicitly data per F9. The domain invariant (sequential ordering) is universal; the phase configuration is data.
- **Period/Year format**: "2024/2025" (Nigeria), "2024-25" (US), "2024/25" (UK). Presentation format varies; the underlying period is the same concept.

#### Presentation Concerns (Not Domain Attributes)
- Cycle display name (e.g., "2024/2025 UTME Admission Cycle" — presentation composition of identity components)
- Phase descriptions (human-readable text for each phase)
- Countdown timers (presentation)
- News/announcements about the cycle

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Period/Year | A1-3 (manual multi-source discovery) | DD2-3 (temporal identity) |
| Defining Authority | A2-5, A2-7 (Agencies as strategic partners, linking to authoritative sources) | F10 (scope from authority) |
| Phase Sequence | A1-3 (JAMB, WAEC as key sources) | F9 (phases are data), INV-C2 |
| Current Phase Index | A6-7 (Assess Eligibility depends on cycle phase) | INV-C2 (sequential transitions) |
| Participating Institutions/Programmes | A3-3 (Discoverability) | DD2-7 (cross-aggregate) |

---

### Information Source (Aggregate Root)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Source Name | String | **Yes** (component) | No | — | — | — | **Yes** | "UNILAG Official Website", "JAMB Portal", "Vanguard Education Section". |
| 2 | Source Type | Source Type | **Yes** (component) | No | **Yes** | — | **Yes** (categories vary) | **Yes** | Official Website, Government Portal, Examination Body Portal, News Outlet, PDF Document, Social Media, etc. |
| 3 | Retrievable Reference | String | **Yes** (component) | Yes (URLs change) | — | — | — | **Yes** | INV-IS3: every registered source has a retrievable reference. URL, file path, or other identifier. |
| 4 | Reliability Status | Source Reliability | — | Yes (lifecycle) | **Yes** | — | — | **Yes** | Discovered → Verified → Unreliable → Deprecated. INV-IS1: cannot be simultaneously verified and unreliable. |
| 5 | Last Verified Date | Date | — | Yes | — | — | — | **Yes** | When the source was last confirmed reliable. Critical for trust assessment (A6-8). |
| 6 | Information Category | Information Category | — | No | **Yes** | — | — | **Yes** | Per A3-7: Official, Verified, Historical, Community-Contributed. Business concept. |
| 7 | Is Reliable | Boolean | — | — | — | **Yes** | — | **Yes** | Derived from reliability status. Not stored. |

#### Identity Composition
- **Business identity** = Source Name + Source Type + Retrievable Reference
- **Identity stability**: Mostly stable — the logical source is the identity, not the current URL. URLs can change; the source continues.
- **Identity scope**: Source-scoped.

#### Mutable Attributes
- Retrievable Reference (URL changes)
- Reliability Status (lifecycle transitions via `verify()`, `markUnreliable()`, `deprecate()`)
- Last Verified Date (updated on verification)

#### Attributes Belonging to Another Entity
- None — Information Source is independently referenced by all entities for provenance.

#### Country-Varying Attributes → Configuration/Reference Data
- **Source Type values**: Country-specific government portals, examination body types. The universal concept is "type of information source"; specific types are data.

#### Presentation Concerns (Not Domain Attributes)
- Source icon/logo
- Source display formatting
- Bookmark/favorite status (user-specific, product feature)

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Source Name | A2-7 (linking to authoritative sources) | DD2-3 |
| Source Type | A3-7 (information categories are business concepts) | — |
| Retrievable Reference | A2-7 | INV-IS3 |
| Reliability Status | A3-2 (Trust pain) | INV-IS1, INV-IS2 |
| Information Category | A3-7 | — |

---

### Admission Policy (Child Entity of Programme or Institution)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Governed Entity | Reference (Programme or Institution) | **Yes** (component) | No | — | — | — | **Yes** | The programme or institution this policy governs. A policy belongs to exactly one entity. |
| 2 | Applicable Admission Cycle | Reference (Admission Cycle) | **Yes** (component) | No | — | — | — | **Yes** | The cycle this policy applies to. Identity is entity+cycle-scoped (DD2-3). |
| 3 | Policy Status | Policy Status | — | Yes (lifecycle) | **Yes** | — | — | **Yes** | Draft → Published → Active → Superseded → Retired. |
| 4 | Admission Rules | Collection of Admission Rule | — | Yes (until published) | **Yes** (each rule is a VO) | — | **Yes** (rule types vary by qualification system) | **Yes** | The collection of rules that define admission requirements. Each rule is a value object defined by its attributes. |
| 5 | Effective Period | Validity Period | — | No | **Yes** | — | — | **Yes** | When this policy is in effect. Typically aligned with the admission cycle's admission period. |
| 6 | Superseding Policy | Reference (Admission Policy) | — | Set on supersession | — | — | — | **Yes** | Reference to the policy that superseded this one. Null if current or retired without replacement. |
| 7 | Source Reference | Reference (Information Source) | — | No | — | — | — | **Yes** | Provenance: where this policy information came from. |

#### Identity Composition
- **Business identity** = Governed Entity + Applicable Admission Cycle
- **Identity stability**: Stable for a given cycle — once published, a policy's identity is fixed.
- **Identity scope**: Entity+Cycle-scoped.

#### Mutable Attributes
- Policy Status (lifecycle transitions)
- Admission Rules (before publication; immutable after publication)
- Superseding Policy (set when superseded)

#### Attributes Belonging to Another Entity
- Governed Entity → parent aggregate (Programme or Institution)
- Applicable Admission Cycle → separate aggregate (referenced)
- Source Reference → separate aggregate (referenced)

#### Country-Varying Attributes → Configuration/Reference Data
- **Admission Rule types**: Rules referencing JAMB UTME thresholds (Nigeria), UCAS tariff points (UK), SAT/ACT scores (US), A-Level grades (UK). The rule structure (qualification + threshold + subjects) is universal; the specific qualifications and threshold types are data.

#### Presentation Concerns (Not Domain Attributes)
- Human-readable policy summary
- Policy document PDF link (presentation/formatting)
- FAQ about admission requirements

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Governed Entity | A6-5 (Evaluate — gather admission information) | DD2-3 (entity+cycle-scoped) |
| Applicable Admission Cycle | A6-7 (Assess Eligibility for a cycle) | INV-P2, INV-I3 |
| Admission Rules | A6-7 (published admission requirements) | DD2-4 (value objects within policies) |
| Source Reference | A4-5 (provenance), A6-8 (trust signals) | — |

---

### Eligibility Policy (Child Entity of Scholarship)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Owning Scholarship | Reference (Scholarship) | **Yes** (component) | No | — | — | — | **Yes** | The scholarship this eligibility policy belongs to. |
| 2 | Applicable Period | Validity Period | **Yes** (component) | No | **Yes** | — | — | **Yes** | The offering period this policy covers. Identity is scholarship+period-scoped (DD2-3). |
| 3 | Policy Status | Policy Status | — | Yes (lifecycle) | **Yes** | — | — | **Yes** | Draft → Published → Active → Superseded → Retired. |
| 4 | Eligibility Rules | Collection of Eligibility Rule | — | Yes (until published) | **Yes** (each rule is a VO) | — | **Yes** (rule types vary) | **Yes** | The collection of rules defining who is eligible. |
| 5 | Superseding Policy | Reference (Eligibility Policy) | — | Set on supersession | — | — | — | **Yes** | Reference to the policy that superseded this one. |
| 6 | Source Reference | Reference (Information Source) | — | No | — | — | — | **Yes** | Provenance. |

#### Identity Composition
- **Business identity** = Owning Scholarship + Applicable Period
- **Identity stability**: Stable for a given period.
- **Identity scope**: Scholarship+Period-scoped.

#### Mutable Attributes
- Policy Status (lifecycle transitions)
- Eligibility Rules (before publication; immutable after publication)
- Superseding Policy (set when superseded)

#### Attributes Belonging to Another Entity
- Owning Scholarship → parent aggregate
- Source Reference → separate aggregate (referenced)

#### Country-Varying Attributes → Configuration/Reference Data
- **Eligibility Rule types**: Same as Admission Rules — universal structure, country-specific qualification references.

#### Presentation Concerns (Not Domain Attributes)
- Eligibility FAQ
- Application instructions
- Human-readable summary

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Owning Scholarship | A2-4 (Scholarship Providers) | DD2-3 |
| Eligibility Rules | A6-7 (Assess Eligibility) | INV-S5 (cannot open applications without published policy) |

---

### Accreditation Record (Child Entity of Programme or Institution)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Accredited Entity | Reference (Programme or Institution) | **Yes** (component) | No | — | — | — | **Yes** | The programme or institution being accredited. |
| 2 | Granting Authority | Reference (Education Authority) | **Yes** (component) | No | — | — | — | **Yes** | Per F3: the Education Authority that granted this accreditation. INV-2: exactly one per record. |
| 3 | Accreditation Status | Accreditation Status | — | No (historical fact) | **Yes** | — | **Yes** (status meanings vary) | **Yes** | Granted, Interim, Partial, Renewed, Suspended, Revoked, Expired. Each record is an immutable historical fact. |
| 4 | Effective Period | Validity Period | **Yes** (component) | No | **Yes** | — | — | **Yes** | When this accreditation is/was effective. Start date + end date. |
| 5 | Accreditation Type | Accreditation Type | — | No | **Yes** | — | **Yes** (types vary by system) | **Yes** | Institutional, Programme, Professional. Distinguishes the kind of accreditation. In Nigeria: NUC grants institutional and programme accreditation; professional bodies grant programme accreditation. In the US: regional accreditors grant institutional; ABET grants programme. |
| 6 | Source Reference | Reference (Information Source) | — | No | — | — | — | **Yes** | Provenance: where this accreditation information came from. |

#### Identity Composition
- **Business identity** = Accredited Entity + Granting Authority + Effective Period Start
- **Identity stability**: Stable — each record is a historical fact that does not change.
- **Identity scope**: Entity+Authority+Period-scoped.

#### Mutable Attributes
- **None** — an Accreditation Record is an immutable historical fact. Status changes (e.g., from Granted to Suspended) are recorded as **new** Accreditation Records, not mutations of existing records. This preserves the audit trail.

#### Attributes Belonging to Another Entity
- Accredited Entity → parent aggregate (Programme or Institution)
- Granting Authority → supporting entity (referenced)
- Source Reference → separate aggregate (referenced)

#### Country-Varying Attributes → Configuration/Reference Data
- **Accreditation Status values**: The specific statuses and their meanings vary. Nigeria: Interim, Full, Renewed (NUC 5-year cycle). US: Accredited, Candidate, Probation. UK: Reviewed, Monitored.
- **Accreditation Type values**: Institutional and Programme (universal); Professional, Specialized, Regional (country-specific categories).

#### Presentation Concerns (Not Domain Attributes)
- Accreditation certificate image/PDF
- Accreditation report summary text
- Inspectorate visit details

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Accredited Entity | A3-2 (Trust — accreditation is a trust signal) | INV-10 (subject within authority's jurisdiction) |
| Granting Authority | A2-5, A2-7 (Agencies as authoritative sources) | F1 (Education Authority), F2 (jurisdiction) |
| Accreditation Status | A6-8 (Trust Signals) | DD2-4 (lifecycle) |
| Effective Period | A3-2 (currency of information) | DD2-5 (time-bounded entity) |
| Accreditation Type | A3-2 (Trust) | — |

---

### Qualification (Supporting Entity)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Qualification Name | String | **Yes** (component) | No | — | — | **Yes** (names are country-specific) | **Yes** | "SSCE", "UTME", "A-Level", "SAT", "IB Diploma". Names are country-specific but the concept is universal. |
| 2 | Defining Authority | Reference (Education Authority) | **Yes** (component) | No | — | — | — | **Yes** | Per F8: the authority that establishes this qualification. Determines scope (national, regional, international). WAEC defines SSCE (regional); JAMB defines UTME (national); IBO defines IB (international). |
| 3 | Qualification Level | Qualification Level | — | No | **Yes** | — | **Yes** (levels vary by system) | **Yes** | Secondary, Tertiary Entrance, Diploma, Sub-Degree, Professional. Classifies where the qualification sits in the education framework. |
| 4 | Qualification Type | Qualification Type | — | No | **Yes** | — | — | **Yes** | Examination, Certification, Diploma, Degree. Distinguishes the nature of the qualification. |
| 5 | Recognition Scope | Recognition Scope | — | No | **Yes** | — | **Yes** (scope varies) | **Yes** | Per F8: the scope of recognition — National, Regional, International, Institutional. Derived from the defining authority's jurisdiction. |
| 6 | Status | Qualification Status | — | Yes (rare) | **Yes** | — | — | **Yes** | Recognized, Deprecated, Replaced. INV-9: recognized by at least one Education Authority. |

#### Identity Composition
- **Business identity** = Qualification Name + Defining Authority
- **Identity stability**: Stable — qualifications are long-standing domain concepts. Deprecation is rare.
- **Identity scope**: Authority-scoped (per F8). "WAEC SSCE" is scoped to WAEC. "JAMB UTME" is scoped to JAMB.

#### Mutable Attributes
- Status (rare — deprecation/replacement events)

#### Attributes Belonging to Another Entity
- Defining Authority → supporting entity (referenced)
- Referenced by Admission Rules and Eligibility Rules (value objects within policies)

#### Country-Varying Attributes → Configuration/Reference Data
- **Qualification Name**: SSCE, UTME, NCE, ND, HND (Nigeria); A-Levels, GCSE, BTEC (UK); SAT, ACT, AP (US); KCSE (Kenya).
- **Qualification Level values**: The levels and their definitions vary by education framework.
- **Recognition Scope**: While the concept is universal, what constitutes "national" vs "regional" varies.

#### Presentation Concerns (Not Domain Attributes)
- Qualification description text
- Exam format / structure details
- Grading scheme explanation
- Study resources links

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Qualification Name | A1-5, A1-6, A2-8 (domain terminology: JAMB, WAEC, etc.) | DD2-3 (national/authority-scoped identity) |
| Defining Authority | A2-5 (Agencies as strategic partners) | F8 (authority-scoped identity) |
| Qualification Level | A3-8 (Alternative Admission Pathways) | — |
| Status | A3-2 (Trust — deprecated qualifications affect reliability) | INV-9 (revised) |

---

### Scholarship Provider (Supporting Entity)

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Official Name | String | **Yes** | Yes (rare renaming) | — | — | — | **Yes** | "Shell Nigeria", "PTDF", "Chevron". "TotalEnergies" (renamed from "Total"). |
| 2 | Provider Type | Provider Type | — | No | **Yes** | — | **Yes** (categories vary) | **Yes** | Government, NGO, Corporate, Foundation, Educational Institution, Professional Body, International Organization. |
| 3 | Country of Operation | String (ISO country code) | — | No | — | — | **Yes** | **Yes** | The country where the provider primarily operates. Some providers are multinational. |
| 4 | Operational Status | Provider Status | — | Yes (rare) | **Yes** | — | — | **Yes** | Active → Inactive → Dissolved. Very stable in practice. |
| 5 | Website URL | String | — | Yes | — | — | — | **Yes** | For provenance and verification. |

#### Identity Composition
- **Business identity** = Official Name
- **Identity stability**: Evolving — name can change, but the continuing entity is the same (same pattern as Educational Institution).
- **Identity scope**: National/International-scoped.

#### Mutable Attributes
- Official Name (rare — via rename)
- Operational Status (rare lifecycle transitions)
- Website URL

#### Attributes Belonging to Another Entity
- Referenced by Scholarships (INV-S1: each scholarship has exactly one provider)

#### Country-Varying Attributes → Configuration/Reference Data
- **Provider Type values**: Government, Corporate (universal); Parastatal (Nigeria); Charity (UK); 501(c)(3) (US).

#### Presentation Concerns (Not Domain Attributes)
- Provider logo
- Provider description / about text
- Contact information (email, phone — administrative)

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Official Name | A2-4 (Scholarship Providers) | DD2-3 (evolving identity) |
| Provider Type | A2-4 | — |
| Operational Status | A3-2 (Trust) | DD2-4 (lifecycle) |

---

### Education Authority (Supporting Entity)

*Renamed from "Government Education Agency" per architectural review F1.*

#### Attributes

| # | Attribute | Type | Identity? | Mutable? | Value Object? | Derived? | Country-Varying? | Ubiquitous Language? | Rationale |
|---|-----------|------|:---------:|:--------:|:-------------:|:--------:|:-----------------:|:-------------------:|-----------|
| 1 | Official Name | String | **Yes** | Yes (rare restructuring) | — | — | — | **Yes** | "Joint Admissions and Matriculation Board", "National Universities Commission", "ABET", "UCAS". |
| 2 | Abbreviation | String | **Yes** (alternative identity) | No | — | — | — | **Yes** | "JAMB", "NUC", "WAEC", "ABET". Often used as the primary reference in domain language. More stable than official name. |
| 3 | Authority Type | Authority Type | — | No | **Yes** | — | — | **Yes** | Per F1: Regulatory, Accrediting, Examining, Coordinating, Standard-Setting, Admissions. An authority may have multiple types (NUC is both regulatory and accrediting). |
| 4 | Is Governmental | Boolean | — | No | — | — | — | **Yes** | Per F1: whether the authority is a government body. JAMB = true; ABET = false. Governmental nature is an attribute, not the defining characteristic. |
| 5 | Jurisdiction | Authority Jurisdiction | — | No (rare changes) | **Yes** | — | **Yes** (jurisdiction rules vary significantly) | **Yes** | Per F2, F5: defines what this authority can accredit/regulate/coordinate. Jurisdiction type (by-institution-type, by-geography, by-subject-area, by-education-level) and jurisdiction criteria. |
| 6 | Country of Operation | String (ISO country code) | — | No | — | — | **Yes** | **Yes** | The country where the authority operates. Some authorities operate across countries (WAEC is regional). |
| 7 | Operational Status | Authority Status | — | Yes (rare) | **Yes** | — | — | **Yes** | Established → Active → Restructured → Dissolved. Very stable in practice. |
| 8 | Website URL | String | — | Yes | — | — | — | **Yes** | For provenance and verification. |

#### Identity Composition
- **Business identity** = Abbreviation (preferred) or Official Name
- **Identity stability**: Stable — authorities are long-standing. Restructuring is rare (e.g., Ghana's NAB merged into GTEC).
- **Identity scope**: National/Regional/International-scoped, depending on jurisdiction.

#### Mutable Attributes
- Official Name (rare — restructuring)
- Jurisdiction (rare — mandate changes, e.g., Ghana's NAB → GTEC merger changed jurisdiction)
- Operational Status (rare lifecycle transitions)
- Website URL

#### Attributes Belonging to Another Entity
- Referenced by Accreditation Records (INV-2, INV-10)
- Referenced by Qualifications (INV-9)
- Referenced by Admission Cycles (as defining authority per F10)

#### Country-Varying Attributes → Configuration/Reference Data
- **Authority Type combinations**: NUC is Regulatory + Accrediting; JAMB is Coordinating + Examining + Admissions; ABET is Accrediting only. The types and their combinations vary.
- **Jurisdiction rules**: By institution type (Nigeria), by geographic region (US), by subject area (professional bodies), by education level (some countries). Per F2, this is data, not domain structure.
- **Is Governmental**: While boolean and universal, the prevalence varies (Nigeria: all major authorities are governmental; US: mix of governmental and non-governmental; UK: mix).

#### Presentation Concerns (Not Domain Attributes)
- Authority logo
- Authority description / mandate text
- Contact information
- Regulatory framework documentation links

#### Traceability
| Attribute | Business Discovery | Topic 1/2 |
|-----------|-------------------|-----------|
| Official Name / Abbreviation | A1-5, A1-6, A2-8 (domain terminology) | F1 (renamed entity) |
| Authority Type | A2-1 (Agencies as secondary users), A2-5 (strategic partners) | F1 (non-governmental authorities exist) |
| Is Governmental | A2-5 | F1 (governmental is an attribute) |
| Jurisdiction | A2-7 (linking to authoritative sources) | F2, F5 (jurisdiction-based invariants) |
| Operational Status | A3-2 (Trust) | DD2-4 (lifecycle) |

---

## DD3-2: Proposed Value Objects

### Value Object Specification Format

Each value object is specified with:
- **Purpose**: Why it exists in the domain model
- **Contained Values**: What it groups
- **Invariants**: Rules it enforces
- **Equality Semantics**: When two instances are equal
- **Entities That Use It**: Where it appears

---

### VO-1: Admission Rule

**Purpose**: Expresses one admission requirement within an Admission Policy. An admission rule is the atomic unit of admission criteria — it specifies what qualification a candidate must have, what threshold they must meet, and what subjects they must include. The concept is universal: every admission system in the world expresses requirements as rules about qualifications.

**Contained Values**:
- qualification: Reference to Qualification
- threshold: Qualification Threshold (or null if the rule has no numeric threshold — e.g., "must possess qualification X")
- subject combination: Subject Combination (or null if no specific subjects required)
- rule type: Rule Type (Mandatory, Preferred, Alternative)
- description: String (free-text explanation for complex or non-standard rules)

**Invariants**:
- Qualification must be a recognized Qualification (not deprecated or replaced)
- If threshold is present, it must reference the same qualification
- At least one of threshold, subject combination, or description must be specified
- Rule type must be valid

**Equality Semantics**: Two Admission Rules are equal if they have the same qualification, same threshold, same subject combination, and same rule type. Description is not part of equality (it's explanatory, not structural).

**Entities That Use It**: Admission Policy (collection of Admission Rules)

**Domain Language**: "Candidates must have WAEC SSCE with at least 5 credits including Mathematics and English" is one Admission Rule. "JAMB UTME score ≥ 200" is another. These are how domain experts express requirements.

---

### VO-2: Eligibility Rule

**Purpose**: Expresses one eligibility criterion within an Eligibility Policy. Mirrors Admission Rule but for scholarship eligibility, which may include non-qualification criteria (e.g., "must be from Niger Delta region", "CGPA ≥ 3.5").

**Contained Values**:
- qualification: Reference to Qualification (or null for non-qualification criteria)
- threshold: Qualification Threshold (or null)
- condition type: Condition Type (Qualification-Based, Academic-Performance, Geographic, Demographic, Financial-Need, Other)
- condition text: String (free-text for non-qualification criteria, e.g., "must be an indigene of Lagos State")
- rule type: Rule Type (Mandatory, Preferred, Alternative)

**Invariants**:
- If condition type is Qualification-Based, qualification must be specified
- If qualification is specified and threshold is present, threshold must reference the same qualification
- At least one of qualification, threshold, or condition text must be specified

**Equality Semantics**: Two Eligibility Rules are equal if they have the same condition type, same qualification, same threshold, and same condition text.

**Entities That Use It**: Eligibility Policy (collection of Eligibility Rules)

**Domain Language**: "Must have CGPA ≥ 3.5", "Must be a Nigerian citizen", "Must be studying Engineering".

---

### VO-3: Subject Combination

**Purpose**: Groups the set of required or recommended subjects for a programme's admission. In many educational systems, specific subjects are required for specific programmes (e.g., Mathematics, Physics, Chemistry for Engineering). This is a universal concept — every admission system that uses subject-based qualifications has subject combinations.

**Contained Values**:
- subjects: Set of String (subject names, e.g., "Mathematics", "Physics", "Chemistry")
- combination type: Combination Type (All-Required — candidate must have all subjects; Any-Of — candidate must have at least one; Best-N-Of — candidate must have at least N of the listed subjects)

**Invariants**:
- At least one subject must be specified
- Subject names must be non-empty
- If combination type is Best-N-Of, N must be specified and 1 ≤ N ≤ count of subjects

**Equality Semantics**: Two Subject Combinations are equal if they have the same set of subjects, same combination type, and (for Best-N-Of) the same N. Order of subjects does not affect equality.

**Entities That Use It**: Admission Rule

**Domain Language**: "5 O'Level credits including Mathematics and English" (All-Required with 5 subjects); "Any two from Physics, Chemistry, Biology" (Best-2-Of).

---

### VO-4: Qualification Threshold

**Purpose**: Expresses a minimum requirement on a qualification — the score, grade, or level a candidate must achieve. This is the universal domain concept that replaces the Nigeria-specific "Cut-off Mark" (F11). Every admission system worldwide uses thresholds on qualifications: "JAMB UTME ≥ 200" (Nigeria), "A-Level grades ≥ AAB" (UK), "SAT ≥ 1200" (US), "UCAS tariff ≥ 112 points" (UK).

**Contained Values**:
- qualification: Reference to Qualification
- minimum value: String (numeric score, grade, or points — stored as string to accommodate diverse grading systems: "200", "AAB", "112", "5 credits")
- comparator: Comparator (≥, >, =, ≤, < — typically ≥ for minimum thresholds)
- scale: String (optional — the grading scale, e.g., "JAMB scale (0-400)", "UCAS tariff", "WAEC grading")

**Invariants**:
- Qualification must be recognized
- Minimum value must be non-empty
- Comparator must be valid

**Equality Semantics**: Two Qualification Thresholds are equal if they have the same qualification, same minimum value, and same comparator.

**Entities That Use It**: Admission Rule, Eligibility Rule

**Note on Cut-off Mark**: Per F11, "Cut-off Mark" is Nigerian terminology for a Qualification Threshold where the qualification is a standardized assessment and the comparator is ≥. The glossary term "Cut-off Mark" remains valid as Nigerian domain terminology, but it is a localized name, not a separate value object. Example: "JAMB UTME cut-off mark of 200" = Qualification Threshold(qualification=JAMB UTME, minimum value="200", comparator=≥).

---

### VO-5: Validity Period

**Purpose**: Defines when something is effective — a date range with start and end boundaries. Used universally across the domain for accreditation periods, policy effective periods, admission cycle dates, and scholarship application periods. Every educational system uses time-bounded concepts.

**Contained Values**:
- start date: Date
- end date: Date

**Invariants**:
- Start date must be on or before end date
- Both dates must be specified (no open-ended periods — if something is ongoing, end date is set to a far-future date or the current review date)

**Equality Semantics**: Two Validity Periods are equal if they have the same start date and end date.

**Entities That Use It**: Accreditation Record, Admission Policy, Eligibility Policy, Admission Cycle, Scholarship

---

### VO-6: Trust Signal

**Purpose**: Composite trust assessment for a piece of information, per A6-8. A Trust Signal aggregates multiple factors that help users assess information reliability: provenance, verification status, currency, source reliability, and information category. This is an implementation-neutral business concept — it is a value computed from multiple sources, not a persisted entity.

**Contained Values**:
- provenance reference: Reference (Information Source or Education Authority)
- verification status: Verification Status (Unverified, Verified, Disputed)
- last verified date: Date (or null if unverified)
- source reliability: Source Reliability (from the referenced Information Source)
- information category: Information Category (from the referenced Information Source)

**Invariants**:
- If verification status is Verified, last verified date must be specified
- Provenance reference must be specified

**Equality Semantics**: Two Trust Signals are equal if they have the same provenance, same verification status, same last verified date, same source reliability, and same information category.

**Entities That Use It**: All entities that track provenance (Accreditation Record, Admission Policy, Eligibility Policy). Not stored as a separate attribute — computed from each entity's source reference and the referenced Information Source's state.

---

### VO-7: Institution Type

**Purpose**: Categorizes an educational institution within its regulatory framework. Determines which Education Authorities have jurisdiction (INV-I2) and what award levels are valid (INV-P4). The concept is universal — every country classifies its institutions into types. The specific values are data, not domain structure (F6).

**Contained Values**:
- type value: String (e.g., "University", "Polytechnic", "College of Education", "Community College", "Further Education College")

**Invariants**:
- Type value must be non-empty
- Type value must be valid within the applicable regulatory framework (checked against reference data)

**Equality Semantics**: Two Institution Types are equal if they have the same type value.

**Entities That Use It**: Educational Institution

**Data Note (F6)**: Nigerian types: University, Polytechnic, College of Education, IEI. US types: Research University, Liberal Arts College, Community College, For-Profit. UK types: University, College, FE College, Sixth Form College. The value object is universal; the specific values are reference data per country.

---

### VO-8: Award Level

**Purpose**: Classifies the award a programme confers upon completion. Determines admission pathways (e.g., Direct Entry for diploma holders into degree programmes). The concept is universal — every education system has award levels. Specific values are data (F7).

**Contained Values**:
- level value: String (e.g., "B.Sc.", "M.Sc.", "Ph.D.", "ND", "HND", "Associate's")
- level tier: Level Tier (Sub-Degree, Undergraduate, Postgraduate, Doctoral — universal classification)

**Invariants**:
- Level value must be non-empty
- Level tier must be specified
- Award level must be valid for the institution type (INV-P4 — validated by the Programme aggregate)

**Equality Semantics**: Two Award Levels are equal if they have the same level value.

**Entities That Use It**: Programme, Admission Rule (for pathway determination), Eligibility Rule

**Data Note (F7)**: Universal values: B.Sc., B.A., M.Sc., Ph.D. Nigeria-specific: ND, HND, NCE. UK-specific: Foundation Degree, HNC, PGCE, MEng. US-specific: Associate's, Bachelor's, Master's, Doctorate.

---

### VO-9: Monetary Amount

**Purpose**: Expresses a financial value with its currency. Used for tuition fees and scholarship values. The concept is universal — every educational system involves costs and financial awards. Grouping amount + currency prevents the error of comparing amounts in different currencies without conversion.

**Contained Values**:
- amount: Decimal (non-negative)
- currency code: String (ISO 4217, e.g., "NGN", "KES", "GBP", "USD")

**Invariants**:
- Amount must be ≥ 0
- Currency code must be a valid ISO 4217 code
- Currency code must be non-empty

**Equality Semantics**: Two Monetary Amounts are equal if they have the same amount and same currency code. Note: 100 NGN ≠ 100 KES even though amounts are equal — different currencies.

**Entities That Use It**: Programme (tuition fee), Scholarship (value)

---

### VO-10: Duration

**Purpose**: Expresses the length of a programme of study. Groups a numeric value with its unit (years, semesters, trimesters, credit hours). Different countries and institutions express programme duration differently: Nigeria/UK typically use years; US uses credit hours; some use semesters.

**Contained Values**:
- value: Decimal (e.g., 4, 2.5, 120)
- unit: Duration Unit (Years, Semesters, Trimesters, Credit Hours, Quarters)
- is minimum: Boolean (if true, this is the minimum duration; actual duration may be longer)

**Invariants**:
- Value must be > 0
- Unit must be specified

**Equality Semantics**: Two Durations are equal if they have the same value and same unit. Note: 4 years ≠ 8 semesters even though they may represent the same duration — different units are not equal without conversion.

**Entities That Use It**: Programme

---

### VO-11: Location

**Purpose**: Expresses the geographic location of an institution. Groups country, region/state, city, and address into a coherent whole. Location affects discoverability (users search by region), jurisdiction (which authorities have authority), and comparison (geographic proximity). Universal concept.

**Contained Values**:
- country code: String (ISO 3166-1 alpha-2, e.g., "NG", "GH", "KE", "GB", "US")
- region: String (state, province, county — varies by country)
- city: String
- address: String (optional — street address)

**Invariants**:
- Country code must be specified and valid
- At least country and city should be specified for meaningful location

**Equality Semantics**: Two Locations are equal if they have the same country, region, city, and address.

**Entities That Use It**: Educational Institution

---

### VO-12: Authority Jurisdiction

**Purpose**: Defines what an Education Authority can accredit, regulate, examine, or coordinate. Per F2 and F5, jurisdiction replaces the Nigeria-specific "agency appropriate to institution type" with a universal concept. Jurisdiction can be defined by institution type (Nigeria), geographic region (US), subject area (professional accrediting bodies), education level, or a combination.

**Contained Values**:
- jurisdiction type: Jurisdiction Type (By-Institution-Type, By-Geography, By-Subject-Area, By-Education-Level, By-Combination, Universal)
- jurisdiction criteria: Map of String → Set of String (the specific criteria: e.g., {"institutionType": ["University"]} for NUC; {"region": ["North-Central"]} for HLC; {"subjectArea": ["Engineering", "Computing"]} for ABET)

**Invariants**:
- Jurisdiction type must be specified
- Jurisdiction criteria must be non-empty (unless type is Universal, meaning the authority has jurisdiction over all entities)
- Criteria must be structurally valid for the jurisdiction type

**Equality Semantics**: Two Authority Jurisdictions are equal if they have the same type and same criteria.

**Entities That Use It**: Education Authority

**Domain Operation**: `hasJurisdictionOver(entity) → Boolean` — evaluates whether the authority can accredit/regulate a given entity, based on the jurisdiction type and criteria. In Nigeria, NUC.hasJurisdictionOver(institution) checks if institution.type = "University". In the US, HLC.hasJurisdictionOver(institution) checks if institution.location.region ∈ HLC's geographic region. The operation is the same; the criteria differ.

---

### VO-13: Phase Sequence

**Purpose**: Defines the ordered sequence of phases for an Admission Cycle. Per F9, phase names and count are data (vary by country and cycle type), while the domain invariant is sequential ordering (INV-C2). This value object encapsulates the configurable phase list.

**Contained Values**:
- phases: Ordered List of Cycle Phase (each has name + sequence position)

**Invariants**:
- At least one phase must be specified
- Phase names must be unique within the sequence
- Sequence positions must be contiguous starting from 0

**Equality Semantics**: Two Phase Sequences are equal if they have the same phases in the same order.

**Entities That Use It**: Admission Cycle

**Data Note (F9)**: Nigerian national cycle: [Registration Open, Examination Period, Results Released, Admission Period]. UK UCAS cycle: [Application, Offer, Reply, Confirmation]. US Common App: [Application, Review, Decision]. Institutional cycles may have different phases from national cycles.

---

### Enum-like Value Objects (VO-14 through VO-25)

These value objects have finite, stable sets of values. Each enforces that only valid values are used, preventing invalid states in the domain model.

| VO # | Name | Possible Values (Illustrative) | Entities Using It | Country-Varying? |
|------|------|-------------------------------|-------------------|:----------------:|
| VO-14 | Accreditation Status | Granted, Interim, Partial, Renewed, Suspended, Revoked, Expired | Accreditation Record | **Yes** (values and meanings vary) |
| VO-15 | Policy Status | Draft, Published, Active, Superseded, Retired | Admission Policy, Eligibility Policy | No |
| VO-16 | Programme Status | Introduced, Admitting, Suspended, Discontinued | Programme | No |
| VO-17 | Scholarship Status | Announced, Open, Closed, Expired, Withdrawn | Scholarship | No |
| VO-18 | Institution Status | Established, Operational, Suspended, Closed | Educational Institution | No |
| VO-19 | Source Reliability | Discovered, Verified, Unreliable, Deprecated | Information Source | No |
| VO-20 | Information Category | Official, Verified, Historical, Community-Contributed | Information Source | No |
| VO-21 | Authority Type | Regulatory, Accrediting, Examining, Coordinating, Standard-Setting, Admissions | Education Authority | No |
| VO-22 | Provider Type | Government, NGO, Corporate, Foundation, Educational Institution, Professional Body, International Organization | Scholarship Provider | **Yes** (categories vary) |
| VO-23 | Ownership Type | Public, Private, Public-Private, Faith-Based, Military | Educational Institution | **Yes** (categories vary) |
| VO-24 | Delivery Mode | Full-Time, Part-Time, Distance, Blended, Online | Programme | No |
| VO-25 | Qualification Status | Recognized, Deprecated, Replaced | Qualification | No |

**Equality for all enum-like VOs**: Two instances are equal if they have the same value.

**Country-varying note**: Where marked "Yes", the specific values are reference data that may differ by country. The value object structure is universal; the values are data.

---

## DD3-3: Rejected Value Objects

| Proposed Value Object | Why Rejected |
|----------------------|-------------|
| **Cut-off Mark** | Per F11: absorbed into Qualification Threshold. "Cut-off mark" is Nigerian terminology for a Qualification Threshold where the qualification is a standardized assessment and the comparator is ≥. No structural distinction — adds no domain concept that Qualification Threshold doesn't already capture. |
| **Minimum Score** | Subsumed by Qualification Threshold. A minimum score is one component (minimum value) of a threshold, not a standalone domain concept. Creating a separate VO for "score" when Qualification Threshold already groups qualification + value + comparator is primitive obsession in reverse — splitting what the domain naturally groups. |
| **Grade** | Too granular and context-dependent. A grade ("A", "First Class", "Distinction") is meaningful only within a specific qualification's grading scheme. It does not group related concepts, express a domain invariant, or replace primitive obsession — it IS a primitive value used within Qualification Threshold's minimum value field. |
| **Institution Name** | Requires temporal tracking (name changes are business events with history). A value object is immutable by definition; an institution name is mutable with domain-relevant history. The name history is tracked as a collection of name change records, not a single value object. |
| **Programme Name** | Same rationale as Institution Name — rare but possible renaming. Too simple to justify a separate VO (it's just a String), and it has no grouped values or invariant to express. |
| **Contact Information** | Administrative/presentation concern, not a domain concept. Phone numbers, email addresses, and physical addresses (beyond Location) are not part of the ubiquitous language of educational opportunity discovery. They belong in a CRM or presentation layer. |
| **Admission Pathway** | This is a genuine domain concept (different routes into education: Direct Entry, standard route, transfer, etc., per A3-8). However, it has identity and lifecycle (pathways are recognized and can be deprecated), and it may relate to multiple qualifications and rules. It is more entity-like than value-like. **Deferred as an open question** — may be promoted to a supporting entity in a future topic. |
| **Educational Level** | Overlaps with both Award Level (for programmes) and Qualification Level (for qualifications). Introducing a third "level" concept creates confusion rather than clarity. The existing two VOs serve different entities and purposes. This would be premature generalization. |
| **Currency** | Subsumed by Monetary Amount. Currency alone is not a domain concept — it is meaningful only in conjunction with an amount. ISO 4217 codes are used within Monetary Amount. |
| **Accreditation Type** | While "institutional" vs "programme" vs "professional" accreditation is meaningful, this is a simple classification attribute on Accreditation Record, not a concept that groups related values or expresses an invariant. A simple enum-like VO (VO-26, if needed) would suffice, but it's already modeled as a string attribute. |
| **Address** (separate from Location) | Subsumed by Location VO. Street address is an optional field within Location. Splitting address from Location creates an unnecessary dependency — they are always used together. |
| **Provider Status** | The lifecycle states for Scholarship Provider (Active, Inactive, Dissolved) are simple and unlikely to grow. A value object adds structure without domain meaning. Keep as a simple enum if needed; currently modeled as an attribute. |

---

## DD3-4: Attribute Ownership Decisions

### Principles

1. **An attribute belongs to the entity that needs it for its business operations and invariants.**
2. **An attribute referenced by multiple entities belongs to the entity that defines it; others reference it.**
3. **Derived attributes are not stored on any entity — they are computed.**
4. **Country-varying attribute values belong to reference data/configuration, not to the domain model's structure.**

### Cross-Entity Attribute Analysis

| Attribute | Candidate Owners | Decision | Rationale |
|-----------|-----------------|----------|-----------|
| Tuition Fee | Programme, Institution | **Programme** | Tuition varies by programme, not by institution (different programmes at the same institution have different fees). In rare cases, institutions charge uniform fees — this is still programme-level data (each programme's fee happens to be the same). |
| Accreditation Status | Institution, Programme, Accreditation Record | **Derived — not stored** | Current accreditation status is derived from the most recent Accreditation Record. Storing it separately would create a consistency risk (stored status could diverge from the records). Each entity derives its status when needed. |
| Admission Status | Programme | **Derived — not stored** | INV-P3: admission status = (lifecycle is Admitting) ∧ (cycle is in Admission Period). Derived at query time. |
| Current Phase | Admission Cycle | **Admission Cycle** (as index) | The current phase is a mutable attribute of the cycle. Stored as an index into the Phase Sequence. |
| Currency | Programme, Scholarship | **Within Monetary Amount VO** | Currency is not a standalone attribute — it exists only as part of a financial amount. |
| Country | Institution, Authority, Provider | **Within Location VO (Institution)**, **as attribute (Authority, Provider)** | Country is part of Location for Institution. For Authority and Provider, it's a direct attribute (they don't have full Location). |
| Discipline | Programme, Institution | **Programme** | Discipline is a characteristic of a programme, not an institution. An institution offers programmes across many disciplines. |
| Website URL | Institution, Authority, Provider, Information Source | **Each entity** | Each entity independently has a web presence. These are separate URLs serving different purposes. Not shared. |
| Name History | Institution, Provider | **Each entity** | Both have evolving names. Each maintains its own name history. Not shared because the history format and business rules differ (institution renames are more significant than provider renames). |

### Attributes Moved Between Entities

| Attribute | Originally Considered For | Moved To | Reason |
|-----------|-------------------------|---------|--------|
| Coverage Type | Scholarship Value | **Scholarship** (direct attribute) | Coverage type (Full Tuition, Partial, Stipend) affects how the monetary value is interpreted. It belongs to the Scholarship, not to the Monetary Amount VO — a Monetary Amount is currency-neutral, but coverage type is scholarship-specific. |
| Renewal Terms | Eligibility Policy | **Scholarship** (direct attribute) | Renewal terms apply to the scholarship as a whole, not to a specific eligibility policy. The same renewal terms apply regardless of which period's eligibility policy is in effect. |
| Source Reference | Various entities | **Each entity that tracks provenance** | Provenance is a cross-cutting concern. Each entity that needs provenance tracking (Accreditation Record, Admission Policy, Eligibility Policy) carries its own reference to an Information Source. Not centralized. |

---

## DD3-5: Derived vs Stored Attribute Decisions

### Derived Attributes (Not Stored)

| Derived Attribute | Derived From | Computation | Why Derived |
|-------------------|-------------|-------------|-------------|
| **Institution's current accreditation status** | Collection of institutional Accreditation Records | Most recent record's status, filtered by effective period (current) | Storing would create dual-source inconsistency. The authoritative source is the record collection. |
| **Programme's current accreditation status** | Collection of programme-level Accreditation Records | Most recent record's status, filtered by effective period (current) | Same rationale as institution. |
| **Programme's admission status** | Programme lifecycle state + Admission Cycle current phase | (lifecycle = Admitting) ∧ (cycle phase = Admission Period) | INV-P3: this is a domain invariant, not a stored state. Depends on two independent states. |
| **Scholarship's applicability to a programme** | Scholarship's targeting rules (target institutions + target programmes) | Programme ∈ target programmes ∨ programme's institution ∈ target institutions ∨ (both targets empty = open to all) | Computed from targeting rules. Targeting rules may change; applicability is always current. |
| **Admission Cycle's isAdmissionOpen** | Current phase index + Phase Sequence | current phase = the phase designated as "admission period" in the sequence | The designation of which phase is "admission" varies by cycle configuration. Derived from configuration. |
| **Information Source's isReliable** | Reliability status | status = Verified | Simple derivation from lifecycle state. |
| **Trust Signal** | Entity's source reference + Information Source's state | Compose from: provenance reference, source's verification status, source's last verified date, source's reliability, source's information category | Per A6-8: trust signals are computed, not persisted. The signal changes when the source's state changes. |

### Stored Attributes (Not Derived)

All other attributes listed in the entity-by-entity analysis are stored. Key principles:

1. **Lifecycle states are stored** — they are mutable and transitioned by business operations.
2. **Identity components are stored** — they define the entity and are used for referencing.
3. **Value object contents are stored** — they are part of the entity's state.
4. **References to other entities/aggregates are stored** — they enable cross-aggregate relationships.
5. **Historical collections are stored** — name histories, accreditation records, policy collections are part of the entity's domain knowledge.

---

## DD3-6: New Assumptions

| ID | Assumption | Rationale | Impact if Wrong |
|----|-----------|-----------|-----------------|
| A-D3-1 | **Programme tuition is the primary financial attribute users compare.** Fees at the faculty level, departmental fees, and ancillary fees are secondary and can be represented as supplementary information without modeling them as separate domain attributes. | A3-4 (Comparison pain) centres on tuition. No business decision references fee breakdowns. | If users need fee breakdowns (tuition + accommodation + departmental), Programme may need a collection of Fee components rather than a single Monetary Amount. |
| A-D3-2 | **Admission Rule and Eligibility Rule are distinct value objects, not a single "Policy Rule" abstraction.** | Admission rules and eligibility rules have different structures: admission rules are qualification-centric (qualification + threshold + subjects), while eligibility rules include non-qualification criteria (geographic, demographic, financial need). Premature generalization would lose this distinction. | If admission and eligibility rules are found to be structurally identical, a shared "Policy Rule" VO would reduce duplication. Current analysis suggests they are different enough to warrant separate VOs. |
| A-D3-3 | **Authority Jurisdiction is a value object, not a separate entity.** Jurisdiction rules change rarely and are defined by the authority itself. | Education Authorities are supporting entities with no business operations. Their jurisdiction is a configuration attribute, not an independently managed domain concept. | If jurisdiction rules become complex enough to require independent lifecycle management (e.g., jurisdiction rules that change through a governed process), Authority Jurisdiction may need promotion to a child entity. |
| A-D3-4 | **Phase Sequence is a value object, not a separate entity.** Once defined at cycle announcement, phases do not change. | Admission Cycle phases are set when the cycle is announced and never modified. A value object (immutable) correctly models this. | If cycles can have phases added or removed after announcement (which would violate INV-C2), Phase Sequence would need to be a child entity. This seems unlikely. |
| A-D3-5 | **Qualification Threshold's minimum value is a String, not a numeric type.** This accommodates diverse grading systems: numeric scores ("200"), letter grades ("AAB"), credit counts ("5 credits"), tariff points ("112"). | Grading systems vary radically across countries and qualifications. Forcing a numeric type would exclude grade-based and point-based thresholds. | If all thresholds are ultimately numeric (even grades map to numbers), a numeric type with an optional grading scale reference would be more type-safe. Open question. |
| A-D3-6 | **Monetary Amount does not handle multi-currency conversion.** Each Monetary Amount is expressed in a single currency. Cross-currency comparison is a presentation/product concern, not a domain concern. | Currency conversion rates change continuously and are not part of the educational domain. The domain records amounts in their original currency. | If domain rules require currency conversion (e.g., "scholarship value must cover full tuition" where currency differs), Monetary Amount may need a conversion capability. This is unlikely for MVP. |
| A-D3-7 | **Subject names within Subject Combination are free-text strings, not references to a Subject entity.** | There is no universal subject taxonomy. Subjects are named differently across countries and examination bodies. A Subject entity would be reference data with no business behavior — free-text within Subject Combination is simpler and more flexible. | If a standardized subject taxonomy becomes important (e.g., for cross-country comparison or eligibility matching), Subject may need to become a supporting entity. |
| A-D3-8 | **Education Authority can have multiple Authority Types.** NUC is both Regulatory and Accrediting; JAMB is Coordinating, Examining, and Admissions. | Authorities in many countries serve multiple roles. A single type would be too restrictive. | If multiple types create complexity without domain value (e.g., if the only operation that uses authority type is "hasJurisdictionOver", which depends on jurisdiction rather than type), a single primary type with secondary attributes may suffice. |

---

## DD3-7: New Open Questions

| ID | Question | Context | Impact on Model |
|----|----------|---------|-----------------|
| OQ-D3-1 | **Should Admission Pathway be a supporting entity?** Alternative Admission Pathways (Direct Entry, IJMB, JUPEB, diploma routes) are a glossary term (A3-8) and exist in every country (UK: Foundation Year, Access Course; US: Transfer, Advanced Placement). They affect Admission Rules (different qualifications are accepted for different pathways). Currently, pathways are implicit in Admission Rules — a rule like "ND/HND holders may enter at 200-level" encodes the pathway. Should pathways be explicit? | If pathways are explicit, Qualification references in Admission Rules could be pathway-qualified. This would improve eligibility assessment clarity. | If yes: add Admission Pathway as a supporting entity referenced by Admission Rules. If no: pathways remain implicit in rule descriptions. |
| OQ-D3-2 | **Should Tuition Fee have historical tracking on Programme?** Programme is an evolving entity (DD2-5). Tuition changes are domain events. Should Programme maintain a tuition history, or is the current tuition sufficient for MVP? | Historical tuition enables trend comparison ("How has tuition changed over 5 years?"). This is a domain query, not a product feature. | If yes: Programme stores a collection of Tuition Records (year + amount) rather than a single Monetary Amount. If no: Programme stores current tuition only; historical tuition deferred. |
| OQ-D3-3 | **Should Qualification Threshold's minimum value be typed (numeric, grade, points) rather than String?** | A-D3-5 assumes String for flexibility. But typed values would enable validation (e.g., JAMB scores must be 0-400) and comparison (e.g., "score ≥ threshold"). | If yes: Qualification Threshold has a typed value with a scale reference. If no: String remains; comparison is deferred to application logic. |
| OQ-D3-4 | **Should Education Authority's Jurisdiction be single or allow multiple jurisdictions?** An authority may have jurisdiction by institution type AND by geography (e.g., a state-level authority in Nigeria has jurisdiction over institutions of all types within its state). | Authority Jurisdiction VO currently allows a single jurisdiction type. Multiple jurisdictions require By-Combination type. | If combination type is sufficient: no change. If not: Authority Jurisdiction may need to be a collection rather than a single VO. |
| OQ-D3-5 | **Should Programme have a Faculty/Department attribute?** Topic 1 deferred Faculty/Department. During attribute analysis, Programme has no organizational attribute linking it to a faculty or department within its institution. | Users may search or filter by faculty ("Show me all Engineering programmes"). This is a discoverability concern (A3-3). | If yes: Programme has a Faculty/Department reference (could be a string attribute or a reference to a future entity). If no: deferred until later topic. |
| OQ-D3-6 | **Should Scholarship have an Application Deadline separate from the Application Period?** The Validity Period on Scholarship covers the full offering period. Application deadline may differ from period end. | "Application closes 15 March 2025" is distinct from "Scholarship period is 2025 academic year". Users need the deadline for decision-making. | If yes: Scholarship has an explicit Application Deadline attribute (Date) separate from Application Period. If no: Application Period's end date serves as the deadline. |
| OQ-D3-7 | **Should Accreditation Record be truly immutable (new record for every status change), or should minor status updates (e.g., "Renewed" with a new period) modify the existing record?** | Current model treats each accreditation event as a new record. But renewal could be modeled as either: (a) a new Accreditation Record with status=Renewed and a new period, or (b) an update to the existing record's period. | If immutable (current model): clean audit trail, simple reasoning about history. If mutable for renewals: fewer records, but requires temporal tracking on the record itself. Recommendation: keep immutable. |
| OQ-D3-8 | **Should Information Source have a Content Last Checked date separate from Last Verified Date?** | Last Verified Date records when the source was confirmed reliable. But content currency (when was the actual information last checked for accuracy?) may differ. A source may be reliable (it exists and is maintained) but its content may be outdated. | If yes: two dates — one for source reliability, one for content currency. If no: Last Verified Date serves both purposes. Per A6-8, trust signals should capture currency; separate dates would improve trust assessment. |

---

## DD3-8: Traceability to Business Discovery

### Attribute-to-Decision Traceability Matrix

| Domain Attribute | Business Discovery Decisions | Domain Decisions |
|-----------------|---------------------------|-----------------|
| Institution Type | A2-9 (IEI definition) | INV-I1, F6 (values are data) |
| Official Name (Institution) | A2-1, A2-3 (Institutions as secondary users) | INV-I4, DD2-3 (evolving identity) |
| Registration Identifier | A2-5 (Agencies as strategic partners) | DD2-3 (identity component) |
| Operational Status | A3-2 (Trust pain) | DD2-4 (lifecycle) |
| Location | A3-3 (Discoverability by region) | — |
| Tuition Fee | A3-4 (Comparison pain — inconsistent presentation) | DD2-5 (evolving entity) |
| Award Level | A1-5, A1-6, A2-8 (domain terminology) | INV-P4, F7 (values are data) |
| Programme Status | A3-2 (Trust) | DD2-4 (lifecycle) |
| Admission Status | A6-7 (Assess Eligibility) | INV-P3 (derived) |
| Accreditation Status | A3-2 (Trust), A6-8 (Trust Signals) | Derived from Accreditation Records |
| Granting Authority | A2-5, A2-7 (Agencies, authoritative sources) | F1 (Education Authority), F2 (jurisdiction) |
| Scholarship Value | A3-4 (Comparison) | — |
| Scholarship Status | A3-2 (Trust) | INV-S3, INV-S4, INV-S5 |
| Target Institutions/Programmes | A3-3 (Discoverability) | DD2-7 (cross-aggregate) |
| Phase Sequence | A1-3 (JAMB as key source) | F9 (phases are data), INV-C2 |
| Defining Authority | A2-5, A2-7 (Agencies as sources) | F10 (scope from authority) |
| Source Reliability | A3-2 (Trust pain) | INV-IS1, INV-IS2 |
| Information Category | A3-7 (business concepts) | — |
| Qualification Name | A1-5, A1-6, A2-8 (domain terminology) | F8 (authority-scoped) |
| Defining Authority (Qualification) | A2-5 (Agencies) | F8 (authority-scoped identity) |
| Authority Type | A2-1, A2-5 (Agencies as secondary users) | F1 (non-governmental authorities exist) |
| Is Governmental | A2-5 | F1 (governmental is attribute) |
| Jurisdiction | A2-7 (linking to authoritative sources) | F2, F5 (jurisdiction-based invariants) |
| Trust Signal | A6-8 (implementation-neutral trust concept) | VO-6 |
| Validity Period | A3-2 (currency of information) | DD2-5 (time-bounded) |
| Admission Rules | A6-7 (published admission requirements) | VO-1, INV-P2 |
| Eligibility Rules | A6-7 (Assess Eligibility) | VO-2, INV-S5 |
| Subject Combination | A6-7 (subject requirements for admission) | VO-3 |
| Qualification Threshold | A1-5 (Cut-off Mark), A6-7 | VO-4, F11 (absorbs Cut-off Mark) |
| Monetary Amount | A3-4 (Comparison — financial values) | VO-9 |
| Duration | A3-4 (Comparison — programme length) | VO-10 |

### Candidate Business Concepts Coverage

| Candidate Concept | How Addressed in Attributes |
|-------------------|---------------------------|
| **Eligibility Status** (WF4) | Derived — not an entity attribute. Computed by evaluating a user's qualifications against an Admission Policy's rules. Per A6-7, assessment method is deferred to Product Discovery. |
| **Comparison Dimension** (WF3) | Not an entity attribute. Comparison dimensions are the attributes themselves (tuition, accreditation status, admission requirements, location, etc.). The set of comparable attributes is determined by what entities have in common. |
| **Trust Signal** (WF5) | Value Object VO-6. Attached to entities via provenance tracking (source reference + source's state). Computed, not stored. |
| **Educational Decision** (WF6) | Not an entity attribute. This is a user action/concept in the workflow domain, not the education opportunity domain. |
| **Current Educational Journey** (WF7) | Not an entity attribute. This is a user concept — the user's existing educational commitment. Belongs to a user/persona model, not the opportunity model. |

---

## DD3-9: Challenges to Topics 1 and 2

### Challenge C-1: Admission Pathway Should Be a Domain Entity

**Current state**: Admission Pathway is a glossary term (A3-8: "Alternative Admission Pathways include Direct Entry, IJMB, JUPEB, diploma pathways, and other recognized admission routes into tertiary education."). It is not an entity in Topics 1 or 2.

**Challenge**: During attribute analysis, Admission Rules reference qualifications without specifying the pathway. A rule like "ND/HND holders may enter at 200-level" implicitly encodes a Direct Entry pathway. But pathways are a universal domain concept that exists in every country:
- Nigeria: Direct Entry, IJMB, JUPEB, diploma routes
- UK: Foundation Year, Access Course, HND progression
- US: Transfer, Advanced Placement, articulation agreements
- Kenya: Diploma progression, bridging courses

Pathways affect:
1. Which qualifications are accepted (pathway determines valid qualifications)
2. What level the student enters at (Direct Entry → 200-level; Foundation → 100-level)
3. What additional criteria apply (some pathways have specific requirements beyond qualifications)

**Current model**: Admission Rules can express pathway-specific requirements through rule combinations (e.g., "if qualification=ND and threshold≥Lower Credit, then entry level=200"). But this is implicit and verbose.

**Recommendation**: Do not add Admission Pathway as an entity in Topic 3 — that would require reopening Topics 1 and 2. Instead, flag this as OQ-D3-1 and note that if pathways become important enough to model explicitly, a future topic (or a Topic 1 amendment) can introduce Admission Pathway as a supporting entity. The current Admission Rule structure is sufficient to express pathway-conditional requirements through rule combinations and descriptions.

**Severity**: Low for MVP. The current model can represent pathway-specific rules. Explicit pathways would improve model expressiveness but are not required for correctness.

---

### Challenge C-2: Programme May Need Faculty/Department Reference

**Current state**: Topic 1 deferred Faculty/Department for re-evaluation during later discovery.

**Challenge**: Programme has no organizational attribute linking it to a faculty or department within its institution. This affects:
1. Discoverability — users may search by faculty ("Show me Engineering programmes at UNILAG")
2. Comparison — comparing programmes within the same faculty across institutions
3. Scholarship targeting — some scholarships target faculties rather than individual programmes

**Current model**: Programme has a Discipline attribute (e.g., "Engineering") which partially serves this purpose, but Discipline is not institution-specific — it's a field-of-study classification. Faculty/Department is institution-specific organizational structure.

**Recommendation**: Add a Faculty attribute to Programme as a simple string (not a reference to a Faculty entity). This provides organizational context without introducing a new entity. If Faculty/Department later needs its own identity, lifecycle, or relationships, it can be promoted to a supporting entity.

**Severity**: Medium for discoverability (A3-3). Recommend adding as a Programme attribute in this topic.

---

### Challenge C-3: Scholarship Application Deadline vs Application Period

**Current state**: Scholarship has an Application Period (Validity Period) covering the full offering period.

**Challenge**: The application deadline (when applications close) is typically earlier than the period end date (which may cover the entire academic year the scholarship applies to). Users need the deadline for decision-making (WF6: "Should I apply? The deadline is in 2 days"). A3-1 (Fragmentation) identifies that scholarship deadlines are currently scattered and hard to find.

**Recommendation**: Add an Application Deadline (Date) attribute to Scholarship, separate from Application Period. The Application Period covers the full offering (announcement → award → completion), while Application Deadline is the specific date by which applications must be submitted.

**Severity**: High for user value. Application deadline is critical for the Make an Educational Decision workflow (WF6).

---

### Challenge C-4: Accreditation Record Immutability Confirmations

**Current state**: Topic 2 models Accreditation Records as immutable historical facts — each status change creates a new record.

**Challenge**: This topic's attribute analysis confirms that Accreditation Record has no mutable attributes (all are set at creation). However, OQ-D3-7 raises whether renewal should modify the existing record or create a new one. If renewal creates a new Accreditation Record (with status=Renewed and a new effective period), then the previous record remains as-is (status=Granted or Renewed, with its original period). This is clean but creates many records for long-standing programmes.

**Recommendation**: Confirm the immutable model. Each accreditation event (grant, interim grant, suspension, revocation, renewal, expiry) creates a new Accreditation Record. The entity's current accreditation status is always derived from the most recent record whose effective period includes today. This preserves a complete audit trail and avoids consistency risks.

**Severity**: Low. This confirms the existing model rather than challenging it. Recording as a decision.

---

## Domain Decisions

| ID | Decision | Rationale |
|----|----------|-----------|
| DD3-1 | **Every entity attribute is classified as identity, mutable, value object, derived, country-varying, or presentation.** No attribute exists in multiple categories simultaneously (an attribute is either stored or derived, either mutable or immutable, either ubiquitous language or presentation). | Clarity of the domain model. Each classification determines how the attribute is treated in implementation. |
| DD3-2 | **Derived attributes are never stored.** Accreditation status, admission status, and applicability are computed when needed. Their authoritative source is always the data from which they are derived. | Prevents dual-source inconsistency. The domain model has a single source of truth for each concept. |
| DD3-3 | **Country-varying values are reference data, not hard-coded domain structure.** Institution Type values, Award Level values, Admission Cycle phases, Authority Jurisdiction rules, and Qualification names are all data that varies by country. The value objects that contain them are domain concepts; the specific values are configuration. | Per F6, F7, F8, F9. The domain model remains valid across countries without structural changes. Only reference data is added. |
| DD3-4 | **Qualification Threshold replaces Cut-off Mark.** The domain concept of a minimum admission threshold is universal. "Cut-off mark" is Nigerian terminology for one specific type of Qualification Threshold (standardized assessment, comparator ≥). No separate value object is needed. | Per F11. Removing Cut-off Mark simplifies the model without losing domain expressiveness. |
| DD3-5 | **Value Objects are introduced only when they have domain meaning, express an invariant, group related concepts, or replace primitive obsession.** Thirteen domain-meaningful VOs and twelve enum-like VOs are proposed. Ten VOs are rejected with explicit rationale. | Per LBC pragmatic philosophy. No VO is introduced merely because it "could" exist. |
| DD3-6 | **Authority Jurisdiction is a Value Object on Education Authority.** Jurisdiction determines what an authority can accredit/regulate. It is set when the authority is established and rarely changes. It is defined by its attributes (type + criteria), not by identity. | Per F2, F5. Jurisdiction is a domain concept with structure (type + criteria) but no independent lifecycle. |
| DD3-7 | **Phase Sequence is a Value Object on Admission Cycle.** The ordered list of phases is set when the cycle is announced and never changes. It is defined by its contents (ordered list of phases), not by identity. | Per F9. Phases are data; sequential ordering (INV-C2) is the domain invariant. |
| DD3-8 | **Admission Rule and Eligibility Rule are distinct Value Objects.** Admission rules are qualification-centric (qualification + threshold + subjects). Eligibility rules include non-qualification criteria (geographic, demographic, financial need). Sharing an abstraction would be premature generalization. | Different structures serve different domain purposes. The overlap (qualification + threshold) is coincidental, not conceptual. |
| DD3-9 | **Monetary Amount groups amount + currency to prevent cross-currency comparison errors.** Tuition fees and scholarship values are expressed in specific currencies. Cross-currency conversion is not a domain concern. | Universal domain concept. Every educational system deals with costs in local currency. |
| DD3-10 | **Programme gains a Faculty attribute (simple string) for organizational context.** This addresses discoverability (C-2) without introducing a Faculty entity. If Faculty later needs identity or relationships, it can be promoted. | Minimal change addressing a real domain need (users search by faculty). Not a Topic 1 challenge — Faculty is an attribute, not an entity. |
| DD3-11 | **Scholarship gains an Application Deadline attribute (Date) separate from Application Period.** The deadline is the specific date by which applications close. The Application Period covers the full offering timeline. | Critical for WF6 (Make an Educational Decision). Addresses C-3. |

---

## Summary

### Entity Count
- **5 Aggregate Roots**: Educational Institution, Programme, Scholarship, Admission Cycle, Information Source
- **3 Child Entity Types**: Admission Policy, Eligibility Policy, Accreditation Record
- **3 Supporting Entities**: Qualification, Scholarship Provider, Education Authority
- **11 entities total** (unchanged from Topic 2 Revision)

### Value Object Count
- **13 Domain-Meaningful VOs**: Admission Rule, Eligibility Rule, Subject Combination, Qualification Threshold, Validity Period, Trust Signal, Institution Type, Award Level, Monetary Amount, Duration, Location, Authority Jurisdiction, Phase Sequence
- **12 Enum-like VOs**: Accreditation Status, Policy Status, Programme Status, Scholarship Status, Institution Status, Source Reliability, Information Category, Authority Type, Provider Type, Ownership Type, Delivery Mode, Qualification Status
- **10 Rejected VOs**: Cut-off Mark, Minimum Score, Grade, Institution Name, Programme Name, Contact Information, Admission Pathway, Educational Level, Currency, Accreditation Type
- **25 total proposed VOs**

### Attribute Statistics
- **Identity attributes**: 26 (across all entities)
- **Mutable attributes**: 23 (lifecycle states, renaming, URL changes, targeting)
- **Derived attributes**: 7 (accreditation status, admission status, applicability, isAdmissionOpen, isReliable, trust signal, eligibility status)
- **Country-varying attributes**: 15 (type values, award levels, qualifications, phases, jurisdictions, currencies, etc.)
- **Presentation-only attributes**: Excluded from domain model (logos, descriptions, marketing text, social links, rankings, UI concerns)

### New Attributes Added
- **Programme**: Faculty (string) — per DD3-10
- **Scholarship**: Application Deadline (Date) — per DD3-11

### Key Architectural Compliance
| Constraint | Compliance |
|-----------|------------|
| **Domain First** | All attributes discovered from the educational domain. No attribute exists for implementation convenience. Value objects express domain concepts, not storage patterns. |
| **Global Domain** | Nigeria-specific terminology replaced throughout (Education Authority, Qualification Threshold, authority-scoped identity, jurisdiction-based invariants). Country-varying values explicitly identified as reference data. |
| **Avoid Premature Generalization** | Admission Rule and Eligibility Rule kept separate (C-1). No "Policy Rule" abstraction. No "Educational Level" abstraction. No Admission Pathway entity (OQ-D3-1). |
| **Laravel Beyond CRUD** | No persistence, Eloquent, migration, API, or repository discussed. No database column modeling. Value objects preferred over unnecessary entities. Derived attributes not stored. Pragmatic VO introductions only. |

---

**Approval Required**: This topic requires explicit approval of:
- Entity-by-entity attribute classifications
- Proposed Value Objects (25 VOs)
- Rejected Value Objects (10 VOs with rationale)
- Attribute ownership decisions
- Derived vs stored decisions
- New assumptions (A-D3-1 through A-D3-8)
- Open questions (OQ-D3-1 through OQ-D3-8)
- Challenges to Topics 1 and 2 (C-1 through C-4)
- Domain decisions (DD3-1 through DD3-11)
