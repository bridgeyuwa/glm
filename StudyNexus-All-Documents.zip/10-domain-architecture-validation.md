# StudyNexus — Domain Architecture Validation & ADR Review
# Adversarial Review of Domain Architecture Document (18-domain-architecture.md)

**Date:** 2026-08-07
**Reviewer:** Architecture Validation Agent
**Subject:** StudyNexus Domain Architecture v1.0
**Method:** Adversarial review — every claim is challenged, every decision is pressure-tested, every omission is surfaced.
**Verdict:** READY WITH CONDITIONS — 4 must-fix corrections required before implementation

---

## 1. Review Method

This document applies an adversarial validation method to the StudyNexus Domain Architecture. The method is designed to find what the architecture gets wrong, omits, or paperes over — not to confirm what it gets right. Every architectural decision is treated as a hypothesis, not a conclusion.

### Validation Framework

| Phase | Purpose | Technique |
|-------|---------|-----------|
| **Consistency Check** | Find internal contradictions | Cross-reference claims between sections; identify where Section X says A and Section Y says ¬A |
| **Justification Test** | Challenge every "because" | For each decision, ask: Is the stated reason the *real* reason? Is it sufficient? Would the opposite decision be worse? |
| **Omission Detection** | Find what's missing | Walk the domain lifecycle; identify concerns not addressed |
| **Boundary Attack** | Test claimed boundaries | For each aggregate boundary, find the operation that crosses it and verify the architecture handles it |
| **Scale Pressure** | Apply growth scenarios | Test the architecture against 10× data, 3× features, 5× countries |
| **ADR Completeness** | Verify decision coverage | Every significant decision must have an ADR; identify decisions without ADRs |

### Review Scope

- 30 sections of the architecture document
- 14 proposed ADRs
- 23 Application Actions
- 5 Aggregate Roots
- 27 Value Objects
- 27 Domain Events
- 9 Spatie package decisions
- 2 Spatie package rejections
- All directory structure and namespace decisions

### Notation

| Symbol | Meaning |
|--------|---------|
| ✅ | Upheld — decision is correct and well-justified |
| ⚠️ | Condition — decision is correct but justification is insufficient or inconsistent |
| ❌ | Rejected — decision must be changed |
| 🔶 | Omission — something important is missing |
| 💡 | Recommendation — improvement that should be considered |

---

## 2. Laravel Beyond CRUD Validation

The architecture claims adherence to Laravel Beyond CRUD (LBC) philosophy. This section validates that claim against the original LBC principles as articulated by Brent Roose and Freek Van der Herten.

### LBC Core Principles vs StudyNexus Implementation

| LBC Principle | StudyNexus Implementation | Aligned? | Challenge |
|--------------|--------------------------|:--------:|-----------|
| **Domain operations as model methods** | Eloquent models have `establish()`, `suspend()`, `close()`, etc. | ✅ | Correct and well-implemented. Named methods are the LBC ideal. |
| **Actions for orchestration only** | 23 Actions listed | ⚠️ | LBC says "not every operation needs an Action." 23 Actions for 5 aggregates is high. The architecture contradicts itself: Section 6 lists operations that "NOT Need" Actions, yet the Action inventory includes ceremonial Actions (ReactivateInstitution, RenameInstitution) that apply the same logic. |
| **No repositories** | "No repositories for MVP" | ✅ | Correct LBC stance. Eloquent IS the repository. |
| **Domain events as facts** | 27 domain events via Laravel native events | ⚠️ | The `DomainEvent` interface is ceremonial — it adds no runtime value (see Section 24, SMELL-1). LBC doesn't mandate a domain event interface. |
| **Value objects as plain PHP** | Immutable PHP objects + custom casts | ✅ | Correct. LBC recommends this over package-based VOs. |
| **Eloquent as aggregate persistence** | Eloquent models contain domain behaviour | ⚠️ | The architecture says "Eloquent Model ≠ Aggregate Root by default" but then maps every aggregate 1:1 to an Eloquent model. This is contradictory rhetoric (see Section 5). |

### Verdict: 7/10 — LBC alignment

The architecture is substantively LBC-compliant but suffers from two credibility problems: (1) the contradiction between "Eloquent Model ≠ Aggregate Root" rhetoric and the 1:1 mapping reality, and (2) 23 Actions that exceed what LBC prescribes for orchestration-only Actions. The architecture should either reduce the Action count or honestly acknowledge that it's using a slightly stricter Action discipline than pure LBC.

---

## 3. Challenge the 23 Application Actions

The architecture lists 23 Actions. This section challenges each one against the architecture's own stated criteria: "An Action is worth having when the operation involves orchestration — more than one domain operation, validation step, or side effect."

### Action-by-Action Challenge

| # | Action | Stated Justification | Adversarial Challenge | Verdict |
|---|--------|---------------------|----------------------|---------|
| 1 | `CreateInstitution` | Authorization, jurisdiction validation, search index | Creates aggregate + validates + indexes. Genuine orchestration. | ✅ Keep |
| 2 | `RenameInstitution` | "Authorization, search index" | **Search index update is a domain event listener concern, not Action orchestration.** `Institution.rename()` dispatches `InstitutionRenamed` event; the `UpdateSearchIndex` listener already handles this. The Action adds authorization (a single `authorize()` call) and then calls `rename()`. This is exactly the pattern the architecture calls "NOT Needed" for other operations like `suspendAdmission`. | ❌ **Remove** |
| 3 | `SuspendInstitution` | Authorization, cascade notification | Needs cascade coordination (programme admission suspension). Genuine. | ✅ Keep |
| 4 | `ReactivateInstitution` | "Authorization, search inclusion" | **Single domain call + authorization. No cascade.** The `InstitutionReactivated` event handles search inclusion via listener. This is no more orchestration than `Programme::resumeAdmission()` which is listed under "NOT Needed." | ❌ **Remove** |
| 5 | `CloseInstitution` | Authorization, cascade to programmes, search exclusion | Significant cascade (programme discontinuation, scholarship flagging). Genuine. | ✅ Keep |
| 6 | `MergeInstitutions` | Authorization, transactional coordination, search rebuild | Most complex operation. Genuine. | ✅ Keep |
| 7 | `PublishAdmissionPolicy` | Authorization, cycle validation, rule validation, search update | Complex validation orchestration. Genuine. | ✅ Keep |
| 8 | `RecordAccreditation` | Authorization, jurisdiction guard, trust signal trigger | Guard + trigger pattern. Genuine. | ✅ Keep |
| 9 | `CreateProgramme` | Authorization, institution validation, award level guard | Multiple validations + creates aggregate. Genuine. | ✅ Keep |
| 10 | `DiscontinueProgramme` | Authorization, scholarship flag cascade | Cascade needed. Genuine. | ✅ Keep |
| 11 | `ReassignProgramme` | "Internal only (domain service)" | **Not an Action at all.** It has "No independent invocation" — it's called only by `InstitutionMerger`. This is an internal method on `Programme`, not an application use case. The architecture itself admits this. | ❌ **Remove** (see SMELL-2) |
| 12 | `AnnounceScholarship` | Authorization, provider validation | Moderate orchestration. Acceptable. | ✅ Keep |
| 13 | `OpenScholarshipApplications` | Authorization, policy check, notification | Notification trigger + policy check. Genuine. | ✅ Keep |
| 14 | `ExpireScholarship` | Scheduled (console/queue) | Time-based trigger. Genuine for scheduled context. | ✅ Keep |
| 15 | `TargetScholarshipProgrammes` | "Authorization, programme existence check" | **The "programme existence check" is a foreign key constraint, not application orchestration.** If a programme ID is invalid, the FK constraint fails. The Action wraps `Scholarship::targetProgrammes()` + authorization — no more orchestration than `Scholarship::withdraw()` which is listed as "NOT Needed." | ❌ **Remove** |
| 16 | `AnnounceAdmissionCycle` | "Authorization, authority validation" | **Moderate but no more orchestration than other "NOT needed" operations.** The "authority validation" is a FK constraint — the `defining_authority_id` must reference a valid `EducationAuthority`, which Eloquent's `belongsTo` relationship + FK enforce. The Action adds authorization + calls `AdmissionCycle::announce()`. Same pattern as `InformationSource::register()` which is kept — but the justification is thin. | ❌ **Remove** |
| 17 | `ActivateAdmissionCycle` | Authorization, read model update trigger | Read model coordination via events. Genuine enough. | ✅ Keep |
| 18 | `AdvanceAdmissionCyclePhase` | Authorization, notification dispatch | Notification trigger. Genuine. | ✅ Keep |
| 19 | `RegisterInformationSource` | Authorization, reference validation | Moderate. Acceptable. | ✅ Keep |
| 20 | `VerifyInformationSource` | Authorization, trust signal cascade trigger | Cascade trigger. Genuine. | ✅ Keep |
| 21 | `MarkSourceUnreliable` | Authorization, trust cascade | Cascade. Genuine. | ✅ Keep |
| 22 | `ImportInstitutionData` | Parsing, validation, deduplication, batch processing | Significant orchestration. Genuine. | ✅ Keep |
| 23 | `ExpireScholarships` (batch) | Time-based batch | Periodic batch. Genuine. | ✅ Keep |

### Summary: 4 Actions Should Be Removed

| Action to Remove | Why |
|------------------|-----|
| `RenameInstitution` | Search index update = event listener concern, not Action orchestration |
| `ReactivateInstitution` | Single domain call + auth. No cascade. |
| `AnnounceAdmissionCycle` | Authority validation = FK constraint, not orchestration |
| `TargetScholarshipProgrammes` | Programme existence = FK constraint, not orchestration |

Additionally, `ReassignProgramme` is not an Action (it's an internal domain method) and should be removed from the Action list entirely.

### The Inconsistency Problem

The architecture's "Actions NOT Needed" list includes `Programme::suspendAdmission()` / `Programme::resumeAdmission()` with the justification "single domain call + auth." But `ReactivateInstitution` is kept as an Action despite being exactly the same pattern: "single domain call + auth." The search index update for `ReactivateInstitution` is handled by the `InstitutionReactivated` event listener — the Action doesn't do it inline.

**This inconsistency must be resolved.** Either both patterns are Actions, or neither is. The principled stance is: if the search index update is handled by event listeners (as the architecture claims), then authorization + single domain call is not sufficient justification for an Action.

**Recommended Action count: 19** (23 − 4 removed − 1 not-an-Action + 1 `ActivateCycles` scheduled action from directory listing = 19)

---

## 4. Challenge the 5 Aggregate Roots

The architecture defines 5 aggregate roots: Institution, Programme, Scholarship, Admission Cycle, Information Source. This section challenges whether each boundary is correctly drawn.

### Aggregate Root Validation

| Aggregate | Boundary Challenge | Verdict |
|-----------|-------------------|---------|
| **Institution** | Should AdmissionPolicy be inside Institution or Programme? The architecture puts it in both (polymorphic). This is correct — an institution can publish its own admission policy (e.g., a general entry requirement) that applies across all programmes. The polymorphic design handles this without duplicating policy structure. | ✅ Correct |
| **Programme** | Should Programme be inside Institution as a child entity? The architecture makes it a separate aggregate root. This is correct because: (1) Programme has its own domain operations (`suspendAdmission`, `discontinue`, `recordAccreditation`), (2) Programme is reassigned during merge (cross-aggregate operation), (3) Programme's identity is independent — "BSc Computer Science at UNILAG" is not "BSc Computer Science at UNIBEN." | ✅ Correct |
| **Scholarship** | Should `targetProgrammeIds` and `targetInstitutionIds` be child entities instead of JSON arrays? The architecture uses JSON arrays of IDs. Challenge: If scholarships need to track *why* a programme was targeted, or if targeting has its own lifecycle (added/removed with reasons), the JSON array is insufficient. However, for MVP, targeting is a simple set operation with no metadata. JSON is acceptable. | ✅ Correct for MVP |
| **Admission Cycle** | Is Admission Cycle really an aggregate root, or is it a child entity of Education Authority? Challenge: An authority defines cycles, but the cycle has its own lifecycle (announce → activate → advancePhase → close → archive) and is referenced by Admission Policies across multiple programmes and institutions. Making it a child entity of EducationAuthority would create a god aggregate. Independent aggregate is correct. | ✅ Correct |
| **Information Source** | Is Information Source truly an aggregate root with invariants? The architecture claims INV-IS1 ("Cannot be simultaneously Verified and Unreliable"), but this is trivially enforced by the state machine (an enum can only hold one value). INV-IS2 ("Cannot verify a Deprecated source") is a guard clause, not a deep invariant. INV-IS3 ("Retrievable reference required") is a NOT NULL constraint. This aggregate has weak invariants — it could be a supporting entity. However, it has its own domain events with downstream impact (trust signal recalculation), and it is verified by humans (verification workflow), which gives it an autonomous lifecycle. Aggregate root is correct. | ✅ Correct |

### Cross-Aggregate Operations Check

| Operation | Crosses Boundaries? | How Handled | Correct? |
|-----------|:-------------------:|-------------|:--------:|
| Institution merge (programme reassignment) | Yes (Institution → Programme) | Domain service (InstitutionMerger) | ✅ |
| Institution suspension (programme cascade) | Yes (Institution → Programme) | Domain event (InstitutionSuspended) + listener | ✅ |
| Scholarship targeting (references Programme) | No (Scholarship holds IDs) | Unidirectional reference | ✅ |
| Admission Policy (references Cycle) | No (Policy holds cycle ID) | FK reference | ✅ |
| Trust signal recalculation | Yes (Source → all referencing entities) | Domain event + listener (eventual consistency) | ✅ |

### Verdict: All 5 aggregate boundaries are correctly drawn

The aggregate boundaries survive adversarial challenge. Each aggregate has: (1) at least one non-trivial invariant, (2) its own domain operations, (3) its own lifecycle, and (4) clear boundaries with other aggregates. The only note is that Information Source's invariants are weak, but its autonomous lifecycle justifies aggregate root status.

---

## 5. Challenge Eloquent-as-Aggregate-Persistence

### The Contradiction

The architecture states in Section 4:

> **"Eloquent Model ≠ Aggregate Root by default."**

Then immediately maps every aggregate root 1:1 to an Eloquent model:

| Aggregate Root | Eloquent Model | Mapping |
|---------------|----------------|---------|
| Institution | `Institution` (Eloquent) | 1:1 |
| Programme | `Programme` (Eloquent) | 1:1 |
| Scholarship | `Scholarship` (Eloquent) | 1:1 |
| Admission Cycle | `AdmissionCycle` (Eloquent) | 1:1 |
| Information Source | `InformationSource` (Eloquent) | 1:1 |

This is **contradictory rhetoric.** The architecture is doing exactly what it says it's not doing by default. Every aggregate root IS an Eloquent model. The disclaimer "≠ by default" is doing heavy lifting — it's saying "we're not making this a rule" while making it a rule for every single case.

### The Real Decision

The real decision is **Option C: Pragmatic Hybrid** — Eloquent models contain domain behaviour. This is the LBC position, and it's the right one for StudyNexus. The architecture should stop pretending it's not doing this and own the decision honestly.

The three options are:

| Option | Description | StudyNexus Reality |
|--------|-------------|-------------------|
| A: Separate Domain Entities | Domain classes + Repositories + mapping to Eloquent | ❌ Not what's happening |
| B: Eloquent Models with Anemic Setters | Eloquent models with `$fillable` + raw attribute assignment | ❌ Not what's happening |
| **C: Eloquent Models with Domain Methods** | Eloquent models with named domain operations that enforce invariants | ✅ **This is what's happening** |

### The Real Risk

There IS a genuine risk with Option C that the architecture understates:

1. **Mass assignment:** Eloquent's `$fillable` is a convention, not a compile-time guarantee. A developer can still call `$model->fill(['status' => 'closed'])` and bypass `close()`. The `$guarded = []` prohibition helps but doesn't prevent all mass assignment risks.
2. **Static facades:** `Institution::create([...])` bypasses `Institution::establish()`. There is no architectural mechanism preventing this.
3. **Active record pattern:** `$model->save()` can be called at any time, even after direct attribute manipulation. There is no "dirty check" that verifies state transitions went through named methods.
4. **Query scopes:** Eloquent scopes can load aggregates in intermediate states that aren't visible to the domain operations.

### Recommended Guardrails

The architecture's guardrails (fillable, named methods, code review discipline) are **necessary but insufficient.** Recommendation:

1. **Accept Option C** but document it honestly as the decision.
2. **Add a concrete enforcement mechanism** beyond "code review discipline":
   - Propose a custom PHPStan rule that flags direct status assignment on aggregate root models (e.g., `$institution->status = 'closed'` triggers a static analysis error).
   - Propose a custom PHPStan rule that flags `Model::create()` calls on aggregate root models (should use `Model::establish()` or equivalent).

```php
// Example: Custom PHPStan rule
// Forbid direct status assignment on aggregate roots
// $institution->status = InstitutionStatus::Closed;  // ❌ Static analysis error
// $institution->close();                             // ✅ Domain method
```

3. **Document the known seam:** If a future requirement demands separate domain entities (e.g., for CQRS with separate read/write models), the domain methods on Eloquent models provide a clean extraction point — each method becomes a method on a standalone domain entity, and the Eloquent model becomes a pure persistence class.

### Verdict: ⚠️ Correct decision, dishonest framing

The Eloquent-as-aggregate-persistence decision is correct for LBC and for StudyNexus. But the architecture needs to: (1) own Option C explicitly, (2) acknowledge the real risks, and (3) propose concrete enforcement beyond code review discipline.

---

## 6. Challenge the No-Repository Decision

### The Architecture's Position

Section 12 states: "No repositories for MVP. Eloquent IS the repository." This is the LBC position, and it's correct for StudyNexus's current state.

### Challenges Raised

| Challenge | Assessment |
|-----------|------------|
| **Testing without database** | The architecture says "Laravel's in-memory SQLite + factories suffice." This is correct — SQLite in-memory is fast enough for StudyNexus's scale. |
| **Complex query composition** | The architecture says "Query classes handle this." Correct — Query classes are the LBC equivalent of read-side repositories. |
| **Multiple persistence backends** | The architecture says "No — single PostgreSQL." Correct for MVP. |
| **Domain model ≠ persistence model** | The architecture says "No — Eloquent models ARE the aggregate persistence representation." This is where the challenge bites. |

### The Genuine Use Case: InstitutionMerger

The `InstitutionMerger` domain service loads Programme aggregates:

```php
class InstitutionMerger
{
    public function merge(Institution $initiating, Institution $target): void
    {
        // 2. Load all programmes belonging to target
        $programmes = Programme::where('institution_id', $target->id)->get();

        // 3. Reassign each programme to initiating institution
        foreach ($programmes as $programme) {
            $programme->reassignTo($initiating->id);
        }
        // ...
    }
}
```

The domain service directly calls `Programme::where('institution_id', ...)->get()`. This couples the domain service to Eloquent's query API. **If Programme's persistence becomes complex** (e.g., Value Object reconstruction from multiple tables, or Programme is split across partitions for performance), the domain service would need to change.

For now, this is acceptable because:
- Programme is a single table with VOs handled by Eloquent casts
- The query is simple (FK lookup)
- The domain service is already coupled to the database (it uses a DB transaction)

### Verdict: ✅ No repositories, but document the seam

The no-repository decision is correct for MVP. However, the architecture fails to identify the `InstitutionMerger` coupling as a known seam. Recommendation: Add a comment in `InstitutionMerger` documenting that `Programme::where(...)` is a persistence coupling point, and that if Programme's persistence becomes complex, this is the first place a repository would be introduced.

**No repositories. Document the InstitutionMerger coupling as a known seam.**

---

## 7. Challenge the 27 Value Objects

The architecture defines 27 Value Objects: 14 "domain-meaningful" (immutable PHP objects) and 13 "enum-like" (PHP backed enums). This section challenges whether each classification is correct.

### Enum-as-Value-Object Tension

**Three VOs should be challenged:**

#### 1. `InstitutionType` (PHP Enum) — ⚠️ Known limitation

The architecture classifies `InstitutionType` as a PHP backed enum with values like `University`, `Polytechnic`, `CollegeOfEducation`, `Monotechnic`, etc. The architecture's own principle P5 states "values are data" (F6, F7 in domain discovery). When a new institution type needs to be added (e.g., `InstituteOfTechnology` for a new country), it requires a **code change** (new enum case + deployment).

This conflicts with the "values are data" principle. In a reference data model, adding a new institution type would be a database insert — no code change, no deployment.

**However**, for MVP with known Nigerian types, enums are acceptable because:
- The set is small (5-8 types) and stable
- Enums provide type safety that reference data doesn't
- Enums match Eloquent casting naturally
- Adding a new type is a trivial code change (one line in the enum)

**Verdict:** Accept enums for MVP, but document this as a known limitation. When institution types start varying by country (e.g., Germany has `Fachhochschule` which isn't a 1:1 mapping), consider migrating to reference data with a validation table.

#### 2. `AwardLevel` (PHP Enum) — ⚠️ Same tension as InstitutionType

Same argument. `AwardLevel` has values like `Undergraduate`, `Postgraduate`, `Doctorate`, `Diploma`, `Certificate`. These are universal enough that the enum is stable, but some countries have non-standard award levels (e.g., `AssociateDegree` in the US, `HND` in Nigeria/UK).

**Verdict:** Same as InstitutionType — accept for MVP, document the limitation.

#### 3. `Duration` (Immutable PHP Object + Custom Cast) — ✅ Warranted

The architecture implements `Duration` as an immutable object with `value` (int) + `unit` (string). Challenge: Is this over-engineered? Could this be two simple database columns (`duration_value` int, `duration_unit` string)?

**Answer: The VO is warranted** because Duration has domain meaning:
- Comparison: Is a 4-year programme longer than a 48-month programme? (Normalisation between units)
- Validation: Is a duration of 0 valid? Is a duration of 20 years valid for an undergraduate programme?
- Presentation: "4 years" vs "48 months" — the VO knows how to present itself in the preferred unit.

Two bare columns would require this logic to be duplicated in every place duration is compared or presented.

**Verdict:** Keep as VO.

### All Other VOs

| VO | Strategy | Challenge | Verdict |
|----|----------|-----------|---------|
| Admission Rule | Immutable + JSON Cast | Complex structure; JSON is natural | ✅ |
| Eligibility Rule | Immutable + JSON Cast | Same pattern | ✅ |
| Subject Combination | Immutable + JSON Cast | Set of subjects; JSON is natural | ✅ |
| Qualification Threshold | Immutable + JSON Cast | Structured comparison data | ✅ |
| Validity Period | Immutable + Custom Cast (two columns) | Date range queries needed | ✅ |
| Trust Signal | Computed (never stored) | Correct — derived attribute | ✅ |
| Monetary Amount | Immutable + Custom Cast (two columns) | Numeric queries + currency filtering | ✅ |
| Location | Immutable + Custom Cast (three columns) | Geographic queries | ✅ |
| Authority Jurisdiction | Immutable + JSON Cast | Structured data | ✅ |
| Phase Sequence | Immutable + JSON Cast | Ordered list | ✅ |
| Admission Pathway | Immutable PHP Object | Demoted from entity; correct | ✅ |
| All 13 enum VOs (except InstitutionType, AwardLevel) | PHP Backed Enum | Fixed sets that are truly stable | ✅ |

### Verdict: 27 VOs are correct with minor enum tension

The 27 VOs are well-classified. The only concern is the `InstitutionType`/`AwardLevel` enum-vs-reference-data tension, which should be documented as a known limitation. All other VOs are correctly implemented.

---

## 8. Spatie Package Architecture Review

The architecture evaluates 16 Spatie packages. This section challenges the adoption timing.

### Package-by-Package Review

| Package | Architecture Decision | Challenge | Recommended Decision |
|---------|---------------------|-----------|---------------------|
| `laravel-permission` | Adopt now | ✅ Correct. RBAC is needed from day 1. | Adopt now |
| `laravel-medialibrary` | Adopt now | ✅ Correct. Institution logos needed early. | Adopt now |
| `laravel-activitylog` | Adopt now | ✅ Correct. Audit trail is cross-cutting. | Adopt now |
| `laravel-sluggable` | Adopt now | ✅ Correct. SEO URLs needed from day 1. | Adopt now |
| `laravel-query-builder` | Adopt now | ✅ Correct. API/query filtering needed early. | Adopt now |
| `laravel-data` | Adopt now | ✅ Correct. DTOs are needed for Actions and API. | Adopt now |
| `laravel-model-states` | Reject | ✅ Correct rejection. See Section 10. | Reject |
| `laravel-settings` | Adopt later | ✅ Correct. No settings need for MVP. | Adopt later |
| `laravel-sitemap` | **Adopt now** | **❌ Incorrect timing.** There are no public pages in the earliest MVP iteration. The admin panel (Filament) doesn't need sitemaps. Sitemaps are needed when public institution/programme/scholarship pages go live. Adopting now means configuring a package that generates sitemaps for zero pages. | **Adopt when public pages exist** |
| `schema-org` | **Adopt now** | **⚠️ Similar timing concern.** Schema.org markup is only useful on public detail pages. If MVP starts with admin-only, this is premature. However, if the first iteration includes any public pages, it's correct. | **Adopt when public pages exist** |
| `laravel-backup` | **Adopt now** | **❌ Incorrect timing.** There is no production database to back up until there's a production deployment. In local development, database backups are unnecessary (you have migrations + seeders). In CI, the database is ephemeral. Adopting now means configuring a package that runs backup commands against a development database. | **Adopt when deploying to production** |
| `laravel-schedule-monitor` | Adopt later | ✅ Correct. Not needed until scheduler is active. | Adopt later |
| `laravel-newsletter` | Evaluate when feature arrives | ✅ Correct. | Same |
| `laravel-fractal` | Reject | ✅ Correct. Superseded by laravel-data. | Reject |
| `laravel-tags` | Evaluate when feature arrives | ✅ Correct. | Same |
| `laravel-comments` | Evaluate when feature arrives | ✅ Correct. | Same |
| `laravel-feed` | Evaluate when feature arrives | ✅ Correct. | Same |

### Phase Correction

| Original Phase | Package | Corrected Phase | Reason |
|---------------|---------|----------------|--------|
| Phase 1 (Adopt Now) | `laravel-backup` | **Phase 1.5 (Adopt when deploying to production)** | No production database to back up until production deployment |
| Phase 1 (Adopt Now) | `laravel-sitemap` | **Phase 1.5 (Adopt when public pages exist)** | No public pages to include in sitemap until public UI is built |
| Phase 1 (Adopt Now) | `schema-org` | **Phase 1.5 (Adopt when public pages exist)** | Schema.org is only useful on public pages |

### Verdict: 8/10 — Timing corrections needed for 2-3 packages

The package selection is correct. The timing is wrong for `laravel-backup` and `laravel-sitemap`. `schema-org` depends on whether the earliest MVP iteration includes public pages.

---

## 9. Challenge Spatie Laravel Data

The architecture correctly identifies that Laravel Data should be used for application-layer DTOs, not domain Value Objects. This section challenges whether the architecture provides sufficient concrete guidance.

### The Five-Type Problem

The architecture identifies 5 distinct types in the StudyNexus codebase:

| Type | Purpose | Location | Example |
|------|---------|----------|---------|
| Form Request | HTTP input validation | `app/Http/Requests/` | `StoreInstitutionRequest` |
| Data DTO | Request→domain and domain→response transformation | `app/Data/` | `InstitutionData` |
| Domain VO | Domain equality semantics, immutability | `app/Domain/ValueObjects/` | `MonetaryAmount` |
| Eloquent Model | Persistence + domain operations | `app/Domain/Models/` | `Institution` |
| Read Model | Query-optimized projections | `app/Queries/` | `GetInstitutionDetails` |

The architecture says "Domain VOs = plain immutable PHP objects with Eloquent casts. DTOs = Spatie Laravel Data objects. Never the same class." This is correct but **doesn't give concrete examples of where Laravel Data is used in the application flow.**

### Concrete Examples (Missing from Architecture)

The architecture should add these concrete examples:

#### 1. ImportInstitutionData — Data Ingestion DTO

```php
// app/Data/ImportData/InstitutionImportRow.php
class InstitutionImportRow extends Data
{
    public function __construct(
        public string $official_name,
        public string $institution_type,
        public string $registration_identifier,
        public ?string $country_code,
        public ?string $city,
        // ... CSV/Excel column mapping
    ) {}

    // Validation rules for import data (different from web form validation)
    public static function rules(): array
    {
        return [
            'official_name' => ['required', 'string', 'min:2'],
            'institution_type' => ['required', 'string', 'in:university,polytechnic,college_of_education'],
            // ...
        ];
    }
}
```

This DTO maps import row data (CSV/Excel) to the application layer. It validates import data differently from web form data (import may have different field names, different required fields, different error handling).

#### 2. InstitutionData — API Response DTO

```php
// app/Data/InstitutionData.php
class InstitutionData extends Data
{
    public function __construct(
        public string $official_name,
        public string $institution_type,
        public string $status,
        public ?LocationData $location,
        public ?string $website_url,
        // Lazy-loaded relations
        #[Lazy]
        public ?ProgrammeCollection $programmes,
    ) {}

    public static function fromModel(Institution $institution): self
    {
        return new self(
            official_name: $institution->official_name,
            institution_type: $institution->institution_type->value,
            status: $institution->status->value,
            location: $institution->location ? LocationData::from($institution->location) : null,
            website_url: $institution->website_url,
            programmes: ProgrammeCollection::from($institution->programmes),
        );
    }
}
```

#### 3. StoreInstitutionRequest — FormRequest Replacement

```php
// Using Data as FormRequest replacement (Laravel Data supports this)
class StoreInstitutionData extends Data
{
    public function __construct(
        #[Rule('required|string|min:2')]
        public string $official_name,
        #[Rule('required|in:university,polytechnic,college_of_education')]
        public string $institution_type,
        // ...
    ) {}
}

// In controller/Livewire:
public function store(StoreInstitutionData $data)
{
    app(CreateInstitution::class)->execute($data);
}
```

### The Boundary Between Data DTO and Domain VO

The architecture correctly says "never the same class," but should add a decision rule:

> **If it has `fromRequest()` or `toResponse()`, it's a DTO (Laravel Data). If it has `equals()` or domain comparison logic, it's a VO (plain PHP). If it has both, split it.**

### Verdict: ⚠️ Correct principle, insufficient concrete guidance

The architecture should add concrete examples of Data DTO usage in the import, API response, and form request contexts. The boundary rule between DTO and VO should be made explicit.

---

## 10. Challenge Model States Rejection

The architecture rejects `spatie/laravel-model-states` with the rationale:

> "State machines are simple enough with PHP enums + named transition methods. `laravel-model-states` adds a layer of indirection (State, Transition, StateConfig classes) that is not justified when each aggregate has at most 5 states and 3-4 transitions."

### Challenge: Does the Package Offer Anything We're Missing?

| Feature | PHP Enums + Named Methods | laravel-model-states |
|---------|--------------------------|---------------------|
| State representation | Enum cases | State classes |
| Transition definition | Named methods on model | Transition classes with `from()` / `to()` |
| Transition validation | Guard clauses in methods | Automatic — package enforces |
| Queryability | `where('status', 'suspended')` | `InState::is(States\Suspended::class)` |
| Explicitness | Implicit — you must read the methods | Explicit — `StateConfig` is a declarative map |
| Audit trail | Manual (activity log in each method) | Optional transition recording |

### The One Genuine Advantage

`laravel-model-states` makes state transitions **explicit and queryable.** With the package, you can see all possible transitions in one place (the `StateConfig` class). With named methods, you must read every method on the model to understand the state machine.

For example, `InstitutionStatus` has 3 states and these transitions:
```
Operational → Suspended → Operational (reactivate)
Operational → Closed (terminal)
```

With named methods, this is implicit — you'd need to read `suspend()`, `reactivate()`, and `close()` to reconstruct the state machine. With `laravel-model-states`, it's explicit in a `StateConfig`.

### Why Rejection Is Still Correct

For StudyNexus's simple state machines (3-5 states, 2-4 transitions each), the cost of the indirection outweighs the benefit:

1. **5 aggregate roots × 1 StateConfig each = 5 extra classes** that do nothing a developer can't see by reading the model.
2. **The State classes add a namespace explosion** — `States\Operational`, `States\Suspended`, `States\Closed` for Institution alone, then Programme states, Scholarship states, etc.
3. **The Transition classes are trivial** — each is a `canTransition()` method that duplicates the guard clause already in the domain method.
4. **Laravel's enum casting makes querying trivial** — `where('status', InstitutionStatus::Suspended)` is already clear.

### Recommendation

Rejection upheld. However, the architecture should acknowledge the trade-off: it's choosing **readability-by-convention** (named methods) over **readability-by-declaration** (StateConfig). If any state machine becomes complex (7+ states, 6+ transitions, conditional transitions), reconsider the package for that aggregate only.

**Verdict: ✅ Rejection is correct.** The architecture should add a one-sentence acknowledgment of the explicitness trade-off.

---

## 11. Filament Architecture Review

### What Filament Does Well

The architecture's Filament boundary is well-drawn:

1. ✅ Filament Resources invoke Actions, not direct model manipulation
2. ✅ Filament must not implement business rules
3. ✅ Filament must not bypass aggregate operations
4. ✅ Filament must not define value objects

### Challenges

| Challenge | Assessment |
|-----------|------------|
| **Filament Resource form schemas duplicate VO structure** | The `InstitutionResource` form schema must mirror the domain attributes (official_name, institution_type, location, etc.). If a domain attribute changes (e.g., `official_name` is renamed to `legal_name`), the Filament form schema must also change. This is a presentation concern, not a domain concern, so it's acceptable — but the architecture should acknowledge this as a known synchronization point. |
| **Filament's `save()` method is a bypass risk** | A developer can define a Filament form that directly saves model attributes without invoking an Action. The architecture says "must invoke Actions," but this is a convention, not an enforcement. The risk is the same as R2 in the risk register. |
| **Filament Resource count: 8 Resources** | Institution, Programme, Scholarship, AdmissionCycle, InformationSource, Qualification, ScholarshipProvider, EducationAuthority. The last 3 are simple CRUD (supporting entities). This is correct — Filament is the right tool for supporting entity management. |
| **Filament custom pages** | The architecture only lists a Dashboard page. What about merge confirmation, import review, verification workflows? These require custom Filament pages that invoke Actions. The architecture should list these. |

### Missing Filament Custom Pages

| Custom Page | Purpose | Invokes Action |
|-------------|---------|---------------|
| MergeInstitutionPage | Merge confirmation with before/after preview | `MergeInstitutions` |
| ImportReviewPage | Review import results before committing | `ImportInstitutionData` |
| VerificationDashboard | Pending verifications queue | `VerifyInformationSource` |

### Verdict: 8/10 — Boundary is correct, missing custom page specifications

The Filament boundary is well-drawn. The architecture should add custom page specifications for non-CRUD admin workflows.

---

## 12. Livewire + Flux Architecture Review

### Boundary Assessment

The architecture's Livewire boundary is correct:

1. ✅ Livewire components must not enforce aggregate invariants
2. ✅ Livewire components must not perform domain transitions
3. ✅ Livewire components must not contain domain calculations
4. ✅ Livewire components must not dispatch domain events
5. ✅ Livewire components must not directly access the database for writes

### Challenges

| Challenge | Assessment |
|-----------|------------|
| **Livewire component count seems low** | 8 public + 4 authenticated = 12 components. For a discovery platform, this seems light. Where is the faceted filter component? The pagination component? The "save to favourites" component? The architecture lists `ProgrammeSearch` but doesn't break down the filter/sort/pagination sub-components. |
| **Livewire component size risk** | `ProgrammeSearch` handles query, country, awardLevel, and presumably many more filters. This could become a "god component" if all filter state, search logic, and rendering are in one class. The architecture should specify a component composition strategy. |
| **Flux component boundary** | The architecture mentions Flux for "UI primitives" but doesn't specify the boundary between Flux components and custom Blade components. When does a component become "too domain-specific" for Flux? |

### Component Composition Strategy (Missing)

```php
// ProgrammeSearch should compose sub-components
class ProgrammeSearch extends Component
{
    public string $query = '';

    // Composed sub-components handle their own state
    // <livewire:programme-search.filter-bar :filters="$filters" />
    // <livewire:programme-search.result-list :programmes="$programmes" />
    // <livewire:programme-search.pagination :meta="$meta" />
}
```

### Verdict: 8/10 — Boundary correct, composition strategy missing

The Livewire boundary is well-drawn. The architecture should add: (1) component composition guidelines, (2) a more complete component inventory including filter/pagination sub-components, (3) Flux vs custom Blade component boundary.

---

## 13. Public Website vs Application UI

The architecture defines two UIs: Filament (admin) and Livewire (public/authenticated). This section challenges whether this separation is sufficient.

### The Missing Third UI: API

The architecture mentions `routes/api.php` ("if needed later") but doesn't define the API boundary. If StudyNexus needs a public API (for mobile apps, partner integrations, or the future Application Management bounded context), the architecture needs to define:

1. **API authentication** — Laravel Sanctum? API tokens?
2. **API versioning** — URI versioning (`/api/v1/`) or header versioning?
3. **API response format** — Laravel Data for API resources? JSON:API spec?
4. **API rate limiting** — Per-user? Per-IP?
5. **API documentation** — OpenAPI/Swagger generation?

For MVP, the API can be deferred. But the architecture should acknowledge this as a missing section and state when it will be addressed.

### The Public vs Authenticated Boundary

The architecture separates Livewire into `Public/` and `Authenticated/` directories. This is correct. However, some components may need to work in both contexts (e.g., `ProgrammeDetail` shows different actions depending on whether the user is logged in). The architecture doesn't address this.

**Recommendation:** Add a rule: "Public components may conditionally render authenticated features using `@auth` directives. They must not import from `app/Livewire/Authenticated/`."

### SEO-Critical vs Interactive Pages

Not all public pages have the same SEO requirements. The architecture should distinguish:

| Page Type | SEO Priority | Rendering Strategy |
|-----------|:------------:|-------------------|
| Institution/Programme/Scholarship detail | **High** | Server-rendered Blade + Livewire for interactive elements |
| Search/filter results | **Medium** | Livewire with crawlable URLs |
| User dashboard/saved items | **None** | Full Livewire (no SEO needed) |
| Comparison interface | **Low** | Livewire (comparison URLs aren't SEO targets) |

### Verdict: 🔶 API boundary is missing; public/authenticated overlap unaddressed

The architecture should add an API boundary section (even if deferred) and clarify the public/authenticated rendering overlap.

---

## 14. Search Boundary Review

### Architecture Position

Section 11 states: "Search Is Infrastructure, Not Domain." This is correct and important.

### Challenges

| Challenge | Assessment |
|-----------|------------|
| **Typesense vs PostgreSQL FTS decision is deferred** | The architecture says "MVP: Database Queries + Meilisearch/Typesense" but doesn't make a decision. This is acceptable for architecture level — the decision belongs in ADR-6. But ADR-6 should be more specific: what is the trigger for switching from PostgreSQL FTS to Typesense? (e.g., "when full-text search requires typo-tolerance or faceted navigation beyond PostgreSQL's capabilities") |
| **Search index update timing** | Domain events → listeners → search index updates. This is eventual consistency. The architecture doesn't specify the lag tolerance. For a discovery platform, how stale can search results be? 1 second? 1 minute? 1 hour? This affects whether listeners are synchronous or queued. |
| **Search document structure** | What fields are in the search document? The architecture doesn't define this. For example, a Programme search document should include: programme name, institution name, country, award level, admission status, tuition fee, accreditation status. Some of these come from different aggregates (institution name from Institution, accreditation from AccreditationRecord). The search document is a denormalized projection — the architecture should specify its structure. |
| **Search reindexing after merge** | When two institutions are merged, all programmes from both institutions need search document updates. The `InstitutionsMerged` event triggers a search rebuild, but the architecture doesn't specify whether this is synchronous (slow for large institutions) or asynchronous (queued). |

### Search Document Structure (Missing)

```php
// Proposed: Programme Search Document
[
    'id' => 'prog_123',
    'programme_name' => 'BSc Computer Science',
    'institution_name' => 'University of Lagos',
    'institution_type' => 'university',
    'country_code' => 'NG',
    'country_name' => 'Nigeria',
    'region' => 'Lagos',
    'award_level' => 'undergraduate',
    'admission_mode' => 'cyclic',
    'delivery_mode' => 'onsite',
    'is_admitting' => true,           // read model
    'accreditation_status' => 'full',  // read model
    'tuition_amount' => 150000,        // for sorting
    'tuition_currency' => 'NGN',
    'trust_signal' => 0.85,            // computed
    'scholarship_count' => 3,          // denormalized
]
```

### Verdict: 7/10 — Search boundary is correct, but missing concrete specifications

The "search is infrastructure" principle is correct. The architecture should add: (1) search document structure, (2) lag tolerance, (3) reindexing strategy for merge operations.

---

## 15. Provenance Architecture Review

The architecture implements provenance as a layered concern:

| Layer | Mechanism | Verdict |
|-------|-----------|---------|
| Domain | `source_id` FK on child entities | ✅ Correct — provenance is a domain attribute |
| Application | Spatie Activity Log | ✅ Correct — operational audit |
| Infrastructure | Eloquent timestamps | ✅ Correct — technical audit |
| Read Model | Trust Signal computation | ✅ Correct — derived quality metric |

### Challenges

| Challenge | Assessment |
|-----------|------------|
| **source_id is only on child entities** | Correct — not every entity is sourced. Admission Cycle phases are administrative, not sourced. The architecture explicitly says "No Eloquent trait for provenance." |
| **Trust Signal computation timing** | The architecture says "event-driven recalculation." But when a source is marked unreliable, ALL entities referencing that source need their trust signals recalculated. This could be a heavy operation. The architecture doesn't specify: (1) is this synchronous or queued? (2) is it batched? (3) what's the cascade depth? |
| **Provenance for imported data** | When data is imported via `ImportInstitutionData`, the import source should be recorded as the `source_id`. The architecture mentions import but doesn't specify how provenance is tracked for imported records. |

### Verdict: 8/10 — Provenance architecture is well-designed

The layered approach is correct. The architecture should specify: (1) trust signal recalculation strategy for bulk source unreliability, (2) provenance tracking for imported data.

---

## 16. Global Expansion Test

The architecture tests against 9 countries and claims "zero structural changes required." This section pressure-tests that claim.

### Country-by-Country Challenge

| Country | Architecture Claim | Adversarial Challenge | Result |
|---------|-------------------|----------------------|--------|
| Nigeria | Zero changes; initial dataset | ✅ No challenge — this is the baseline | Pass |
| Ghana | Zero changes; reference data | ✅ GTEC = Education Authority, WAEC = shared | Pass |
| Kenya | Zero changes; reference data | ✅ CUE = Education Authority | Pass |
| South Africa | Zero changes; mixed admission modes | ⚠️ SA has `Universities of Technology` — is this a new `InstitutionType` enum case or reference data? If enum, requires code change. | **Pass with enum tension** |
| UK | Zero changes; UCAS = Admission Cycle | ✅ UCAS is an Education Authority + Admission Cycle. Clearing = a phase within the cycle. | Pass |
| USA | Zero changes; Early Decision = Admission Pathway | ⚠️ US has `Community College` (2-year) — is this a new `InstitutionType`? US has `Associate Degree` — new `AwardLevel`? Both require enum changes. | **Pass with enum tension** |
| Canada | Zero changes; similar to US | ✅ Same as US | Pass |
| Germany | Zero changes; two intakes = Multiple-Intake | ⚠️ Germany has `Fachhochschule` (University of Applied Sciences) — new `InstitutionType`? Germany has `Diplom` — new `AwardLevel`? | **Pass with enum tension** |
| Australia | Zero changes; Multiple-Intake | ✅ Similar to UK pattern | Pass |

### The Enum Tension Reappears

Three countries (South Africa, USA, Germany) require new `InstitutionType` or `AwardLevel` values that aren't in the current enum. This confirms the Section 7 finding: **InstitutionType and AwardLevel as PHP enums is a known limitation for global expansion.**

For each new country, the required changes are:

| Country | New InstitutionType Values | New AwardLevel Values | Change Type |
|---------|---------------------------|----------------------|-------------|
| South Africa | UniversityOfTechnology | — | Code change (new enum case) |
| USA | CommunityCollege | AssociateDegree | Code change (2 new enum cases) |
| Germany | Fachhochschule | Diplom | Code change (2 new enum cases) |

If these were reference data, the changes would be database inserts (no code change, no deployment). For MVP with Nigeria-only data, this is acceptable. For global expansion, the architecture should document this as a migration trigger: "When adding the 4th+ country, evaluate migrating InstitutionType and AwardLevel from enums to reference data."

### The Deeper Global Challenge: Admission Rules

The architecture assumes that `AdmissionRule` as a VO is sufficiently flexible for all countries. But admission rules vary significantly:

- **Nigeria:** UTME score + subject combination + post-UTME score
- **UK:** A-level grades + personal statement + interview
- **USA:** GPA + SAT/ACT score + extracurriculars + essay

The `AdmissionRule` VO with `qualification_threshold` + `subject_combination` handles the Nigerian and UK patterns. The US pattern (GPA, extracurriculars, essay) is harder to express — but these are *requirements*, not rules that StudyNexus enforces. StudyNexus records admission policies; it doesn't evaluate applications against them. So the flexibility of `AdmissionRule` is about **data capture**, not **rule evaluation**.

**Verdict:** The architecture is correct — `AdmissionRule` as a flexible JSON VO can capture any admission policy structure. The presentation layer handles the differences in how rules are displayed.

### Verdict: 9/10 — Zero structural changes confirmed, with documented enum tension

The global expansion claim holds. The only friction points are `InstitutionType` and `AwardLevel` enum additions, which are trivial code changes (not structural changes). The architecture should document the enum-to-reference-data migration trigger.

---

## 17. Identify Future Bounded Contexts

The architecture identifies 5 deferred bounded contexts:

1. Application Management
2. Credential Assessment
3. Immigration & Mobility
4. Student Services
5. Financial Services

### Challenge: Are These the Right BCs?

| Proposed BC | Challenge | Assessment |
|-------------|-----------|------------|
| Application Management | ✅ Clear BC — students applying through StudyNexus. Has its own aggregate root (Application), its own invariants, its own lifecycle. | Correct |
| Credential Assessment | ✅ Clear BC — comparing qualifications across national systems. | Correct |
| Immigration & Mobility | ⚠️ Is this one BC or two? Visa requirements (Immigration) and travel/mobility services may have different rates of change. | Consider splitting |
| Student Services | ⚠️ This is a grab bag. Accommodation, travel, support services have different domain models. "Student Services" might be 3 BCs, not 1. | Over-broad |
| Financial Services | ✅ Clear BC — payments, currency, loans. | Correct |

### Missing BCs

| Missing BC | Why It's Needed | Trigger |
|------------|----------------|--------|
| **Content Management** | Blog posts, guides, country profiles, editorial content. This is distinct from the entity data managed in the core domain. | When editorial content is needed for SEO |
| **Analytics & Reporting** | Usage analytics, search analytics, conversion tracking. This is a read-only BC that consumes events from the core. | When product decisions need data |
| **Notification & Communication** | Email, SMS, push notifications. Currently handled by event listeners, but as notification complexity grows (templates, preferences, delivery tracking), it warrants its own BC. | When notification preferences or delivery tracking are needed |

### BC Extraction Seam Check

The architecture claims "refactor seams exist for future context extraction." Are these seams real?

| Seam | How It Would Work | Difficulty |
|------|-------------------|------------|
| Namespace separation | `App\Domain\*` → separate package | Medium — domain models are self-contained |
| Event-driven communication | Domain events become inter-BC messages | Low — events are already decoupled |
| Action isolation | Actions become API calls to new BC | Medium — Actions orchestrate within a transaction |
| Query independence | Queries read from search index, not DB | Low — queries are already read-only |

### Verdict: 8/10 — BCs are correctly identified with minor gaps

The 5 deferred BCs are reasonable. The architecture should: (1) consider splitting Student Services, (2) add Content Management and Analytics BCs, (3) verify that namespace separation provides real extraction seams (it does, with medium difficulty).

---

## 18. Testing Architecture

### Architecture Position

The architecture defines 4 testing layers: Domain (unit), Application (feature), Presentation (browser), Integration (end-to-end). Domain tests are highest priority.

### Challenges

| Challenge | Assessment |
|-----------|------------|
| **Domain unit tests "without DB"** | The architecture says "Domain logic (invariant checks, state transitions) can be tested on unsaved model instances." This is correct for most operations, but Eloquent models that use relationships (e.g., `hasActivePolicyForCycle()`) require database queries. These can't be unit-tested without a DB. The architecture should distinguish between: (1) pure domain logic (testable without DB), and (2) domain logic that queries relationships (requires DB). |
| **Action test coverage** | 23 Actions × 1 test each = 23 feature tests. Plus negative tests (unauthorized, invalid state). This is ~50-70 feature tests. Is this too many? No — each Action is a single use case with clear test scenarios. The volume is acceptable. |
| **Event listener testing** | The architecture doesn't specify how event listeners are tested. Listeners are infrastructure-coupled (search index, notifications) and should be tested with integration tests, not feature tests. |
| **Test data factories** | The architecture mentions factories but doesn't specify factory complexity. With 5 aggregate roots + 3 child entities + 3 supporting entities + 27 VOs, factory definitions are non-trivial. The architecture should specify factory strategy. |
| **Browser testing scope** | The architecture lists Livewire tests in `Browser/` but doesn't specify scope. Which components need browser tests? All 12? Or just the critical search + detail flows? |

### Factory Strategy (Missing)

```php
// Institution factory with VO support
class InstitutionFactory extends Factory
{
    public function definition(): array
    {
        return [
            'official_name' => fake()->company() . ' University',
            'institution_type' => InstitutionType::University,
            'registration_identifier' => fake()->unique()->regexify('[A-Z]{3}/[0-9]{4}'),
            'status' => InstitutionStatus::Operational,
            'ownership_type' => OwnershipType::Public,
            'country_code' => 'NG',
            // VOs set via cast-compatible raw values
            'amount' => 150000,
            'currency' => 'NGN',
        ];
    }

    // State modifiers for domain operations
    public function suspended(): static
    {
        return $this->state(['status' => InstitutionStatus::Suspended]);
    }

    public function closed(): static
    {
        return $this->state(['status' => InstitutionStatus::Closed]);
    }
}
```

### Test Priority Matrix

| Priority | Test Type | Count (est.) | Why |
|:--------:|-----------|:------------:|-----|
| 1 | Domain invariant tests | ~30 | Protect business rules |
| 2 | Domain state transition tests | ~20 | Verify state machines |
| 3 | Action feature tests | ~50 | Verify use case orchestration |
| 4 | Query tests | ~15 | Verify read models |
| 5 | Event listener tests | ~10 | Verify side effects |
| 6 | Livewire component tests | ~12 | Verify user interactions |
| 7 | Integration tests | ~5 | Verify search, import |

### Verdict: 8/10 — Testing architecture is solid, missing factory strategy and listener testing guidance

---

## 19. Security and Authorization

### Architecture Position

The architecture uses Spatie `laravel-permission` for RBAC and Laravel Policies for authorization. Actions call `$this->authorize()` before domain operations.

### Challenges

| Challenge | Assessment |
|-----------|------------|
| **Role model** | The architecture doesn't define the role model. What roles exist? Admin, Staff, User? What permissions does each role have? This is a gap — the authorization architecture is incomplete without a role/permission model. |
| **Policy registration** | 5 Policies are listed (Institution, Programme, Scholarship, AdmissionCycle, InformationSource). But no Policy logic is defined. What can a Staff user do vs an Admin? Can a User close an institution? (No — only Admin.) |
| **Filament authorization** | Filament has its own authorization system (gate checks on Resources). The architecture should specify how Filament authorization integrates with Spatie Permission and Laravel Policies. |
| **API authorization** | If a public API is added later, how are API consumers authorized? Sanctum tokens with scoped permissions? |
| **Domain-level authorization** | The architecture puts authorization in Actions (application layer). But some authorization is domain-level: e.g., "Only the institution's owner can rename it." If ownership matters, it's a domain concern, not just an application policy. For MVP (single-tenant admin), this isn't an issue. For multi-tenant, it would be. |

### Proposed Role Model (Missing)

| Role | Permissions | Scope |
|------|------------|-------|
| Super Admin | All operations | All entities |
| Admin | Create, update, suspend, reactivate, close | All entities |
| Data Manager | Create, update, import, verify | Institutions, Programmes, Sources |
| Content Editor | Publish policies, update descriptions | Programmes, Scholarships |
| Viewer | Read only | All entities (public data) |

### Verdict: 🔶 6/10 — Authorization framework is chosen, but role/permission model is undefined

The architecture should define the role model and Policy logic before implementation. Without this, the `$this->authorize()` calls in Actions are aspirational — they have no implementation.

---

## 20. Performance Architecture

### 🔶 MAJOR OMISSION: No Performance Architecture Section

The architecture document has no dedicated performance section. This is a significant omission for a platform that could serve millions of pages (SEO-critical) and handle search queries across potentially 100K+ programmes.

### Missing Performance Concerns

| Concern | Impact | Architecture Gap |
|---------|--------|-----------------|
| **Caching strategy** | Read model queries (isAdmitting, getTrustSignal) are called frequently and could benefit from caching. No caching strategy defined. | 🔶 Missing |
| **N+1 query risk** | The Educational Opportunity read model composes data from Institution + Programme + Scholarship + Accreditation. Without eager loading, this creates N+1 queries. The architecture mentions "cached Eloquent query with eager loading" but doesn't specify the eager loading strategy. | ⚠️ Mentioned but underspecified |
| **Search index freshness** | Domain events → listeners → search index. If listeners are queued, search results may be stale. No lag tolerance specified. | 🔶 Missing |
| **Database indexing** | The architecture mentions indexing on polymorphic columns but doesn't provide a complete index strategy. | 🔶 Missing |
| **Query performance for faceted navigation** | Faceted navigation requires counting results per facet value. With PostgreSQL, this is a GROUP BY query. With Typesense, it's built-in. No performance comparison. | 🔶 Missing |
| **Read model materialization** | The Opportunity read model could be materialized (pre-computed) for performance. The architecture says "cached query with TTL" for MVP and "search index document" for scale. When is the trigger to switch? | ⚠️ Partially addressed |

### Proposed Caching Strategy (Missing)

| Cache Key | Data | TTL | Invalidation |
|-----------|------|-----|-------------|
| `institution:{id}:details` | Institution details with programmes | 5 minutes | Domain event listener |
| `programme:{id}:admitting` | isAdmitting result | 1 minute | AdmissionCycle event, Programme event |
| `opportunity:feed:{filters_hash}` | Opportunity feed page | 5 minutes | Any domain event in filter scope |
| `trust:signal:{source_id}` | Trust signal value | 15 minutes | InformationSource event |
| `search:programmes:{query_hash}` | Search results | 30 seconds | Not cached (search engine handles) |

### Proposed Database Index Strategy (Missing)

```sql
-- Core indexes beyond PK and FK
CREATE INDEX idx_institutions_status_country ON institutions (status, country_code);
CREATE INDEX idx_programmes_status_institution ON programmes (status, institution_id);
CREATE INDEX idx_scholarships_status_deadline ON scholarships (status, application_deadline);
CREATE INDEX idx_admission_policies_governed ON admission_policies (governed_entity_type, governed_entity_id, admission_cycle_id);
CREATE INDEX idx_accreditation_records_accreditable ON accreditation_records (accreditable_type, accreditable_id);
```

### Verdict: 🔶 7/10 — No dedicated performance section; caching and indexing strategies are missing

The architecture should add a Performance Architecture section covering caching, indexing, eager loading, and scalability triggers.

---

## 21. SEO Architecture

### Architecture Position

Section 24 provides a thorough SEO architecture: server-rendered HTML, Schema.org, sitemaps, canonical URLs, crawlable faceted navigation.

### Challenges

| Challenge | Assessment |
|-----------|------------|
| **Sitemap timing** | As noted in Section 8, `laravel-sitemap` should be "Adopt when public pages exist," not "Adopt now." |
| **Schema.org complexity** | The architecture shows a simple `Schema::course()` example, but real Schema.org for educational institutions is complex: `EducationalOrganization` → `CollegeOrUniversity`, with nested `Program` (note: not `Course`), `Offer`, `AggregateRating`, etc. The architecture should provide a more complete Schema.org mapping. |
| **Faceted navigation noindex rules** | The architecture says "No-indexed for low-value or near-duplicate combinations" but doesn't define what constitutes "low-value." For example, is `/programmes?country=ng&type=university` indexable (high-value) but `/programmes?country=ng&type=university&delivery=onsite&level=undergraduate&sort=name` noindexable (near-duplicate)? A rule is needed. |
| **Page load performance** | SEO depends on page load speed. Livewire's initial render is server-side (fast), but subsequent interactions load JS. The architecture should specify: Core Web Vitals targets, Livewire lazy-loading strategy, Tailwind CSS purging. |
| **International SEO** | If StudyNexus serves multiple countries, does it use hreflang tags? Country-specific subdomains (ng.studynexus.com) or subdirectories (studynexus.com/ng/)? The architecture doesn't address international SEO. |

### Verdict: 9/10 — SEO architecture is thorough

The architecture's SEO section is one of its strongest. Minor gaps: Schema.org mapping completeness, faceted navigation noindex rules, international SEO, and Core Web Vitals targets.

---

## 22. Data Ingestion Architecture

### 🔶 MAJOR OMISSION: No Data Ingestion Architecture Section

Data ingestion is mentioned only in passing:
- `ImportInstitutionData` Action (1 of 23 Actions)
- `ImportInstitutionData.php` in the directory structure
- `ImportInstitutionData` DTO in the Data directory

But there is no section that describes:
1. **Import sources** — Where does institution data come from? JAMB? NUC? Manual entry? Web scraping?
2. **Import formats** — CSV? Excel? JSON? API?
3. **Import validation** — How are import rows validated? What happens with invalid rows?
4. **Deduplication** — How are duplicate institutions detected? By registration_identifier? By name similarity?
5. **Import conflict resolution** — When imported data conflicts with existing data, which wins?
6. **Import provenance** — How is the Information Source recorded for imported data?
7. **Batch processing** — How are large imports (1000+ institutions) processed? Queued? Chunked?
8. **Import error handling** — Partial success (some rows valid, some invalid) or all-or-nothing?
9. **Import monitoring** — How is import progress tracked? How are errors reported?

### Proposed Data Ingestion Architecture (Missing)

```
Import Flow:
1. Upload/trigger import source (CSV, Excel, API)
2. Parse rows → ImportInstitutionData DTOs (validation per row)
3. Deduplicate against existing records (registration_identifier match)
4. For new records: CreateInstitution Action
5. For existing records: Update strategy (skip, overwrite, merge)
6. Record provenance (source_id from import)
7. Log import results (rows processed, created, updated, errors)
```

### Why This Matters

Data ingestion is not a minor feature — it's the **primary way StudyNexus gets its data.** Without institutions, programmes, and scholarships in the database, there's nothing to search or display. The architecture treats data ingestion as "just another Action," but it has unique concerns (validation, deduplication, conflict resolution, provenance) that warrant a dedicated section.

### Verdict: 🔶 6/10 — Data ingestion is critically underspecified

The architecture must add a Data Ingestion Architecture section before implementation.

---

## 23. Admin Data Management

### Architecture Position

Filament handles admin data management: CRUD for supporting entities, Action-invoking forms for aggregate roots, verification workflows, import management, dashboards.

### Challenges

| Challenge | Assessment |
|-----------|------------|
| **Bulk operations** | The architecture doesn't address bulk admin operations. Can an admin suspend 10 institutions at once? Can they import 100 programmes? Bulk operations need Action support (e.g., `SuspendInstitutions` batch Action) or Filament bulk actions that invoke Actions per-record. |
| **Data export** | Can admins export data? (e.g., export all Nigerian universities as CSV). Filament supports export, but the architecture doesn't specify export format or scope. |
| **Admin audit trail** | Spatie Activity Log records "who did what, when." But the architecture doesn't specify: (1) retention policy (how long are logs kept?), (2) log volume (with 23 Actions, each creating an activity log entry, log volume grows quickly), (3) log cleanup (scheduled cleanup of old logs?). |
| **Admin vs Staff permissions** | As noted in Section 19, the role/permission model is undefined. Admin data management depends on this. |

### Verdict: 7/10 — Admin architecture is adequate for MVP, missing bulk operations and export

---

## 24. Architectural Smell Detection

This section identifies architectural smells — code structures that indicate design problems even if they "work."

### SMELL-1: Ceremonial DomainEvent Interface

**Location:** Section 8, Domain Event contract

```php
interface DomainEvent
{
    public function eventType(): string;
    public function aggregateId(): string;
    public function aggregateType(): string;
    public function occurredAt(): DateTimeImmutable;
}
```

**The Smell:** Laravel events don't need to implement an interface to be dispatched. The `Event` facade or `event()` helper dispatches any object. The interface adds zero runtime value — no Laravel mechanism checks for it, no listener requires it, no test depends on it.

**What it costs:**
- Every domain event class must implement 4 methods that could be derived from the class itself (e.g., `eventType()` returns the class name, `occurredAt()` returns a timestamp set in the constructor).
- It creates a false sense of architectural rigour — developers may think the interface provides enforcement when it provides nothing.
- It adds boilerplate to every event class.

**Options:**
1. **Remove the interface** — Events are plain PHP classes. Listeners type-hint the specific event class.
2. **Replace with a trait** — `DomainEventTrait` provides default implementations of the 4 methods. Events `use DomainEventTrait` instead of `implements DomainEvent`.
3. **Keep but justify** — If there's a concrete benefit (e.g., a generic event handler that processes any `DomainEvent`), document it.

**Recommendation:** Remove the interface or replace with a trait. If no generic handler exists that processes `DomainEvent` polymorphically, the interface is pure ceremony.

### SMELL-2: ReassignProgramme Listed as an Action

**Location:** Section 6, Action Inventory

The `ReassignProgramme` Action is listed with:
- Entry Points: "Domain service only"
- Justification: "No independent invocation"

**The Smell:** An Action with "No independent invocation" is not an Action. By the architecture's own definition, Actions represent application use cases with entry points (HTTP, console, queue, API). If `ReassignProgramme` is only called by `InstitutionMerger`, it's an internal domain method, not an application Action.

**Recommendation:** Remove from Action list. `Programme::reassignTo()` is a domain method called by the domain service.

### SMELL-3: Inconsistent Action Justification

**Location:** Sections 6 and "Actions NOT Needed"

The architecture keeps `RenameInstitution` as an Action because "search index needed." But `Programme::suspendAdmission()` / `Programme::resumeAdmission()` are listed as "NOT Needed" — and both of these operations also trigger search index updates (via `ProgrammeAdmissionSuspended` and `ProgrammeAdmissionResumed` events).

**The Smell:** The same justification (search index update) is sufficient to keep `RenameInstitution` as an Action but insufficient to keep `SuspendAdmission`/`ResumeAdmission` as Actions. This is inconsistent.

**Root cause:** Search index updates are handled by domain event listeners, not by Actions. The `RenameInstitution` Action's search index update is redundant — the `InstitutionRenamed` event listener already handles it. The Action doesn't need to exist for the search index to be updated.

**Recommendation:** Reconcile the justification. If search index updates are handled by event listeners (as the architecture claims in the event flow diagram), then "search index update" is not a valid justification for an Action. Remove `RenameInstitution` (and `ReactivateInstitution`) as Actions.

### SMELL-4: Namespace Inconsistency

**Location:** Section 4 mapping table vs Section 26 directory structure

The mapping table in Section 4 uses `App\Models\Institution` namespace:

```
| Educational Institution | App\Models\Institution | institutions | ...
```

But the directory structure in Section 26 uses `App\Domain\Models\Institution`:

```
app/
    Domain/
        Models/
            Institution.php
```

**The Smell:** Two different namespaces for the same class. Which is correct?

The directory structure in Section 26 is correct — the architecture chose `Domain/Models/` to keep domain concepts together. But the mapping table in Section 4 uses the Laravel default `App\Models\` namespace.

**Recommendation:** Fix the mapping table to use `App\Domain\Models\Institution` (and all other models). This is a documentation inconsistency, but it could confuse implementers.

### SMELL-5: "Code Review Discipline" as Enforcement

**Location:** Section 20, Enforcement

The architecture says: "Code review discipline is the primary enforcement mechanism for a small team."

**The Smell:** Code review discipline is not an enforcement mechanism — it's a social convention. It depends on: (1) reviewers knowing the rules, (2) reviewers consistently catching violations, (3) no time pressure causing shortcuts. For a small team under delivery pressure, code review discipline degrades.

**Recommendation:** As noted in Section 5, add a concrete enforcement mechanism: custom PHPStan rules that flag architectural violations. Code review discipline is a supplement, not a replacement.

### Smell Summary

| Smell | Severity | Fix Difficulty | Verdict |
|-------|:--------:|:--------------:|---------|
| SMELL-1: DomainEvent interface | Low | Easy (remove or replace with trait) | Fix before implementation |
| SMELL-2: ReassignProgramme as Action | Low | Easy (remove from list) | Fix before implementation |
| SMELL-3: Inconsistent Action justification | Medium | Medium (reconcile and remove Actions) | Fix before implementation |
| SMELL-4: Namespace inconsistency | Low | Easy (fix mapping table) | Fix before implementation |
| SMELL-5: Code review as enforcement | Medium | Medium (add PHPStan rules) | Fix during implementation |

---

## 25. ADR Review

The architecture proposes 14 ADRs (ADR-1 through ADR-14), all in "Proposed" status.

### ADR-by-ADR Assessment

| ADR | Title | Assessment | Challenge |
|-----|-------|------------|-----------|
| ADR-1 | Eloquent Model as Aggregate Root Persistence | ⚠️ Decision is correct but framing is dishonest (see Section 5). ADR should state "Option C: Eloquent models contain domain behaviour" explicitly. | Reframe honestly |
| ADR-2 | Action Pattern Adoption | ⚠️ 23 Actions is too many. ADR should specify the Action criteria more precisely and acknowledge that 4 Actions should be removed. | Reduce to 19 Actions |
| ADR-3 | Domain Event Implementation | ⚠️ Should address whether domain events implement a base interface. Currently the DomainEvent interface is ceremonial. | Add sub-decision: interface vs trait vs none |
| ADR-4 | Value Object Persistence | ⚠️ This ADR is too broad. The JSON-vs-columns decision for each VO is significant enough to warrant sub-decisions. For example: "Why is AdmissionRule stored as JSON but MonetaryAmount as separate columns?" — these are independent decisions. | Split into sub-decisions |
| ADR-5 | Read Model Strategy | ✅ Clear and well-justified. | No change |
| ADR-6 | Search Engine Selection | ✅ Correct to defer the Typesense vs PostgreSQL FTS decision. But ADR should specify the trigger for switching. | Add trigger |
| ADR-7 | Spatie Package Adoption | ⚠️ Timing is wrong for `laravel-backup` and `laravel-sitemap` (see Section 8). | Fix timing |
| ADR-8 | Filament vs Custom Admin | ✅ Correct decision. Filament for admin is the right call. | No change |
| ADR-9 | Bounded Context Implementation | ✅ Single app with namespace separation is correct for MVP. | No change |
| ADR-10 | Namespace and Directory Structure | ⚠️ The mapping table uses `App\Models\*` but the directory structure uses `App\Domain\Models\*`. Inconsistency. | Fix mapping table |
| ADR-11 | Polymorphic vs Separate Tables | ✅ Correct for Admission Policy and Accreditation Record. | No change |
| ADR-12 | Repository Decision | ✅ Correct — no repositories. But should document InstitutionMerger coupling. | Add known seam |
| ADR-13 | Reference Data Management | ✅ Correct. | No change |
| ADR-14 | Testing Strategy | ✅ Correct — domain tests highest priority. | No change |

### Missing ADRs

| ADR | Title | Why It's Needed | Impact |
|-----|-------|----------------|--------|
| **ADR-15** | InstitutionType and AwardLevel: Enum vs Reference Data | This is a real decision that affects extensibility. The architecture chooses enums but doesn't acknowledge the trade-off (code change vs data change for new types). | Medium — affects global expansion |
| **ADR-16** | Domain Event Interface Contract | Whether domain events implement a base interface, use a trait, or are plain classes. This is a concrete decision that affects every event class. | Low — affects boilerplate |
| **ADR-17** | Caching and Performance Strategy | No caching strategy is defined. This is a significant infrastructure decision. | High — affects production readiness |
| **ADR-18** | Data Ingestion Architecture | How data is imported, validated, deduplicated. This is a core operational concern. | High — affects MVP launch |

### ADR Status Issue

All 14 ADRs are in "Proposed" status. This is fine pre-implementation, but the architecture should define the ADR approval process:
1. Who approves ADRs? (Architecture owner? Team consensus?)
2. What is the approval criteria? (No unresolved challenges? All alternatives evaluated?)
3. Can ADRs be superseded? (Yes — by later ADRs with new information)

### Verdict: 7/10 — ADRs cover the main decisions, but 4 are missing and 4 need corrections

---

## 26. Final Architecture Scorecard

This scorecard is honest. The architecture is good — but it is not perfect, and pretending otherwise serves no one.

| Criterion | Score | Justification |
|-----------|:-----:|--------------|
| **LBC alignment** | 8/10 | Substantively LBC-compliant but 23 Actions exceeds LBC's orchestration-only prescription, and the "Eloquent ≠ Aggregate" rhetoric is contradicted by the 1:1 mapping |
| **Domain integrity** | 9/10 | Solid invariants, correct aggregate boundaries, minor inconsistency in Action justification |
| **Pragmatism** | 7/10 | 23 Actions is too many (should be 19); DomainEvent interface is ceremonial; some VO over-engineering (InstitutionType/AwardLevel as enums when they're really reference data); no-repository decision is correct but seam is undocumented |
| **Global extensibility** | 9/10 | 9 countries tested with zero structural changes; enum tension documented; Admission Rule flexibility confirmed |
| **Maintainability** | 8/10 | Clean namespace separation; Action pattern provides clear use case entry points; risk of Action proliferation if discipline slips |
| **Testability** | 8/10 | Domain unit tests prioritized; factory strategy missing; event listener testing unspecified |
| **TALL-stack fit** | 9/10 | Server-rendered for SEO, Livewire for interactivity, Filament for admin — correct choices |
| **Filament integration** | 8/10 | Boundary well-drawn but missing custom page specifications (merge, import, verification) |
| **Spatie integration** | 8/10 | Package selection correct; timing wrong for laravel-backup and laravel-sitemap |
| **SEO suitability** | 9/10 | Thorough SEO architecture; Schema.org, sitemaps, canonical URLs, crawlable faceted navigation |
| **Performance scalability** | 7/10 | No caching strategy defined; no database index strategy defined; no eager loading strategy defined; search index lag tolerance unspecified |
| **Data ingestion** | 6/10 | Missing from architecture — only mentioned as 1 of 23 Actions. No section covering import sources, formats, validation, deduplication, conflict resolution, or provenance tracking |
| **Study Abroad extensibility** | 8/10 | Correctly defers Study Abroad BCs; existing domain supports most concerns; enum tension for new institution types |
| **Complexity control** | 7/10 | 27 VOs, 23 Actions, 27 events — high surface area for a small team. Each concept is justified individually, but the aggregate complexity is substantial. The architecture should acknowledge this. |

### Overall Score: 7.9/10

The architecture is **good but not excellent.** Its strengths are: correct aggregate boundaries, solid invariant protection, correct LBC philosophy, strong SEO architecture, and genuine global extensibility. Its weaknesses are: Action over-proliferation, missing Data Ingestion and Performance sections, ceremonial DomainEvent interface, inconsistent Action justification, and namespace inconsistency.

---

## 27. Required Corrections

### MUST FIX (before implementation begins)

| # | Correction | Section | Effort | Evidence |
|---|-----------|--------|--------|----------|
| MF-1 | **Fix namespace inconsistency** — Change mapping table (Section 4) from `App\Models\*` to `App\Domain\Models\*` to match directory structure (Section 26) | SMELL-4 | 30 min | Section 4 uses `App\Models\Institution`; Section 26 uses `app/Domain/Models/Institution.php` |
| MF-2 | **Remove or justify DomainEvent interface** — Either remove the `DomainEvent` interface (events are plain PHP classes) or replace with a `DomainEventTrait` that provides default implementations, or justify with a concrete benefit (e.g., "a generic event handler processes any DomainEvent polymorphically") | SMELL-1 | 1 hour | No Laravel mechanism checks for the interface; no listener requires it |
| MF-3 | **Remove ReassignProgramme from Action list** — It has "No independent invocation" and is only called by `InstitutionMerger`. It's a domain method (`Programme::reassignTo()`), not an Action | SMELL-2 | 15 min | Listed with "Domain service only" entry point |
| MF-4 | **Reconcile Action justification** — Search index update cannot be both sufficient justification (for `RenameInstitution`) and insufficient justification (for `SuspendAdmission`/`ResumeAdmission`). If search index updates are handled by event listeners, "search index update" is not a valid Action justification. Remove `RenameInstitution` and `ReactivateInstitution` as Actions | SMELL-3 | 1 hour | `InstitutionRenamed` event → `UpdateSearchIndex` listener already handles the index update |

### SHOULD FIX (before or during early implementation)

| # | Correction | Section | Effort |
|---|-----------|--------|--------|
| SF-1 | **Reduce Actions from 23 to 19** — Remove 4 ceremonial Actions: `RenameInstitution`, `ReactivateInstitution`, `AnnounceAdmissionCycle`, `TargetScholarshipProgrammes` | Section 3 | 2 hours |
| SF-2 | **Change `laravel-backup` to "Adopt when deploying to production"** — No production database to back up until production deployment | Section 8 | 15 min |
| SF-3 | **Change `laravel-sitemap` to "Adopt when public pages exist"** — No public pages in earliest MVP iteration | Section 8 | 15 min |
| SF-4 | **Add Data Ingestion architecture section** — Import sources, formats, validation, deduplication, conflict resolution, provenance tracking, batch processing, error handling | Section 22 | 4 hours |
| SF-5 | **Add Performance/Caching architecture section** — Caching strategy, database indexing, eager loading strategy, scalability triggers | Section 20 | 3 hours |
| SF-6 | **Document InstitutionType/AwardLevel enum-vs-reference-data tension** — Acknowledge that adding new types requires code changes, and define the migration trigger (when adding 4th+ country) | Section 7 | 30 min |

### CAN DEFER (during implementation or post-MVP)

| # | Correction | Section | Effort |
|---|-----------|--------|--------|
| CD-1 | **Add ADR-15 for InstitutionType/AwardLevel decision** — Document the enum-vs-reference-data trade-off | Section 25 | 1 hour |
| CD-2 | **Add ADR-16 for DomainEvent interface decision** — Interface vs trait vs plain class | Section 25 | 30 min |
| CD-3 | **Add ADR-17 for Caching/Performance strategy** — Define caching approach | Section 25 | 2 hours |
| CD-4 | **Add ADR-18 for Data Ingestion architecture** — Define import approach | Section 25 | 2 hours |
| CD-5 | **Add custom PHPStan rules for domain isolation** — Flag direct status assignment, `Model::create()` on aggregates | Section 5 | 4 hours |
| CD-6 | **Add concrete Laravel Data examples** — ImportInstitutionData, InstitutionData, StoreInstitutionData | Section 9 | 1 hour |
| CD-7 | **Define admin role/permission model** — Roles, permissions, Policy logic | Section 19 | 2 hours |
| CD-8 | **Add Filament custom page specifications** — Merge, import, verification pages | Section 11 | 1 hour |

### DO NOT CHANGE

| Decision | Section | Why |
|----------|---------|-----|
| No-repository decision | Section 6 | Correct for MVP. Document InstitutionMerger coupling as known seam. |
| Eloquent-as-aggregate-persistence | Section 5 | Correct for LBC. Reframe as Option C honestly; add enforcement mechanism. |
| TALL stack | Section 13 | Correct for SEO, simplicity, team velocity. |
| Filament boundary | Section 11 | Correct — Filament for admin, domain rules outside Filament. |
| `laravel-model-states` rejection | Section 10 | Correct — simple state machines don't justify the indirection. |
| 5 aggregate root boundaries | Section 4 | All 5 boundaries survive adversarial challenge. |
| 27 Value Objects | Section 7 | Correct with minor enum tension documented. |
| `laravel-data` for DTOs only | Section 9 | Correct — VOs are plain PHP; DTOs are Laravel Data. Never the same class. |

---

## 28. Architectural Freeze Proposal

### What to Freeze

The following architectural decisions are **frozen** — they must not be revisited unless a concrete, demonstrated need emerges during implementation:

| # | Frozen Decision | Rationale | Unfreeze Trigger |
|---|----------------|-----------|------------------|
| F-1 | 5 aggregate root boundaries | Survived adversarial challenge; all boundaries are correct | New aggregate root with genuine invariants |
| F-2 | No repositories | Correct for MVP; InstitutionMerger coupling documented | Programme persistence requires complex reconstruction |
| F-3 | Eloquent models as aggregate persistence (Option C) | Pragmatic LBC choice; enforcement mechanism added | CQRS requires separate domain entities |
| F-4 | TALL stack (no SPA) | SEO-critical; team velocity; simplicity | Team composition change to frontend specialists |
| F-5 | Filament for admin | Correct boundary; domain rules outside Filament | Admin UI needs exceed Filament's capabilities |
| F-6 | `laravel-model-states` rejection | Simple state machines don't justify indirection | Any state machine exceeds 7 states or 6 transitions |
| F-7 | `laravel-data` for DTOs only | VOs are plain PHP; DTOs are Laravel Data | Spatie Data adds VO-like features (unlikely) |
| F-8 | 27 Value Objects (with enum tension documented) | Correct classification; minor limitation noted | New country requires 3+ enum changes |
| F-9 | Domain events via Laravel native events | Correct — no event sourcing; events as business facts | Audit requirements demand event sourcing |
| F-10 | Single bounded context for MVP | Pragmatic; namespace separation provides seams | Extraction justified by team scaling or deployment needs |

### What Remains Unfrozen

These decisions may be revisited during implementation if evidence warrants:

| # | Unfrozen Decision | Current Position | Revisit Trigger |
|---|-------------------|-----------------|-----------------|
| U-1 | Action count | 23 (should be 19) | Implementation reveals orchestration needs |
| U-2 | DomainEvent interface | Present (ceremonial) | If generic event handler is needed |
| U-3 | InstitutionType/AwardLevel as enums | Enums (with tension documented) | 4th+ country addition |
| U-4 | Search engine | Typesense (deferred decision) | Performance testing results |
| U-5 | Caching strategy | Undefined | Production performance requirements |
| U-6 | Data ingestion architecture | Undefined (1 Action only) | First import implementation |
| U-7 | Admin role/permission model | Undefined | First admin user creation |

### Freeze Enforcement

- Frozen decisions require a **formal ADR supersession** to change. The superseding ADR must cite concrete evidence (production incident, performance data, user feedback) — not theoretical concerns.
- Unfrozen decisions can be changed by **team consensus** with a brief written rationale.
- This freeze proposal is effective immediately and remains in force until the architecture validation is re-run (after MVP delivery or after 3 months, whichever comes first).

---

## 29. Implementation Readiness

### Readiness Checklist

| # | Check | Status | Blocker? | Notes |
|---|-------|:------:|:--------:|-------|
| 1 | Aggregate boundaries defined | ✅ | No | All 5 boundaries survived challenge |
| 2 | Invariants specified | ✅ | No | 22 invariants across 5 aggregates |
| 3 | Domain operations specified | ✅ | No | Named methods on each aggregate |
| 4 | Value Objects classified | ✅ | No | 27 VOs with implementation strategy |
| 5 | Domain events enumerated | ✅ | No | 27 events with listeners |
| 6 | Actions identified | ⚠️ | **Yes** | 23 Actions should be 19; 4 must be removed |
| 7 | Read models specified | ✅ | No | 7 queries with implementation approach |
| 8 | Directory structure defined | ⚠️ | **Yes** | Namespace inconsistency must be fixed |
| 9 | Spatie packages evaluated | ⚠️ | No | Timing corrections needed (not blocking) |
| 10 | ADRs drafted | ⚠️ | No | 14 proposed; 4 missing (not blocking for MVP) |
| 11 | Testing strategy defined | ✅ | No | 4 layers with domain highest priority |
| 12 | SEO architecture defined | ✅ | No | Thorough coverage |
| 13 | Dependency direction defined | ✅ | No | Clear layering with constraints |
| 14 | Filament boundary defined | ✅ | No | Well-drawn boundary |
| 15 | Livewire boundary defined | ✅ | No | Well-drawn boundary |
| 16 | Global extensibility tested | ✅ | No | 9 countries, 0 structural changes |
| 17 | Performance architecture | ❌ | No | Missing but not blocking for MVP |
| 18 | Data ingestion architecture | ❌ | No | Missing but partially addressed by Import Action |
| 19 | Security/authorization model | ❌ | No | Role model undefined but Spatie Permission chosen |
| 20 | Namespace consistency | ❌ | **Yes** | Must fix before code generation |

### Must-Fix Blockers (3)

These must be resolved before writing implementation code:

1. **MF-1: Fix namespace inconsistency** — `App\Models\*` vs `App\Domain\Models\*`. This will cause incorrect namespace imports in generated code.
2. **MF-3: Remove ReassignProgramme from Action list** — It's not an Action; keeping it creates confusion.
3. **MF-4: Reconcile Action justification and remove ceremonial Actions** — The inconsistent justification (search index = sufficient for RenameInstitution but insufficient for SuspendAdmission) will cause ongoing confusion about when to create Actions.

Additionally, **MF-2 (DomainEvent interface)** should be resolved before event classes are generated, but it's not strictly blocking — the interface can be removed later with a find-and-replace.

### Verdict: READY WITH CONDITIONS

```
┌──────────────────────────────────────────────────────────┐
│                                                          │
│   IMPLEMENTATION READINESS: READY WITH CONDITIONS        │
│                                                          │
│   3 must-fix corrections required before coding begins   │
│   6 should-fix corrections recommended                   │
│   8 can-defer corrections for later                      │
│                                                          │
│   Overall Architecture Score: 7.9/10                     │
│                                                          │
│   Strongest: Domain integrity (9/10), Global ext (9/10)  │
│   Weakest:   Data ingestion (6/10), Pragmatism (7/10)   │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

### Implementation Order Recommendation

| Phase | What to Build | Dependencies | Corrections Required |
|:-----:|--------------|-------------|---------------------|
| **0** | Fix architecture document | None | MF-1, MF-2, MF-3, MF-4 |
| **1** | Domain models + VOs + enums | Phase 0 | SF-6 (enum tension doc) |
| **2** | Migrations + factories | Phase 1 | SF-5 (index strategy) |
| **3** | Domain events + listeners | Phase 1 | MF-2 (interface decision) |
| **4** | Actions (19, not 23) | Phase 1, 3 | SF-1 (reduce Actions) |
| **5** | Spatie package integration | Phase 1 | SF-2, SF-3 (timing fixes) |
| **6** | Filament admin | Phase 4, 5 | CD-7 (role model), CD-8 (custom pages) |
| **7** | Data ingestion | Phase 4, 5 | SF-4 (ingestion architecture) |
| **8** | Livewire public UI | Phase 4, 5 | None |
| **9** | SEO implementation | Phase 8 | None |
| **10** | Performance optimization | Phase 8 | SF-5 (caching strategy) |

### Final Statement

The StudyNexus Domain Architecture is a **well-designed, pragmatic architecture** that correctly applies Laravel Beyond CRUD principles to a real domain. Its aggregate boundaries are sound, its invariants are expressible, and its global extensibility is genuine — not aspirational.

However, the architecture suffers from four credibility problems that undermine confidence in its decisions:

1. **Contradictory rhetoric** — claiming "Eloquent ≠ Aggregate" while mapping 1:1
2. **Action over-proliferation** — 23 Actions where 19 would suffice, with inconsistent justification
3. **Ceremonial abstractions** — the DomainEvent interface adds no value
4. **Missing sections** — Data Ingestion and Performance are too important to omit

Once these corrections are made, the architecture is ready for implementation. The corrections are straightforward and can be completed in a single focused session.

**The architecture is 95% right. The remaining 5% matters.**

---

*End of Domain Architecture Validation & ADR Review*
