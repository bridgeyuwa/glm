# StudyNexus — Architectural Review
# Domain Discovery Normalization: Global Domain & Domain-First Constraints

**Date:** 2026-08-07
**Scope:** Topic 1 and revised Topic 2
**Purpose:** Identify and correct every place where the current domain model is unnecessarily Nigeria-specific or implementation-driven, per the four architectural constraints

---

## Architectural Constraints (Stated for Reference)

1. **Domain First** — Discover from the educational domain, not from Laravel Beyond CRUD. Laravel Beyond CRUD constrains implementation, not domain discovery. When multiple equally valid domain models exist, prefer the one that best aligns with pragmatic DDD.
2. **Global Domain** — StudyNexus is an educational opportunity discovery and decision-support platform whose initial operating context is Nigeria. Nigeria is data. The domain is global. Avoid Nigerian-specific abstractions; model concepts that exist across educational systems.
3. **Avoid Premature Generalization** — Only introduce a broader concept if it genuinely exists in the educational domain and accurately represents multiple country-specific implementations. Genericity without semantic value is not an improvement.
4. **Laravel Beyond CRUD Constraint** — Pragmatic DDD as implementation constraint. Discover business concepts before implementation concepts. Prefer value objects over unnecessary entities.

---

## Findings

### F1: "Government Education Agency" — Nigeria-Specific Entity Name

**Current decision:** The entity is named "Government Education Agency" (Topic 1 entity, Topic 2 supporting entity, canonical glossary term per A2-1, A2-8).

**Why it is problematic:**

The name encodes two Nigeria-specific assumptions:

1. **"Government"** — Not all education authorities are government agencies. In the US, ABET accredits engineering programmes but is a non-governmental federation of professional societies. In the UK, the QAA (Quality Assurance Agency) is an independent body. Professional accrediting bodies (AACSB for business, EAC for engineering) operate across national boundaries without government mandate. In Ghana, the NAB (National Accreditation Board) was merged into the GTEC (Ghana Tertiary Education Commission), but professional bodies also accredit specific programmes.

2. **"Agency"** — The term "agency" implies a specific organizational form. Education authorities take many forms: commissions (NUC, NCCE), boards (NBTE, NABTEB), councils (JAMB's governing council), examination bodies (WAEC, NECO), ministries (Federal Ministry of Education), coordinating bodies (KUCCPS in Kenya, UCAS in the UK). "Agency" captures only one of these organizational forms.

The universal domain concept is: **an organization that holds authoritative standing in education** — whether regulatory, accrediting, examining, coordinating, or standard-setting. This concept exists in every educational system on Earth.

**Proposed revision:** Rename "Government Education Agency" to **"Education Authority"**.

**Why this better supports global expansion:**

- "Education Authority" covers all Nigerian instances: JAMB (admissions authority), NUC (university accreditation authority), WAEC (examination authority), NBTE (technical education authority), NCCE (college of education authority).
- "Education Authority" covers non-Nigerian instances: ABET (US engineering accreditation authority), UCAS (UK admissions authority), QAA (UK quality authority), GTEC (Ghana tertiary education authority), KUCCPS (Kenya admissions authority).
- "Education Authority" covers non-governmental authorities: professional bodies, independent accreditors, international bodies.
- Whether a specific authority is governmental becomes an **attribute** of the authority, not its defining characteristic. JAMB is governmental. ABET is not. Both are education authorities.

**Why this is not premature generalization:**

The concept of "an authoritative body in education" genuinely exists across all educational systems. This is not an abstraction invented for genericity — it is the real concept that "Government Education Agency" narrows to the Nigerian case. The Nigerian bodies (JAMB, NUC, WAEC, etc.) are **instances** of this domain concept, not the concept itself.

**Business Discovery alignment:**

- A2-1 defines secondary users including "Government Education Agencies (JAMB, WAEC, NECO, NABTEB, NUC, NBTE, NCCE, state agencies)". The **role** these entities play — authoritative source, regulator, accreditor, examiner — is the domain concept. Their governmental nature is a Nigerian data fact.
- A2-5 states "Government Education Agencies are strategic partners (data providers)." The strategic partnership role is based on their **authority**, not their government status.
- The glossary term should be updated. This is a domain discovery refinement, not a business decision change. The approved decisions (A2-1 through A2-8) describe the **role** of these entities; the entity name should reflect the universal role.

---

### F2: INV-I2 / INV-P5 — Nigeria-Specific Accreditation Type Mapping

**Current decision:**

> INV-I2: "An Institution can only be accredited by the agency appropriate to its type (NUC for universities, NBTE for polytechnics/IEIs, NCCE for colleges of education)."

> INV-P5: "A Programme's accreditation can only be from the agency appropriate to its Institution type."

**Why it is problematic:**

This invariant hard-codes the Nigerian regulatory structure (NUC→universities, NBTE→polytechnics, NCCE→colleges) into the domain model. Other countries organize accreditation differently:

- **United States**: Regional accrediting commissions accredit institutions regardless of type. The Higher Learning Commission accredits both universities and community colleges in its region. There is no type-to-accreditor mapping.
- **United Kingdom**: The QAA reviews all higher education institutions. The Office for Students (OfS) regulates all. There is no separate accreditor per institution type.
- **Ghana**: The GTEC accredits all tertiary institutions. No separate bodies per type.
- **Professional accreditation** (across all countries): ABET, AACSB, AMBA accredit specific programme **disciplines** regardless of institution type. This is subject-matter jurisdiction, not institution-type jurisdiction.

The universal domain concept is: **An Education Authority has a jurisdiction that defines which entities it can accredit.** Jurisdiction may be defined by institution type (Nigeria), geographic region (US), subject area (professional bodies), level of education, or a combination. The domain model should express jurisdiction; the specific jurisdiction rules are data.

**Proposed revision:**

Replace INV-I2 and INV-P5 with:

> **INV-I2 (revised)**: An Accreditation Record's granting authority must have jurisdiction over the accredited entity.
>
> **INV-P5 (revised)**: A Programme's accreditation can only be granted by an authority with jurisdiction over that Programme.

The jurisdiction check is a real business invariant — an authority cannot accredit entities outside its jurisdiction. What defines jurisdiction is data (varies by country), not domain structure.

**Why this better supports global expansion:**

- In Nigeria: Education Authority jurisdiction is defined by institution type. NUC's jurisdiction = universities. NBTE's jurisdiction = polytechnics/IEIs. This is one possible jurisdiction rule.
- In the US: Regional accreditor jurisdiction is defined by geography. HLC's jurisdiction = north-central states. This is another possible jurisdiction rule.
- For professional bodies: Jurisdiction is defined by subject area. ABET's jurisdiction = engineering programmes at any institution. This is yet another rule.
- The domain model supports all of these through a single invariant: "the granting authority must have jurisdiction." The jurisdiction definition is data.

**Aggregate operation adjustment:**

`recordAccreditation(authority, status, period)` — The Programme/Institution validates that the authority has jurisdiction. In Nigeria, this happens to check institution type. In the US, this would check geographic region. The invariant is the same; the jurisdiction rule is data.

---

### F3: INV-2 (Original Topic 2) — "Granted by exactly one Government Education Agency"

**Current decision:**

> INV-2: "An Accreditation Record is granted by exactly one Government Education Agency."

**Why it is problematic:**

Two issues:

1. **"Government"** — Same as F1. Accreditation may be granted by non-governmental bodies (ABET, AACSB, professional councils).
2. **"exactly one"** — This may be overly restrictive. OQ2-8 already asks whether a programme can be accredited by multiple authorities simultaneously (e.g., NUC + a professional body). In the US, a programme commonly holds both institutional accreditation (from a regional accreditor) and programme-specific accreditation (from ABET or similar). These are separate records, each from one authority — so "exactly one per record" is correct. But the current phrasing implies the programme can only have accreditation from a government agency, which is wrong.

**Proposed revision:**

> **INV-2 (revised)**: An Accreditation Record is granted by exactly one Education Authority.

Each record has one granting authority. A Programme/Institution may have multiple Accreditation Records from different authorities (institutional accreditor + professional accreditor). This is already the case in the data model (1:N from Programme to Accreditation Record); the revision only changes the entity name and removes the governmental constraint.

---

### F4: INV-9 — Nigeria-Scoped Qualification Recognition

**Current decision:**

> INV-9: "A Qualification is recognized by at least one authority in the Nigerian education system."

**Why it is problematic:**

This scopes qualification recognition to Nigeria. When StudyNexus expands to Ghana, Kenya, or the UK, qualifications recognized in those countries must also be supported. The domain concept of qualification recognition is universal; the specific authorities and qualifications are data.

**Proposed revision:**

> **INV-9 (revised)**: A Qualification is recognized by at least one Education Authority.

The scope of recognized qualifications is determined by which authorities StudyNexus operates within. This is a data configuration, not a domain structure.

---

### F5: INV-10 — Nigeria-Specific Accreditation Type Constraint

**Current decision:**

> INV-10: "An Accreditation Record's subject (Institution or Programme) must be of the appropriate type for the granting Agency."

**Why it is problematic:**

Same root cause as F2. This hard-codes the Nigerian rule that NUC accredits only universities, NBTE only polytechnics, etc. In other countries, the mapping between accreditor and institution type is different or non-existent.

**Proposed revision:**

> **INV-10 (revised)**: An Accreditation Record's subject must fall within the granting Education Authority's jurisdiction.

This subsumes F2's revision. Both INV-I2 and INV-10 express the same invariant from different perspectives: the authority must have jurisdiction, and the subject must be within that jurisdiction.

---

### F6: Institution Type Enum — Nigeria-Specific Values

**Current decision:** Institution Type is a value object with values: University, Polytechnic, College of Education, Innovation Enterprise Institution (IEI).

**Why it is problematic:**

The specific types are Nigeria's classification system. Other countries have different institutional taxonomies:

- **US**: Research University, Liberal Arts College, Community College, For-Profit Institution, Tribal College, etc.
- **UK**: University, College, Further Education College, Sixth Form College, Specialist Institution, etc.
- **Ghana**: University, University College, Polytechnic, College of Education, Technical Institute, etc.

The concept of "institution type" is universal. The specific types are data.

**Proposed revision:**

Keep **Institution Type** as a value object, but recognize that the specific type values are **data, not domain structure**. The domain concept is: an institution has a type that categorizes it within its regulatory framework. The type values vary by country.

The value object itself remains — it has domain meaning (type affects which authorities have jurisdiction, what award levels are valid, etc.). What changes is the understanding that the enum values are configuration data, not hard-coded domain knowledge.

**In practice**: The MVP operates in Nigeria and uses Nigerian institution types. But the domain model does not depend on these specific values. When expanding to Ghana, Ghanaian types are added. When expanding to the UK, UK types are added. No structural redesign required.

---

### F7: Award Level Enum — Partially Nigeria-Specific Values

**Current decision:** Award Level is a value object with values like B.Sc., B.A., M.Sc., Ph.D., ND, HND, NCE.

**Why it is problematic:**

Some award levels are universal (B.Sc., B.A., M.Sc., Ph.D.), but others are Nigeria-specific (ND = National Diploma, HND = Higher National Diploma, NCE = Nigeria Certificate in Education). Other countries have their own national awards:

- **UK**: Foundation Degree, HNC, HND, PGCE, MEng (undergraduate master's)
- **US**: Associate's Degree, Bachelor's, Master's, Doctorate — with various sub-types
- **Germany**: Diplom, Magister, Staatsexamen

**Proposed revision:**

Same approach as F6: Keep **Award Level** as a value object. The specific values are data. Some values are internationally recognized (B.Sc., Ph.D.); others are national (ND, HND, NCE). This is already implicit in the model — the revision makes it explicit: **Award Level values are data, not domain structure.**

---

### F8: Qualification Identity Scoped as "National"

**Current decision:** "Qualification identity is national" — Qualifications are not scoped to institutions; "WAEC SSCE" is the same regardless of institution.

**Why it is problematic:**

"National" is a Nigeria-specific scope designation. More precisely, a qualification's scope is determined by its defining authority. WAEC SSCE is authority-scoped (defined by WAEC, which operates across West Africa — it's not even national, it's regional). Some qualifications are institution-specific (a university's own entrance examination). Some are international (IB, IGCSE).

**Proposed revision:**

> Qualification identity is **authority-scoped** — a qualification is defined by the Education Authority that establishes it. Its scope (national, regional, international, institutional) is determined by its defining authority's jurisdiction.

This is more precise and more general. WAEC SSCE is defined by WAEC (a regional authority). JAMB UTME is defined by JAMB (a national authority). The IB is defined by the IBO (an international authority). All are authority-scoped.

---

### F9: Admission Cycle Lifecycle Phases — Example-Driven as Universal

**Current decision:** Admission Cycle lifecycle phases are: upcoming → registration_open → examination_period → results_released → admission_period → closed → archived.

**Why it is problematic:**

These phases are modeled after the **JAMB UTME process**. While the concept of an admission cycle with ordered phases is universal, the specific phases vary:

- **UK (UCAS)**: Application → Offer → Reply → Confirmation → Enrollment. No centralised examination period.
- **US (Common App)**: Application → Review → Decision → Enrollment. No centralised examination or results release.
- **Nigeria (JAMB)**: Registration → Examination → Results → Admission. Matches the current model.
- **Some countries**: Direct application to institutions with no national cycle at all.

The current phases are not wrong — they represent one valid admission cycle structure. But they should not be the **only** possible structure in the domain model.

**Proposed revision:**

Keep the current phases as the **default lifecycle for Nigeria's national admission cycle**. But recognize in the domain model that:

1. Admission Cycle has an **ordered sequence of phases** (this is the domain invariant — INV-C2).
2. The specific phases are **configurable** — they depend on the type of admission cycle and the country's system.
3. The current phases are the Nigerian national cycle configuration, not the universal domain structure.

This does not require a model change — the phases are already described as "a defined sequence" in INV-C2. The revision is to make explicit that the phase **names and count** are data, while the **sequential ordering invariant** is the domain concept.

**No structural change required.** The domain invariant (phases follow a defined sequence) is already universal. The phase names are already flagged as an open question (OQ2-6).

---

### F10: Admission Cycle Scope — "National" as Hard-Coded Scope Level

**Current decision:** Admission Cycle identity includes "scope level (national/institutional/programme)." Examples: "2024/2025 UTME Cycle" (national), "2024/2025 UNILAG Admission Cycle" (institutional).

**Why it is problematic:**

Not all countries have national admission cycles. In the US, admission is entirely institutional. In the UK, UCAS provides a centralized application system but is not a "national admission cycle" in the JAMB sense. The scope levels "national/institutional/programme" reflect Nigeria's structure.

**Proposed revision:**

An Admission Cycle's scope is determined by the **Education Authority** that defines it:

- A national authority (JAMB) defines a national cycle.
- An institution defines an institutional cycle.
- A programme defines a programme-level cycle.
- In countries without a national cycle, only institutional/programme cycles exist.

The scope levels are not hard-coded into the domain — they emerge from which authorities define cycles. This is already close to the current model; the revision removes the assumption that "national" scope always exists.

---

### F11: "Cut-off Mark" — Nigerian Terminology in Value Object

**Current decision:** Cut-off Mark is a distinct value object, described as "a specialized form of Qualification Threshold used specifically for minimum admission scores. In Nigerian domain, 'cut-off mark' is a distinct and well-understood concept."

**Why it is problematic:**

"Cut-off mark" is Nigerian/West African educational terminology. Other countries use different terms for the same concept:

- **US**: "minimum score", "benchmark score"
- **UK**: "entry requirements", "tariff points threshold"
- **General**: "minimum score requirement", "admission threshold"

The domain concept — a minimum score or threshold used as an admission requirement — is universal. The Nigerian term "cut-off mark" is a localization of this concept.

**Proposed revision:**

**Absorb Cut-off Mark into Qualification Threshold.** The domain concept is a score/grade threshold; "cut-off mark" is Nigerian terminology for one type of threshold. Qualification Threshold already captures the general concept (qualification + minimum value + comparator). A cut-off mark is a Qualification Threshold where the qualification is a standardized assessment and the comparator is ≥.

The glossary term "Cut-off Mark" remains valid as Nigerian domain terminology, but it is a **localized name** for a Qualification Threshold, not a separate value object.

**Why this is not premature generalization:**

Qualification Threshold already exists in the model. Cut-off Mark adds no structural distinction — it is a Qualification Threshold with specific parameter values. Removing the separate value object simplifies the model without losing domain expressiveness. The concept of a minimum admission score is preserved; only the redundant specialization is removed.

---

### F12: Domain Justifications Written in Nigerian Terms

**Current decision:** Multiple invariants, operations, and justifications reference Nigerian specifics (NUC, NBTE, NCCE, JAMB, UTME, WAEC) as if they define the domain concept rather than being instances of it.

**Examples:**

- "An Institution can only be accredited by the agency appropriate to its type (NUC for universities, NBTE for polytechnics/IEIs, NCCE for colleges of education)."
- "JAMB announces the UTME cycle"
- "NUC granted full accreditation to Computer Science at UNILAG"
- "WAEC SSCE", "JAMB UTME" as qualification examples
- "In Nigerian domain, 'cut-off mark' is a distinct concept"

**Why it is problematic:**

These examples conflate **the domain concept** with **Nigerian instances of the concept**. NUC is an instance of Education Authority, not a domain concept. UTME is an instance of a national assessment, not a domain concept. The domain model should express concepts; examples should illustrate with instances.

**Proposed revision:**

Express all domain concepts in universal terms. Use Nigerian instances as **examples** (illustrative, not definitional):

| Current (Definitional) | Revised (Concept + Example) |
|------------------------|---------------------------|
| "NUC for universities" | "the authority with jurisdiction over universities (e.g., NUC in Nigeria)" |
| "JAMB announces the UTME cycle" | "a national authority announces the admission cycle (e.g., JAMB in Nigeria)" |
| "WAEC SSCE", "JAMB UTME" | "standardized qualifications (e.g., WAEC SSCE, JAMB UTME in Nigeria)" |
| "In Nigerian domain, 'cut-off mark'" | "minimum admission threshold (known as 'cut-off mark' in Nigeria)" |

---

### F13: Original Topic 2's Rejection of "Educational Authority" Abstraction

**Current decision:** Topic 2 rejected "Educational Authority" as a shared abstraction between Government Education Agency and Scholarship Provider, because they have fundamentally different roles.

**Why this is not problematic — but needs clarification:**

The rejection was correct **in its original context** — Government Education Agency and Scholarship Provider should not share an abstraction because they serve different roles. However, the user's "Global Domain" constraint now requires re-evaluating "Government Education Agency" as an entity name, which leads to renaming it to "Education Authority" (F1 above).

This is **not** a contradiction with the original rejection. The original rejection said "Government Education Agency and Scholarship Provider are too different to share an abstraction." The proposed revision says "Government Education Agency should be renamed to Education Authority because its name is Nigeria-specific." These are different statements:

- **Rejected**: Creating a shared parent abstraction for Agency and Provider
- **Proposed**: Renaming Agency to a more universal term

Scholarship Provider remains a separate entity. Education Authority replaces Government Education Agency. No shared abstraction is created.

---

### F14: Aggregate Boundary Decisions — Implementation-Driven Reasoning

**Current decision:** The Topic 2 revision classified entities using pragmatic DDD criteria (protects invariants, independent lifecycle, independently manipulable, standalone to domain experts, own consistency boundary).

**Why this needs examination:**

The "Domain First" constraint requires discovering the domain from the educational domain, then applying pragmatic DDD as a tiebreaker when multiple equally valid models exist. The revision should be checked to ensure it wasn't driven by implementation preferences over domain discovery.

**Assessment:**

The aggregate boundary decisions are **domain-justified**, not implementation-driven:

- **Educational Institution as aggregate root**: Domain experts treat institutions as standalone concepts. Institutions have independent lifecycles. This is domain discovery, not DDD patterning.
- **Programme as aggregate root**: Domain experts reason about admission at the programme level. "Computer Science at UNILAG" is the unit of admission. This is how the educational domain works.
- **Admission Policy as child entity**: In the educational domain, admission requirements are always "for a programme for a cycle." Domain experts don't manage policies independently. This is domain observation, not DDD imposition.
- **Qualification as supporting entity**: Qualifications are defined by external bodies. StudyNexus records them; it doesn't manage them. This is domain fact, not implementation preference.

The one area where implementation reasoning influenced the model: the decision to keep Programme as a separate aggregate from Institution (rather than a child entity) was partially justified by aggregate size concerns. However, the primary justification is domain-based (Programme has its own invariants, is the primary unit of admission, is discussed independently by domain experts). The size concern is a secondary, pragmatic consideration — which is exactly how Laravel Beyond CRUD should be applied: as a constraint on an already domain-justified decision.

**No revision required.** The aggregate boundary decisions are domain-first with pragmatic DDD as tiebreaker, which is the correct order per the "Domain First" constraint.

---

## Summary of Recommended Revisions

| # | Finding | Current | Proposed | Type |
|---|---------|---------|----------|------|
| F1 | Entity name | Government Education Agency | **Education Authority** | Rename |
| F2 | Invariant INV-I2, INV-P5 | Agency determined by institution type (Nigerian regulatory structure) | **Granting authority must have jurisdiction over the accredited entity** | Generalize invariant |
| F3 | Invariant INV-2 | "exactly one Government Education Agency" | **"exactly one Education Authority"** | Rename + generalize |
| F4 | Invariant INV-9 | "Nigerian education system" | **"at least one Education Authority"** | Remove Nigeria-scoping |
| F5 | Invariant INV-10 | "appropriate type for granting Agency" | **"within granting authority's jurisdiction"** | Generalize invariant |
| F6 | Value object | Institution Type with Nigerian enum values | **Keep value object; specific values are data** | Clarify scope |
| F7 | Value object | Award Level with Nigerian-specific values (ND, HND, NCE) | **Keep value object; specific values are data** | Clarify scope |
| F8 | Identity rule | Qualification identity is "national" | **Qualification identity is "authority-scoped"** | Generalize scope |
| F9 | Lifecycle | Admission Cycle phases modeled on JAMB | **Keep phases; clarify they are configuration data, not universal structure** | Clarify scope |
| F10 | Identity rule | Cycle scope "national/institutional/programme" | **Cycle scope determined by defining authority** | Generalize scope |
| F11 | Value object | Cut-off Mark as separate value object | **Absorb into Qualification Threshold; "cut-off mark" is Nigerian terminology** | Remove redundancy |
| F12 | Documentation | Nigerian instances used as definitions | **Express concepts universally; use Nigerian instances as examples** | Documentation correction |
| F13 | Previous rejection | "Educational Authority" abstraction rejected | **Renaming ≠ shared abstraction; no contradiction** | Clarify |
| F14 | Methodology | Pragmatic DDD drove classifications | **Classifications are domain-justified; DDD was tiebreaker** | Confirm alignment |

---

## Invariants After Revision

| ID | Original | Revised | Change Type |
|----|----------|---------|-------------|
| INV-I1 | Institution has a valid type | **Unchanged** | — |
| INV-I2 | Agency appropriate to type (NUC/NBTE/NCCE) | **Granting authority must have jurisdiction** | Generalized |
| INV-I3 | One active institutional Admission Policy per cycle | **Unchanged** | — |
| INV-I4 | Institution has current official name | **Unchanged** | — |
| INV-I5 | Closed institution cannot operate | **Unchanged** | — |
| INV-P1 | Programme belongs to one Institution | **Unchanged** | — |
| INV-P2 | One active Admission Policy per cycle | **Unchanged** | — |
| INV-P3 | Admission status = lifecycle ∧ cycle | **Unchanged** | — |
| INV-P4 | Award level valid for Institution type | **Unchanged** | — |
| INV-P5 | Accreditation from agency appropriate to type | **Accreditation from authority with jurisdiction** | Generalized |
| INV-P6 | Discontinued programme cannot operate | **Unchanged** | — |
| INV-S1–S5 | Scholarship invariants | **Unchanged** | — |
| INV-C1–C3 | Admission Cycle invariants | **Unchanged** | — |
| INV-IS1–IS3 | Information Source invariants | **Unchanged** | — |
| INV-2 | Granted by one Government Education Agency | **Granted by one Education Authority** | Renamed + generalized |
| INV-9 | Recognized in Nigerian education system | **Recognized by at least one Education Authority** | Generalized |
| INV-10 | Subject appropriate for Agency type | **Subject within granting authority's jurisdiction** | Generalized |

---

## Entity Names After Revision

| Original | Revised | Reason |
|----------|---------|--------|
| Government Education Agency | **Education Authority** | F1: Universal concept; governmental nature is an attribute, not the essence |
| Educational Institution | **Educational Institution** (unchanged) | Universal concept |
| Programme | **Programme** (unchanged) | Universal concept (used in UK/Commonwealth; US uses "program" — same concept) |
| Scholarship | **Scholarship** (unchanged) | Universal concept |
| Qualification | **Qualification** (unchanged) | Universal concept |
| Admission Cycle | **Admission Cycle** (unchanged) | Universal concept |
| Admission Policy | **Admission Policy** (unchanged) | Universal concept |
| Eligibility Policy | **Eligibility Policy** (unchanged) | Universal concept |
| Accreditation Record | **Accreditation Record** (unchanged) | Universal concept |
| Scholarship Provider | **Scholarship Provider** (unchanged) | Universal concept |
| Information Source | **Information Source** (unchanged) | Universal concept |

---

## Value Objects After Revision

| Original | Revised | Reason |
|----------|---------|--------|
| Cut-off Mark | **Removed (absorbed into Qualification Threshold)** | F11: "Cut-off mark" is Nigerian terminology for a Qualification Threshold |
| Institution Type | **Institution Type** (unchanged) | F6: Concept is universal; specific values are data |
| Award Level | **Award Level** (unchanged) | F7: Concept is universal; specific values are data |
| All others | **Unchanged** | — |

---

## Glossary Impact

The canonical glossary (02-glossary.md) contains the term "Government Education Agency" defined as "An official body that regulates, examines, or coordinates education in Nigeria." This should be updated to:

> **Education Authority**: An organization that holds authoritative standing in education — whether regulatory, accrediting, examining, coordinating, or standard-setting. In Nigeria, examples include JAMB, NUC, WAEC, NECO, NABTEB, NBTE, and NCCE.

The glossary term "Cut-off Mark" remains valid as Nigerian domain terminology but should note that it is a specialization of Qualification Threshold.

**Note**: Glossary updates require a Change Proposal per the Business Discovery freeze (F2: Approved decisions are immutable without a Change Proposal). However, this is a terminology refinement (narrowing to a more precise universal concept), not a semantic change to any approved business decision. The approved decisions (A2-1, A2-8) describe the **role** of these entities; the name update reflects the same role more precisely.

---

## Principles Applied

| Constraint | How Applied |
|-----------|------------|
| **Domain First** | All revisions are driven by domain concepts (education authority, jurisdiction, authority-scoped identity) not implementation patterns. The aggregate boundary decisions (F14) were confirmed as domain-justified. |
| **Global Domain** | F1–F12 systematically remove Nigeria-specific assumptions from entity names, invariants, identity rules, lifecycle assumptions, and value objects. Nigeria becomes data (instances, configuration) not domain structure. |
| **Avoid Premature Generalization** | Each revision introduces a broader concept only where it genuinely exists across educational systems. "Education Authority" exists in every country. "Jurisdiction" is how every accreditation system works. No abstract concepts were invented. |
| **Laravel Beyond CRUD** | No aggregate boundaries were changed. The pragmatic DDD classifications remain valid — the revisions affect naming and invariant wording, not aggregate structure. The model remains non-anemic, with business operations protecting named invariants. |

---

## Readiness Assessment

### Are Topics 1 and 2 sufficiently stable to proceed to Topic 3?

**Yes, with one condition: the revisions in this review must be applied first.**

The revisions are **confined and mechanical** — they do not require rethinking the domain model, re-evaluating aggregate boundaries, or re-analyzing relationships. They are:

1. **One entity rename** (Government Education Agency → Education Authority)
2. **Four invariant generalizations** (replace Nigeria-specific regulatory structure with jurisdiction-based invariant)
3. **One value object removal** (Cut-off Mark absorbed into Qualification Threshold)
4. **Several documentation clarifications** (express concepts universally, use Nigerian instances as examples)
5. **Identity scope corrections** (national → authority-scoped, scope determined by defining authority)

None of these affect:
- Aggregate boundaries (the same 5 aggregate roots, 3 child entity types, 3 supporting entities)
- Ownership relationships (composition, aggregation, association classifications)
- Cardinality (all M:N relationships remain)
- Lifecycles (entity lifecycle states and transitions remain)
- Temporal behaviour (time-bounded patterns remain)

**Once these revisions are applied, Topics 1 and 2 are stable and Topic 3 (Entity Attributes & Value Objects) can proceed.**

### Topic 3 Preparation Notes

Topic 3 should:

1. Use **Education Authority** (not Government Education Agency) throughout.
2. Express all invariants in **jurisdiction-based** terms (not Nigeria-specific regulatory mapping).
3. Model **Institution Type** and **Award Level** values as **data/configuration** rather than hard-coded enum values.
4. Model **Admission Cycle phases** as configurable (the invariant is sequential ordering; the phase names are data).
5. Treat **Qualification Threshold** as the primary value object (no separate Cut-off Mark).
6. Use Nigerian specifics (JAMB, NUC, WAEC, etc.) as **examples**, not as definitions of domain concepts.
7. Consider whether **Admission Pathway** (currently a glossary term, A3-8) should be promoted to a domain entity — it is a universal concept (different routes into education) that exists in every country.
