# StudyNexus — Domain Integrity Review
# Comprehensive Critical Design Review of Domain Discovery (Topics 1–3)

**Date:** 2026-08-07
**Reviewer Role:** Senior Domain Architect — Critical Design Review
**Objective:** Break the model. Challenge every important decision. Do not defend the status quo.
**Scope:** All domain entities, value objects, relationships, invariants, and assumptions from Topics 1–3, post-architectural-review revisions
**Authority Order:** Business Discovery → Topic 1 → Topic 2 (revised) → Topic 3 → Architectural Review

---

## 1. Executive Assessment

The domain model is **substantially correct** for an MVP focused on tertiary educational opportunity discovery in a single country (Nigeria). The entity boundaries are pragmatic, the value objects serve genuine domain purposes, and the invariants protect real business consistency.

However, the model has **five structural weaknesses** that will cause problems during global expansion, two of which will cause problems even within Nigeria's MVP if certain types of information need to be represented. The model also carries **three hidden assumptions** that contradict the stated "Global Domain" constraint, and **two missing concepts** that are fundamental to the educational domain worldwide.

The model is usable but not yet robust. It requires targeted corrections before Behaviour and Application Discovery.

---

## 2. Strengths

### S1: Pragmatic Aggregate Boundaries
The reduction from 11 to 5 aggregate roots (Topic 2 Revision) is well-justified. Every aggregate root protects named invariants and has meaningful business operations. Child entities (Admission Policy, Eligibility Policy, Accreditation Record) correctly live within their parent's consistency boundary because their lifecycle is driven by the parent and they have no independent invariants. This is textbook Laravel Beyond CRUD — pragmatic, not dogmatic.

### S2: Jurisdiction-Based Invariant Generalization
Replacing "NUC for universities, NBTE for polytechnics" with "granting authority must have jurisdiction" (F2, F5) is the single most important architectural correction. It transforms a Nigeria-specific hard-coded rule into a universal domain invariant with data-driven criteria. This is exactly the right pattern for global extensibility without structural redesign.

### S3: Authority-Scoped Identity
Qualification identity scoped to Education Authority (F8) rather than "national" is correct and precise. WAEC SSCE is defined by WAEC (a regional body operating across 5 countries). JAMB UTME is defined by JAMB (a national body). IB is defined by IBO (an international body). Authority-scoping captures all these cases without special handling.

### S4: Derived Attribute Discipline
The decision to never store derived attributes (accreditation status, admission status, applicability) and always compute them from their authoritative sources is correct. This eliminates an entire class of consistency bugs. The domain model has a single source of truth for each concept.

### S5: Value Object Restraint
25 value objects for 11 entities is appropriate — not excessive, not sparse. Each VO either removes primitive obsession (Monetary Amount = amount + currency), groups related concepts (Subject Combination, Authority Jurisdiction), or expresses domain meaning (Qualification Threshold, Trust Signal). The 10 rejected VOs are correctly rejected.

### S6: Separation of Domain Structure from Reference Data
Explicitly identifying 15 country-varying attributes and classifying their values as "data, not domain structure" (F6, F7, F8, F9) is a genuine architectural strength. It means the domain model can operate in Nigeria, Ghana, or Germany without structural changes — only reference data loading differs.

### S7: Immutable Historical Records
Accreditation Records as immutable facts (each status change creates a new record) preserves audit trail integrity and simplifies reasoning about accreditation history. This is a strong pattern that avoids the complexity of temporal versioning.

---

## 3. Weaknesses

### W1: Programme and Scholarship Are Opportunity Projections, Not Independent Domain Concepts [CRITICAL]

**The Problem:** Educational Institution, Programme, and Scholarship are modeled as three independent aggregate roots with no shared concept. But from the user's perspective (A0-3: "Users search, discover, compare, and verify educational opportunities and information"), these are all **educational opportunities** — things a person might choose to pursue. The original Topic 2 rejected "Educational Opportunity" as a shared abstraction, and the architectural review upheld this rejection (F13).

**Why This Is a Weakness Despite F13:**

The rejection was correct in its original context — "Educational Opportunity" as a shared *abstraction* (with Institution, Programme, and Scholarship as subtypes) would be classical DDD over-engineering. But the absence of any connecting concept creates a problem: **StudyNexus has no way to express that a Programme at an Institution is an opportunity, or that a Scholarship is an opportunity.** The workflows (WF1–WF6) all operate on "educational opportunities" — yet the domain model has no concept that corresponds to what the workflows consume.

This is not an abstraction problem. It is a **ubiquitous language problem**. The term "educational opportunity" appears in A0-3, A3-3, A3-6, A6-9, and the glossary definition of StudyNexus. The domain model cannot express it.

**Impact:** When StudyNexus later adds fellowships, grants, research positions, or exchange programmes, each will be a new aggregate root with no shared concept. The product layer will need to invent its own "opportunity" projection. This is acceptable pragmatically (LBC permits it) — but it should be a conscious decision, not an accidental omission.

**Recommendation:** Do NOT create an "Educational Opportunity" entity or abstraction. Instead, acknowledge explicitly in the domain model that Programme and Scholarship are **opportunity-bearing entities** — they are the entities users evaluate in workflows. This is a documentation/terminology clarification, not a structural change. Mark this as a known gap in the ubiquitous language.

**Severity:** Medium (ubiquitous language gap; no structural damage; will cause product-layer friction during expansion)

---

### W2: Admission Policy Has a Dual-Parent Problem [CRITICAL]

**The Problem:** Admission Policy is a child entity that can belong to either a Programme or an Institution. Topic 2 acknowledged this: "An Admission Policy can belong to either a Programme or an Institution. This is a modelling reality, not an implementation problem." But a child entity within a specific aggregate must have exactly one parent aggregate. An Admission Policy cannot be simultaneously a child of Programme *and* a child of Institution.

**Current Model:** The invariant is "exactly one parent." But the aggregate diagram shows Admission Policy as a child of *both* Programme and Institution, which violates the aggregate boundary rule. In implementation, this means either:
- (a) Two separate collections: Programme.AdmissionPolicies + Institution.AdmissionPolicies, or
- (b) One collection with a parent-type discriminator.

**Why This Matters:** Option (a) means the same domain concept (Admission Policy) exists in two different aggregate contexts, with potentially different rules. Option (b) means an Admission Policy has a polymorphic parent reference, which DDD traditionally avoids but LBC pragmatically accepts.

**LBC Assessment:** Laravel Beyond CRUD would accept option (b) — a `parent_type` + `parent_id` discriminator is pragmatic and common in Laravel applications. This is not a domain purity problem; it's an implementation strategy. The domain invariant (exactly one parent) is clear regardless of how it's modeled.

**Recommendation:** Accept the dual-parent as a pragmatic reality. The domain invariant is clear: an Admission Policy belongs to exactly one entity (Programme or Institution). Model this with a governed entity reference (already in Topic 3: "Governed Entity: Reference (Programme or Institution)"). The aggregate boundary is determined at creation time and never changes. This is LBC-compatible.

**Severity:** Low (acknowledged, pragmatic solution exists, LBC-compatible)

---

### W3: Scholarship Targeting Is Underspecified [HIGH]

**The Problem:** Scholarship has Target Institutions and Target Programmes as collections of references. But the targeting semantics are unclear:
- If a Scholarship targets an Institution, does it apply to *all programmes* at that institution?
- If a Scholarship targets both an Institution and a Programme at a *different* institution, what is the logical relationship? AND (must be at the target institution AND in the target programme)? OR (at the target institution OR in the target programme)?
- Can a Scholarship target by Discipline ("Engineering") without targeting specific programmes? By Award Level ("Undergraduate")? By Location ("Niger Delta states")?

**Current Model:** The derived attribute "Is Applicable To Programme" says: "Programme ∈ target programmes ∨ programme's institution ∈ target institutions ∨ (both targets empty = open to all)." This is an OR relationship with an open-default. But scholarships commonly have more complex targeting: "Must be studying Engineering at a Federal University" — this is an AND of discipline + ownership type.

**Impact:** The current targeting model cannot express common scholarship eligibility conditions that involve institutional characteristics (public/private), geographic constraints (Niger Delta), or disciplinary constraints without listing every individual programme.

**Recommendation:** Add a Targeting Mode attribute to Scholarship: Open (no targeting), Explicit (target specific institutions/programmes), Criteria-Based (target by characteristics). For MVP, Explicit targeting with OR semantics is sufficient. Criteria-Based targeting can be added when needed. This is a minor attribute addition, not a structural change.

**Severity:** Medium for MVP (most Nigerian scholarships list target institutions explicitly); High for expansion (many scholarships target by characteristics)

---

### W4: Education Authority Is Undermodeled for Its Central Role [HIGH]

**The Problem:** Education Authority is classified as a supporting entity — "reference data with no business behavior." But the architectural review made it the **central organizing concept** for:
1. Accreditation jurisdiction (INV-I2, INV-P5, INV-10)
2. Qualification definition and scope (INV-9, F8)
3. Admission Cycle definition and scope (F10)
4. Information provenance (referenced by Information Source for trust)

Education Authority is referenced by four different entity types and participates in three domain invariants. It is not merely "reference data" — it has structural significance in the domain. Classifying it as a supporting entity with "no business behavior" understates its role.

**LBC Assessment:** Does Education Authority need to be an aggregate root? Only if it has invariants to protect and business operations to perform. Currently, StudyNexus does not manage Education Authorities — it references externally-defined ones. So "supporting entity" is correct for MVP. But the justification should be "StudyNexus does not manage authorities in MVP; it references them," not "authorities have no business behavior." Authorities have significant business behavior (granting accreditation, defining qualifications, announcing admission cycles) — but that behavior belongs to the authority's own systems, not to StudyNexus.

**Recommendation:** Reclassify the justification: Education Authority is a supporting entity because **StudyNexus references but does not manage authorities in its MVP scope** (per A2-5: "Government Education Agencies are strategic partners (data providers)"). If Stage 3 (Education Ecosystem) enables authorities to participate directly, Education Authority may be promoted to aggregate root. This is a documentation correction, not a structural change.

**Severity:** Low (justification correction; no structural impact)

---

### W5: Information Source Lacks Provenance Integration Specificity [MEDIUM]

**The Problem:** Information Source is an aggregate root with provenance tracking attributes (reliability, verification, category). Multiple entities reference Information Source for provenance. But the model does not specify:
- Whether each entity attribute can have a different source, or only the entity as a whole has a source.
- Whether provenance is tracked at the entity level or the attribute level.
- How Trust Signals are computed when different attributes of the same entity come from different sources with different reliability levels.

**Current Model:** Accreditation Record, Admission Policy, and Eligibility Policy each have a single "Source Reference" attribute. This implies entity-level provenance — the entire record came from one source. But in practice, some attributes of a programme (name, award level) may come from the institution's website, while others (accreditation status) come from NUC, and still others (tuition) come from a different source.

**Impact:** If provenance must be tracked at the attribute level (which A6-8's Trust Signal concept implies — "helps users assess the reliability of information"), the current single-reference-per-entity model is insufficient. A programme's tuition might be less reliable than its accreditation status if they come from different sources.

**Recommendation:** For MVP, entity-level provenance is sufficient and pragmatically simpler. Acknowledge as an open question whether attribute-level provenance is needed. The Trust Signal VO already composes multiple factors — it can be computed per-entity for MVP and refined to per-attribute in a future stage. This aligns with A4-5's concern about the Stage 3 transition.

**Severity:** Low for MVP (entity-level provenance is pragmatic); Medium for Stage 3 (attribute-level provenance becomes important when multiple contributors exist)

---

## 4. Required Changes (Must Fix)

### RC-1: Admission Policy and Eligibility Policy Should Share a Common Pattern [STRUCTURAL CLARITY]

**Issue:** Admission Policy and Eligibility Policy have identical lifecycle states (Draft → Published → Active → Superseded → Retired), identical status VOs (Policy Status), and structurally similar rule collections (Admission Rules vs Eligibility Rules). They differ in: (a) parent entity (Programme/Institution vs Scholarship), (b) rule types (qualification-centric vs broader condition types), (c) identity scoping (entity+cycle vs scholarship+period).

**Classical DDD approach:** Create a "Policy" abstraction with Admission Policy and Eligibility Policy as specializations. This was rejected in Topic 2 (DD2-8) because the shared aspects are lifecycle mechanics, not domain meaning.

**LBC approach:** Keep them separate. The shared lifecycle is coincidental — admission policies and eligibility policies serve fundamentally different domain purposes. A shared abstraction would be premature generalization.

**Verdict:** The current model is correct per LBC. But the model should explicitly document *why* they are separate despite structural similarity, to prevent future developers from "fixing" this by introducing a shared abstraction. **Required change: add explicit rationale documentation.**

---

### RC-2: Education Authority Must Support Multiple Authority Types [DATA MODEL CORRECTION]

**Issue:** Topic 3 specifies Authority Type as a value object (VO-21) with values: Regulatory, Accrediting, Examining, Coordinating, Standard-Setting, Admissions. Assumption A-D3-8 states "Education Authority can have multiple Authority Types." But the attribute table lists Authority Type as a single value, not a collection.

**Problem:** NUC is both Regulatory and Accrediting. JAMB is Coordinating, Examining, and Admissions. WAEC is Examining. In the UK, UCAS is Coordinating and Admissions. Most authorities serve multiple roles. A single Authority Type cannot represent this.

**Required Change:** Authority Type must be a **collection** (Set of Authority Type), not a single value. This is a data model correction, not a structural change. The value object remains; the multiplicity changes from 1 to 1..N.

---

### RC-3: Scholarship Must Have Application Deadline [ATTRIBUTE ADDITION]

**Issue:** Challenge C-3 in Topic 3 identified that Scholarship needs an Application Deadline separate from Application Period. This was accepted as DD3-11 but was not reflected in the Scholarship attribute table.

**Problem:** The Scholarship attribute table (Topic 3) lists Application Period (Validity Period) but not Application Deadline. The domain decision DD3-11 says to add it, but the table doesn't include it. This is an inconsistency.

**Required Change:** Add Application Deadline (Date) to Scholarship's attribute table, between Application Period and Scholarship Status. It is a mutable attribute (providers occasionally extend deadlines).

---

### RC-4: Programme Must Have Faculty Attribute [ATTRIBUTE ADDITION]

**Issue:** Challenge C-2 in Topic 3 identified that Programme needs a Faculty attribute. This was accepted as DD3-10 but was not reflected in the Programme attribute table.

**Required Change:** Add Faculty (String) to Programme's attribute table. It is mutable (rare — programme moves between faculties during restructuring). Not country-varying (every institution organizes programmes into faculties/departments, though the names vary). Part of ubiquitous language.

---

## 5. Recommended Improvements (Should Fix)

### RI-1: Introduce "Admission Pathway" as a Supporting Entity

**Rationale:** Admission Pathway (Direct Entry, standard route, transfer, etc.) is a glossary term (A3-8) that exists in every country. Currently, pathways are implicit in Admission Rules — a rule like "ND/HND holders may enter at 200-level" encodes the Direct Entry pathway. But pathways are first-class concepts in the educational domain:
- They determine entry level (200-level, 300-level, 100-level)
- They have identity (named pathways that domain experts discuss)
- They affect which qualifications are accepted
- They exist in every country (UK: Foundation Year; US: Transfer; Kenya: Diploma progression)

**Current status:** OQ-D3-1 (open question).

**Recommendation:** Promote Admission Pathway from open question to supporting entity. It has identity (name + defining authority), is referenced by Admission Rules, and is stable reference data. It does not need to be an aggregate root — it's a supporting entity like Qualification. This would make Admission Rules more expressive: a rule can reference both a qualification and a pathway ("ND via Direct Entry → 200-level admission").

---

### RI-2: Make Authority Jurisdiction a Collection, Not a Single Value

**Rationale:** Some Education Authorities have multiple jurisdiction dimensions. A Nigerian state university's coordinating body might have jurisdiction by institution type AND by geography (all universities within the state). The current Authority Jurisdiction VO supports a single jurisdiction type, with "By-Combination" as a catch-all. But By-Combination requires a single criteria map to express multiple dimensions, which is awkward.

**Recommendation:** Change Authority Jurisdiction from a single VO to a **collection of Authority Jurisdictions**. Each entry in the collection expresses one dimension of jurisdiction. An authority has jurisdiction over an entity if ALL dimensions are satisfied (AND semantics). This is more explicit and more natural than encoding multiple dimensions in a single criteria map.

---

### RI-3: Add "Country" as a First-Class Value Object

**Rationale:** Country appears as an attribute on Education Authority, Scholarship Provider, and as part of the Location VO on Educational Institution. It's currently a string (ISO country code). But Country has domain meaning in StudyNexus — it determines which reference data applies (institution types, award levels, qualifications), which authorities operate, and which admission cycles exist. StudyNexus's entire operational context is country-scoped.

**Recommendation:** Introduce a Country value object (ISO code + display name). This gives the domain model a single concept for country-scoping rather than scattering ISO codes across entities. Country also becomes the natural root of reference data hierarchies.

---

### RI-4: Separate Scholarship Value from Coverage

**Rationale:** Scholarship has both a Value (Monetary Amount) and a Coverage Type (Full Tuition, Partial, Stipend, etc.). But these interact: if Coverage Type is "Full Tuition," the Value is implicitly "tuition of the programme" and doesn't need to be stored. If Coverage Type is "Stipend," Value is the stipend amount. The current model allows both to be specified independently, which can create inconsistency (Coverage = Full Tuition, Value = ₦500,000 — is the scholarship worth ₦500,000 or is it worth the full tuition?).

**Recommendation:** Model scholarship financial terms as a **Financial Coverage** value object with two variants: Fixed Amount (Monetary Amount) and Tuition Coverage (percentage or full). This eliminates the inconsistency and more accurately models how scholarships are actually described.

---

## 6. Nice-to-Have Improvements

### NH-1: Programme Could Have a "Specialization" or "Concentration" Attribute
Many programmes have specializations (B.Sc. Computer Science with specialization in AI; MBA with concentration in Finance). Currently, this would need to be modeled as a separate programme or embedded in the programme name. A specialization attribute would improve discoverability but adds complexity.

### NH-2: Institution Could Have a "Ranking" or "Tier" Attribute
Many educational systems have institutional rankings or tiers (Nigeria: first-generation vs second-generation vs state universities; UK: Russell Group; US: R1 research universities). These are discoverability and comparison signals. However, ranking is product-sensitive (which ranking system?) and potentially controversial. Defer to Product Discovery.

### NH-3: Qualification Threshold Could Be Strongly Typed
Currently, Qualification Threshold's minimum value is a String to accommodate diverse grading systems. A strongly-typed approach (NumericThreshold, GradeThreshold, PointThreshold) would enable validation and comparison. But this adds complexity for marginal benefit in MVP, where thresholds are displayed rather than computed against.

### NH-4: Admission Cycle Could Support Parallel Phases
The current Phase Sequence assumes strictly sequential phases. But some admission cycles have parallel phases (applications and examinations can overlap; institutional screening happens concurrently with departmental review). This is a refinement that can wait until a country's admission system requires it.

---

## 7. Bounded Context Discovery

### Analysis

The domain model currently treats all 11 entities as part of a single monolithic domain. But the entities cluster naturally around three distinct concerns:

**Cluster 1: Educational Opportunity (Discovery & Comparison)**
- Educational Institution, Programme, Scholarship
- Admission Policy, Eligibility Policy
- Admission Cycle, Qualification
- Admission Rule, Eligibility Rule, Subject Combination, Qualification Threshold

This cluster is about **what opportunities exist and what they require**. Users discover, evaluate, compare, and assess eligibility for these opportunities.

**Cluster 2: Trust & Provenance (Verification & Quality)**
- Information Source, Trust Signal
- Accreditation Record, Education Authority
- Validity Period, Information Category, Source Reliability

This cluster is about **how reliable the information is**. Users assess trust, StudyNexus verifies sources, accreditation provides quality signals.

**Cluster 3: Reference Data (Configuration & Framework)**
- Institution Type, Award Level, Authority Jurisdiction
- Country, Location, Monetary Amount, Duration
- All country-varying enum values

This cluster is about **the reference framework that makes the domain meaningful**. It doesn't change through business operations; it configures the domain.

### Proposed Bounded Contexts

#### BC-1: Opportunity Discovery

**Purpose:** Discover, compare, and assess eligibility for educational opportunities.

**Core Entities:** Educational Institution (AR), Programme (AR), Scholarship (AR), Admission Cycle (AR), Admission Policy (child), Eligibility Policy (child), Qualification (supporting).

**Responsibilities:** Manage the core entities users interact with. Publish admission and eligibility requirements. Track admission cycle phases. Determine eligibility.

**Reason It Should Exist:** The workflows (WF1–WF6) all operate within this context. The ubiquitous language of "opportunities," "requirements," and "eligibility" is self-contained here. This context could be deployed and tested independently.

#### BC-2: Trust & Accreditation

**Purpose:** Assess and communicate the reliability and quality of educational information.

**Core Entities:** Information Source (AR), Accreditation Record (child), Education Authority (supporting).

**Responsibilities:** Verify information sources. Track accreditation status. Compute trust signals. Maintain provenance chains.

**Reason It Should Exist:** Trust assessment (WF5) operates on different concepts and at different times than opportunity discovery. A piece of information's trust level can change without any opportunity changing. Accreditation events happen on different timelines than admission cycles. This context has its own invariants (INV-IS1–IS3, INV-2, INV-10) that don't overlap with opportunity invariants.

#### BC-3: Reference Framework

**Purpose:** Provide the reference data and configuration that structures the domain.

**Core Entities:** None (this context contains value objects and reference data, not entities with business operations).

**Responsibilities:** Define institution types, award levels, qualification frameworks, authority jurisdictions, and country-specific reference data.

**Reason It Should Exist:** Reference data changes through administrative/configuration operations, not through business workflows. It is loaded and maintained by operators or data pipelines, not by user interactions. It is the most stable part of the domain.

### Assessment

These three contexts emerge **naturally** from the domain — they are not invented. The entities within each context share language, invariants, and lifecycle patterns. Cross-context communication happens through references (Opportunity Discovery references Trust & Accreditation for provenance; both reference Reference Framework for configuration).

**However**, for MVP, implementing three bounded contexts adds technical complexity (cross-context references, eventual consistency, separate persistence) that may not be justified. **LBC would recommend a single context for MVP with awareness of the natural separation, refactoring into bounded contexts when the codebase demands it.** This aligns with the pragmatic philosophy: discover the natural boundaries, but don't over-engineer the implementation.

**Recommendation:** Acknowledge the three natural bounded contexts in the domain model. Implement as a single context for MVP. Refactor into separate contexts when the code shows the seams (likely around Stage 2, when Trust & Accreditation develops its own workflows for source verification and quality assessment).

---

## 8. Hidden Assumptions

### HA-1: The Model Assumes Tertiary Education Only

**Evidence:** Every entity and example in Topics 1–3 refers to tertiary education. Institution Types are "University, Polytechnic, College of Education." Qualifications are "SSCE, UTME, NCE, ND, HND." Award Levels are "B.Sc., M.Sc., Ph.D., ND, HND." The term "secondary school" appears only in persona descriptions, not in domain entities.

**Why This Is Hidden:** Business Discovery does not explicitly scope StudyNexus to tertiary. A0-1 says "comprehensive education knowledge platform." A0-2 says "education infrastructure for Africa." A1-1 defines primary users as "Secondary School Student and Graduate" — but the student is *preparing to pursue tertiary*, not seeking secondary opportunities. The assumption is that "educational opportunities" means "tertiary educational opportunities."

**Impact:** If StudyNexus later supports secondary school discovery (e.g., finding the best secondary schools for your child, comparing O-Level performance across schools), the current model cannot represent secondary institutions as "Educational Institutions" without semantic distortion (a secondary school is not a "University" or "Polytechnic," and the Institution Type VO would need new values that break the current regulatory assumptions).

**Recommendation:** Make the tertiary-only assumption **explicit** in the domain model. Document that "Educational Institution" means "tertiary/post-secondary educational institution" in the current domain scope. If secondary education is added later, it may require a separate bounded context rather than expanding the current one.

---

### HA-2: The Model Assumes Admission Always Has a Cycle

**Evidence:** Admission Policy is scoped to an Admission Cycle. INV-P2 says "Only one active Admission Policy per Admission Cycle." Programme's admission status is derived from the intersection of lifecycle state and cycle state (INV-P3). Every admission event is assumed to occur within a time-bounded cycle.

**Why This Is Hidden:** In Nigeria, this is true — JAMB defines national admission cycles, and institutions define institutional cycles. But in many countries, admission is **rolling** (no fixed cycle). US graduate programmes commonly accept applications year-round. UK Clearing happens outside the main UCAS cycle. Online programmes often have multiple start dates per year with no unified cycle.

**Impact:** Rolling admission doesn't fit the Admission Cycle entity. An Admission Cycle requires start/end dates (INV-C1, INV-C3) and a defined phase sequence. Rolling admission has no phases — applications are received and evaluated continuously.

**Recommendation:** Add an Admission Mode attribute to Programme: Cyclic (admission occurs within defined cycles) or Rolling (applications accepted continuously). For Cyclic programmes, Admission Policies are cycle-scoped. For Rolling programmes, Admission Policies are period-scoped (or not scoped at all — one standing policy). This is a small addition that significantly broadens the model's applicability.

---

### HA-3: The Model Assumes Opportunities Are Location-Bound

**Evidence:** Educational Institution has a Location VO. Programme belongs to an Institution (which has a location). Scholarship targets Institutions (which have locations). The model implicitly assumes that educational opportunities happen at physical locations.

**Why This Is Hidden:** Online education, distance learning, and remote programmes challenge this assumption. A programme delivered fully online has no meaningful physical location — or its "location" is the institution's administrative office, which is irrelevant to the student. The current Delivery Mode attribute (Full-Time, Part-Time, Distance, Blended, Online) partially addresses this, but Location remains mandatory on Institution.

**Impact:** As online education grows (accelerated by post-pandemic shifts), programmes where location is irrelevant become more common. The current model handles this adequately (Location is always present but may be administratively meaningless for online-only institutions). The real issue is that **users searching for online programmes don't care about location**, and the model should not force location-based discoverability for these programmes.

**Recommendation:** Make Location optional (or add an "Is Location-Dependent" flag) on Educational Institution. For online-only institutions, location becomes administrative rather than discoverable. This is a minor change.

---

### HA-4: The Model Assumes One Currency per Financial Amount

**Evidence:** Monetary Amount (VO-9) has exactly one currency. Tuition is expressed in one currency. Scholarship value is expressed in one currency. Assumption A-D3-6 says "Monetary Amount does not handle multi-currency conversion."

**Why This Is Hidden:** In most countries, this is correct — tuition is in the local currency. But some programmes charge in foreign currency (Nigerian programmes priced in USD; international scholarships that cover tuition in one currency and provide a stipend in another). Some scholarships are "valued" in multiple currencies (tuition covered in the institution's currency, living expenses in the student's currency).

**Impact:** For MVP, single-currency is sufficient. For expansion (especially study abroad), multi-currency or currency-conversion may be needed.

**Recommendation:** No change for MVP. Flag as an expansion consideration. The current Monetary Amount VO is extensible (a multi-currency variant would be a different VO, not a modification).

---

### HA-5: The Model Assumes Qualifications Are Static, External Concepts

**Evidence:** Qualification is a supporting entity with no business operations. It is "defined by external bodies" and "StudyNexus records them; it doesn't manage them." Qualification has a Status attribute (Recognized, Deprecated, Replaced) but no lifecycle transitions managed by StudyNexus.

**Why This Is Hidden:** In practice, StudyNexus must manage qualification data — someone must create and maintain the Qualification records, even if the qualifications themselves are defined externally. When StudyNexus expands to a new country, someone must load that country's qualifications. When a qualification is deprecated, someone must update the status. The model treats these as administrative operations outside the domain, but they are necessary operations that the system must support.

**Impact:** The application layer will need administrative capabilities for managing Qualifications, Education Authorities, and other "supporting entities." The domain model is correct that these are not business operations driven by workflows, but the model should acknowledge that administrative operations exist.

**Recommendation:** Document that supporting entities (Qualification, Scholarship Provider, Education Authority) have **administrative lifecycles** managed by data operations, not business workflows. This is a clarification, not a structural change.

---

## 9. Missing Concepts

### MC-1: Country / Operational Context [FUNDAMENTAL]

**Why It's Missing:** Country appears as a string attribute on Education Authority, Scholarship Provider, and within the Location VO. But it is not a domain entity or value object with its own identity.

**Why It Should Exist:** Country is fundamental to the domain:
- It determines which reference data applies (A4-4: "Geographic expansion beyond Nigeria only after the Nigerian model has matured")
- It scopes Education Authority jurisdiction
- It determines currency, qualification systems, and institutional taxonomies
- StudyNexus's operational context is country-scoped
- A4-6: "International expansion should be anticipated but not optimized for"

**Is It Fundamental, Broadly Applicable, and Traceable?** Yes. Country is the most fundamental unit of educational system variation. Every educational system is organized at the national or sub-national level. It traces directly to A4-4, A4-6, and the Global Domain constraint.

**Recommendation:** Introduce Country as a value object (ISO 3166-1 alpha-2 code + display name). It becomes the root of reference data hierarchies and the natural scope for configuration.

---

### MC-2: Admission Pathway [FUNDAMENTAL]

**Why It's Missing:** Currently an open question (OQ-D3-1). The glossary defines "Alternative Admission Pathway" (A3-8) but the domain model has no corresponding entity.

**Why It Should Exist:** Admission pathways are first-class concepts in every educational system:
- Nigeria: Direct Entry, IJMB, JUPEB, standard UTME route
- UK: Foundation Year, Access Course, standard A-Level route, Clearing
- US: Standard admission, Transfer, Advanced Placement, Early Decision/Action
- Germany: Numerus Clausus, Dialogorientiertes Serviceverfahren
- Kenya: Standard KCSE route, diploma progression, bridging courses

Pathways determine:
1. Which qualifications are accepted
2. What level the student enters at
3. What additional criteria apply
4. How admission rules are structured

**Is It Fundamental, Broadly Applicable, and Traceable?** Yes. It exists in every country. It traces to A3-8 (Alternative Admission Pathways) and to the Assess Eligibility workflow (WF4), which currently cannot express pathway-specific requirements explicitly.

**Recommendation:** Introduce Admission Pathway as a supporting entity. Attributes: Name, Defining Authority (Education Authority), Entry Level (integer — 100, 200, 300), Accepted Qualifications (collection of references), Status. Referenced by Admission Rule. This makes admission rules more expressive and the ubiquitous language more complete.

---

### MC-3: Programme Offering (or Programme Instance) [IMPORTANT BUT DEFERRABLE]

**Why It Might Be Missing:** Currently, Programme is modeled as a single entity with a Tuition Fee and Programme Status. But a programme is offered repeatedly across admission cycles, and its characteristics change per offering:
- Tuition may differ per academic year
- Admission requirements may change per cycle (handled by Admission Policy)
- The programme may be admitting in one cycle and not in another

The current model handles per-cycle variation through Admission Policy (a new policy per cycle). Tuition variation is acknowledged as an evolving attribute but not fully modeled (OQ-D3-2).

**Why It Might NOT Be Needed:** Creating a "Programme Offering" entity for each cycle-year would multiply entities and add complexity. The current model handles the most important per-cycle variation (admission requirements) through Admission Policies. Tuition history can be tracked as an append-only collection on Programme.

**Recommendation:** Do NOT introduce Programme Offering as an entity. The current model is pragmatically sufficient. Track tuition history as a collection on Programme if needed (resolve OQ-D3-2).

---

## 10. Global Domain Review

### Test: Would the domain model remain unchanged in 9 countries?

| Country | Structural Changes Required? | What Differs (Reference Data Only) |
|---------|:---------------------------:|-----------------------------------|
| **Nigeria** | No | Current reference data |
| **Ghana** | No | Institution Types (University, University College, Polytechnic, Technical Institute, College of Education). Education Authorities (GTEC, NAB, WAEC). Qualifications (WASSCE, BECE). Award Levels (same as Nigeria plus Ghana-specific). |
| **Kenya** | No | Institution Types (University, National Polytechnic, Technical College, TTC). Education Authorities (CUE, KNEC, KUCCPS). Qualifications (KCSE, KCPE). Admission Cycle (KUCCPS placement cycle — different phases from JAMB). |
| **South Africa** | No | Institution Types (University, University of Technology, TVET College, Private FET College). Education Authorities (CHE, SAQA, Umalusi). Qualifications (NSC, NATED). Award Levels (Bachelor's, Diploma, Advanced Certificate, etc. — NQF levels). |
| **United Kingdom** | **Minor** | Institution Types (University, College, FE College, Sixth Form College, Specialist Institution). Education Authorities (OfS, QAA, UCAS, Ofsted). Qualifications (A-Levels, GCSE, BTEC, IB). **Admission Cycle phases differ (no examination period in UCAS cycle)** — already handled by configurable Phase Sequence. **Rolling admission for some programmes** — not handled (HA-2). |
| **Canada** | **Minor** | Institution Types (University, University College, College, CEGEP). Education Authorities (provincial — AUCC, Colleges Ontario, etc.). Qualifications (provincial diploma, IB, AP). **No national admission cycle** — handled by Defining Authority (institution-level cycles). **Rolling admission common** — not handled (HA-2). |
| **United States** | **Minor** | Institution Types (Research University, Liberal Arts College, Community College, For-Profit, Tribal). Education Authorities (regional accreditors, ABET, AACSB, College Board). Qualifications (SAT, ACT, AP, GED). **No national admission cycle** — handled. **Rolling admission very common** — not handled (HA-2). **Non-governmental accreditation predominant** — handled by F1. |
| **Germany** | **Minor** | Institution Types (Universität, Fachhochschule, Berufsakademie). Education Authorities (KMK, HRK, ASIIN). Qualifications (Abitur, Fachabitur). **Numerus Clausus admission** — a different admission mechanism (centralized vs institutional). **No "admission cycle" in the Nigerian sense** — some programmes have continuous enrollment. |
| **Australia** | **Minor** | Institution Types (University, TAFE, Private College). Education Authorities (TEQSA, AQF, VTAC, UAC). Qualifications (ATAR, VCE, HSC). **Multiple tertiary admission centres** (VTAC, UAC, QTAC, SATAC) — each defines its own admission cycle. |

### Summary

The domain model requires **no structural changes** for Nigeria, Ghana, Kenya, and South Africa — all Anglophone African countries with similar educational structures (centralized admission cycles, government-dominated accreditation, national qualification frameworks).

The model requires **minor structural accommodation** for UK, Canada, US, Germany, and Australia — specifically:
1. **Rolling admission** (HA-2) — programmes without admission cycles
2. **Non-cycle-based admission** — some countries don't have national admission cycles

Both are addressed by **RI-2 (Admission Mode)** — a small addition that adds an Admission Mode attribute (Cyclic/Rolling) to Programme. With this one change, the model works across all 9 countries.

**Verdict: The domain model is globally viable with one small addition (Admission Mode).**

---

## 11. Future Expansion Review

| Expansion Area | Belongs In Core Domain? | Bounded Context | Structural Changes Required? |
|---------------|:----------------------:|----------------|:---------------------------:|
| **Study Abroad** | **No** | New context: International Mobility | Yes — involves visa requirements, partner institutions, credit transfer, language requirements. These are different domain concepts. |
| **Student Visas** | **No** | New context: International Mobility | Yes — visas are a legal/administrative domain, not an educational domain. |
| **Exchange Programmes** | **Partial** | New context: International Mobility | Yes — exchange involves bilateral agreements, time-limited enrolment, credit transfer between institutions in different countries. |
| **Fellowships** | **Yes** | Opportunity Discovery | **No** — Fellowships are scholarships with different semantics (academic merit vs financial need, post-graduate focus, research component). Add Fellowship as a type alongside Scholarship, or as a separate aggregate root with the same structure as Scholarship. |
| **Grants** | **Yes** | Opportunity Discovery | **No** — Grants are financial awards for education/research. Same structure as Scholarship with different Coverage Type values (Research Grant, Equipment Grant, Travel Grant). |
| **Online Education** | **Yes** | Opportunity Discovery | **No** — Already partially handled (Delivery Mode = Online). May need enhancement (MOOC provider as a new type of institution, micro-credentials as a new qualification type). |
| **Professional Certifications** | **Yes** | Opportunity Discovery | **Minor** — Professional certifications are qualifications awarded by professional bodies (ACCA, ICAN, PMP). The current model handles them: Certification Body = Education Authority (non-governmental, accrediting type); Certification = Qualification; Certification Programme = Programme at an institution or directly offered by the authority. |
| **Vocational Training** | **Yes** | Opportunity Discovery | **No** — Already handled. Vocational institutions = Educational Institution with appropriate Institution Type. Vocational qualifications = Qualification with appropriate Qualification Type. |
| **Apprenticeships** | **Partial** | Opportunity Discovery + new context: Work-Based Learning | **Minor** — Apprenticeships combine education with employment. The educational component fits the current model (Programme at an Institution). The employment component (employer, wage, work placement) does not fit and would need a new context. |
| **Research Opportunities** | **No** | New context: Research Discovery | Yes — research opportunities (PhD positions, post-docs, research assistantships) have different structure: research topic, supervisor, lab, funding source, publication expectations. Some overlap with Programme (PhD programme) but enough difference to warrant a separate context. |
| **Continuing Education** | **Yes** | Opportunity Discovery | **No** — Short courses, professional development, certificate programmes. Already handled: Programme with appropriate Award Level (Certificate, Professional Development) and Duration. |

### Pressure Points

1. **Scholarship → Fellowship → Grant convergence:** These three concepts share 80%+ of their structure. If all three are aggregate roots, there's significant duplication. This is the same pattern as Admission Policy / Eligibility Policy (RC-1). LBC recommends keeping them separate until the duplication becomes painful, then refactoring.

2. **Opportunity Discovery context will grow significantly:** Fellowships, Grants, Professional Certifications, Vocational Training, and Continuing Education all fit within Opportunity Discovery. This context will eventually become large enough to warrant sub-division (e.g., by opportunity type: Academic, Professional, Financial). This is a future concern, not an MVP concern.

3. **International Mobility is a fundamentally different domain:** Study Abroad, Student Visas, and Exchange Programmes involve legal, immigration, and cross-border concepts that have no place in the current domain. These should be a separate bounded context from the start, with integration points (a Programme at an overseas Institution is discoverable; the visa/mobility requirements are in the Mobility context).

---

## 12. Laravel Beyond CRUD Review

### Evaluation Against Pragmatic DDD Principles

| Principle | Assessment | Concern? |
|-----------|-----------|:--------:|
| **Protects business invariants** | ✅ Strong | No |
| Every aggregate root protects named invariants through explicit business operations. INV-I1 through INV-IS3 are enforced by aggregate operations, not by external validation. | | |
| **Appropriate aggregate boundaries** | ✅ Strong | No |
| 5 aggregate roots is appropriate for the domain scope. The reduction from 11 was well-justified. The dual-parent on Admission Policy (W2) is the only concern, and LBC pragmatically accepts it. | | |
| **Avoids unnecessary entities** | ✅ Strong | No |
| 11 entities for this domain scope is lean. Admission Policy and Eligibility Policy could be merged into a single "Policy" entity (saving one entity), but the domain meaning is different. LBC prefers separate entities when the ubiquitous language demands it. | | |
| **Avoids premature abstractions** | ✅ Strong | No |
| No "Educational Opportunity," "Policy," or "Educational Offering" abstraction. Authority Jurisdiction and Phase Sequence are value objects, not abstract entities. This is well-calibrated. | | |
| **Encourages rich domain behaviour** | ⚠️ Adequate | **Minor** |
| Aggregate roots have meaningful operations (publishAdmissionPolicy, openApplications, recordAccreditation). But child entities (Admission Policy, Eligibility Policy, Accreditation Record) have no operations — their state changes are driven entirely by parent operations. This is correct per the model (they have no independent invariants), but it means child entities are structurally passive. LBC accepts this — not every entity needs operations; child entities exist within their parent's behavioural boundary. | | |
| **Keeps ubiquitous language clean** | ⚠️ Adequate | **Medium** |
| The language is mostly clean: "Education Authority," "Qualification Threshold," "Admission Rule" are domain terms. But "Educational Opportunity" (the most important term in A0-3) has no representation (W1). And "Admission Pathway" (A3-8) is missing (MC-2). These are gaps in the ubiquitous language. | | |
| **Remains pragmatic rather than academically DDD** | ✅ Strong | No |
| The model is clearly pragmatic: no domain events, no domain services, no repositories, no factories, no specifications pattern. The aggregate boundaries are justified by business need, not theoretical purity. Value objects serve practical purposes (Monetary Amount prevents currency comparison bugs; Subject Combination groups related data). | | |

### Where Classical DDD and LBC Would Diverge

| Decision | Classical Evans DDD | Laravel Beyond CRUD | Current Model | Verdict |
|----------|-------------------|--------------------|--------------|---------|
| Admission Policy / Eligibility Policy separation | Shared "Policy" abstraction with subtypes | Separate entities — shared lifecycle is coincidental | **Separate** (LBC) | ✅ Correct |
| Education Authority classification | Aggregate root (has identity, referenced by 4 entity types) | Supporting entity (no invariants to protect in StudyNexus) | **Supporting** (LBC) | ✅ Correct for MVP |
| Dual-parent Admission Policy | Separate aggregates with identity | Polymorphic parent reference | **Polymorphic** (LBC) | ✅ Correct |
| "Educational Opportunity" concept | Shared abstraction or interface | No abstraction — separate aggregates | **No abstraction** (LBC) | ✅ Correct (but acknowledge ubiquitous language gap) |
| Value Object for Admission Rule | Entity (has complex structure with references to Qualification) | Value Object (defined by attributes, no identity needed for comparison) | **Value Object** (LBC) | ✅ Correct — rules are compared by value for eligibility assessment |

---

## 13. Newly Discovered Open Questions

| ID | Question | Impact |
|----|----------|--------|
| OQ-R1 | Should Programme have an Admission Mode (Cyclic vs Rolling) to handle countries without admission cycles? | **High** — without this, the model cannot represent rolling admission programmes in the UK, US, Canada, Germany, Australia |
| OQ-R2 | Should Scholarship targeting support criteria-based targeting (by discipline, by ownership type, by location) in addition to explicit institution/programme lists? | **Medium** — most Nigerian scholarships target explicitly, but international scholarships commonly target by criteria |
| OQ-R3 | Should the domain model explicitly acknowledge that "Educational Opportunity" is a ubiquitous language term with no corresponding domain entity? | **Low** — documentation clarification |
| OQ-R4 | Should Trust Signals be computed per-entity or per-attribute? | **Low for MVP** — entity-level is pragmatic; attribute-level may be needed for Stage 3 |
| OQ-R5 | Should the domain model support secondary education institutions, or is the tertiary-only assumption acceptable? | **Low for MVP** — explicit documentation of the assumption is sufficient |

---

## 14. Readiness Assessment

### Assessment Against Review Objectives

| Objective | Assessment | Rating |
|-----------|-----------|:------:|
| **Correctness** | The model is correct for its stated scope (tertiary education, admission-cycle-based systems, location-bound institutions). The invariants are genuine business rules. The aggregate boundaries protect real consistency. | 8/10 |
| **Completeness** | Two fundamental concepts are missing (Country as VO, Admission Pathway as entity). Two important attributes were identified but not added to attribute tables (Application Deadline, Faculty). The ubiquitous language gap around "Educational Opportunity" is unacknowledged. | 7/10 |
| **Conceptual Integrity** | The model is internally consistent. No contradictions between invariants. No overlapping entity responsibilities. The separation of domain structure from reference data is well-maintained. | 9/10 |
| **Extensibility** | The model is extensible to most countries with reference data changes only. One structural addition (Admission Mode) is needed for rolling admission. The bounded context boundaries are natural and will support future separation. | 8/10 |
| **Consistency** | The domain model is consistent with Business Discovery decisions. All invariants trace to approved decisions. The architectural review revisions are consistently applied. | 9/10 |
| **Ubiquitous Language Quality** | The language is strong within the modeled domain but has two notable gaps: "Educational Opportunity" (no representation) and "Admission Pathway" (open question, not entity). | 7/10 |
| **Long-Term Maintainability** | The model is lean and pragmatic. No premature abstractions. No anemic aggregates. The value objects are purposeful. The only maintainability risk is the Scholarship → Fellowship → Grant convergence that will create pressure in Stage 2+. | 8/10 |

### Required Changes Summary

| Change | Type | Effort |
|--------|------|--------|
| Authority Type → Collection (RC-2) | Data model correction | Trivial |
| Add Application Deadline to Scholarship (RC-3) | Attribute addition | Trivial |
| Add Faculty to Programme (RC-4) | Attribute addition | Trivial |
| Document Admission/Eligibility Policy separation rationale (RC-1) | Documentation | Trivial |

### Recommended Improvements Summary

| Improvement | Type | Effort |
|-------------|------|--------|
| Admission Pathway as supporting entity (RI-1) | Entity addition | Small |
| Authority Jurisdiction as collection (RI-2) | VO multiplicity change | Small |
| Country as value object (RI-3) | VO addition | Small |
| Financial Coverage VO replaces Value + Coverage Type (RI-4) | VO redesign | Small |

---

## Final Answer

# YES, WITH MINOR REVISIONS

**Justification:**

The domain model is structurally sound, pragmatically scoped, and globally extensible with reference data changes. The aggregate boundaries are correct. The invariants protect real business rules. The value objects serve genuine domain purposes. The model is consistent with Business Discovery and internally coherent.

However, four minor revisions are **required** before proceeding:

1. **Authority Type must be a collection, not a single value** (RC-2). This is a data model error — the assumption says "multiple types" but the attribute is singular.

2. **Application Deadline must be added to Scholarship's attribute table** (RC-3). This was decided (DD3-11) but not reflected in the entity attribute table.

3. **Faculty must be added to Programme's attribute table** (RC-4). This was decided (DD3-10) but not reflected in the entity attribute table.

4. **Admission/Eligibility Policy separation rationale must be documented** (RC-1). Without this, future developers will "fix" the structural similarity by introducing a shared abstraction.

Additionally, **two recommended improvements should be strongly considered** before Behaviour Discovery begins:

5. **Admission Pathway as a supporting entity** (RI-1). This fills a gap in the ubiquitous language and makes Admission Rules more expressive. It is small, well-scoped, and traceable to A3-8.

6. **Admission Mode (Cyclic/Rolling) on Programme** (from HA-2). This is the single change needed to make the model globally valid across all 9 test countries. Without it, the model cannot represent rolling admission — a common pattern in the UK, US, Canada, and Germany.

With these revisions applied, the Domain Discovery is sufficiently complete and internally consistent to begin Behaviour Discovery and Application Discovery. The model's strengths (pragmatic aggregates, jurisdiction-based invariants, authority-scoped identity, derived attribute discipline) substantially outweigh its weaknesses (two missing concepts, three hidden assumptions, ubiquitous language gap). The weaknesses are addressable without structural redesign.
