# StudyNexus — Post-Freeze Platform, Product & Search Architecture Review

**Date:** 2026-08-08
**Status:** Architecture Review
**Subject:** Frozen Baseline (20-domain-architecture-frozen-baseline.md)
**Method:** Adversarial review of platform/product capabilities against the frozen domain architecture
**Prerequisite:** Frozen Baseline (20), Validation & ADR Review (19), Domain Architecture (18), Consolidation (13), Behaviour Discovery (14)
**Architectural Philosophy:** Laravel Beyond CRUD (Brent Roose & Freek Van der Herten) — Pragmatic Domain-Driven Design
**Stack:** TALL (Laravel + Blade + Livewire + Flux + Tailwind CSS) + Filament (Admin) + Typesense (Search)
**Constraint:** Do NOT begin implementation. Produce the review document only.
**Verdict:** FROZEN BASELINE REMAINS — WITH SUPPLEMENTARY PLATFORM ARCHITECTURE

---

## 1. Executive Summary

This document reviews the StudyNexus frozen architectural baseline against newly clarified platform and product requirements that were not fully addressed during domain discovery and architecture freezing. The review covers authorization, user engagement, comparison, notifications, social sharing, Typesense search, SEO faceted architecture, Spatie packages, and future expansion.

**Key Findings:**

1. **The frozen domain model is sound.** No newly identified requirement contradicts the aggregate boundaries, invariants, or domain operations. All five aggregate roots remain correctly drawn. The 20 Actions, 28 VOs, and 29 domain events remain justified.

2. **The gaps are in platform/product architecture, not domain architecture.** The frozen baseline deliberately focused on domain structure — entities, aggregates, invariants, and domain operations. What it did not address (because the requirements were not yet clarified) are the application-layer and product-layer capabilities that surround the domain: how users authorize, how they engage, how they discover via search, how they compare, how they receive notifications, and how the platform is administered by multiple organizational roles.

3. **No frozen decision needs to be reversed.** Every gap identified in this review is additive — it extends the architecture without contradicting it. The supplementary architecture can be built on top of the frozen baseline without modifying the domain model.

4. **The most significant new architectural requirement is the scoped authorization model.** The frozen baseline deferred the role/permission model. The clarified requirement — multiple user classes with scoped roles across institutions — requires a deliberate design decision that must be documented before implementation.

5. **Typesense search architecture is the second most significant gap.** The frozen baseline identified search as a deferred infrastructure decision. The clarified requirement — highly faceted listing pages, SEO-friendly URLs, and intentional SEO landing pages — requires architectural treatment that goes beyond "use Scout + Typesense."

6. **User engagement capabilities (save, follow, compare, alert) are product features, not domain entities.** They should be implemented as application-layer relationships and read models, not as domain aggregates with invariants. This is the correct Laravel Beyond CRUD classification.

7. **Notification architecture is an application-layer concern that should use Laravel's native notification system.** No custom notification framework is needed.

8. **The frozen baseline should remain frozen.** This review produces a supplementary platform architecture document that layers on top of the frozen baseline. No ADR supersession is required.

---

## 2. Baseline Being Protected

The following decisions from the frozen baseline are treated as authoritative and are not reopened without evidence:

| Frozen Decision | Canonical Form | This Review's Stance |
|----------------|---------------|---------------------|
| 5 aggregate roots | Institution, Programme, Scholarship, Admission Cycle, Information Source | **Protected.** No new requirement contradicts these boundaries. |
| 20 Application Actions | With explicit Action Criterion | **Protected.** New platform Actions will follow the same criterion. |
| 28 Value Objects | 11 objects + 1 computed + 1 demoted + 15 enums | **Protected.** No new VOs needed for platform features. |
| No repositories | Eloquent IS the repository | **Protected.** Scoped permissions are application-layer, not domain. |
| TALL stack | No SPA, no React/Next.js/Vue | **Protected.** Confirmed explicitly. |
| Filament for admin only | Domain rules outside Filament | **Protected.** Filament authorization consumes the same model. |
| Domain events as plain PHP classes | No shared interface, no event sourcing | **Protected.** Notification triggers via event listeners. |
| Educational Opportunity is NOT an entity | It is a product/read-model abstraction | **Protected.** Comparison and discovery use read models. |
| Global-first | No Nigerian concepts as universal abstractions | **Protected.** Scoped auth supports any organization type. |

---

## 3. New Requirements

| # | Requirement | Since When | Domain Concern? | Application Concern? | Product/ Presentation? | Infrastructure? |
|---|-------------|-----------|:---------------:|:-------------------:|:---------------------:|:---------------:|
| R-1 | Multiple user classes with scoped roles | Post-freeze | No | **Yes** | Yes | No |
| R-2 | Multiple administrators per institution | Post-freeze | No | **Yes** | Yes | No |
| R-3 | Organization/institution membership | Post-freeze | No | **Yes** | Yes | No |
| R-4 | Save/bookmark educational resources | Post-freeze | No | **Yes** | Yes | No |
| R-5 | Follow resources for updates | Post-freeze | No | **Yes** | Yes | No |
| R-6 | Compare resources side-by-side | Post-freeze | No | No | **Yes** | No |
| R-7 | Like/lightweight engagement | Post-freeze | No | No | **Yes** | No |
| R-8 | Alerts/watchlists | Post-freeze | No | **Yes** | No | No |
| R-9 | Social sharing | Post-freeze | No | No | **Yes** | No |
| R-10 | Multi-channel notifications | Post-freeze | No | **Yes** | No | **Yes** |
| R-11 | Typesense as search engine | Architecture | No | No | **Yes** | **Yes** |
| R-12 | Highly faceted listing pages | Post-freeze | No | No | **Yes** | No |
| R-13 | SEO landing pages for facets | Post-freeze | No | No | **Yes** | No |
| R-14 | Web push notifications | Post-freeze | No | No | No | **Yes** |

**Critical observation:** None of these requirements are domain concerns. They do not introduce new invariants, new business rules, or new aggregate boundaries. They are application, product, and infrastructure concerns. This confirms that the frozen domain model is complete — the gaps are in the platform layer that surrounds it.

---

## 4. Domain vs Application vs Infrastructure vs Product Classification

### Classification Principle

| Layer | Contains | Examples in StudyNexus | Depends On |
|-------|----------|----------------------|-----------|
| **Domain** | Business rules, invariants, aggregate operations | Institution lifecycle, Programme admission, Scholarship eligibility, Source trust | Nothing (pure PHP) |
| **Application** | Use cases, orchestration, authorization, relationships between users and domain | Actions, scoped permissions, user saves, user follows, notification triggers | Domain |
| **Infrastructure** | Persistence, search, queues, external services | Eloquent, Typesense, Redis, queues, email providers | Application |
| **Product/Presentation** | UI, SEO, comparison views, discovery pages, social sharing | Blade templates, Livewire components, Flux UI, SEO meta, listing pages | Application |
| **Read Model** | Search projections, computed views, faceted data | Typesense documents, opportunity feed, comparison data | Domain + Infrastructure |

---

## 5. RBAC Architecture

### Requirement

StudyNexus needs a flexible authorization model supporting:

- Platform-wide roles (super admin, moderator, content admin)
- Organization-scoped roles (institution admin, institution editor, institution admissions staff)
- Scholarship-provider-scoped roles (provider admin, provider staff)
- Education-authority-scoped roles (authority admin, authority staff)
- Ordinary users (student, guardian, tutor)
- Future organizational types without redesign

### Evaluation of Spatie Laravel Permission

Spatie Laravel Permission provides:
- **Roles** (with permissions)
- **Permissions** (granular)
- **Role/permission assignment** to users
- **Wildcard permissions**
- **Caching**

What it does NOT provide natively:
- **Scoped/tenant roles** — a user having "institution-admin" globally is different from having "institution-admin" for Institution A only
- **Team/organization membership** — there is no built-in concept of "this user belongs to this organization with these roles"

### Decision: Spatie Permission + Application-Layer Scoping

**Do NOT reinvent RBAC.** Spatie Permission provides the role/permission foundation. The scoping layer is a small application addition.

#### Architecture

```
User
  ├── Has global roles/permissions (platform level)
  │     e.g., "platform-admin", "content-moderator"
  │
  └── Has memberships (OrganizationMember pivot)
        ├── organization_type: "institution" | "scholarship_provider" | "education_authority" | ...
        ├── organization_id: FK to the organization
        ├── roles: Spatie roles scoped to this membership
        └── permissions: Spatie permissions scoped to this membership
```

#### OrganizationMember Pivot Table

```sql
organization_members
    id                  bigint PK
    user_id             bigint FK → users
    organization_type   string (morph type: "institution", "scholarship_provider", "education_authority")
    organization_id     bigint (morph ID)
    role                string (e.g., "admin", "editor", "admissions_staff", "viewer")
    created_at          timestamp
    updated_at          timestamp
```

**Why a single pivot table instead of Spatie's team feature?**

Spatie Permission has no built-in team/tenant concept (it was removed in v6). The `OrganizationMember` pivot is the minimum custom layer. It uses polymorphic relationships so that any future organization type (e.g., "training_provider", "professional_body") can be added with zero schema changes — only a new morph type.

#### Role Model

**Do NOT hardcode all future roles.** Define the roles the system actually needs now, with the understanding that new roles are data additions, not code changes.

| Scope | Role | Permissions (examples) | Can Manage |
|-------|------|----------------------|-----------|
| **Platform** | `platform-admin` | All permissions | Everything |
| **Platform** | `platform-moderator` | Review, verify, edit content | Content moderation, source verification |
| **Platform** | `content-admin` | CRUD institutions, programmes, scholarships | Data management |
| **Platform** | `content-editor` | Edit descriptions, media, publish | Content editing |
| **Institution** | `institution-admin` | Full management of one institution | Institution + programmes + policies |
| **Institution** | `institution-editor` | Edit details, media, programmes | Non-status-changing operations |
| **Institution** | `institution-admissions` | Manage admission policies, cycles | Admission-specific operations |
| **Scholarship Provider** | `provider-admin` | Full management of provider's scholarships | Provider + scholarships |
| **Scholarship Provider** | `provider-staff` | Edit scholarship details | Non-status-changing scholarship ops |
| **Education Authority** | `authority-admin` | Manage authority data, cycles | Authority + cycles |
| **Authority** | `authority-staff` | View authority data | Read-only |
| **User** | `student` | Search, save, follow, compare, apply | Public + authenticated features |
| **User** | `guardian` | Search, save, follow, compare (on behalf) | Public + authenticated features |
| **User** | `tutor` | Search, save, follow, compare, advise | Public + authenticated features |

**Key design rule:** Roles are strings, not enums. New roles can be added as data without code changes. This is the pragmatic Laravel approach — Spatie Permission already stores roles as strings in the database.

#### Authorization Checks

```php
// Platform-level: Spatie Permission native
if ($user->hasRole('platform-admin')) { ... }
if ($user->can('institution.create')) { ... }

// Organization-scoped: Application layer
if ($user->isMemberOf($institution, 'admin')) { ... }
if ($user->canManage($institution)) { ... }

// Laravel Policy integration
class InstitutionPolicy
{
    public function update(User $user, Institution $institution): bool
    {
        return $user->hasRole('platform-admin')
            || $user->hasRole('content-admin')
            || $user->isMemberOf($institution, 'admin')
            || $user->isMemberOf($institution, 'editor');
    }

    public function suspend(User $user, Institution $institution): bool
    {
        return $user->hasRole('platform-admin')
            || $user->isMemberOf($institution, 'admin');
    }
}
```

#### Filament Authorization

Filament uses Laravel's native authorization (Policies + Gates). The same `InstitutionPolicy` that protects Livewire/Blade actions also protects Filament resources. **Filament is NOT the authorization system** — it is a consumer of the same application-wide authorization model.

#### Livewire Authorization

Livewire components call `$this->authorize()` which uses the same Policies. No separate authorization logic.

#### Why Not Spatie Teams/Tenancy?

Spatie's `laravel-permission` v6 removed the team feature. Even in v5, teams were global (a user belongs to a team, not to a specific organization's team). StudyNexus needs **organization-scoped membership** — the same user can be admin of Institution A and viewer of Institution B. This requires the custom `OrganizationMember` pivot, which is minimal and pragmatic.

**Do NOT adopt a full multi-tenancy package** (like `stancl/tenancy`). StudyNexus is a single-tenant application with organization-scoped authorization. Multi-tenancy implies separate databases or schema isolation, which is unnecessary complexity for this use case.

---

## 6. Organization/Institution Membership Architecture

### Model

```
User  ────M:N────> Organizations (polymorphic)
                     ├── Institution
                     ├── ScholarshipProvider
                     ├── EducationAuthority
                     └── (future: TrainingProvider, ProfessionalBody, ...)
```

The `OrganizationMember` pivot enables:

1. **Multiple administrators per institution** — Add multiple users with `role = 'admin'` to the same institution.
2. **One user managing multiple institutions** — Add the same user to different institutions with different roles.
3. **Future organization types** — Add a new morph type without schema changes.

### New Application Structures

| Structure | Namespace | Purpose |
|-----------|-----------|---------|
| `OrganizationMember` model | `App\Domain\Models\OrganizationMember` | Pivot model for polymorphic organization membership |
| `IsMemberOf` query | `App\Queries\Membership\IsMemberOf` | Check if user is a member of an organization with a given role |
| `AddOrganizationMember` action | `App\Actions\Membership\AddOrganizationMember` | Add a user to an organization with a role |
| `RemoveOrganizationMember` action | `App\Actions\Membership\RemoveOrganizationMember` | Remove a user from an organization |

**Why is OrganizationMember in Domain\Models?** Because it is a persistent Eloquent model that the authorization layer queries. It is NOT a domain aggregate — it has no invariants to protect. It is an application relationship model stored alongside domain models. This is the pragmatic Laravel approach: Eloquent models live in `Domain\Models\` regardless of whether they are domain aggregates or application relationships.

**Alternative considered:** Put `OrganizationMember` in `App\Models\`. **Rejected** — this violates the namespace consistency established in F1. All Eloquent models use `App\Domain\Models\*`.

---

## 7. Multiple Institution Administrators

### Design

The `OrganizationMember` pivot naturally supports multiple administrators:

```php
// Add two admins to the same institution
AddOrganizationMember::execute($user1, $institution, 'admin');
AddOrganizationMember::execute($user2, $institution, 'admin');

// Check authorization
$institution->members()->wherePivot('role', 'admin')->count(); // 2
```

There is no "owner" field on Institution. **Ownership is a membership concept, not a domain concept.** The Institution aggregate does not know who administers it — that is an application concern. The domain model remains clean: Institution protects its invariants (name, status, policies, accreditation), and the authorization layer determines who can invoke those domain operations.

**This is the correct separation.** Injecting "owner_id" or "admin_user_id" into the Institution aggregate would violate the principle that aggregate roots protect domain invariants, not application authorization rules.

---

## 8. User Engagement Architecture

### Classification of Each Engagement Type

| Capability | Classification | Persisted? | Rationale |
|-----------|---------------|:----------:|-----------|
| **Save/Bookmark** | Application + Product | **Yes** | User wants to return to a resource. Must survive across sessions. Requires persistence. |
| **Follow** | Application | **Yes** | User wants notifications on changes. Must be queryable for notification dispatch. Requires persistence. |
| **Like** | Product | **Yes** (minimal) | Lightweight engagement signal. Can be used for personalization. Persisted as a simple relationship. |
| **Compare** | Product + Session | **Ephemeral (anonymous), Persisted (authenticated)** | Comparison sets are temporary during a session. Authenticated users may save comparison sets for later. |
| **Share** | Product | **No** (client-side) | Sharing is a client-side action (open WhatsApp/Facebook with a URL). No domain or application state change. Share counts are vanity metrics with dubious value. |
| **Hide/Not Interested** | Product | **Yes** (user preference) | Affects what the user sees in future feeds. Persisted as a user preference. |
| **Alert/Watchlist** | Application | **Yes** | User defines conditions for notification triggers. Requires persistence for evaluation. |

### Implementation Strategy

#### Save/Bookmark

```sql
saved_resources
    id              bigint PK
    user_id         bigint FK → users
    resource_type   string (morph: "institution", "programme", "scholarship")
    resource_id     bigint (morph ID)
    created_at      timestamp
```

**Polymorphic relationship.** A user can save institutions, programmes, and scholarships. No `UserInteraction` entity — this is a simple `SavedResource` Eloquent model with a polymorphic relationship. It is NOT a domain aggregate — it has no invariants, no domain operations, no events. It is an application relationship.

**New query:** `App\Queries\User\SavedResources` — returns the user's saved resources, optionally filtered by type.

#### Follow

```sql
followed_resources
    id              bigint PK
    user_id         bigint FK → users
    resource_type   string (morph: "institution", "programme", "scholarship")
    resource_id     bigint (morph ID)
    created_at      timestamp
```

Same polymorphic pattern as saves. Following is distinct from saving: **Save = "I want to return to this." Follow = "Tell me when something changes."** A user may save without following (bookmark only) or follow without saving (watchlist only).

**Notification trigger:** When a domain event occurs (e.g., `ProgrammeAdmissionSuspended`), the `DispatchNotifications` listener checks `FollowedResource` to determine who should be notified.

#### Like

```sql
liked_resources
    id              bigint PK
    user_id         bigint FK → users
    resource_type   string (morph: "institution", "programme", "scholarship")
    resource_id     bigint (morph ID)
    created_at      timestamp
```

Lightweight. No unlike operation is necessary for MVP — users can like, and the like is idempotent. If unlike is needed, add a deleted_at soft delete.

**Do NOT use likes as domain signals.** Likes are product features for engagement and personalization. They do not affect trust signals, accreditation, or any domain concept.

#### Compare

**Anonymous users:** Comparison set stored in the Livewire component state (session). No persistence needed. The comparison component holds an array of resource IDs and renders them side-by-side.

**Authenticated users:** May optionally save a comparison set:

```sql
comparison_sets
    id              bigint PK
    user_id         bigint FK → users
    name            string (nullable)
    resource_type   string ("institution", "programme", "scholarship")
    resource_ids    json (array of IDs)
    created_at      timestamp
    updated_at      timestamp
```

Comparison is NOT a domain concept. It is a product/view capability. No `ComparisonAggregate`. No invariants. No domain events.

#### Alert/Watchlist

```sql
user_alerts
    id              bigint PK
    user_id         bigint FK → users
    alert_type      string ("admission_open", "scholarship_deadline", "accreditation_change", ...)
    criteria        json (alert-specific: {"country": "ng", "institution_type": "university", "discipline": "computer-science"})
    is_active       boolean
    last_triggered_at  timestamp (nullable)
    created_at      timestamp
    updated_at      timestamp
```

Alerts are application-layer constructs. They define conditions that, when met, trigger notifications. They do not belong to any domain aggregate.

### No Generic UserInteraction Entity

**Explicitly rejected.** Each engagement type (save, follow, like, compare, alert) has different semantics, different lifecycle, and different consumers. Collapsing them into a single `UserInteraction` entity with an `interaction_type` discriminator would save one migration but would:
- Create a god table with heterogeneous columns (some fields only apply to saves, others only to alerts)
- Make querying specific engagement types slower (index on interaction_type + resource_type + user_id)
- Obscure the distinct semantics of each capability
- Encourage adding "just one more interaction_type" without considering whether it belongs

The Laravel Beyond CRUD principle is clear: **each concept that has distinct behaviour gets its own model.** Save, Follow, Like, and Alert have distinct behaviour. They get distinct models.

---

## 9. Comparison Architecture

### Classification

Comparison is a **product/presentation capability**, not a domain concept.

**Evidence:**
- Comparison has no invariants — there is no business rule about what can or cannot be compared.
- Comparison has no domain operations — comparing is reading data side-by-side, not modifying state.
- Comparison does not affect any aggregate's consistency boundary.
- Comparison data is a projection of domain state — it reads from the same models that detail pages read from.

### Implementation

| Aspect | Approach |
|--------|---------|
| **Anonymous comparison** | Livewire component holds selected IDs in component state; Query classes fetch detail data for each ID; Blade renders comparison table |
| **Authenticated comparison** | Same Livewire component + optional "Save Comparison Set" action that persists to `comparison_sets` table |
| **Comparison dimensions** | Hardcoded per resource type in Blade/Query classes. Programme comparison shows duration, award, tuition, admission requirements, accreditation. Institution comparison shows type, ownership, location, programmes count. Scholarship comparison shows amount, eligibility, deadline, provider. |
| **Cross-type comparison** | NOT supported initially. Comparing a programme with a scholarship makes no semantic sense. If future "Study Abroad Opportunity" comparison requires a unified interface, the Educational Opportunity read model (already planned) provides it — but this is a product view, not a domain entity. |
| **Livewire implementation** | `App\Livewire\Public\OpportunityComparison` component. Manages selection state, calls Query classes, renders comparison template. |

### Educational Opportunity Decision Preserved

**The previous decision that Educational Opportunity is a business/product abstraction remains in force.** Comparison does not require an `EducationalOpportunity` domain entity. The comparison component can render different templates per resource type. If a future unified comparison across resource types is needed, the `GetOpportunityFeed` read model query (already in the architecture) provides the unified view.

---

## 10. Notification Architecture

### Decision: Laravel Native Notifications

Laravel's notification system provides:
- **Notifiable entities** (users, and any model with `HasDatabaseNotification`)
- **Multiple channels** (mail, database, custom channels for web push, SMS)
- **Queue support** (notifications can be queued)
- **Notification events** (for tracking delivery)
- **Per-user preferences** (via custom logic)

**This is sufficient for StudyNexus.** Do NOT create a custom notification framework.

### Architecture

```
Domain Event
    ↓ (dispatched by aggregate method)
Domain Event Listener
    ↓ (determines who should be notified)
Notification Dispatch
    ↓ (via Laravel Notification facade)
Notification Class
    ├── toMail()       → Email channel
    ├── toDatabase()   → In-app notification storage
    ├── toWebPush()    → Custom channel (web-push)
    ├── toSms()        → Custom channel (SMS via provider)
    └── toTelegram()   → Custom channel (future)
```

### Notification Classes

```php
// Example: Admission cycle opening notification
class AdmissionCycleOpenedNotification extends Notification
{
    public function via(object $notifiable): array
    {
        // Check user's notification preferences
        $channels = ['database'];
        if ($notifiable->wantsEmailFor('admission_updates')) $channels[] = 'mail';
        if ($notifiable->wantsWebPushFor('admission_updates')) $channels[] = WebPushChannel::class;
        return $channels;
    }

    public function toMail(object $notifiable): MailMessage { ... }
    public function toDatabase(object $notifiable): array { ... }
    public function toWebPush(object $notifiable): WebPushMessage { ... }
}
```

### Notification Preferences

```sql
notification_preferences
    id              bigint PK
    user_id         bigint FK → users
    category        string ("admission_updates", "scholarship_alerts", "accreditation_changes", ...)
    email           boolean default true
    in_app          boolean default true
    web_push        boolean default false
    sms             boolean default false
    digest_frequency string nullable ("daily", "weekly", "instant")
    created_at      timestamp
    updated_at      timestamp
```

Notification preferences are **user settings**, not domain concepts. They belong in the application layer.

### Key Design Rules

1. **Notifications originate from domain events, not from aggregate roots.** Aggregate roots dispatch events; listeners determine who to notify and dispatch Laravel notifications. This keeps notification logic out of the domain model.
2. **Notification classes are in `App\Notifications\`.** They are application-layer, not domain.
3. **Notification preferences are per-user, per-category, per-channel.** Users control their own notification preferences.
4. **Web push uses a custom channel class.** Laravel doesn't provide web push natively, but adding a `WebPushChannel` class is a small, well-defined extension — not a framework.
5. **SMS uses a custom channel class.** Same approach — a `SmsChannel` class wrapping an SMS provider (e.g., Termii for Nigeria, Twilio for global).
6. **Digest/batch notifications** are handled by a scheduled job that checks for pending notifications and sends a digest email/in-app notification summary.

### Notification Sources

| Source | Event | Who Gets Notified |
|--------|-------|-------------------|
| Admission cycle opening | `AdmissionCycleActivated` | Users following programmes in this cycle |
| Programme info changed | `ProgrammeAdmissionPolicyPublished` | Users following this programme |
| Scholarship deadline approaching | Scheduled check | Users who saved/followed this scholarship |
| Scholarship published | `ScholarshipAnnounced` | Users with matching alert criteria |
| Institution updated | `InstitutionRenamed` etc. | Users following this institution |
| Accreditation status changed | `InstitutionAccredited` / `ProgrammeAccredited` | Users following this entity |
| Followed resource changed | Any domain event on followed entity | Users following the entity |

---

## 11. Social Sharing Architecture

### Classification: Product/Presentation Only

Social sharing is entirely a client-side + Blade concern. No domain model, no application model, no persistence needed for the sharing action itself.

### Implementation

| Aspect | Approach |
|--------|---------|
| **Share buttons** | Blade component with links to WhatsApp, Facebook, X, LinkedIn, Telegram, copy-link. Pure client-side — `window.open()` with pre-filled share URLs. |
| **Share URLs** | Canonical public URLs: `/institutions/{slug}`, `/programmes/{slug}`, `/scholarships/{slug}` |
| **Open Graph metadata** | Blade `<meta property="og:">` tags on every public detail page. Generated from domain data (name, description, image, URL). |
| **Schema.org structured data** | `spatie/schema-org` for `CollegeOrUniversity`, `EducationalOccupationalProgram`, `EducationalOccupationalCredential` on detail pages. |
| **Share counts** | **NOT tracked.** Share counts are vanity metrics. They are inaccurate (most sharing happens via copy-paste or native share sheets, not through tracked links), they add database writes to read-heavy pages, and they provide negligible business value. If share analytics are needed in future, use a client-side analytics event, not a server-side counter. |
| **Social previews** | Open Graph metadata ensures rich previews when StudyNexus URLs are shared on any platform. |

### Why No Share Count Tracking

1. **Inaccurate:** Most sharing bypasses tracked share buttons (copy-paste, native share, forwarding).
2. **Write-on-read:** Incrementing a share count on every page view or share click adds writes to read-heavy pages, which is an anti-pattern for performance.
3. **Gaming risk:** Share counts can be manipulated, making them unreliable as signals.
4. **No domain invariant:** There is no business rule about share counts. They do not affect trust, accreditation, eligibility, or any domain concept.
5. **Analytics alternative:** If the business needs to know "how often is this resource shared," use client-side analytics events (PostHog, Plausible, etc.) — server-side counters are the wrong tool.

---

## 12. Typesense Architecture

### Core Principle

> **PostgreSQL is the authoritative system of record. Typesense is a search/discovery projection.**

Typesense never holds data that cannot be reconstructed from PostgreSQL. Typesense documents are denormalized search-optimized representations of domain state. If Typesense goes down, the application still functions (with degraded search — fallback to Eloquent queries). If PostgreSQL goes down, the application is down.

### Three Separate Representations

| Representation | Technology | Purpose | Update Mechanism |
|---------------|-----------|---------|-----------------|
| **Authoritative domain** | PostgreSQL + Eloquent | Source of truth; invariants; transactions | Domain operations on aggregate roots |
| **Search projection** | Typesense | Full-text search, faceting, autocomplete, typo tolerance | Domain events → `UpdateSearchIndex` listener → Scout |
| **SEO/public representation** | Blade + Livewire | Crawlable HTML, meta tags, structured data, canonical URLs | Server-rendered from Eloquent (detail pages) or Typesense (listing pages with SEO) |

**These must not be collapsed into one model.** The search document structure is denormalized for search performance. The Eloquent model is normalized for domain integrity. The Blade template is optimized for SEO and user experience.

### Search Document Design

#### Institution Search Document

```json
{
  "id": "inst_abc123",
  "official_name": "University of Lagos",
  "slug": "university-of-lagos",
  "institution_type": "university",
  "ownership_type": "public",
  "country": "NG",
  "region": "Lagos",
  "city": "Lagos",
  "status": "operational",
  "accreditation_status": "full",
  "programme_count": 87,
  "programme_levels": ["undergraduate", "postgraduate"],
  "disciplines": ["engineering", "sciences", "arts", "law", "medicine"],
  "has_scholarships": true,
  "trust_signal": 0.85,
  "year_established": 1962,
  "sort_name": "university of lagos",
  "sort_relevance": 0.92
}
```

#### Programme Search Document

```json
{
  "id": "prog_def456",
  "name": "BSc Computer Science",
  "slug": "bsc-computer-science-unilag",
  "institution_name": "University of Lagos",
  "institution_slug": "university-of-lagos",
  "institution_type": "university",
  "award_level": "bachelors_degree",
  "discipline": "computer_science",
  "country": "NG",
  "region": "Lagos",
  "city": "Lagos",
  "admission_mode": "cyclic",
  "delivery_mode": "on_campus",
  "duration_years": 4,
  "tuition_amount": 150000,
  "tuition_currency": "NGN",
  "is_admitting": true,
  "accreditation_status": "full",
  "has_scholarships": true,
  "status": "admitting",
  "trust_signal": 0.85,
  "sort_name": "bsc computer science"
}
```

#### Scholarship Search Document

```json
{
  "id": "sch_ghi789",
  "name": "PTDF Scholarship",
  "slug": "ptdf-scholarship",
  "provider_name": "PTDF",
  "coverage_type": "full",
  "value_amount": 5000000,
  "value_currency": "NGN",
  "country": "NG",
  "status": "open",
  "application_deadline": "2026-04-30",
  "target_institution_ids": ["inst_abc123"],
  "target_programme_ids": ["prog_def456"],
  "disciplines": ["engineering", "sciences"],
  "sort_name": "ptdf scholarship"
}
```

### Synchronization Strategy

| Event | Action | Mechanism |
|-------|--------|-----------|
| Any domain event that modifies searchable data | Upsert affected document in Typesense | `UpdateSearchIndex` listener → queued Scout job |
| Relationship change (e.g., programme added to institution) | Re-index both institution and programme documents | `UpdateSearchIndex` listener with related-entity awareness |
| Bulk import | Queue bulk indexing job | `ImportInstitutionData` action → queue bulk Scout import |
| Full re-index | Artisan command: `scout:import` | Scheduled or manual; zero-downtime via Typesense's alias swapping |
| Deletion | Delete document from Typesense | `UpdateSearchIndex` listener → Scout `unsearchable()` |

### Eventual Consistency

Search documents are eventually consistent with PostgreSQL. After a domain operation commits, the `UpdateSearchIndex` listener queues a Scout job. The search document is updated asynchronously. **This is correct for a discovery platform.** Users expect slight lag in search results after data changes — they do not expect real-time search consistency.

**Stale document tolerance:** A search document may be stale for up to 5 seconds after a domain change. This is acceptable for StudyNexus. If tighter consistency is needed, the listener can be made synchronous for specific operations.

### Typesense Schema Versioning

When the search document schema changes (new field, renamed field, changed type):
1. Create a new Typesense collection with the updated schema
2. Bulk index into the new collection
3. Atomically swap the collection alias (Typesense supports this)
4. Delete the old collection

This enables zero-downtime schema changes.

---

## 13. Search Projection Model

### Denormalization Strategy

Each search document includes:
- **Direct attributes** from the aggregate (name, status, type)
- **Parent attributes** for filtering (institution_name, institution_type on programme documents)
- **Computed attributes** for faceting (is_admitting, programme_count, disciplines array)
- **Sort attributes** for sorting (sort_name for alphabetical, sort_relevance for ranking)

**Why denormalize?** Typesense is not a relational database. Joining institution data with programme data at query time is not possible. Denormalization is the standard approach for search engines — it trades write complexity (updating parent data on child documents when parent changes) for read performance (single document per result).

**Write amplification:** When an institution's name changes, all programme documents for that institution must also be updated. This is handled by the `InstitutionRenamed` event → `UpdateSearchIndex` listener, which updates the institution document AND all related programme documents in a single queued job.

---

## 14. Listing Page Architecture

### The Challenge

StudyNexus needs highly faceted listing pages (e.g., `/programmes?country=ng&type=university&discipline=computer-science`) that are:
1. **Fast** — Typesense excels at faceted search
2. **SEO-friendly** — Google needs crawlable HTML
3. **Interactive** — Users want instant filter feedback

### The Anti-Pattern

> "Typesense-powered listing = client-side JavaScript-only listing"

**This is wrong for StudyNexus.** A purely client-side listing page (React/Vue fetching from Typesense API) produces:
- Empty initial HTML (SEO failure)
- JavaScript-dependent content (accessibility failure)
- SPA complexity (violates TALL stack)

### The Correct Approach: Server-Rendered + Livewire + Typesense

```
1. User requests /programmes?country=ng&discipline=computer-science

2. Laravel route → Controller/Livewire component

3. Component calls SearchProgrammes Query:
   - Query Typesense via Scout
   - Apply filters, facets, sorting, pagination
   - Return results

4. Blade template renders:
   - Full HTML with results, filters, facet counts
   - SEO meta tags, canonical URL, structured data
   - Livewire wired filters for interactive updates

5. When user changes a filter (Livewire interaction):
   - Component re-queries Typesense with updated filters
   - Re-renders only the results + facets portion
   - URL updates via Livewire's query string binding
```

**Initial page load is fully server-rendered HTML.** Google sees complete content. Subsequent interactions are Livewire-powered (partial re-renders, no full page reload).

### Livewire Query String Binding

```php
class ProgrammeSearch extends Component
{
    #[Url]
    public ?string $country = null;

    #[Url]
    public ?string $discipline = null;

    #[Url]
    public ?string $level = null;

    #[Url]
    public ?string $institutionType = null;

    // ... other filters

    public function render()
    {
        $results = app(SearchProgrammes::class)->search(
            country: $this->country,
            discipline: $this->discipline,
            level: $this->level,
            institutionType: $this->institutionType,
        );

        return view('livewire.public.programme-search', [
            'results' => $results,
            'facets' => $results->facets(),
        ]);
    }
}
```

Livewire's `#[Url]` attribute binds component properties to query string parameters. When a user changes a filter, the URL updates, and the component re-renders. This is SEO-friendly — every filter state has a URL — and interactive — no full page reloads.

---

## 15. SEO Architecture

### Server-Rendered Principle

**Every public page must produce meaningful crawlable HTML on initial load.** This is non-negotiable for a discovery platform that depends on organic search traffic.

### Three Page Types

| Page Type | Rendering | SEO Strategy |
|-----------|-----------|-------------|
| **Detail pages** (e.g., `/programmes/bsc-computer-science-unilag`) | Blade server-rendered | Full SEO: canonical URL, Schema.org, Open Graph, meta description, breadcrumbs |
| **Listing pages** (e.g., `/programmes`) | Blade + Livewire + Typesense | SEO-friendly filters via Livewire query string binding; canonical URL management; structured data for ItemList |
| **SEO landing pages** (e.g., `/programmes/computer-science`, `/universities/lagos`) | Blade server-rendered | Curated SEO content + Typesense results; intentional content; not auto-generated from every filter combination |

---

## 16. Faceted URL / Indexation Strategy

### The Problem

Faceted search creates an exponential number of URL combinations:

```
/programmes?country=ng&type=university&discipline=cs&level=undergraduate&mode=on_campus&...
```

If every combination is indexable, Google's crawl budget is exhausted on low-value pages, and duplicate content issues arise.

### Strategy: Controlled Indexation

#### Rule 1: Only specific URL patterns are indexable

| URL Pattern | Indexable? | Reason |
|-------------|:----------:|--------|
| `/programmes` | ✅ Yes | Main listing page — high SEO value |
| `/programmes?discipline={slug}` | ✅ Yes | Discipline landing page — high SEO value |
| `/programmes?discipline={slug}&country={code}` | ✅ Yes | Discipline + country — moderate SEO value |
| `/programmes?discipline={slug}&country={code}&region={slug}` | ✅ Yes | Discipline + country + region — moderate SEO value |
| `/institutions` | ✅ Yes | Main listing |
| `/institutions?country={code}` | ✅ Yes | Country landing |
| `/institutions?country={code}&region={slug}` | ✅ Yes | Country + region landing |
| `/institutions?country={code}&type={type}` | ✅ Yes | Country + type landing |
| `/programmes?discipline={d}&country={c}&type={t}&level={l}&mode={m}` | ❌ No | Too specific — noindex, nofollow |

#### Rule 2: Non-indexable combinations get `noindex`

Any URL with more than 3 filter parameters, or with filter combinations not in the curated list, gets:

```html
<meta name="robots" content="noindex, follow">
```

The `follow` ensures Google can still discover detail pages linked from the listing, but it won't index the listing page itself.

#### Rule 3: Canonical URLs

Every listing page has a canonical URL pointing to the most generic version:

```html
<!-- /programmes?discipline=computer-science&country=ng&type=university -->
<link rel="canonical" href="/programmes?discipline=computer-science&country=ng">
```

#### Rule 4: SEO Landing Pages

StudyNexus intentionally creates curated SEO landing pages with:
- Hand-written or template-generated introductory content
- Typesense-powered results for the relevant filter
- Schema.org structured data
- Internal linking to related landing pages

```blade
{{-- /programmes/computer-science --}}
<x-seo-landing
    title="Computer Science Programmes in Nigeria & Africa"
    description="Discover computer science programmes across Nigerian universities..."
    :breadcrumb="['Home', 'Programmes', 'Computer Science']"
>
    {{-- Introductory content for SEO --}}
    <x-marketing-content discipline="computer-science" />

    {{-- Typesense-powered programme listing --}}
    <livewire:public.programme-search discipline="computer-science" />
</x-seo-landing>
```

These landing pages are **routes defined in `routes/web.php`** that render a Blade template + Livewire component. They are NOT auto-generated from every filter combination — they are intentionally created for high-value SEO targets.

#### Rule 5: Sitemap

The sitemap includes:
- All detail pages (institutions, programmes, scholarships)
- All curated SEO landing pages
- The main listing pages (`/programmes`, `/institutions`, `/scholarships`)

The sitemap does NOT include parameterized filter URLs.

### Sitemap Generation

Use `spatie/laravel-sitemap` to generate sitemaps. Run on a schedule (daily or weekly) to include newly published resources.

---

## 17. Study Abroad Expansion Analysis

### Already Supported

| Study Abroad Concept | How Modelled |
|---------------------|-------------|
| International institutions | Institution with `country != 'NG'` + appropriate InstitutionType |
| International programmes | Programme with foreign institution + Location VO |
| Rolling/multiple-intake admission | `AdmissionMode::Rolling` / `AdmissionMode::MultipleIntake` |
| International scholarships | Scholarship targeting international institutions/programmes |
| Foreign currency tuition | `MonetaryAmount` VO with ISO 4217 currency |
| Foreign accreditation | AccreditationRecord with foreign EducationAuthority |
| Foreign admission requirements | AdmissionRule VO with qualification references to foreign qualifications |

### Future Bounded Contexts (NOT modelled now)

| Concept | Why Separate | When |
|---------|-------------|------|
| **Visa & Immigration** | Country-pair-specific reference data; fundamentally different from opportunity discovery | When Study Abroad feature is developed |
| **Qualification Equivalency** | Mapping between qualification systems; complex rules per country pair | When international qualification matching is needed |
| **Application Process Tracking** | Student applying to institutions; different lifecycle from discovery | When application management feature is developed |
| **Language Requirements** | Could extend AdmissionRule VO with `language_proficiency` rule type; NOT a new entity | When Study Abroad detail pages need language requirement display |
| **Accommodation & Travel** | Product/content data; not domain concern | When Study Abroad information pages are developed |
| **Proof of Funds** | Reference data per country; not domain entity | When Study Abroad guidance pages are developed |

### Critical Requirement Preserved

> **Future Study Abroad expansion must not require rewriting the core Nigerian education model.**

The frozen domain model satisfies this: every Nigerian concept (JAMB, UTME, Naira, Nigerian institutions) is data, not architecture. Adding Study Abroad requires:
- New reference data (countries, qualifications, authorities)
- New `InstitutionType` enum cases (if needed — ADR-15 trigger)
- New SEO landing pages for Study Abroad
- Eventually, new bounded contexts (visa, application tracking)

**Zero structural changes to the core domain model.**

---

## 18. Global Expansion Analysis

### Country Addition Process

Adding a new country (e.g., Ghana) requires:

| Step | Action | Code Change? |
|------|--------|:------------:|
| 1 | Add country to `CountrySeeder` (ISO 3166-1) | No (data) |
| 2 | Add country-specific `EducationAuthority` records | No (data) |
| 3 | Add country-specific `Qualification` records | No (data) |
| 4 | Add country-specific `AdmissionPathway` reference data | No (data) |
| 5 | Possibly add new `InstitutionType` enum cases | Yes (if new types needed — ADR-15 trigger) |
| 6 | Possibly add new `AwardLevel` enum cases | Yes (if new levels needed — ADR-15 trigger) |
| 7 | Add SEO landing pages for the country | Yes (Blade templates + routes) |
| 8 | Configure Typesense facets for country-specific filters | No (Typesense facets are data-driven) |

**Steps 1-4 and 8 are data-only.** Steps 5-6 are code changes only if new enum values are needed. Step 7 is presentation-layer work. The domain model is untouched.

---

## 19. Future Education Expansion

### Test Against Education Types

| Education Type | Fits Model? | What Changes | New Entity? |
|---------------|:----------:|-------------|:-----------:|
| Primary education | Yes | `InstitutionType::PrimarySchool` | No |
| Secondary education | Yes | `InstitutionType::SecondarySchool` | No |
| Vocational/technical | Yes | `InstitutionType::VocationalInstitute` | No |
| Professional certification | Yes | `AwardLevel::ProfessionalCertificate` | No |
| Online education | Yes | `DeliveryMode::Online` (exists) | No |
| Bootcamps | Yes | `InstitutionType::Bootcamp` | No |
| Language education | Yes | `InstitutionType::LanguageSchool` | No |
| Short courses | Yes | Programme with short Duration | No |
| Exchange programmes | Yes | Programme + Scholarship (exchange type) | No |
| Foundation/pathway | Yes | Programme + AdmissionPathway | No |

**Verdict:** All education types are accommodated through enum additions and reference data. No domain redesign needed. The over-generalization trap is avoided — no generic `EducationalThing` or `Offering` abstraction.

---

## 20. Spatie Package Matrix

| Package | Decision | Where Used | Why | Domain Coupling | When |
|---------|----------|------------|-----|----------------|------|
| `laravel-permission` | **Adopt Now** | Authorization layer (Policies, Gates, Filament, Livewire) | Role/permission-based auth is core requirement; scoped via OrganizationMember | None — permissions are application-layer | Pre-implementation |
| `laravel-data` | **Adopt Now** | `App\Data\` DTOs, Form Requests, API responses | Type-safe request/response transformation; validation; Laravel-native | None — DTOs are application-layer | Pre-implementation |
| `laravel-medialibrary` | **Adopt Now** | Institution logos, document attachments | Media upload/management for institution profiles | None — media is infrastructure | When profile UI is built |
| `laravel-activitylog` | **Adopt Now** | `App\Listeners\LogActivity` | Audit trail for admin actions and status changes | Low — logs domain events but is not domain | Pre-implementation |
| `laravel-sluggable` | **Adopt Now** | Institution, Programme, Scholarship models | SEO-friendly URLs for public pages | None — slug is presentation | Pre-implementation |
| `laravel-query-builder` | **Adopt Now** | Query classes, API endpoints | Structured filtering without manual query building | None — query construction is infrastructure | When search UI is built |
| `laravel-backup` | **Adopt Later** | Backup job | No production database yet | None | Production deployment |
| `laravel-sitemap` | **Adopt Later** | SEO sitemap generation | No public pages yet | None | When public UI is built |
| `schema-org` | **Adopt Later** | Blade templates (structured data) | Schema.org markup for SEO | None — presentation | When public UI is built |
| `laravel-settings` | **Adopt Later** | Admin settings (feature flags, thresholds, notification defaults) | Flexible key-value settings | None | When admin settings UI is needed |
| `laravel-schedule-monitor` | **Evaluate When Needed** | Scheduled tasks monitoring | Useful for monitoring import/cycle jobs | None | When scheduled tasks are in production |
| `laravel-newsletter` | **Evaluate When Needed** | Email newsletter | May be needed for student notifications | None | When newsletter feature is requested |
| `laravel-ray` | **Evaluate When Needed** | Development debugging | Debug tool only | None | Developer preference |
| `laravel-model-states` | **Do Not Use** | — | PHP enums + domain methods + events are cleaner; no state machine exceeds 7 states | N/A | Re-evaluate only if any state machine exceeds 7 states |
| `laravel-fractal` | **Do Not Use** | — | Laravel Data provides superior DTO support | N/A | Not reconsidered |
| `valuestore` | **Do Not Use** | — | `laravel-settings` is a better fit; valuestore's flat-file approach doesn't suit database-backed app | N/A | Not reconsidered |

### Where NOT to Use Spatie

| Capability | Spatie Package? | What Instead | Why |
|-----------|:---------------:|-------------|-----|
| Notifications | No | **Laravel native `Illuminate\Notifications\`** | Laravel's notification system is excellent and already supports multi-channel, queuing, and database storage. No package needed. |
| Authorization scoping | No (Spatie doesn't provide this) | **Custom `OrganizationMember` pivot** | Spatie Permission v6 has no team/tenant feature. Scoping is a small custom addition. |
| Event dispatching | No | **Laravel native events** | Already decided in frozen baseline (ADR-3). |
| Queue processing | No | **Laravel native queues** | Laravel's queue system is robust. No package needed. |
| Caching | No | **Laravel native cache** | Redis via Laravel's cache facade. No package needed. |
| Search abstraction | No | **Laravel Scout** | Scout provides the Typesense driver. No additional Spatie package. |

---

## 21. Laravel/Blade/Livewire/Flux Architecture

### Public Site

```
Route → Controller/Livewire Component → Action/Query → Domain/Read Model → Blade Template → HTML
```

| Page Type | Blade | Livewire | Alpine | Flux |
|-----------|:-----:|:--------:|:------:|:----:|
| Static content pages | ✅ | — | — | ✅ (layout components) |
| Detail pages (institution, programme, scholarship) | ✅ | ✅ (interactive elements like save/follow) | ✅ (UI toggles) | ✅ |
| Listing/search pages | ✅ | ✅ (filters, pagination, facets) | — | ✅ |
| Comparison page | ✅ | ✅ (selection, re-render) | — | ✅ |
| Eligibility checker | ✅ | ✅ (form, results) | — | ✅ |

### Authenticated Dashboards

```
Route (auth middleware) → Livewire Component → Action/Query → Domain/Read Model → Blade Template
```

| Feature | Blade | Livewire | Flux |
|---------|:-----:|:--------:|:----:|
| Student dashboard | ✅ (layout) | ✅ (dynamic content) | ✅ |
| Saved opportunities | ✅ | ✅ (list, remove) | ✅ |
| Followed resources | ✅ | ✅ (list, unfollow) | ✅ |
| Comparison sets | ✅ | ✅ (manage, compare) | ✅ |
| Eligibility assessments | ✅ | ✅ (form, results) | ✅ |
| Notification preferences | ✅ | ✅ (form, save) | ✅ |
| Qualification profile | ✅ | ✅ (CRUD) | ✅ |

### Administration (Filament)

```
Filament Route → Filament Resource → Action → Domain → Database
                                      → Query → Read Model → Display
```

Filament Resources invoke Actions. Business logic is never in Filament Resource hooks. Authorization uses the same Policies that Livewire/Blade use.

### Explicit Confirmation

**React and Next.js are NOT part of the StudyNexus architecture.** The public site, authenticated dashboards, and administration are all built with Laravel-native technologies: Blade + Livewire + Flux + Filament. No SPA build step. No JavaScript framework. Alpine.js for lightweight browser-side interactions only.

---

## 22. Filament Architecture

### Resource Boundaries

| Filament Resource | Domain Model | Actions Invoked | Custom Pages Needed |
|-------------------|-------------|----------------|-------------------|
| `InstitutionResource` | Institution | CreateInstitution, SuspendInstitution, CloseInstitution, MergeInstitutions | Merge page, Import page |
| `ProgrammeResource` | Programme | CreateProgramme, PublishAdmissionPolicy, RecordAccreditation, DiscontinueProgramme | — |
| `ScholarshipResource` | Scholarship | AnnounceScholarship, OpenScholarshipApplications, TargetScholarshipProgrammes | — |
| `AdmissionCycleResource` | AdmissionCycle | AnnounceAdmissionCycle, ActivateAdmissionCycle, AdvanceAdmissionCyclePhase | — |
| `InformationSourceResource` | InformationSource | RegisterInformationSource, VerifyInformationSource, MarkSourceUnreliable | — |
| `QualificationResource` | Qualification | Direct CRUD (supporting entity) | — |
| `ScholarshipProviderResource` | ScholarshipProvider | Direct CRUD (supporting entity) | — |
| `EducationAuthorityResource` | EducationAuthority | Direct CRUD (supporting entity) | — |
| `OrganizationMemberResource` | OrganizationMember | AddOrganizationMember, RemoveOrganizationMember | — |

### Filament Authorization

Every Filament Resource uses Laravel Policies:

```php
class InstitutionResource extends XResource
{
    public static function canCreate(): bool
    {
        return auth()->user()->can('create', Institution::class);
    }
}
```

The same `InstitutionPolicy` that protects the public API and Livewire components protects Filament. **Filament is NOT the authorization system.** It is a consumer.

---

## 23. Cross-Cutting Concerns

### Classification

| Concern | Layer | Mechanism | Depends on Domain? |
|---------|-------|-----------|:------------------:|
| **Authorization** | Application | Spatie Permission + OrganizationMember + Policies | No (checks identity, not invariants) |
| **User engagement** (save, follow, like) | Application + Product | Eloquent relationships + Livewire | No (reads domain, doesn't modify) |
| **Comparison** | Product | Livewire + Query classes | No (reads domain) |
| **Notifications** | Application + Infrastructure | Laravel Notifications + queues | No (triggered by domain events, but logic is application-layer) |
| **Social sharing** | Product | Blade + meta tags | No (reads domain for OG data) |
| **Search** | Infrastructure + Product | Scout + Typesense + Livewire | No (search is a projection) |
| **SEO** | Product | Blade + Schema.org + sitemap | No (reads domain for meta) |
| **Media** | Infrastructure | Spatie medialibrary | No (media is not domain) |
| **Provenance** | Domain | source_id FK on entities | Yes (domain attribute) |
| **Activity logging** | Infrastructure | Spatie activitylog | No (records who did what) |
| **Analytics** | Infrastructure | Client-side (PostHog/Plausible) | No (not server-side) |
| **User preferences** | Application | notification_preferences + user_settings | No |
| **Saved resources** | Application | SavedResource Eloquent model | No |
| **Follows/alerts** | Application | FollowedResource + UserAlert models | No |
| **Organization membership** | Application | OrganizationMember pivot | No |

### Dependency Direction

```
Domain ← Application ← Infrastructure
                  ← Product/Presentation
```

- Domain has zero knowledge of authorization, engagement, notifications, search, or SEO.
- Application layer orchestrates domain + authorization + notification triggers.
- Infrastructure provides persistence, search, queues, email.
- Product/Presentation renders data and handles user interaction.

---

## 24. Proposed Directory Structure Changes

The frozen baseline directory structure is preserved. The following additions are needed for the platform architecture:

```
app/
    Domain/Models/                    — (existing, unchanged)
        OrganizationMember.php        — NEW: polymorphic membership pivot
    Domain/Events/                    — (existing, unchanged)
    Domain/Services/                  — (existing, unchanged)

    Actions/                          — (existing, unchanged)
        Membership/                   — NEW: organization membership actions
            AddOrganizationMember.php
            RemoveOrganizationMember.php

    Queries/                          — (existing, unchanged)
        Membership/                   — NEW: membership queries
            IsMemberOf.php
            GetOrganizationMembers.php
        User/                         — NEW: user engagement queries
            SavedResources.php
            FollowedResources.php
            GetComparisonSets.php

    Notifications/                    — NEW: Laravel notification classes
        AdmissionCycleOpenedNotification.php
        ScholarshipDeadlineApproachingNotification.php
        ProgrammeInfoChangedNotification.php
        InstitutionUpdatedNotification.php
        AccreditationStatusChangedNotification.php

    Data/                             — (existing, unchanged)

    Policies/                         — (existing + new)
        OrganizationMemberPolicy.php  — NEW

    Listeners/                        — (existing, unchanged — UpdateSearchIndex now targets Typesense)

    Livewire/
        Public/                       — (existing + new)
            ProgrammeSearch.php       — (existing, enhanced with Typesense)
            InstitutionSearch.php     — (existing, enhanced with Typesense)
            ScholarshipSearch.php     — (existing, enhanced with Typesense)
            OpportunityComparison.php — (existing, enhanced)
            EligibilityChecker.php    — (existing)
        Authenticated/                — (existing + new)
            Dashboard.php
            SavedOpportunities.php
            FollowedResources.php     — NEW
            ComparisonSets.php        — NEW
            NotificationPreferences.php — NEW
            QualificationProfile.php  — NEW
        Components/                   — NEW: shared Livewire components
            SaveButton.php
            FollowButton.php
            LikeButton.php
            ShareButtons.php

    Filament/                         — (existing + new)
        Resources/
            OrganizationMemberResource.php — NEW
        Pages/
            Dashboard.php

    Channels/                         — NEW: custom notification channels
        WebPushChannel.php
        SmsChannel.php

    Support/                          — (existing, unchanged)

config/
    typesense.php                     — NEW: Typesense configuration
```

### New Migrations

| Migration | Purpose |
|-----------|---------|
| `create_organization_members_table` | Polymorphic organization membership |
| `create_saved_resources_table` | User saves/bookmarks |
| `create_followed_resources_table` | User follows |
| `create_liked_resources_table` | User likes |
| `create_comparison_sets_table` | Saved comparison sets |
| `create_user_alerts_table` | Alert/watchlist definitions |
| `create_notification_preferences_table` | Per-user notification preferences |

---

## 25. Required Database/Application Structures

### New Eloquent Models (Application Layer)

| Model | Namespace | Aggregate? | Invariants | Purpose |
|-------|-----------|:----------:|:----------:|---------|
| `OrganizationMember` | `App\Domain\Models` | No | None | Polymorphic membership pivot |
| `SavedResource` | `App\Domain\Models` | No | None | User save/bookmark |
| `FollowedResource` | `App\Domain\Models` | No | None | User follow |
| `LikedResource` | `App\Domain\Models` | No | None | User like |
| `ComparisonSet` | `App\Domain\Models` | No | None | Saved comparison set |
| `UserAlert` | `App\Domain\Models` | No | None | Alert/watchlist definition |
| `NotificationPreference` | `App\Domain\Models` | No | None | Per-user notification preferences |

**None of these are domain aggregates.** They have no invariants, no domain operations, and no domain events. They are application-layer Eloquent models that happen to live in the `Domain\Models\` namespace for consistency with F1. This is the pragmatic Laravel approach — Eloquent models share a namespace regardless of whether they are domain aggregates or application relationships.

### New Actions

| Action | Justification |
|--------|--------------|
| `AddOrganizationMember` | Multi-entry-point (Filament + API); authorization + validation |
| `RemoveOrganizationMember` | Authorization + cascade (remove saves/follows scoped to membership) |

### New Queries

| Query | Purpose |
|-------|---------|
| `IsMemberOf` | Check if user is a member of an organization with a role |
| `GetOrganizationMembers` | List members of an organization |
| `SavedResources` | List user's saved resources |
| `FollowedResources` | List user's followed resources |
| `GetComparisonSets` | List user's saved comparison sets |

### New Notification Classes

| Notification | Trigger |
|-------------|---------|
| `AdmissionCycleOpenedNotification` | `AdmissionCycleActivated` event |
| `ScholarshipDeadlineApproachingNotification` | Scheduled check |
| `ProgrammeInfoChangedNotification` | Programme domain events |
| `InstitutionUpdatedNotification` | Institution domain events |
| `AccreditationStatusChangedNotification` | Accreditation domain events |

---

## 26. New Architectural Decisions

| Decision | Rationale |
|----------|-----------|
| Scoped authorization via OrganizationMember pivot | Spatie Permission provides role/permission; scoping requires minimal custom layer |
| User engagement as application relationships, not domain entities | Save/Follow/Like/Alert have no invariants; they are application-layer concepts |
| Comparison as product/presentation capability | No domain concept; Livewire + Query classes |
| Laravel native notifications | Laravel's notification system is sufficient; no custom framework |
| Social sharing as client-side + Blade meta | No server-side tracking; Open Graph metadata for previews |
| Typesense as search projection | PostgreSQL is source of truth; Typesense is denormalized for search |
| Server-rendered listing pages with Livewire | SEO-critical; Typesense for data, Blade for HTML |
| Controlled indexation for faceted URLs | Not every filter combination is indexable; curated SEO landing pages |
| No share count tracking | Vanity metric; inaccurate; analytics events are better |

---

## 27. New ADRs Required

| ADR | Title | Decision |
|-----|-------|----------|
| **ADR-19** | Scoped Authorization Model | Spatie Permission + custom OrganizationMember pivot for organization-scoped roles; polymorphic membership supporting multiple organization types |
| **ADR-20** | User Engagement Architecture | Save/Follow/Like as application-layer Eloquent relationships with polymorphic resource types; no generic UserInteraction entity |
| **ADR-21** | Comparison Architecture | Product/presentation capability using Livewire + Query classes; ephemeral for anonymous users; persisted for authenticated users |
| **ADR-22** | Notification Architecture | Laravel native notifications with multi-channel support; custom WebPushChannel and SmsChannel; notification preferences per user per category per channel |
| **ADR-23** | Typesense Search Architecture | PostgreSQL as source of truth; Typesense as denormalized search projection; synchronization via domain events + Scout; eventual consistency |
| **ADR-24** | SEO Faceted URL Strategy | Controlled indexation; curated SEO landing pages; noindex for deep filter combinations; canonical URLs; sitemap for detail + landing pages only |
| **ADR-25** | Social Sharing Architecture | Client-side share buttons + Open Graph metadata; no share count tracking; spatie/schema-org for structured data |

---

## 28. Changes Required to Frozen Baseline

### Required Changes: NONE

No frozen decision needs to be reversed. Every gap identified in this review is additive — it extends the architecture without contradicting the domain model.

| Frozen Decision | Challenge | Verdict |
|----------------|-----------|--------|
| 5 aggregate roots | Do engagement features require new aggregates? | **No.** Save/Follow/Like are application relationships, not domain entities. |
| 20 Actions | Do new platform features require more Actions? | **Yes, but not domain Actions.** 2 new Actions for membership management. The frozen 20 remain unchanged. |
| No repositories | Do application relationships need repositories? | **No.** Eloquent is sufficient for application relationships too. |
| TALL stack | Does Typesense require client-side JavaScript? | **No.** Typesense is queried server-side via Scout. Livewire provides interactivity. |
| Educational Opportunity is NOT an entity | Does comparison need a unified entity? | **No.** Comparison uses resource-type-specific Query classes and Blade templates. |
| Filament for admin only | Do organization members need Filament? | **Yes, for admin.** OrganizationMemberResource for managing who belongs to what. Filament remains admin-only. |

### Recommended Additions

| Addition | Layer | Impact on Domain |
|----------|-------|:----------------:|
| OrganizationMember model | Application | None |
| SavedResource, FollowedResource, LikedResource models | Application | None |
| ComparisonSet model | Application | None |
| UserAlert model | Application | None |
| NotificationPreference model | Application | None |
| 7 new migrations | Infrastructure | None |
| 2 new Actions | Application | None |
| 5+ new Queries | Application | None |
| 5 new Notification classes | Application | None |
| 2 custom Channel classes | Infrastructure | None |
| Typesense configuration | Infrastructure | None |
| SEO landing page Blade templates | Presentation | None |
| 7 new ADRs | Documentation | None |

**None of these additions touch the domain layer.** The domain model (5 aggregates, 3 child entities, 3 supporting entities, 28 VOs, 29 domain events, 20 domain-facing Actions, 1 domain service) remains exactly as frozen.

---

## 29. Deferred Decisions

| Decision | Why Deferred | Trigger |
|----------|-------------|---------|
| Web Push implementation details | Provider selection (web-push-php, OneSignal, etc.) | When push notifications are needed |
| SMS provider selection | Country-specific (Termii for Nigeria, Twilio for global) | When SMS notifications are needed |
| Notification digest scheduling | Frequency and batch size | When notification volume warrants digests |
| Share count analytics integration | Analytics provider selection | When share analytics are requested |
| Study Abroad bounded contexts | Feature not yet developed | When Study Abroad capability is developed |
| Organization member invitation flow | Email verification + acceptance flow | When institution self-service is needed |
| Institution claim/verification flow | User claiming admin of an institution | When institution self-registration is needed |
| Typesense cloud vs self-hosted | Infrastructure decision | When search infrastructure is provisioned |
| Analytics provider integration | Product decision | When analytics are needed |

---

## 30. Adversarial Findings

### Finding 1: Authorization Was Under-Specified (Severity: Medium)

The frozen baseline deferred the role/permission model with "Role model undefined but Spatie Permission chosen." This review reveals that the requirement is more complex than a simple role list — scoped authorization across multiple organization types is needed. The `OrganizationMember` pivot is a necessary addition that was not anticipated.

**Classification:** Strong recommendation (not a correction — the frozen baseline explicitly deferred this).

### Finding 2: User Engagement Was Completely Absent (Severity: Low)

The frozen baseline focused on domain architecture and did not address user engagement (save, follow, like, compare, alert). This is not a flaw — the domain model is complete. But the platform architecture must address these capabilities before implementation.

**Classification:** Optional improvement (these are product features, not domain requirements).

### Finding 3: Search Architecture Was Deferred Too Vaguely (Severity: Medium)

The frozen baseline deferred search engine selection with "Both options viable; MVP works with PostgreSQL FTS." This review specifies Typesense as the intended engine and designs the full search architecture. Without this, implementers would default to Eloquent-based search, which is insufficient for highly faceted listing pages.

**Classification:** Strong recommendation.

### Finding 4: SEO Faceted URL Strategy Was Missing (Severity: Medium)

The frozen baseline specified "crawlable faceted navigation" but did not address the exponential URL problem. Without an explicit indexation strategy, implementers risk either (a) making every filter combination indexable (crawl budget waste) or (b) making no filter combination indexable (SEO opportunity loss).

**Classification:** Strong recommendation.

### Finding 5: Notification Architecture Was Implicit (Severity: Low)

The frozen baseline included domain events that trigger notifications (e.g., `ScholarshipApplicationsOpened → CandidateNotification`), but did not design the notification system itself. Laravel's native notifications are sufficient, but the preference model and multi-channel strategy need explicit design.

**Classification:** Optional improvement.

### Finding 6: No Domain Model Changes Needed (Severity: None)

The most important adversarial finding is that **none of the new platform/product requirements contradict the frozen domain model.** The domain model is complete for the domain it models. The gaps are in the platform layer that surrounds it.

**Classification:** Confirmed — frozen baseline is sound.

---

## 31. Final Architecture Scorecard

| Criterion | Score | Justification |
|-----------|:-----:|--------------|
| **Domain integrity** | 9/10 | Unchanged from frozen baseline. All 5 aggregates, 22 invariants, 20 Actions remain valid. |
| **LBC alignment** | 9/10 | Platform features are application/product layer — no domain ceremony added. |
| **Authorization** | 8/10 | Spatie Permission + OrganizationMember is pragmatic. Not as polished as a full RBAC framework, but appropriate for StudyNexus's needs. |
| **Search architecture** | 8/10 | Typesense + Scout + Livewire is correct. Denormalization strategy and sync mechanism are defined. SEO integration is addressed. |
| **SEO architecture** | 9/10 | Server-rendered + controlled indexation + curated landing pages + canonical URLs + sitemap. Comprehensive. |
| **Notification architecture** | 8/10 | Laravel native + multi-channel + preferences. Sufficient and pragmatic. |
| **User engagement** | 8/10 | Save/Follow/Like/Compare/Alert as application relationships. No unnecessary domain abstractions. |
| **Global extensibility** | 9/10 | Scoped auth supports any organization type. Study Abroad stress-tested. Zero structural changes. |
| **Pragmatism** | 9/10 | No custom frameworks. Laravel native where possible. Spatie where appropriate. Application-layer additions are minimal. |
| **TALL-stack fit** | 9/10 | Confirmed. No React/Next.js/Vue. Server-rendered listing pages with Livewire interactivity. |
| **Spatie integration** | 8/10 | 6 adopt now, 3 later, 3 evaluate, 3 rejected. Clear rationale for every decision. |
| **Security** | 7/10 | Authorization model is designed but specific roles/permissions need implementation. Web push and SMS security considerations deferred. |
| **Completeness** | 8/10 | All major platform capabilities addressed. Some implementation details deferred (invitation flow, claim flow, analytics). |
| **Complexity control** | 8/10 | 7 new Eloquent models (all application-layer, no domain). 2 new Actions. 7 new ADRs. Controlled growth. |

### Overall Score: 8.4/10

Consistent with the frozen baseline's 8.4/10. The platform architecture fills the identified gaps without adding unnecessary complexity or contradicting the domain model.

---

## 32. Implementation Readiness Verdict

### Verdict

```
┌──────────────────────────────────────────────────────────────────────┐
│                                                                      │
│   FROZEN BASELINE REMAINS — WITH SUPPLEMENTARY PLATFORM ARCHITECTURE │
│                                                                      │
│   Architecture Score: 8.4/10                                         │
│   Frozen domain model: UNCHANGED                                     │
│   Platform additions: 7 application models, 2 actions,               │
│       5+ queries, 5 notifications, 2 channels, 7 ADRs               │
│                                                                      │
│   No frozen decision reversed.                                       │
│   No ADR supersession required.                                      │
│   All new requirements are additive.                                 │
│                                                                      │
│   The supplementary platform architecture should be                  │
│   appended to the frozen baseline as a companion document.           │
│   Implementation may proceed when ready.                             │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

### Summary of All Findings

**Required changes:** None to the frozen domain model.

**Strong recommendations:**
1. Adopt Spatie Permission + OrganizationMember pivot for scoped authorization (ADR-19)
2. Define Typesense as the search engine with full architecture (ADR-23)
3. Define SEO faceted URL strategy with controlled indexation (ADR-24)

**Recommended additions:**
4. User engagement as application-layer relationships (ADR-20)
5. Comparison as product/presentation capability (ADR-21)
6. Laravel native notification architecture (ADR-22)
7. Social sharing as client-side + Blade meta (ADR-25)

**Rejected ideas:**
- Generic `UserInteraction` entity — each engagement type has distinct semantics
- `EducationalOpportunity` domain entity — comparison uses read models
- Share count tracking — vanity metric, inaccurate, analytics is better
- Full multi-tenancy package — over-engineered for scoped authorization
- Custom notification framework — Laravel's is sufficient
- Client-side-only listing pages — SEO failure
- Every facet combination as SEO page — crawl budget waste

**New ADRs required:** ADR-19 through ADR-25 (7 total)

**Frozen baseline should:** Remain frozen. This review is a companion document, not a replacement.

**Implementation readiness:** StudyNexus is ready for implementation planning. The domain model is frozen, the platform architecture is defined, and the only remaining decisions are infrastructure-level (Typesense hosting, SMS provider, queue driver, cache strategy).

---

### Architectural Summary

**Stack:** Laravel + Blade + Livewire + Flux + Alpine.js + Tailwind CSS + Filament (admin) + Typesense (search)
**Philosophy:** Laravel Beyond CRUD (Pragmatic Domain-Driven Design)
**Domain:** 5 aggregate roots, 3 child entities, 3 supporting entities, 28 VOs, 29 domain events, 15 queries, 1 domain service, 22 invariants — UNCHANGED
**Application:** 22 Actions (20 domain + 2 membership), 5+ Policies, 7 application models
**Platform:** Scoped RBAC, user engagement (save/follow/like/compare/alert), notifications (multi-channel), social sharing, Typesense search, controlled SEO
**Spatie:** 6 adopt now, 3 later, 3 evaluate, 3 rejected
**No:** Repositories, Event Sourcing, CQRS framework, SPA, Microservices, Generic abstractions, React/Next.js/Vue/Inertia, Custom notification framework, Share count tracking, UserInteraction entity
**Global:** Zero structural changes for 9 countries + Study Abroad + 13 education types
**Search:** Typesense as denormalized projection; PostgreSQL as source of truth; server-rendered listing pages
**SEO:** Controlled indexation; curated landing pages; canonical URLs; noindex for deep combinations
**Status:** FROZEN BASELINE REMAINS — supplementary platform architecture appended

---

*End of Post-Freeze Platform, Product & Search Architecture Review*
