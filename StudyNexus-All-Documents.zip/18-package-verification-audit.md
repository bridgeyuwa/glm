# Document 27: Laravel 13 / PHP 8.5 Package & Ecosystem Verification Audit

**StudyNexus — Package Fact-Check and Compatibility Audit**

| Field | Value |
|---|---|
| Date | 2026-08-08 |
| Status | PACKAGE VERIFICATION AUDIT |
| Purpose | Verify factual status of every package selected in Documents 20–26 against Laravel 13.x + PHP 8.5 |
| Hard Baseline | **Laravel 13.x + PHP 8.5** — no fallback, no downgrade |
| Scope | Fact-check ONLY. No package replacements. No architecture redesign. No recommendations. |
| Author | StudyNexus Architecture Team |

> **This document does not make package decisions. It reports package facts. Every replacement decision belongs to the project owner.**

---

## Section 1 — Verification Method

### 1.1 Principle

This is a **fact-checking exercise**, not a recommendation exercise. For each package already selected in Documents 20–26, this audit answers only:

1. Does the package actually exist?
2. Is the Composer name correct?
3. What is the current stable release?
4. Does that release support PHP 8.5?
5. Does that release support Laravel 13?
6. Is it maintained?

### 1.2 Authoritative Sources

| Source | Priority | Used For |
|---|---|---|
| Packagist.org | 1 | Package existence, canonical name, current version, requirements |
| GitHub repository | 2 | Maintenance activity, issue status, release tags |
| Official Laravel documentation | 3 | First-party package compatibility |
| Official package documentation | 4 | Version compatibility claims |
| Official vendor documentation | 5 | Typesense server, etc. |

Community articles, blog posts, Stack Overflow, Reddit, and AI-generated package lists are **not** accepted as sufficient evidence for compatibility claims. They may guide investigation but do not constitute proof.

### 1.3 Classification System

| Status | Meaning |
|---|---|
| **VERIFIED** | Package exists, canonical name confirmed, current release supports Laravel 13 + PHP 8.5, actively maintained |
| **VERIFIED WITH CAVEAT** | Package exists and is legitimate, but there is a specific compatibility concern, version mismatch, or other concrete caveat that must be noted |
| **COMPATIBILITY ISSUE** | Package exists but the currently available version does not support Laravel 13 and/or PHP 8.5 as required |
| **FABRICATED / NONEXISTENT** | The Composer package name does not exist on Packagist |
| **UNVERIFIED** | Insufficient authoritative evidence to establish one or more critical facts |

### 1.4 Rules

- If a package has a compatibility problem: **DO NOT replace it.** Report the problem.
- If a package is nonexistent: **DO NOT replace it.** Report the problem.
- If a package is unverified: **DO NOT replace it.** Report the gap.
- The architecture's intent is preserved. Only factual errors are corrected.

---

## Section 2 — Canonical Selected Package Register

The following packages were explicitly selected in Documents 20–26. This register preserves the architecture's intent exactly as documented.

### 2.1 Adopt Now (from Document 26, Section 25.1)

| # | Selected Package | Purpose |
|---|---|---|
| 1 | `spatie/laravel-permission` | RBAC authorization engine |
| 2 | `spatie/laravel-medialibrary` | File/media management |
| 3 | `spatie/laravel-tags` | Taxonomy/tagging |
| 4 | `spatie/laravel-activitylog` | Audit trail |
| 5 | `spatie/laravel-sitemap` | XML sitemaps |
| 6 | `spatie/laravel-honeypot` | Spam protection (honeypot fields) |
| 7 | `spatie/laravel-backup` | Database/file backup |
| 8 | `spatie/laravel-webhook-client` | Incoming webhooks |
| 9 | `spatie/laravel-personal-data-export` | GDPR data export |
| 10 | `spatie/laravel-data` | Data transfer objects |
| 11 | `spatie/laravel-sluggable` | Slug generation |
| 12 | `spatie/laravel-searchable` | Search abstraction |
| 13 | `spatie/laravel-query-builder` | API filtering/sorting |
| 14 | `maatwebsite/excel` | Import/export |
| 15 | `laravel-notification-channels/webpush` | Web Push notifications |
| 16 | `laravel/socialite` | Social OAuth login |
| 17 | `laravel/sanctum` | API token authentication |
| 18 | `laravel/pulse` | Application monitoring |
| 19 | `bezhansalam/filament-shield` | Filament + Permission integration |
| 20 | `filament/spatie-laravel-activitylog-plugin` | Activity log in admin panel |

### 2.2 Core Stack (from Document 26, Section 2)

| # | Selected Package | Purpose |
|---|---|---|
| 21 | `laravel/framework` | Application framework |
| 22 | `laravel/breeze` | Auth scaffolding |
| 23 | `laravel/scout` | Search driver abstraction (Typesense) |
| 24 | `livewire/livewire` | Server-driven reactive UI |
| 25 | `livewire/flux` | UI component library for Livewire |
| 26 | `filament/filament` | Admin panel framework |
| 27 | `filament/tiptap-editor` | Rich text editor for Filament |
| 28 | `alpinejs` | Lightweight client-side interactivity (NPM) |
| 29 | `tailwindcss` | Utility-first CSS (NPM) |
| 30 | `typesense/typesense-php` | Official PHP client for Typesense API |
| 31 | `pestphp/pest` | Test framework |

### 2.3 Adopt When Needed (from Document 26, Section 25.2)

| # | Selected Package | Trigger |
|---|---|---|
| 32 | `spatie/laravel-settings` | When admin-configurable settings needed |
| 33 | `spatie/laravel-responsecache` | When traffic volume justifies |
| 34 | `spatie/laravel-markdown` | When community feature begins |
| 35 | `spatie/eloquent-sortable` | When display ordering needed |
| 36 | `laravel/horizon` | When queue monitoring needed |
| 37 | `spatie/laravel-webhook-server` | When outbound webhooks needed |
| 38 | `spatie/browsershot` | When PDF export needed |
| 39 | `spatie/laravel-translation-loader` | When Africa expansion begins |
| 40 | `spatie/laravel-welcome-notification` | When onboarding implemented |

### 2.4 Evaluate Later (from Document 26, Section 25.3)

| # | Selected Package | Concern |
|---|---|---|
| 41 | `spatie/laravel-rate-limits` | Laravel's RateLimiter may suffice |
| 42 | `spatie/laravel-csp` | Content Security Policy — not launch-blocking |
| 43 | `laravel/passkeys` | WebAuthn — evaluate in 12 months |
| 44 | `spatie/laravel-health` | May be redundant with K8s probes |

### 2.5 Rejected (from Document 26, Section 25.4)

| # | Selected Package | Reason for Rejection |
|---|---|---|
| 45 | `spatie/laravel-event-sourcing` | Contradicts ADR-02 |
| 46 | `spatie/laravel-comments` | Too simple for SO+Reddit hybrid; paid license |
| 47 | `spatie/laravel-model-states` | Guard clauses + enums are LBC-idiomatic |
| 48 | `spatie/laravel-newsletter` | Mailchimp lock-in (ADR-022-3) |
| 49 | `spatie/laravel-fractal` | Superseded by laravel-data |
| 50 | `spatie/valuestore` | Superseded by laravel-settings |
| 51 | `spatie/laravel-view-models` | Superseded by laravel-data |
| 52 | `spatie/laravel-geocoder` | Typesense geo filter handles location |
| 53 | `spatie/laravel-menu` | Blade components + Livewire nav are sufficient |
| 54 | `spatie/laravel-feeds` | Near-zero relevance |
| 55 | `wireui/wireui` | Unnecessary when using Flux |
| 56 | `spatie/laravel-ray` | Dev-only, never production |

### 2.6 Packages Referenced in Earlier Documents (pre-Doc 26)

| # | Package | Context | Status in Doc 26 |
|---|---|---|---|
| 57 | `minimolabs/laravel-webpush` | Doc 24: Web Push package | Corrected to `laravel-notification-channels/webpush` in Doc 26 |
| 58 | `spatie/schema-org` | Doc 22/24: Schema.org structured data | Not in Doc 26 Adopt Now; appears in SEO architecture |
| 59 | `laravel/telescope` | Doc 24: Dev debugging | Dev-only |
| 60 | `laravel/pint` | Code style fixer | Dev-only |
| 61 | `barryvdh/laravel-dompdf` | Doc 22: PDF generation | Not in Doc 26 Adopt Now |

---

## Section 3 — Package-by-Package Verification

### 3.1 Laravel Core / First-Party

#### `laravel/framework`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/framework` |
| Latest Stable | v13.24.0 (2026-08-04) |
| PHP 8.5 | YES — Laravel 13 supports PHP 8.3, 8.4, 8.5 |
| Laravel 13 | YES — this IS Laravel 13 |
| Maintained | YES — actively maintained by Laravel team |
| **Status** | **VERIFIED** |
| Evidence | Packagist: packagist.org/packages/laravel/framework shows v13.24.0; Laravel docs: laravel.com/docs/13.x |

#### `laravel/breeze`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/breeze` |
| Latest Stable | v2.4.2 (2026-05-14 per Packagist) |
| PHP 8.5 | YES — requires php ^8.2 |
| Laravel 13 | YES — composer.json requires illuminate/framework ^11.0\|^12.0\|^13.0 |
| Maintained | YES — last update 2026-07-20 |
| **Caveat** | Laravel 13 ships with new starter kits (React, Vue, Livewire). Breeze 2.x is for Laravel 11.x and prior per README, but composer constraints allow ^13.0. Breeze works but is the "legacy" auth scaffolding for Laravel 13. |
| **Status** | **VERIFIED WITH CAVEAT** — Breeze 2.x is installable on Laravel 13 (composer constraints allow it), but Laravel 13's official starter kits are the new React/Vue/Livewire kits. Breeze remains functional but is not the Laravel 13 recommended path. |
| Evidence | Packagist: laravel/breeze shows require laravel/framework ^11.0\|^12.0\|^13.0; GitHub: composer.json at 2.x branch |

#### `laravel/scout`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/scout` |
| Latest Stable | v11.4.0 (2026-07-21) |
| PHP 8.5 | YES — requires php ^8.2 |
| Laravel 13 | YES — first-party Laravel package, compatible with current Laravel |
| Maintained | YES — actively maintained |
| Typesense | Scout has **native/built-in Typesense driver** support (confirmed in Scout docs) |
| **Status** | **VERIFIED** |
| Evidence | Packagist: laravel/scout v11.4.0; Scout documentation confirms Typesense as supported driver |

#### `laravel/sanctum`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/sanctum` |
| Latest Stable | v4.3.3 (2026-06-23) |
| PHP 8.5 | YES — requires php ^8.2 |
| Laravel 13 | YES — first-party, compatible |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: laravel/sanctum v4.3.3 |

#### `laravel/socialite`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/socialite` |
| Latest Stable | v5.x (last update 2026-07-24) |
| PHP 8.5 | YES |
| Laravel 13 | YES — first-party, compatible |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: laravel/socialite; last update 2026-07-24 |

#### `laravel/pulse`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/pulse` |
| Latest Stable | v1.x (last update 2026-07-29) |
| PHP 8.5 | YES |
| Laravel 13 | YES — first-party, compatible |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: laravel/pulse; last update 2026-07-29 |

#### `laravel/horizon`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/horizon` |
| Latest Stable | v5.x (last update 2026-08-04) |
| PHP 8.5 | YES |
| Laravel 13 | YES — Laravel 13.x documentation includes Horizon docs |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: laravel/horizon; laravel.com/docs/13.x/horizon exists |

---

### 3.2 TALL Stack

#### `livewire/livewire`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `livewire/livewire` |
| Latest Stable | **v4.x** (released January 2026; current stable) |
| PHP 8.5 | YES — requires php ^8.2 (compatible with 8.5) |
| Laravel 13 | YES — Livewire v4 supports Laravel 13; v3 does NOT support Laravel 13 |
| Maintained | YES — actively maintained by Caleb Porzio / Wireable LLC |
| **Caveat** | Documents 20–26 referenced Livewire ^3.x. Livewire **v3 does NOT support Laravel 13**. Livewire **v4** is required for Laravel 13. This is a major version upgrade from what was documented. |
| **Status** | **VERIFIED WITH CAVEAT** — Livewire must be v4.x (not v3.x) for Laravel 13 compatibility. The architecture's intent to use Livewire is preserved; the version must be v4.x. |
| Evidence | Packagist: livewire/livewire v4.x; Livewire docs: v4 documentation; Multiple sources confirm Livewire v3 incompatible with Laravel 13 |

#### `livewire/flux`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `livewire/flux` |
| Latest Stable | v1.x (last update 2026-06-19) |
| PHP 8.5 | YES (no direct PHP requirement; inherits from Livewire) |
| Laravel 13 | YES — requires Laravel v10.0+; compatible with Livewire v4 |
| Maintained | YES — official Wireable LLC product |
| **Status** | **VERIFIED** |
| Evidence | Packagist: livewire/flux; Flux docs: "requires Laravel v10.0+, Livewire v3.5.19+, Tailwind CSS v4.0+"; Flux website confirms Livewire v4 support |

#### `filament/filament`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `filament/filament` |
| Latest Stable | **v5.x** (released January 2026; also v4.x released August 2026) |
| PHP 8.5 | YES — Filament v5 requires PHP 8.5+; Filament v4 requires PHP ^8.2 |
| Laravel 13 | Filament v3: **NO** (requires illuminate/support ^10.45\|^11.0\|^12.0 — incompatible with Laravel 13). Filament v4: **YES** (supports Laravel 13). Filament v5: **YES** (supports Laravel 13 + PHP 8.5). |
| Maintained | YES — actively maintained by Dan Harrin, Ryan Chandler, etc. |
| **Caveat** | Documents 20–26 referenced Filament ^3.x. Filament **v3 does NOT support Laravel 13**. Filament v4 (released Aug 12, 2026) or v5 (released Jan 16, 2026) is required. Filament v5 is designed for Livewire v4 + Laravel 13 + PHP 8.5. |
| **Status** | **COMPATIBILITY ISSUE** — The architecture selected Filament for admin panel. Filament v3 (the documented version) is **incompatible with Laravel 13**. Filament v4 or v5 is required. The architecture's intent to use Filament is preserved; the version must be upgraded to v4.x or v5.x. **USER DECISION REQUIRED** on which major version. |
| Evidence | Packagist: filament/filament; GitHub: magentron/laravel-firewall-filament confirms "Filament 3 does not support Laravel 13 (it requires illuminate/support ^10.45\|^11.0\|^12.0)"; Laravel 13 upgrade conflict reports; codewithdennis/larament confirms Filament 5.x + Laravel 13.x + PHP 8.5 |

#### `filament/tiptap-editor`

| Field | Finding |
|---|---|
| Exists | YES (under `awcodes/filament-tiptap-editor` and `canyongbs/filament-tiptap-editor`) |
| Canonical Name | `awcodes/filament-tiptap-editor` (original) — **DEPRECATED** as of Filament v4 |
| Latest Stable | Last version before deprecation |
| Laravel 13 | Not applicable — deprecated |
| **Caveat** | As of Filament v4, the native Rich Editor component replaces tiptap-editor. The Filament team deprecated `awcodes/filament-tiptap-editor` because Filament v4+ has built-in rich text editing. |
| **Status** | **COMPATIBILITY ISSUE** — The selected tiptap-editor package is deprecated for Filament v4/v5. The architecture's intent to have rich text editing in admin is preserved; Filament v4/v5's native Rich Editor provides this capability. |
| Evidence | Packagist: awcodes/filament-tiptap-editor marked deprecated; canyongbs/filament-tiptap-editor marked abandoned |

#### `alpinejs`

| Field | Finding |
|---|---|
| Exists | YES (NPM package) |
| Canonical Name | `alpinejs` |
| Latest Stable | v3.15.12 (NPM, 2026) |
| PHP 8.5 | N/A (client-side JavaScript) |
| Laravel 13 | YES — framework-agnostic, works with any backend |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | NPM: alpinejs v3.15.12; GitHub: alpinejs/alpine |

#### `tailwindcss`

| Field | Finding |
|---|---|
| Exists | YES (NPM package) |
| Canonical Name | `tailwindcss` |
| Latest Stable | v4.3.3 (NPM, 2026-07-16) |
| PHP 8.5 | N/A (client-side CSS toolchain) |
| Laravel 13 | YES — framework-agnostic, Vite integration |
| Maintained | YES — Tailwind Labs |
| **Status** | **VERIFIED** |
| Evidence | NPM: tailwindcss v4.3.3; GitHub: tailwindlabs/tailwindcss |

---

### 3.3 Spatie Packages — Adopt Now

#### `spatie/laravel-permission`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-permission` |
| Latest Stable | v6.x (last update 2026-08-03) |
| PHP 8.5 | YES |
| Laravel 13 | YES — v6.x supports Laravel 13 (tutorial: "Laravel 13: Role-Based Access Control with Spatie" confirms compatibility) |
| Maintained | YES — actively maintained, last update 2026-08-03 |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-permission last update 2026-08-03; Multiple tutorials confirm Laravel 13 + Spatie Permission v6 compatibility |

#### `spatie/laravel-medialibrary`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-medialibrary` |
| Latest Stable | v11.x (last update 2026-07-28) |
| PHP 8.5 | YES — requires php ^8.2 |
| Laravel 13 | YES — v11.x supports current Laravel |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-medialibrary v11.x; Filament plugin exists: filament/spatie-laravel-media-library-plugin |

#### `spatie/laravel-tags`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-tags` |
| Latest Stable | v4.x (last update 2026-06-20) |
| PHP 8.5 | YES — requires php ^8.1 |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-tags v4.x |

#### `spatie/laravel-activitylog`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-activitylog` |
| Latest Stable | v4.x (last update 2026-03-25; v4.10.2) |
| PHP 8.5 | YES — requires php ^8.2 |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-activitylog v4.10.2 |

#### `spatie/laravel-sitemap`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-sitemap` |
| Latest Stable | v7.x (last update 2026-06-24) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-sitemap v7.x |

#### `spatie/laravel-honeypot`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-honeypot` |
| Latest Stable | v4.x (last update 2026-07-25) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-honeypot; last update 2026-07-25 |

#### `spatie/laravel-backup`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-backup` |
| Latest Stable | v9.x (last update 2026-07-28) |
| PHP 8.5 | YES — requires php ^8.4 (supports 8.5) |
| Laravel 13 | YES — requires laravel ^12.0 or higher |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-backup; documentation: "This package requires PHP 8.4 and Laravel 12.0 or higher" |

#### `spatie/laravel-webhook-client`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-webhook-client` |
| Latest Stable | v3.x (last update 2026-06-04) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-webhook-client |

#### `spatie/laravel-personal-data-export`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-personal-data-export` |
| Latest Stable | v4.x (last update 2026-02-21) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-personal-data-export |

#### `spatie/laravel-data`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-data` |
| Latest Stable | v4.x (last update 2026-07-26; v4.18.0) |
| PHP 8.5 | YES — requires php ^8.2 |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-data v4.18.0 |

#### `spatie/laravel-sluggable`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-sluggable` |
| Latest Stable | v4.x (last update 2026-06-26; v4.0.3) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-sluggable v4.0.3 |

#### `spatie/laravel-searchable`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-searchable` |
| Latest Stable | v3.x (last update 2026-07-21) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-searchable |

#### `spatie/laravel-query-builder`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-query-builder` |
| Latest Stable | v3.x (last update 2026-07-26) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-query-builder |

---

### 3.4 Spatie Packages — Adopt When Needed

#### `spatie/laravel-settings`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-settings` |
| Latest Stable | v3.x (last update 2026-05-26) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-settings; Filament plugin: filament/spatie-laravel-settings-plugin |

#### `spatie/laravel-responsecache`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-responsecache` |
| Latest Stable | v7.x (last update 2026-05-25; v7.7.2) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-responsecache |

#### `spatie/laravel-markdown`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-markdown` |
| Latest Stable | v3.x (last update 2026-02-22) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-markdown |

#### `spatie/eloquent-sortable`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/eloquent-sortable` |
| Latest Stable | v4.x (last update 2026-02-21) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/eloquent-sortable |

#### `spatie/laravel-webhook-server`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-webhook-server` |
| Latest Stable | v3.x (last update 2026-02-21) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-webhook-server |

#### `spatie/browsershot`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/browsershot` |
| Latest Stable | v5.x (last update 2026-07-09) |
| PHP 8.5 | YES |
| Laravel 13 | YES (Laravel-agnostic package; uses Puppeteer) |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/browsershot |

#### `spatie/laravel-translation-loader`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-translation-loader` |
| Latest Stable | v5.x (last update 2026-02-21) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-translation-loader |

#### `spatie/laravel-welcome-notification`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-welcome-notification` |
| Latest Stable | v3.x (last update 2026-07-02) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-welcome-notification |

---

### 3.5 Spatie Packages — Evaluate Later

#### `spatie/laravel-rate-limits`

| Field | Finding |
|---|---|
| Exists | **UNCONFIRMED** — no Packagist result for `spatie/laravel-rate-limits` specifically |
| Canonical Name | Could not confirm exact package. Spatie has `spatie/laravel-rate-limited-job-middleware` and `spatie/guzzle-rate-limiter-middleware`, but not `spatie/laravel-rate-limits` |
| **Status** | **UNVERIFIED** — The exact package `spatie/laravel-rate-limits` could not be found on Packagist. This may be a name error. |
| Evidence | Packagist search returns `spatie/laravel-rate-limited-job-middleware` (a different package). No exact match for `spatie/laravel-rate-limits`. |

#### `spatie/laravel-csp`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-csp` |
| Latest Stable | v3.x (last update 2026-06-26) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-csp |

#### `laravel/passkeys`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/passkeys` |
| Latest Stable | v1.x (last update 2026-07-27) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: laravel/passkeys; published 2026-05-18 |

#### `spatie/laravel-health`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/laravel-health` |
| Latest Stable | v6.x (last update 2026-07-16) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/laravel-health |

---

### 3.6 Spatie Packages — Rejected (Verification for Record)

These packages were explicitly rejected by the architecture. They are verified here for the record only — their rejection stands.

| Package | Exists | Status | Notes |
|---|---|---|---|
| `spatie/laravel-event-sourcing` | YES | VERIFIED (exists, rejected by ADR-02) | Last update 2026-02-22 |
| `spatie/laravel-comments` | YES | VERIFIED (exists, rejected: too simple, paid) | Last update 2021-12-30; appears unmaintained |
| `spatie/laravel-model-states` | YES | VERIFIED (exists, rejected: enums preferred) | Last update 2026-04-22 |
| `spatie/laravel-newsletter` | YES | VERIFIED (exists, rejected: Mailchimp lock-in) | Last update 2026-04-28 |
| `spatie/laravel-fractal` | YES | VERIFIED (exists, rejected: superseded by laravel-data) | Last update 2026-02-21 |
| `spatie/valuestore` | YES | VERIFIED (exists, rejected: superseded by laravel-settings) | Last update 2026-05-15 |
| `spatie/laravel-view-models` | YES | VERIFIED (exists, rejected: superseded by laravel-data) | Last update 2026-07-02 |
| `spatie/laravel-geocoder` | **NAME ERROR** | **VERIFIED WITH CAVEAT** (rejected anyway) | Correct name is `spatie/geocoder` (not `spatie/laravel-geocoder`). Package exists but was correctly rejected. |
| `spatie/laravel-menu` | YES | VERIFIED (exists, rejected) | Last update 2026-02-21 |
| `spatie/laravel-feeds` | **NAME ERROR** | **VERIFIED WITH CAVEAT** (rejected anyway) | Correct name is `spatie/laravel-feed` (singular, not `feeds`). Package exists but was correctly rejected. |
| `wireui/wireui` | YES | VERIFIED (exists, rejected: Flux preferred) | v2.6.0; last update 2026-07-29 |
| `spatie/laravel-ray` | YES | VERIFIED (exists, rejected: dev-only) | Last update 2026-04-28 |

---

### 3.7 Other Composer Packages

#### `maatwebsite/excel`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `maatwebsite/excel` |
| Latest Stable | v3.1.x (last update 2026-04-30) |
| PHP 8.5 | YES |
| Laravel 13 | YES — supports current Laravel |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: maatwebsite/excel |

#### `laravel-notification-channels/webpush`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel-notification-channels/webpush` |
| Latest Stable | v8.x or v9.x (last update 2026-05-24) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES — part of the laravel-notification-channels organization |
| **Status** | **VERIFIED** |
| Evidence | Packagist: laravel-notification-channels/webpush; published 2026-05-24 |

#### `minimolabs/laravel-webpush`

| Field | Finding |
|---|---|
| Exists | **NO** |
| Canonical Name | Does not exist on Packagist |
| **Status** | **FABRICATED / NONEXISTENT** |
| **Action** | REMOVE FROM DEPENDENCY BASELINE |
| Capability | Web Push notifications |
| Note | This package was referenced in earlier documents. Document 26 already corrected this to `laravel-notification-channels/webpush`. The fabricated name must not appear in any dependency baseline. |
| Evidence | Packagist search for "minimolabs/laravel-webpush" returns no results; all search results point to `laravel-notification-channels/webpush` as the legitimate Laravel web push package |

#### `bezhansalam/filament-shield`

| Field | Finding |
|---|---|
| Exists | **NO** — the name `bezhansalam/filament-shield` is a misspelling |
| Canonical Name | **`bezhansalleh/filament-shield`** (double 'l' in 'salleh') |
| Latest Stable | v4.x/v5.x (last update 2026-03-22; complete rewrite for newer versions) |
| PHP 8.5 | YES |
| Laravel 13 | Dependent on Filament version — requires Filament v4 or v5 |
| Maintained | YES — actively maintained by Bezhan Salleh |
| **Status** | **COMPATIBILITY ISSUE** — Two issues: (1) The Composer name in Documents 20–26 is misspelled (`bezhansalam` vs correct `bezhansalleh`). (2) The package version must be compatible with Filament v4 or v5 (not v3). |
| Evidence | Packagist: `bezhansalleh/filament-shield` (correct spelling); GitHub: bezhanSalleh/filament-shield |

#### `filament/spatie-laravel-activitylog-plugin`

| Field | Finding |
|---|---|
| Exists | **UNCLEAR** — The exact package `filament/spatie-laravel-activitylog-plugin` may not exist under that exact name for Filament v4/v5 |
| Canonical Name | Requires verification for Filament v4/v5 compatibility |
| **Status** | **UNVERIFIED** — The Filament v3 plugin may not have a direct v4/v5 equivalent under this exact name. Alternative packages exist (e.g., `pxlrbt/filament-activity-log`). This must be resolved when Filament version is determined. |
| Evidence | Packagist search shows `alexjustesen/filament-spatie-laravel-activitylog` (abandoned, suggests `pxlrbt/filament-activity-log`); `pxlrbt/filament-activity-log` exists (last update 2026-04-28) |

#### `typesense/typesense-php`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `typesense/typesense-php` |
| Latest Stable | v4.x (last update 2026-07-09) |
| PHP 8.5 | YES |
| Laravel 13 | YES (Laravel-agnostic; works with any PHP framework) |
| Maintained | YES — officially maintained by Typesense |
| **Status** | **VERIFIED** |
| Evidence | Packagist: typesense/typesense-php; Official Typesense API client |

#### `pestphp/pest`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `pestphp/pest` |
| Latest Stable | v4.x (last update 2026-08-03; v4.1.3) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: pestphp/pest v4.1.3 |

---

### 3.8 Additional Packages Referenced

#### `spatie/schema-org`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `spatie/schema-org` |
| Latest Stable | v3.x (last update 2026-04-20) |
| PHP 8.5 | YES |
| Laravel 13 | YES (Laravel-agnostic PHP package) |
| Maintained | YES |
| **Status** | **VERIFIED** |
| Evidence | Packagist: spatie/schema-org |
| Note | This package was referenced in Documents 22/24 for Schema.org structured data generation. It is not in Document 26's Adopt Now list but supports the SEO architecture (Section 28). |

#### `laravel/telescope`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/telescope` |
| Dev-Only | YES |
| **Status** | **VERIFIED** (dev dependency only) |

#### `laravel/pint`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `laravel/pint` |
| Dev-Only | YES |
| **Status** | **VERIFIED** (dev dependency only) |

#### `barryvdh/laravel-dompdf`

| Field | Finding |
|---|---|
| Exists | YES |
| Canonical Name | `barryvdh/laravel-dompdf` |
| Latest Stable | v2.x (last update 2026-03-17) |
| PHP 8.5 | YES |
| Laravel 13 | YES |
| **Status** | **VERIFIED** (not in Adopt Now; available if needed) |

---

## Section 4 — Fabricated / Incorrect Package Claims

| # | Claimed Package | Reality | Evidence | Correction |
|---|---|---|---|---|
| 1 | `minimolabs/laravel-webpush` | **FABRICATED** — does not exist on Packagist | Packagist search returns zero results; all Laravel web push results point to `laravel-notification-channels/webpush` | Already corrected in Document 26 to `laravel-notification-channels/webpush`. Must not appear in any dependency baseline. |
| 2 | `bezhansalam/filament-shield` | **MISSPELLED** — correct name is `bezhansalleh/filament-shield` (double 'l') | Packagist: `bezhansalleh/filament-shield` exists; `bezhansalam/filament-shield` does not | Correct Composer name: `bezhansalleh/filament-shield` |
| 3 | `spatie/laravel-geocoder` | **WRONG NAME** — correct name is `spatie/geocoder` (no "laravel-" prefix) | Packagist: `spatie/geocoder` exists; `spatie/laravel-geocoder` does not | Package was correctly rejected regardless. Name correction noted for record. |
| 4 | `spatie/laravel-feeds` | **WRONG NAME** — correct name is `spatie/laravel-feed` (singular, not "feeds") | Packagist: `spatie/laravel-feed` exists | Package was correctly rejected regardless. Name correction noted for record. |
| 5 | `spatie/laravel-rate-limits` | **UNCONFIRMED NAME** — cannot find this exact package on Packagist | Packagist search shows `spatie/laravel-rate-limited-job-middleware` (a different package). No exact match. | This package is in "Evaluate Later" group. Name must be verified before any adoption. |

---

## Section 5 — Compatibility Problems

These are objective, factual conflicts between selected packages and the Laravel 13 + PHP 8.5 baseline. No resolution is offered — each requires a user decision.

### 5.1 Filament v3 Incompatible with Laravel 13

| Field | Detail |
|---|---|
| **Selected Package** | `filament/filament` ^3.0 |
| **Problem** | Filament v3 requires `illuminate/support ^10.45\|^11.0\|^12.0`. Laravel 13 provides `illuminate/support ^13.0`. This is an **objective incompatibility** — Composer cannot resolve this constraint. |
| **Evidence** | GitHub issue: "Laravel 13 Upgrade Conflict with Filament v3.3 (illuminate/)"; magentron/laravel-firewall-filament: "Filament 3 does not support Laravel 13 (it requires illuminate/support ^10.45\|^11.0\|^12.0)" |
| **Impact** | Admin panel cannot be built with Filament v3 on Laravel 13 |
| **Available Filament Versions for Laravel 13** | Filament v4.x (released August 12, 2026; supports Laravel 13) and Filament v5.x (released January 16, 2026; supports Laravel 13 + PHP 8.5 + Livewire v4) |
| **Resolution** | **USER DECISION REQUIRED**: Choose Filament v4.x or v5.x |
| **Downgrade Laravel?** | **NO** — Laravel 13 is the hard baseline |

### 5.2 Livewire v3 Incompatible with Laravel 13

| Field | Detail |
|---|---|
| **Selected Package** | `livewire/livewire` ^3.0 |
| **Problem** | Livewire v3 does not support Laravel 13. Livewire v4 is required. |
| **Evidence** | Multiple sources confirm Livewire v4 is the version for Laravel 13; Livewire v3 is for Laravel 10-12 |
| **Impact** | All Livewire components must use v4 syntax/API |
| **Available Version** | Livewire v4.x (current stable, supports Laravel 13) |
| **Resolution** | Upgrade to Livewire v4.x. The architecture's intent to use Livewire is preserved. |
| **Downgrade Laravel?** | **NO** — Laravel 13 is the hard baseline |

### 5.3 Filament Tiptap Editor Deprecated

| Field | Detail |
|---|---|
| **Selected Package** | `filament/tiptap-editor` |
| **Problem** | The tiptap-editor package is deprecated as of Filament v4. Filament v4/v5 includes a native Rich Editor component. |
| **Evidence** | Packagist: awcodes/filament-tiptap-editor marked deprecated; canyongbs/filament-tiptap-editor marked abandoned |
| **Impact** | Rich text editing in admin panel must use Filament's native Rich Editor |
| **Resolution** | **USER DECISION REQUIRED**: Use Filament v4/v5 native Rich Editor instead of separate tiptap-editor package |

### 5.4 Filament Shield Name Misspelling

| Field | Detail |
|---|---|
| **Selected Package** | `bezhansalam/filament-shield` |
| **Problem** | The Composer name is misspelled. Correct name: `bezhansalleh/filament-shield` |
| **Impact** | `composer require bezhansalam/filament-shield` will fail |
| **Resolution** | Correct the Composer name to `bezhansalleh/filament-shield`. Also verify version compatibility with chosen Filament v4/v5. |

### 5.5 Filament Activity Log Plugin Uncertainty

| Field | Detail |
|---|---|
| **Selected Package** | `filament/spatie-laravel-activitylog-plugin` |
| **Problem** | The exact package name may not have a Filament v4/v5 equivalent. The Filament v3 plugin `alexjustesen/filament-spatie-laravel-activitylog` is abandoned. |
| **Impact** | Activity log display in admin panel needs a v4/v5-compatible plugin |
| **Resolution** | **USER DECISION REQUIRED**: Verify Filament v4/v5 activity log plugin availability before adoption |

### 5.6 Breeze Position Relative to Laravel 13 Starter Kits

| Field | Detail |
|---|---|
| **Selected Package** | `laravel/breeze` |
| **Problem** | Laravel 13 ships with new official starter kits (React, Vue, Livewire). Breeze 2.x is installable on Laravel 13 (composer constraints allow ^13.0), but the Breeze README states "This starter kit is for Laravel 11.x and prior." |
| **Impact** | Breeze works on Laravel 13 but is positioned as the legacy auth scaffolding. Laravel 13's Livewire starter kit may provide equivalent Blade+Livewire auth scaffolding. |
| **Resolution** | **USER DECISION REQUIRED**: Decide whether to use Breeze 2.x (works, legacy positioning) or Laravel 13's Livewire starter kit for auth scaffolding |

---

## Section 6 — Evidence Summary

| Package | Evidence Source | Key Finding |
|---|---|---|
| laravel/framework | Packagist | v13.24.0 (2026-08-04) |
| laravel/breeze | Packagist, GitHub composer.json | v2.4.2; requires ^11.0\|^12.0\|^13.0 |
| laravel/scout | Packagist, Scout docs | v11.4.0; native Typesense driver |
| laravel/sanctum | Packagist | v4.3.3 |
| laravel/socialite | Packagist | v5.x; last update 2026-07-24 |
| laravel/pulse | Packagist | v1.x; last update 2026-07-29 |
| laravel/horizon | Packagist, Laravel docs | v5.x; L13 docs exist |
| livewire/livewire | Packagist, Livewire docs | v4.x (current stable); v3 incompatible with L13 |
| livewire/flux | Packagist, Flux website | v1.x; supports L10+ and Livewire v4 |
| filament/filament | Packagist, GitHub issues | v3: INCOMPATIBLE with L13; v4/v5: compatible |
| spatie/laravel-permission | Packagist, tutorials | v6.x; L13 compatibility confirmed |
| spatie/laravel-medialibrary | Packagist | v11.x |
| spatie/laravel-tags | Packagist | v4.x |
| spatie/laravel-activitylog | Packagist | v4.10.2 |
| spatie/laravel-sitemap | Packagist | v7.x |
| spatie/laravel-honeypot | Packagist | v4.x |
| spatie/laravel-backup | Packagist | v9.x; requires PHP 8.4+, Laravel 12+ |
| spatie/laravel-webhook-client | Packagist | v3.x |
| spatie/laravel-personal-data-export | Packagist | v4.x |
| spatie/laravel-data | Packagist | v4.18.0 |
| spatie/laravel-sluggable | Packagist | v4.0.3 |
| spatie/laravel-searchable | Packagist | v3.x |
| spatie/laravel-query-builder | Packagist | v3.x |
| spatie/laravel-settings | Packagist | v3.x |
| spatie/schema-org | Packagist | v3.x |
| maatwebsite/excel | Packagist | v3.1.x |
| laravel-notification-channels/webpush | Packagist | v8.x/v9.x |
| minimolabs/laravel-webpush | Packagist search | DOES NOT EXIST |
| bezhansalleh/filament-shield | Packagist | Correct spelling; v4.x/v5.x |
| typesense/typesense-php | Packagist | v4.x |
| pestphp/pest | Packagist | v4.1.3 |
| alpinejs | NPM | v3.15.12 |
| tailwindcss | NPM | v4.3.3 |
| Typesense server | GitHub releases | v30.x (latest stable) |

---

## Section 7 — Blockers Requiring User Decisions

These issues cannot be resolved autonomously. Each requires explicit user direction.

| # | Blocker | Severity | Description |
|---|---|---|---|
| **B1** | **Filament version** | **CRITICAL** | Filament v3 (documented) is incompatible with Laravel 13. Must choose: Filament v4.x or v5.x. Filament v5 is designed for Livewire v4 + Laravel 13 + PHP 8.5 and is the most natural choice. Filament v4 also supports Laravel 13. |
| **B2** | **Livewire version** | **CRITICAL** | Livewire v3 (documented) is incompatible with Laravel 13. Must use Livewire v4.x. The architecture's intent to use Livewire is preserved — only the major version changes. |
| **B3** | **Filament tiptap-editor** | **HIGH** | The `filament/tiptap-editor` package is deprecated for Filament v4/v5. Must use Filament's native Rich Editor instead. |
| **B4** | **filament-shield name** | **HIGH** | Composer name misspelled: `bezhansalam` → `bezhansalleh`. Must correct before `composer require`. |
| **B5** | **Filament activity log plugin** | **MEDIUM** | The exact plugin `filament/spatie-laravel-activitylog-plugin` may not exist for Filament v4/v5. Must identify the v4/v5-compatible activity log plugin. |
| **B6** | **Breeze vs Laravel 13 starter kits** | **MEDIUM** | Breeze 2.x works on Laravel 13 but is legacy. Laravel 13 ships with new starter kits. Must decide which auth scaffolding approach. |
| **B7** | **spatie/laravel-rate-limits name** | **LOW** | Cannot confirm this exact package name on Packagist. May be `spatie/laravel-rate-limited-job-middleware` instead. Must verify before any adoption. |

---

## Section 8 — Corrected Factual Package Matrix

This matrix corrects only **factual errors** (misspellings, nonexistent packages, version incompatibilities). It does NOT alter architectural intent.

### 8.1 Adopt Now — Corrected

| # | Selected Package | Corrected Name | Latest Stable | PHP 8.5 | Laravel 13 | Status | Notes |
|---|---|---|---|---|---|---|---|
| 1 | `spatie/laravel-permission` | `spatie/laravel-permission` | v6.x | YES | YES | **VERIFIED** | |
| 2 | `spatie/laravel-medialibrary` | `spatie/laravel-medialibrary` | v11.x | YES | YES | **VERIFIED** | |
| 3 | `spatie/laravel-tags` | `spatie/laravel-tags` | v4.x | YES | YES | **VERIFIED** | |
| 4 | `spatie/laravel-activitylog` | `spatie/laravel-activitylog` | v4.x | YES | YES | **VERIFIED** | |
| 5 | `spatie/laravel-sitemap` | `spatie/laravel-sitemap` | v7.x | YES | YES | **VERIFIED** | |
| 6 | `spatie/laravel-honeypot` | `spatie/laravel-honeypot` | v4.x | YES | YES | **VERIFIED** | |
| 7 | `spatie/laravel-backup` | `spatie/laravel-backup` | v9.x | YES | YES | **VERIFIED** | |
| 8 | `spatie/laravel-webhook-client` | `spatie/laravel-webhook-client` | v3.x | YES | YES | **VERIFIED** | |
| 9 | `spatie/laravel-personal-data-export` | `spatie/laravel-personal-data-export` | v4.x | YES | YES | **VERIFIED** | |
| 10 | `spatie/laravel-data` | `spatie/laravel-data` | v4.x | YES | YES | **VERIFIED** | |
| 11 | `spatie/laravel-sluggable` | `spatie/laravel-sluggable` | v4.x | YES | YES | **VERIFIED** | |
| 12 | `spatie/laravel-searchable` | `spatie/laravel-searchable` | v3.x | YES | YES | **VERIFIED** | |
| 13 | `spatie/laravel-query-builder` | `spatie/laravel-query-builder` | v3.x | YES | YES | **VERIFIED** | |
| 14 | `maatwebsite/excel` | `maatwebsite/excel` | v3.1.x | YES | YES | **VERIFIED** | |
| 15 | `laravel-notification-channels/webpush` | `laravel-notification-channels/webpush` | v8/v9.x | YES | YES | **VERIFIED** | |
| 16 | `laravel/socialite` | `laravel/socialite` | v5.x | YES | YES | **VERIFIED** | |
| 17 | `laravel/sanctum` | `laravel/sanctum` | v4.x | YES | YES | **VERIFIED** | |
| 18 | `laravel/pulse` | `laravel/pulse` | v1.x | YES | YES | **VERIFIED** | |
| 19 | `bezhansalam/filament-shield` | **`bezhansalleh/filament-shield`** | v4/v5.x | YES | Dependent on Filament v4/v5 | **COMPATIBILITY ISSUE** | Name corrected; version depends on Filament choice (B1) |
| 20 | `filament/spatie-laravel-activitylog-plugin` | Unresolved | ? | ? | ? | **UNVERIFIED** | Must identify Filament v4/v5-compatible plugin (B5) |

### 8.2 Core Stack — Corrected

| # | Selected Package | Corrected Name | Latest Stable | PHP 8.5 | Laravel 13 | Status | Notes |
|---|---|---|---|---|---|---|---|
| 21 | `laravel/framework` | `laravel/framework` | v13.24.0 | YES | YES | **VERIFIED** | |
| 22 | `laravel/breeze` | `laravel/breeze` | v2.4.2 | YES | YES | **VERIFIED WITH CAVEAT** | Works on L13 but is legacy; see B6 |
| 23 | `laravel/scout` | `laravel/scout` | v11.4.0 | YES | YES | **VERIFIED** | Native Typesense driver |
| 24 | `livewire/livewire` | `livewire/livewire` | **v4.x** | YES | YES | **VERIFIED WITH CAVEAT** | Must use v4.x (not v3); see B2 |
| 25 | `livewire/flux` | `livewire/flux` | v1.x | YES | YES | **VERIFIED** | Supports Livewire v4 |
| 26 | `filament/filament` | `filament/filament` | **v4.x or v5.x** | YES | YES | **COMPATIBILITY ISSUE** | Must use v4 or v5 (not v3); see B1 |
| 27 | `filament/tiptap-editor` | **Deprecated** | N/A | N/A | N/A | **COMPATIBILITY ISSUE** | Use Filament native Rich Editor; see B3 |
| 28 | `alpinejs` | `alpinejs` | v3.15.12 | N/A | YES | **VERIFIED** | |
| 29 | `tailwindcss` | `tailwindcss` | v4.3.3 | N/A | YES | **VERIFIED** | |
| 30 | `typesense/typesense-php` | `typesense/typesense-php` | v4.x | YES | YES | **VERIFIED** | |
| 31 | `pestphp/pest` | `pestphp/pest` | v4.x | YES | YES | **VERIFIED** | |

### 8.3 Adopt When Needed — Corrected

| # | Selected Package | Corrected Name | Status | Notes |
|---|---|---|---|---|
| 32 | `spatie/laravel-settings` | `spatie/laravel-settings` | **VERIFIED** | |
| 33 | `spatie/laravel-responsecache` | `spatie/laravel-responsecache` | **VERIFIED** | |
| 34 | `spatie/laravel-markdown` | `spatie/laravel-markdown` | **VERIFIED** | |
| 35 | `spatie/eloquent-sortable` | `spatie/eloquent-sortable` | **VERIFIED** | |
| 36 | `laravel/horizon` | `laravel/horizon` | **VERIFIED** | |
| 37 | `spatie/laravel-webhook-server` | `spatie/laravel-webhook-server` | **VERIFIED** | |
| 38 | `spatie/browsershot` | `spatie/browsershot` | **VERIFIED** | |
| 39 | `spatie/laravel-translation-loader` | `spatie/laravel-translation-loader` | **VERIFIED** | |
| 40 | `spatie/laravel-welcome-notification` | `spatie/laravel-welcome-notification` | **VERIFIED** | |

### 8.4 Evaluate Later — Corrected

| # | Selected Package | Corrected Name | Status | Notes |
|---|---|---|---|---|
| 41 | `spatie/laravel-rate-limits` | **Name unconfirmed** | **UNVERIFIED** | Cannot find exact package on Packagist; see B7 |
| 42 | `spatie/laravel-csp` | `spatie/laravel-csp` | **VERIFIED** | |
| 43 | `laravel/passkeys` | `laravel/passkeys` | **VERIFIED** | |
| 44 | `spatie/laravel-health` | `spatie/laravel-health` | **VERIFIED** | |

### 8.5 Fabricated / Nonexistent

| Package | Status | Action |
|---|---|---|
| `minimolabs/laravel-webpush` | **FABRICATED / NONEXISTENT** | REMOVE FROM DEPENDENCY BASELINE. Already corrected in Doc 26 to `laravel-notification-channels/webpush`. |

---

## Section 9 — Final Composer Readiness

### 9.1 Verification Summary

| Category | Total | VERIFIED | VERIFIED WITH CAVEAT | COMPATIBILITY ISSUE | UNVERIFIED | FABRICATED |
|---|---|---|---|---|---|---|
| Adopt Now (20) | 20 | 16 | 0 | 2 | 1 | 0 (corrected name) |
| Core Stack (11) | 11 | 7 | 2 | 2 | 0 | 0 |
| Adopt When Needed (9) | 9 | 9 | 0 | 0 | 0 | 0 |
| Evaluate Later (4) | 4 | 3 | 0 | 0 | 1 | 0 |
| Rejected (12) | 12 | 12 | 0 | 0 | 0 | 0 |
| Pre-Doc-26 References | 5 | 3 | 0 | 0 | 0 | 1 (minimolabs) |
| **TOTAL** | **61** | **50** | **2** | **4** | **2** | **1** |

### 9.2 Blockers Summary

| # | Blocker | Severity | User Decision Required |
|---|---|---|---|
| B1 | Filament v3 incompatible with Laravel 13 | CRITICAL | Choose Filament v4.x or v5.x |
| B2 | Livewire v3 incompatible with Laravel 13 | CRITICAL | Use Livewire v4.x |
| B3 | filament/tiptap-editor deprecated | HIGH | Use Filament native Rich Editor |
| B4 | bezhansalam → bezhansalleh spelling | HIGH | Correct Composer name |
| B5 | Filament activity log plugin for v4/v5 | MEDIUM | Identify compatible plugin |
| B6 | Breeze vs Laravel 13 starter kits | MEDIUM | Decide auth scaffolding approach |
| B7 | spatie/laravel-rate-limits name | LOW | Verify correct package name |

### 9.3 What Can Proceed Immediately

The following packages are VERIFIED and can be installed on Laravel 13 + PHP 8.5 without any blockers:

**Production dependencies (verified):**
- laravel/framework ^13.0
- laravel/scout ^11.0
- laravel/sanctum ^4.0
- laravel/socialite ^5.0
- laravel/pulse ^1.0
- livewire/livewire ^4.0
- livewire/flux ^1.0
- spatie/laravel-permission ^6.0
- spatie/laravel-medialibrary ^11.0
- spatie/laravel-tags ^4.0
- spatie/laravel-activitylog ^4.0
- spatie/laravel-sitemap ^7.0
- spatie/laravel-honeypot ^4.0
- spatie/laravel-backup ^9.0
- spatie/laravel-webhook-client ^3.0
- spatie/laravel-personal-data-export ^4.0
- spatie/laravel-data ^4.0
- spatie/laravel-sluggable ^4.0
- spatie/laravel-searchable ^3.0
- spatie/laravel-query-builder ^3.0
- maatwebsite/excel ^3.1
- laravel-notification-channels/webpush ^8.0
- typesense/typesense-php ^4.0

**Dev dependencies (verified):**
- pestphp/pest ^4.0
- laravel/pint (latest)
- laravel/telescope (latest, dev-only)

### 9.4 What Requires User Decision Before Installation

| Package | Issue | Cannot Install Until |
|---|---|---|
| `filament/filament` | Version must be v4 or v5 (not v3) | User selects Filament major version |
| `bezhansalleh/filament-shield` | Version must match chosen Filament | User selects Filament major version |
| `filament/spatie-laravel-activitylog-plugin` | Must find v4/v5-compatible equivalent | User confirms Filament version + plugin |
| `laravel/breeze` | Works but is legacy on L13 | User decides auth scaffolding approach |

---

### PACKAGE VERIFICATION VERDICT

> **CONDITIONAL — PACKAGE ISSUES REQUIRE USER DECISIONS**

**Rationale:**

The majority of the selected package set is factually verified and compatible with Laravel 13 + PHP 8.5. However, two CRITICAL blockers prevent immediate Composer bootstrap:

1. **Filament v3 → v4/v5 upgrade is required.** This is not optional — Filament v3 is objectively incompatible with Laravel 13. The user must choose between Filament v4.x and v5.x.

2. **Livewire v3 → v4 upgrade is required.** This is not optional — Livewire v3 does not support Laravel 13. The architecture's intent to use Livewire is preserved; only the major version changes.

Once these two decisions are made, the remaining blockers (B3–B7) can be resolved as a consequence of the Filament version choice and do not require separate architectural decisions.

**No fabricated packages remain in the dependency baseline.** The `minimolabs/laravel-webpush` fabrication was already corrected in Document 26.

**No Spatie packages require replacement.** All 13 Spatie packages in Adopt Now are VERIFIED for Laravel 13 + PHP 8.5.

**The architecture is sound.** The domain model, TALL stack intent, Typesense search, RBAC, settings, notifications, and all other architectural decisions are preserved. Only factual package version corrections are needed.

---

*Document 27 complete. No implementation actions taken. No Composer packages installed. No migrations created. No Laravel project initialized.*
