# StudyNexus — Architecture Decision Records (ADRs)

| ADR | Title | Status | Date |
|-----|-------|--------|------|
| *(None yet — ADRs begin when architectural decisions are made)* | | | |
