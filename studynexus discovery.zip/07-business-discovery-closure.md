# StudyNexus — Business Discovery Closure Report

**Date:** 2026-08-07
**Status:** FROZEN (per 09-business-discovery-freeze.md)

---

## Business Discovery Summary

StudyNexus is a comprehensive education knowledge platform for Nigeria, with a vision to become Africa's education infrastructure. It solves five interconnected problems — Fragmentation, Trust, Discoverability, Comparison, and Accessibility — by aggregating, verifying, organizing, and presenting educational information in searchable, comparable, and trustworthy form.

The platform serves four primary user personas who all share the same canonical business goals (explore, evaluate, compare, assess eligibility, assess reliability, decide), plus one persona with an additional goal (understand current educational journey). It evolves through four strategic business stages from a trusted knowledge base to education infrastructure.

---

## Approved Topics

| Topic | Name | Decisions |
|-------|------|-----------|
| 0 | Identity, Vision, Core Interaction | A0-1, A0-2, A0-3 |
| 1 | Primary Users | A1-1 through A1-6 |
| 2 | Secondary Users | A2-1 through A2-11 |
| 3 | Problem Space | A3-1 through A3-8 |
| 4 | Evolution | A4-1 through A4-9 |
| 5 | Business Capabilities | A5-1 through A5-8 |
| 6 | Workflows: Secondary School Student and Graduate | A6-1 through A6-10 |
| 7 | Workflows: Undergraduate Student | A7-1 through A7-5 |
| 8 | Canonical Workflow Consolidation | A8-1 through A8-4 |
| 9 | Workflows: Guidance Counsellor or Teacher | A9-1, A9-2, A9-3 |

**Total Approved Decisions:** 40

---

## Canonical Business Capabilities

### Core MVP (8)

1. Acquire Educational Information
2. Organize Educational Knowledge
3. Verify Educational Information
4. Maintain Educational Knowledge
5. Discover Educational Opportunities
6. Search Educational Knowledge
7. Compare Educational Opportunities
8. Present Educational Knowledge

### Supporting MVP (2)

9. Preserve Information Provenance
10. Manage Information Quality

### Future (5)

11. Personalize educational guidance (Stage 2)
12. Support verified organization participation (Stage 3)
13. Notify users of important changes (Stage 2)
14. Provide trusted education data to third parties (Stage 4)
15. Enable ecosystem collaboration (Stage 3/4)

---

## Canonical Business Workflows

### Canonical (6) — shared by all 4 primary personas

The 6 canonical workflows represent the recurring business goals exercised by all primary personas. Their emergence across multiple personas indicates they are properties of the domain rather than of individual users.

| # | Workflow | Business Goal |
|---|----------|--------------|
| WF1 | Explore Educational Opportunities | Understand what educational opportunities exist based on interests, qualifications, or aspirations. |
| WF2 | Evaluate Educational Opportunities | Gather sufficient information about an educational opportunity to make an informed decision. |
| WF3 | Compare Educational Opportunities | Objectively compare multiple opportunities using standardized information before making a decision. |
| WF4 | Assess Eligibility | Determine whether the user's qualifications satisfy the published admission requirements. |
| WF5 | Assess Information Reliability | Determine whether educational information is trustworthy, current, and supported by authoritative sources. |
| WF6 | Make an Educational Decision | Reach a decision about whether and how to proceed with an educational opportunity. |

### Persona-Specific (1)

| # | Workflow | Persona | Business Goal |
|---|----------|---------|--------------|
| WF7 | Understand Current Educational Journey | Undergraduate Student | Understand information relevant to the educational opportunity the user is already pursuing in order to make informed decisions throughout that journey. |

### Persona Workflow Matrix

| | SS Student/Grad | Undergrad | Parent/Guardian | Counsellor/Teacher |
|---|:---:|:---:|:---:|:---:|
| WF1 | ✓ | ✓ | ✓ | ✓ |
| WF2 | ✓ | ✓ | ✓ | ✓ |
| WF3 | ✓ | ✓ | ✓ | ✓ |
| WF4 | ✓ | ✓ | ✓ | ✓ |
| WF5 | ✓ | ✓ | ✓ | ✓ |
| WF6 | ✓ | ✓ | ✓ | ✓ |
| WF7 | — | ✓ | ? | ? |

---

## Remaining Open Questions

### Domain Discovery (5)

| ID | Question |
|----|----------|
| OQ3-1 | Are the 5 problem dimensions complete? |
| OQ5-1 | Are the 10 MVP capabilities complete? |
| OQ6-1 | What constitutes "sufficient" information for evaluation/decision? |
| OQ6-7 | What specific information types per opportunity category? |
| OQ7-1 | Critical information types for managing current educational journey? |
| OQ6-2 | What are the standard comparison dimensions? |
| OQ7-2 | Does WF7 apply beyond Undergraduate Students? |

### Product Discovery (7)

| ID | Question |
|----|----------|
| OQ1-3 | Foreign institutions on day one? |
| OQ1-4 | Distinct interface patterns per persona? |
| OQ4-1 | MVP user accounts/identity? |
| OQ4-2 | User feedback mechanisms for information quality? |
| OQ6-3 | Eligibility assessment method? |
| OQ6-4 | What trust signals to present? |
| OQ6-6 | Structured exploration parameters per persona? |
| OQ6-8 | Trust signals across Information Categories? |

### Strategy (3)

| ID | Question |
|----|----------|
| OQ1-1 | Persona priority ranking? |
| OQ4-4 | Business/revenue model? |
| OQ4-3 / OQ6-5 | Decision support definition? |

### Future Evolution (2)

| ID | Question |
|----|----------|
| OQ2-3 | Institution management features timing? |
| OQ2-4 | Scholarship provider management timing? |

### Data Acquisition (1)

| ID | Question |
|----|----------|
| OQ2-5 | Government agency data: active provision vs public aggregation? |

### Non-Blocking (1)

| ID | Question |
|----|----------|
| OQ7-3 | Promote 4 candidate concepts to canonical? |

---

## Candidate Business Concepts

| Concept | Introduced In | Recurs Across Personas | Promotion Status |
|---------|--------------|----------------------|-----------------|
| Comparison Dimension | WF3 (Topic 6) | Yes — all 4 primary personas | Eligible (OQ7-3) |
| Eligibility Status | WF4 (Topic 6) | Yes — all 4 primary personas | Eligible (OQ7-3) |
| Trust Signal | WF5 (Topic 6) | Yes — all 4 primary personas | Eligible (OQ7-3) |
| Educational Decision | WF6 (Topic 6) | Yes — all 4 primary personas | Eligible (OQ7-3) |
| Current Educational Journey | WF7 (Topic 7) | No — Undergraduate Student only | Not yet eligible |

---

## Business Discovery Principles

These principles were established during discovery and should guide all subsequent discovery phases:

| ID | Principle | Origin |
|----|-----------|--------|
| P1 | **Never guess missing information** — ask focused questions | Session protocol |
| P2 | **Never silently rename concepts** — respect established domain terminology | Session protocol |
| P3 | **Never redesign previously approved decisions** — build incrementally | Session protocol |
| P4 | **Never introduce unjustified architectural patterns** — defer to architecture phase | Session protocol |
| P5 | **No implementation talk during Business Discovery** — stay at business level | Session protocol |
| P6 | **Discover one business topic at a time** — don't combine unrelated topics | Session protocol |
| P7 | **Maintain incremental canonical documents** — never regenerate from scratch | Session protocol |
| P8 | **Separate Approved Decisions, Proposed Ideas, and Open Questions** — never conflate | Session protocol |
| P9 | **Workflows are defined by business goals, not search activities** (A6-2) | Topic 6 |
| P10 | **Variations remain within the same workflow unless fundamentally different goals** (A6-3) | Topic 6 |
| P11 | **Workflow definitions should remain stable** — specific information types belong to business rules and domain discovery (A6-5) | Topic 6 |
| P12 | **Keep business language implementation-neutral** — e.g., "trust signals" not "provenance indicators" (A6-8) | Topic 6 |
| P13 | **Candidate concepts require recurrence + explicit approval to become canonical** (A6-10) | Topic 6 |
| P14 | **Canonical workflows emerge from the domain, not from individual personas** (A8-1) | Topic 8 |
| P15 | **Execution context ≠ business goal** — different personas may execute workflows differently without introducing new goals (A9-2) | Topic 9 |
| P16 | **New workflows require 4 conditions**: different goal, different trigger, different success outcome, would exist independently of existing workflows | Topic 9 |
| P17 | **Architecture flexibility principle** — secondary users influence flexibility without compromising day-one simplicity (A2-10) | Topic 2 |
| P18 | **Business evolution ≠ product roadmap** — stages are strategic, not chronological (A4-1) | Topic 4 |

---

## Exit Criteria

| Criterion | Status | Evidence |
|-----------|--------|----------|
| All primary users identified and described | ✅ | A1-1: 4 personas defined |
| All secondary users identified with trajectories | ✅ | A2-1: 6 groups defined with day-one roles and trajectories |
| Problem space fully dimensioned | ✅ | A3-1 through A3-5: 5 dimensions approved |
| Strategic evolution defined | ✅ | A4-1: 4 stages defined; A4-2: MVP scoped; A4-3: exclusions documented |
| Business capabilities identified | ✅ | A5-1: 10 MVP + A5-2: 5 Future |
| Capability relationships documented | ✅ | A5-3 through A5-8 |
| All primary personas evaluated for workflows | ✅ | A9-1: Guidance Counsellor evaluated; A8-3: Parent evaluated; A7-1: Undergraduate evaluated; A6-1: Secondary Student evaluated |
| Canonical workflows identified and consolidated | ✅ | A8-1: WF1–WF6 canonical; A8-2: WF7 persona-specific |
| No blocking open questions remain | ✅ | All 24 open questions are deferred to later discovery phases (Domain, Product, Strategy, etc.) |
| Discovery principles documented | ✅ | 18 principles established |
| Canonical documents are consistent and current | ✅ | 7 documents maintained incrementally |

**Conclusion:** Business Discovery is complete. All exit criteria are satisfied. Domain Discovery can begin.

---

## Canonical Document Inventory

| Document | Purpose |
|----------|---------|
| `01-business-overview.md` | Central business document: identity, users, problems, evolution, capabilities, workflows |
| `02-glossary.md` | Domain terminology + candidate business concepts |
| `03-approved-decisions.md` | All 40 approved decisions with rationale |
| `04-open-questions.md` | 24 open questions grouped by next discovery phase |
| `05-adrs.md` | Architecture Decision Records (empty — begins at architecture phase) |
| `06-business-workflows.md` | Detailed workflow definitions with personas, rules, concepts, and questions |
| `07-business-discovery-closure.md` | This closure report |
| `08-traceability-matrix.md` | Full traceability of 96 artifacts to approved decisions; 0 unsupported assumptions |
| `09-business-discovery-freeze.md` | Freeze principles, frozen inventory, and Change Proposal protocol |
| `10-domain-discovery-readiness.md` | Precondition checklist, inputs, boundaries, and readiness verdict |
