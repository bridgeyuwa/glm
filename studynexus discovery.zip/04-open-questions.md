# StudyNexus — Open Questions

**Business Discovery Status:** FROZEN (2026-08-07) — per 09-business-discovery-freeze.md

| ID | Topic | Question | Status | Next Discovery Phase |
|----|-------|----------|--------|---------------------|
| OQ1-1 | Primary Users | What is the priority ranking of the four primary personas based on business impact, usage frequency, and strategic value? | Active (deferred) | Business Strategy Discovery |
| OQ1-3 | Primary Users | Can users research foreign institutions on day one, or is the scope strictly Nigerian institutions? | Active | Product Discovery |
| OQ1-4 | Primary Users | Do the personas interact with the platform differently enough to require distinct interface patterns, or is the core interaction uniform across all four? | Active | Product Discovery |
| OQ2-3 | Secondary Users | When are institution management features expected? | Active (deferred) | Product Roadmap Discovery |
| OQ2-4 | Secondary Users | When are scholarship provider management features expected? | Active (deferred) | Product Roadmap Discovery |
| OQ2-5 | Data Acquisition | Do Government Education Agencies actively provide data to StudyNexus, or is information aggregated from public sources? | Active (deferred; default: public sources unless formal partnership) | Data Acquisition Discovery |
| OQ3-1 | Problem Space | Are Fragmentation, Trust, Discoverability, Comparison, and Accessibility the complete set of problem dimensions? | Active | Domain Discovery |
| OQ3-4 | Problem Space | What is the relative severity of the five problem dimensions for each primary persona? | Active (deferred) | User Journey Discovery |
| OQ4-1 | Evolution | Does the MVP require user accounts/identity? | Active (deferred) | Product Discovery |
| OQ4-2 | Evolution | What user feedback mechanisms exist for information quality? | Active (deferred) | Product Discovery |
| OQ4-3 | Evolution | What does "decision support" mean as a business capability? | Active (deferred) | Capability Discovery |
| OQ4-4 | Evolution | What is the business model/revenue model for each stage? | Active (deferred) | Business Strategy Discovery |
| OQ5-1 | Capabilities | Are these 10 capabilities the complete MVP set, or are there additional capabilities not yet identified? | Active | Domain Discovery |
| OQ6-1 | Workflows | What constitutes "sufficient" information for an evaluation or decision? | Active | Domain Discovery |
| OQ6-2 | Workflows | What are the standard comparison dimensions? | Active (deferred) | Domain Discovery / Product Discovery |
| OQ6-3 | Workflows | Does StudyNexus perform eligibility assessment for the user, present requirements for self-assessment, or both? | Active (deferred; per A6-7) | Product Discovery |
| OQ6-4 | Workflows | What trust signals should be presented to users? | Active (deferred; per A6-8) | Product Discovery |
| OQ6-5 | Workflows | Does StudyNexus provide decision support beyond presenting consolidated information? | Active (related to OQ4-3) | Capability Discovery |
| OQ6-6 | Workflows | What parameters guide structured exploration per persona? | Active (deferred) | Product Discovery |
| OQ6-7 | Workflows | What specific information types are required for evaluating different categories of educational opportunity? | Active (deferred) | Domain Discovery |
| OQ6-8 | Workflows | How do trust signals differ across Information Categories (Official, Verified, Historical, Community-Contributed)? | Active (deferred) | Product Discovery |
| OQ7-1 | Workflows | What specific information types are most critical for an undergraduate managing their current educational journey? | Active (deferred) | Domain Discovery |
| OQ7-2 | Workflows | Does WF7 (Understand Current Educational Journey) apply only to Undergraduate Students, or also to other enrolled students (e.g., postgraduate)? | Active | Domain Discovery |
| OQ7-3 | Workflows | Should the four candidate concepts (Comparison Dimension, Eligibility Status, Trust Signal, Educational Decision) be promoted to canonical now that they recur across all 4 primary personas? | Active — requires explicit approval per A6-10 | Anytime (non-blocking) |
