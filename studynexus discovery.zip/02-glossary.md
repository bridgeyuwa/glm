# StudyNexus — Glossary

| Term | Definition | Source |
|------|-----------|--------|
| StudyNexus | Comprehensive education knowledge platform for Nigeria, with a vision to become Africa's education infrastructure. | Topic 0 |
| Aggregate | Collect educational information from disparate sources into a unified system. | Topic 0 |
| Verify | Confirm the accuracy and authenticity of educational information. | Topic 0 |
| Organize | Structure educational information so it is navigable and comparable. | Topic 0 |
| Searchable | Users can find information through query-based discovery. | Topic 0 |
| Comparable | Users can evaluate options side-by-side on meaningful dimensions. | Topic 0 |
| Trustworthy | Information has been verified or sourced credibly enough for users to rely on it. | Topic 0 |
| Primary User | A user the platform must serve on day one to justify its existence. | Topic 1 |
| Secondary School Student and Graduate | A student currently in secondary school (e.g., SS3) or a recent graduate preparing to pursue tertiary education. | Topic 1 |
| Undergraduate Student | A student already enrolled in tertiary education. | Topic 1 |
| Parent or Guardian | A decision-maker helping a child navigate educational choices. | Topic 1 |
| Guidance Counsellor / Teacher | An educator helping students make informed educational decisions. | Topic 1 |
| JAMB | Joint Admissions and Matriculation Board — Nigeria's unified tertiary admission body. | Topic 1 |
| WAEC | West African Examinations Council. | Topic 1 |
| Cut-off Mark | Minimum score required for admission into a programme or institution. | Topic 1 |
| Programme | A specific course of study offered by an institution (e.g., "Computer Science" at University of Lagos). | Topic 1 |
| Secondary User | A user who benefits from the platform's data but is not required for the initial value proposition. | Topic 2 |
| Educational Institution | A university, polytechnic, college of education, Innovation Enterprise Institution (IEI), or other institution offering educational programmes. | Topic 2 |
| Scholarship Provider | A government agency, NGO, foundation, corporation, or educational organization that provides scholarships. | Topic 2 |
| Government Education Agency | An official body that regulates, examines, or coordinates education in Nigeria (e.g., JAMB, WAEC, NECO, NABTEB, NUC, NBTE, NCCE, state agencies). | Topic 2 |
| Strategic Partner | A secondary user who provides or publishes authoritative information rather than actively using the platform as a primary workflow. | Topic 2 |
| NECO | National Examinations Council. | Topic 2 |
| NABTEB | National Business and Technical Examinations Board. | Topic 2 |
| NUC | National Universities Commission. | Topic 2 |
| NBTE | National Board for Technical Education. | Topic 2 |
| NCCE | National Commission for Colleges of Education. | Topic 2 |
| Innovation Enterprise Institution (IEI) | A category of institution recognized within the Nigerian tertiary education system, distinct from universities, polytechnics, and colleges of education. | Topic 2 |
| Structured Exploration | The ability for users to discover relevant educational opportunities without already knowing their exact names or identifiers. Implementation determined during Product Design and Architecture. | Topic 3 |
| Information Category | A classification of information provenance: Official (from authoritative source), Verified (confirmed by StudyNexus), Historical (accurate as of a past date), Community-Contributed (user-submitted, unverified). These are business concepts; day-one support scope is a Product Roadmap decision. | Topic 3 |
| Alternative Admission Pathway | A route into tertiary education beyond the standard UTME route, including Direct Entry, IJMB, JUPEB, diploma pathways, and other recognized admission routes. | Topic 3 |
| Standardized Information | Educational information presented in a consistent structure and format that enables side-by-side comparison across institutions and programmes. | Topic 3 |
| Accessibility | A problem dimension distinct from Discoverability: information exists but is practically inaccessible due to format, connectivity, device, or usability barriers. | Topic 3 |
| IJMB | Interim Joint Matriculation Board — an alternative admission pathway programme in Nigeria. | Topic 3 |
| JUPEB | Joint Universities Preliminary Examinations Board — an alternative admission pathway programme in Nigeria. | Topic 3 |
| Direct Entry | Admission into tertiary education at an advanced level (typically 200-level) based on prior qualifications such as A-levels, IJMB, JUPEB, ND, or NCE. | Topic 3 |
| MVP | Minimum Viable Product — Stage 1 of StudyNexus evolution: Trusted Education Knowledge Base. | Topic 4 |
| Stage 1 | Trusted Education Knowledge Base — aggregate, organize, verify, present educational knowledge in searchable, comparable form. Strategic business stage, not a fixed implementation phase. | Topic 4 |
| Stage 2 | Personalized Education Companion — personalization, saved preferences, notifications, decision support built on the knowledge base. Strategic business stage, not a fixed implementation phase. | Topic 4 |
| Stage 3 | Education Ecosystem — verified organizations participate directly in maintaining and publishing information. Strategic business stage, not a fixed implementation phase. | Topic 4 |
| Stage 4 | Education Infrastructure — trusted educational data and services exposed through well-defined interfaces for third-party consumption. Strategic business stage, not a fixed implementation phase. | Topic 4 |
| Provenance | The origin and custody history of a piece of information — who created it, who modified it, and when. Critical for the Stage 3 transition. | Topic 4 |
| Business Capability | A description of what the business must be able to do, independent of software, implementation, or organizational structure. | Topic 5 |
| Core Capability | A business capability that directly delivers value to primary users and is required for the MVP. | Topic 5 |
| Supporting Capability | A business capability that enables or sustains core capabilities but is not directly user-facing. | Topic 5 |
| Future Capability | A business capability that is not required for the MVP but is expected to be needed in later stages. | Topic 5 |
| Capability Relationship | A relationship between capabilities indicating that one requires, benefits from, feeds, consumes, or supports another. Not a fixed execution order. | Topic 5 |
| Business Workflow | A description of how a user achieves a business goal by exercising one or more business capabilities. Defined by business goal, not by search activity. | Topic 6 |
| Canonical Workflow | A business workflow whose goal recurs independently across multiple primary personas. Defined by the domain, not by any individual persona. Currently: WF1–WF6. | Topic 8 |
| Persona-Specific Workflow | A business workflow that addresses a goal unique to a particular persona's relationship with the domain. Currently: WF7 (Undergraduate Student only). | Topic 8 |

## Candidate Business Concepts

These concepts were introduced during workflow discovery. They become canonical (promoted to the main glossary) only when they recur across multiple workflows or personas. Promoting a concept requires explicit approval.

| Term | Definition | Introduced In |
|------|-----------|---------------|
| Eligibility Status | The degree to which a user's qualifications match published admission requirements: meet, partially meet, or do not meet. | WF4 (Topic 6) |
| Comparison Dimension | A standardized attribute on which educational opportunities can be evaluated and compared (e.g., tuition, admission requirements, accreditation status). | WF3 (Topic 6) |
| Trust Signal | An implementation-neutral signal that helps users assess the reliability of information. May include provenance, verification status, publication dates, official sources, editorial review, or other mechanisms. | WF5 (Topic 6) |
| Educational Decision | A user's decision about whether and how to proceed with an educational opportunity. The outcome may be to pursue, defer, or reject the opportunity. StudyNexus supports informed decision-making but does not perform applications. | WF6 (Topic 6) |
| Current Educational Journey | The educational opportunity a user is already pursuing. Distinct from prospective opportunities — the user is managing an existing commitment, not evaluating a new one. | WF7 (Topic 7) |
