# StudyNexus — Business Overview

## Identity

StudyNexus is a comprehensive education knowledge platform that aggregates, verifies, organizes, and makes educational information across Nigeria searchable, comparable, and trustworthy.

## Vision

Become the education infrastructure for Africa.

## Core Interaction

Users search, discover, compare, and verify educational opportunities and information.

## Users

### Primary Users

StudyNexus serves four primary user personas on day one, all sharing the core need to discover, understand, compare, and verify educational information:

| Persona | Description |
|---------|-------------|
| **Secondary School Student and Graduate** | A student currently in secondary school (e.g., SS3) or a recent graduate preparing to pursue tertiary education who needs to discover institutions, programmes, admission requirements, cut-off marks, tuition, scholarships, and career pathways. |
| **Undergraduate Student** | A student already in tertiary education looking for scholarships, transfers, postgraduate opportunities, internships, or accurate information about their institution and programme. |
| **Parent or Guardian** | A decision-maker helping a child choose institutions, compare costs, evaluate quality, and understand admission requirements. |
| **Guidance Counsellor or Teacher** | An educator helping students make informed educational decisions using accurate and up-to-date information. |

**Current behavior without StudyNexus:** All personas manually piece together information from JAMB, WAEC, institution websites, scholarship sites, PDFs, blogs, social media, WhatsApp groups, and friends. The process is fragmented, inconsistent, and difficult to verify.

**StudyNexus replaces** this fragmented discovery with a single trusted source.

### Secondary Users

Secondary users benefit from the platform's data but are not required for the initial value proposition. Dedicated features for them may be introduced as the platform evolves.

| Persona | Day-One Role | Trajectory to Primary |
|---------|-------------|----------------------|
| **Educational Institutions** | Ensure accurate representation; increase visibility to prospective students; review programme, admission, accreditation, and contact information. | Potential future primary users if institution management/verification/profile features are introduced. Not guaranteed. |
| **Scholarship Providers** | Publish scholarship opportunities; maintain eligibility requirements and deadlines; reach qualified applicants. | Potential future primary users if direct scholarship creation/management is supported. Not guaranteed. |
| **Government Education Agencies** (JAMB, WAEC, NECO, NABTEB, NUC, NBTE, NCCE, state agencies) | Benefit from increased discoverability/accessibility of official information; platform links back to authoritative sources. | Strategic partners (data providers), not on a path to becoming primary users. |
| **Educational Researchers and Analysts** | Explore structured educational data; analyze trends; compare institutions and programmes; access historical information. | No planned promotion to primary. |
| **Employers** | Not in initial scope. | Future possibility if career-related capabilities are introduced. |
| **Developers** | Not in initial scope. | May become primary if platform evolves into infrastructure with public APIs (long-term vision). |

## Problem Space

### Fragmentation

Information is scattered across many independent sources (JAMB, institution websites, faculty/departmental pages, government agencies, scholarship sites, blogs, forums, YouTube, WhatsApp, social media), each covering only part of the picture. Sources are disconnected, structurally inconsistent, and vary in quality. Users spend significant time collecting, organizing, and reconciling information before they can decide.

**Core pain:** No trusted source presents a complete, connected view.

### Trust

Users cannot determine whether information is accurate, current, or authoritative. Official websites are outdated or incomplete. Third-party sites copy without citation. Figures contradict across sources. Information changes without indication. No way to distinguish official, verified, historical, and community-contributed information.

**Core pain:** Inability to confidently assess reliability.

### Discoverability

Users are unaware of opportunities that match their goals — institutions, programmes, scholarships, alternative admission pathways, vocational/technical/specialized options, opportunities outside their geographic region. Information is available only if the user already knows exactly what to search for.

**Core pain:** Information requires known-target search. Users should be able to discover educational opportunities through structured exploration as well as direct search.

### Comparison

Information lacks consistent structure across institutions. Tuition is presented differently. Terminology varies for similar programmes. Admission requirements use inconsistent formats. Accreditation is non-uniform. Important characteristics are omitted entirely by some sources. Users resort to manual notes and spreadsheets and still cannot compare objectively.

**Core pain:** Absence of standardized, comparable information across educational opportunities.

### Accessibility

Users may know exactly what they are looking for but still struggle to access it. Official websites are slow, unavailable, or difficult to navigate. Information is buried inside PDFs or scanned documents. Sites are not optimized for mobile devices. High data usage and poor connectivity make access difficult. Information is not presented in a consistent, user-friendly format.

**Core pain:** Educational information exists but is practically inaccessible to many users due to format, connectivity, device, or usability barriers.

## Evolution

StudyNexus evolves strategically through four stages, each building on the previous. These stages describe **business evolution**, not a fixed chronological product roadmap. Some capabilities may arrive earlier or later depending on business priorities.

| Stage | Name | Core Capability |
|-------|------|----------------|
| **1** | **Trusted Education Knowledge Base** (MVP) | Aggregate, organize, verify, and present educational knowledge in searchable, comparable form. Help users make informed decisions. |
| **2** | **Personalized Education Companion** | Build on the knowledge base with personalization, saved preferences, notifications, and decision support. Knowledge remains the foundation. |
| **3** | **Education Ecosystem** | Verified organizations (institutions, scholarship providers) participate directly in maintaining and publishing information. StudyNexus becomes the central platform connecting stakeholders, maintaining editorial standards and verification. |
| **4** | **Education Infrastructure** | Provide trusted educational data and services through well-defined interfaces for third-party consumption. Foundational infrastructure while continuing to serve end users directly. |

### MVP Scope

The MVP (Stage 1) solves the five approved business problems: Fragmentation, Trust, Discoverability, Comparison, and Accessibility. It enables users to discover, understand, compare, and verify educational opportunities using trusted, structured information.

**Explicitly excluded from MVP:** Institution self-service, scholarship provider self-service, public APIs, developer platform, multi-country support, marketplace/transactional features.

### Geographic Expansion

Beyond Nigeria only after the Nigerian model has matured and proven successful. Anticipated in the data model but not optimized for prematurely.

### Critical Business Concern

The most concerning transition is Stage 1 → Stage 3 (internally curated information → externally contributed information). This introduces questions around verification, ownership, provenance, moderation, and trust. The business should support information originating from different authorities and contributors while preserving trust and provenance.

## Business Capabilities

### Core MVP Capabilities

| # | Capability | Purpose |
|---|-----------|---------|
| 1 | Acquire Educational Information | Obtain information from authoritative and publicly available sources. |
| 2 | Organize Educational Knowledge | Transform acquired information into consistent, structured, understandable knowledge. |
| 3 | Verify Educational Information | Evaluate reliability, authority, and currency of information. |
| 4 | Maintain Educational Knowledge | Keep information accurate, current, and historically traceable as it changes. |
| 5 | Discover Educational Opportunities | Enable users to find relevant opportunities without knowing exactly what they're looking for. |
| 6 | Search Educational Knowledge | Allow users to efficiently locate known information. |
| 7 | Compare Educational Opportunities | Enable objective comparison using standardized information. |
| 8 | Present Educational Knowledge | Communicate information clearly, understandably, and accessibly, including its provenance and references to authoritative sources where appropriate. |

### Supporting MVP Capabilities

| # | Capability | Purpose |
|---|-----------|---------|
| 9 | Preserve Information Provenance | Maintain traceability between information and its supporting sources. |
| 10 | Manage Information Quality | Continuously improve completeness, consistency, and quality. |

### Future Capabilities

| # | Capability | Stage |
|---|-----------|-------|
| 11 | Personalize educational guidance | Stage 2 |
| 12 | Support verified organization participation | Stage 3 |
| 13 | Notify users of important changes | Stage 2 |
| 14 | Provide trusted education data to third parties | Stage 4 |
| 15 | Enable ecosystem collaboration | Stage 3/4 |

### Capability Relationships

Capabilities describe what the business is able to do. These relationships indicate which capabilities require or benefit from others — they are **not** a fixed business process or execution order. Workflows that compose these capabilities will be discovered later.

| Capability | Relationship | Related Capability |
|-----------|-------------|-------------------|
| Compare Educational Opportunities | depends on | Organized Educational Knowledge |
| Search Educational Knowledge | depends on | Organized Educational Knowledge |
| Discover Educational Opportunities | depends on | Organized Educational Knowledge |
| Present Educational Knowledge | consumes outputs from | Search, Discover, Compare |
| Verify Educational Information | improves | Information Quality (via Manage Information Quality) |
| Preserve Information Provenance | supports | Verify, Maintain, Present |
| Acquire Educational Information | feeds | Organize Educational Knowledge |

## Business Workflows

### Canonical Workflows (WF1–WF6)

The 6 canonical workflows represent the recurring business goals exercised by all primary personas. Their emergence across multiple personas indicates they are properties of the domain rather than of individual users.

| # | Workflow | Business Goal |
|---|----------|--------------|
| 1 | Explore Educational Opportunities | Understand what educational opportunities exist based on interests, qualifications, or aspirations. |
| 2 | Evaluate Educational Opportunities | Gather sufficient information about an educational opportunity to make an informed decision. |
| 3 | Compare Educational Opportunities | Objectively compare multiple opportunities using standardized information before making a decision. |
| 4 | Assess Eligibility | Determine whether the user's qualifications satisfy the published admission requirements. |
| 5 | Assess Information Reliability | Determine whether educational information is trustworthy, current, and supported by authoritative sources. |
| 6 | Make an Educational Decision | Reach a decision about whether and how to proceed with an educational opportunity. |

**Shared by:** Secondary School Student and Graduate, Undergraduate Student, Parent or Guardian, Guidance Counsellor or Teacher.

### Persona-Specific Workflows

| # | Workflow | Persona | Business Goal |
|---|----------|---------|--------------|
| 7 | Understand Current Educational Journey | Undergraduate Student | Understand information relevant to the educational opportunity the user is already pursuing in order to make informed decisions throughout that journey. |

Workflows are defined by business goals, not by search activities. Variations within a workflow remain within the same workflow unless they introduce fundamentally different business goals. Workflows may be executed in any order; there is no mandatory sequence. Detailed workflow documentation is in `06-business-workflows.md`.
